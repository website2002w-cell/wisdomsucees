import React, { useState } from 'react';
import {
  ShoppingBag,
  CheckCircle2,
  Clock,
  Shirt,
  Search,
  Filter,
  Package,
  Truck,
  CreditCard,
  Ruler,
  AlertCircle,
  Plus,
  Minus,
  Trash2,
  ChevronRight,
  PhoneCall,
  Check,
  X,
  Sparkles,
  ShieldCheck,
  Building2,
  Calendar,
} from 'lucide-react';
import { StudentProfile } from '../types';

interface SchoolStoreProps {
  student?: StudentProfile | null;
}

interface UniformItem {
  id: string;
  name: string;
  category: 'Regular Uniform' | 'Sports / House Day' | 'Footwear & Accessories' | 'Winter & Sweaters' | 'Stationery & Bags';
  gender: 'Boys' | 'Girls' | 'Unisex';
  price: number;
  image: string;
  description: string;
  sizes: string[];
  inStock: boolean;
  material: string;
}

interface CartItem {
  item: UniformItem;
  selectedSize: string;
  quantity: number;
  customEmbroiderName?: string;
}

interface StoreOrder {
  orderId: string;
  date: string;
  studentName: string;
  grade: string;
  parentPhone: string;
  items: { name: string; size: string; qty: number; price: number }[];
  totalAmount: number;
  deliveryMethod: 'Classroom Delivery' | 'School Store Pickup';
  paymentStatus: 'Paid via GPay/UPI' | 'Pay at Store Counter';
  currentStep: number; // 1 to 5
  estimatedPickupDate: string;
}

export const SchoolStore: React.FC<SchoolStoreProps> = ({ student }) => {
  // Uniform Catalog Data
  const [catalog] = useState<UniformItem[]>([
    {
      id: 'unf-01',
      name: 'Wisdom Regular Uniform Set (Boys: Shirt + Shorts/Trousers)',
      category: 'Regular Uniform',
      gender: 'Boys',
      price: 650,
      image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=500&q=80',
      description: 'Official navy blue and white check shirt with dark navy shorts/trousers and school crest emblem.',
      sizes: ['22"', '24"', '26"', '28"', '30"', '32"'],
      inStock: true,
      material: '65% Premium Cotton, 35% Polyester Easy-Iron',
    },
    {
      id: 'unf-02',
      name: 'Wisdom Regular Uniform Set (Girls: Pinafore / Shirt + Skirt)',
      category: 'Regular Uniform',
      gender: 'Girls',
      price: 680,
      image: 'https://images.unsplash.com/photo-1576995853123-5a10305d93c0?auto=format&fit=crop&w=500&q=80',
      description: 'Navy blue pinafore/skirt with checked blouse and stitched school emblem badge.',
      sizes: ['22"', '24"', '26"', '28"', '30"', '32"'],
      inStock: true,
      material: 'Wrinkle-Resistant Cotton Blend',
    },
    {
      id: 'unf-03',
      name: 'House Day Sports T-Shirt & Track Pants (Red / Blue / Green / Yellow)',
      category: 'Sports / House Day',
      gender: 'Unisex',
      price: 520,
      image: 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=500&q=80',
      description: 'Breathable sports polo with house emblem (Kalam / Tagore / Raman / Sarabhai Houses).',
      sizes: ['S (24")', 'M (28")', 'L (32")', 'XL (36")'],
      inStock: true,
      material: 'Dri-FIT Breathable Mesh Fabric',
    },
    {
      id: 'unf-04',
      name: 'Official School Leather Shoes (Black Velcro / Laces)',
      category: 'Footwear & Accessories',
      gender: 'Unisex',
      price: 450,
      image: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=500&q=80',
      description: 'Durable, slip-resistant black leather school shoes with reinforced toe box.',
      sizes: ['Size 9 (Child)', 'Size 10', 'Size 11', 'Size 12', 'Size 1', 'Size 2', 'Size 3'],
      inStock: true,
      material: 'Synthetic Leather with Orthopedic Insole',
    },
    {
      id: 'unf-05',
      name: 'Wisdom Crest Belt + Navy Blue Cotton Socks (Set of 2 Pairs)',
      category: 'Footwear & Accessories',
      gender: 'Unisex',
      price: 180,
      image: 'https://images.unsplash.com/photo-1608256246200-53e635b5b65f?auto=format&fit=crop&w=500&q=80',
      description: 'Brass buckle woven belt with school initials and two pairs of elasticated cotton socks.',
      sizes: ['Small (LKG-UKG)', 'Medium (Class 1-3)', 'Large (Class 4-5)'],
      inStock: true,
      material: '100% Elasticated Cotton Socks & Canvas Belt',
    },
    {
      id: 'unf-06',
      name: 'Navy Blue Winter V-Neck Cardigan Sweater',
      category: 'Winter & Sweaters',
      gender: 'Unisex',
      price: 580,
      image: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=500&q=80',
      description: 'Warm knitted dark navy cardigan with golden embroidered school badge.',
      sizes: ['24"', '28"', '32"', '36"'],
      inStock: true,
      material: 'Soft Non-Itch Wool Blend',
    },
    {
      id: 'unf-07',
      name: 'Ergonomic Wisdom Primary School Bag (Waterproof)',
      category: 'Stationery & Bags',
      gender: 'Unisex',
      price: 750,
      image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=500&q=80',
      description: 'Heavy-duty multi-compartment backpack with padded shoulder straps and side bottle holder.',
      sizes: ['Standard Primary Size'],
      inStock: true,
      material: 'Waterproof Nylon Denier',
    },
  ]);

  // Filters & State
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [showSizeGuide, setShowSizeGuide] = useState(false);

  // Active Orders State (pre-populated with mock active orders for demo)
  const [orders, setOrders] = useState<StoreOrder[]>([
    {
      orderId: 'ORD-2026-8842',
      date: '26 Jul 2026',
      studentName: student?.name || 'S. Kavin Vijay',
      grade: student?.grade || 'Class 3-A',
      parentPhone: student?.parentPhone || '+91 98402 38192',
      items: [
        { name: 'Wisdom Regular Uniform Set (Boys)', size: '26"', qty: 2, price: 650 },
        { name: 'Crest Belt + Socks Set', size: 'Medium', qty: 1, price: 180 },
      ],
      totalAmount: 1480,
      deliveryMethod: 'Classroom Delivery',
      paymentStatus: 'Paid via GPay/UPI',
      currentStep: 3, // Tailoring & Packaging at Store Desk
      estimatedPickupDate: '28 Jul 2026 (Delivered to Class Teacher)',
    },
  ]);

  // Selected Order for Tracking Inspector
  const [trackingOrderId, setTrackingOrderId] = useState<string>('ORD-2026-8842');
  const [activeTab, setActiveTab] = useState<'shop' | 'tracker'>('shop');

  // Checkout Form Modal State
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [formStudentName, setFormStudentName] = useState(student?.name || '');
  const [formGrade, setFormGrade] = useState(student?.grade || 'Class 3');
  const [formParentPhone, setFormParentPhone] = useState(student?.parentPhone || '');
  const [formDelivery, setFormDelivery] = useState<'Classroom Delivery' | 'School Store Pickup'>('Classroom Delivery');
  const [formPayment, setFormPayment] = useState<'Paid via GPay/UPI' | 'Pay at Store Counter'>('Paid via GPay/UPI');
  const [orderConfirmed, setOrderConfirmed] = useState<StoreOrder | null>(null);

  // Cart operations
  const handleAddToCart = (item: UniformItem, size: string) => {
    const existingIndex = cart.findIndex(
      (c) => c.item.id === item.id && c.selectedSize === size
    );
    if (existingIndex > -1) {
      const updated = [...cart];
      updated[existingIndex].quantity += 1;
      setCart(updated);
    } else {
      setCart([...cart, { item, selectedSize: size, quantity: 1 }]);
    }
  };

  const handleUpdateQty = (index: number, delta: number) => {
    const updated = [...cart];
    updated[index].quantity += delta;
    if (updated[index].quantity <= 0) {
      updated.splice(index, 1);
    }
    setCart(updated);
  };

  const cartTotal = cart.reduce((acc, c) => acc + c.item.price * c.quantity, 0);

  // Submit Order
  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const newOrderId = `ORD-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: StoreOrder = {
      orderId: newOrderId,
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      studentName: formStudentName || 'Student Name',
      grade: formGrade,
      parentPhone: formParentPhone,
      items: cart.map((c) => ({
        name: c.item.name,
        size: c.selectedSize,
        qty: c.quantity,
        price: c.item.price,
      })),
      totalAmount: cartTotal,
      deliveryMethod: formDelivery,
      paymentStatus: formPayment,
      currentStep: 1, // Order Placed
      estimatedPickupDate: 'Within 2 Working Days',
    };

    setOrders([newOrder, ...orders]);
    setOrderConfirmed(newOrder);
    setTrackingOrderId(newOrderId);
    setCart([]);
    setShowCheckoutModal(false);
  };

  const categories = ['All', 'Regular Uniform', 'Sports / House Day', 'Footwear & Accessories', 'Winter & Sweaters', 'Stationery & Bags'];

  const filteredCatalog = catalog.filter((item) => {
    const matchesCat = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = (item?.name || '').toLowerCase().includes(searchQuery.toLowerCase()) || (item?.description || '').toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const selectedTrackingOrder = orders.find((o) => o.orderId === trackingOrderId) || orders[0];

  const fulfillmentSteps = [
    { step: 1, title: 'Order Received', desc: 'Payment verified & order recorded at Store Office' },
    { step: 2, title: 'Size & Stock Check', desc: 'Items picked from inventory stack' },
    { step: 3, title: 'Tailoring & Embroidery', desc: 'Custom crest & size fitting check' },
    { step: 4, title: 'Packed & Dispatched', desc: 'Bundled with student registration tag' },
    { step: 5, title: 'Fulfilled', desc: 'Handed over to classroom teacher / parent' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl shrink-0">
              <ShoppingBag className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-blue-950">
                  Wisdom Online Uniform & School Store
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-300">
                  Academic Session 2026-27
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Official stitched uniforms, sports kit, shoes, and accessories with home/classroom delivery.
              </p>
            </div>
          </div>

          {/* Navigation Sub-Tabs */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('shop')}
              className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 ${
                activeTab === 'shop'
                  ? 'bg-blue-950 text-amber-400 shadow'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <Shirt className="w-4 h-4 text-amber-400" />
              <span>Browse Catalog ({catalog.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('tracker')}
              className={`px-4 py-2.5 rounded-xl text-xs font-black transition flex items-center gap-2 ${
                activeTab === 'tracker'
                  ? 'bg-blue-950 text-amber-400 shadow'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              <Package className="w-4 h-4 text-amber-400" />
              <span>Order Fulfillment Tracker ({orders.length})</span>
            </button>

            <button
              onClick={() => setShowSizeGuide(true)}
              className="px-3 py-2.5 rounded-xl bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold transition flex items-center gap-1.5"
            >
              <Ruler className="w-4 h-4 text-amber-800" />
              <span className="hidden sm:inline">Size Chart</span>
            </button>
          </div>
        </div>

        {/* Store Manager Contact Quick Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-200 text-slate-700 font-medium">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-blue-900" />
            <span>Store Counter Location: <strong>Wisdom Campus Ground Floor (Admin Block)</strong></span>
          </div>
          <div className="flex items-center gap-3">
            <span>Hours: Mon-Sat (09:00 AM - 04:30 PM)</span>
            <span>In-Charge: <strong>Mrs. S. Kanthimathi (+91 94421 82901)</strong></span>
          </div>
        </div>
      </div>

      {/* SHOP CATALOG VIEW */}
      {activeTab === 'shop' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Catalog Column */}
          <div className="lg:col-span-8 space-y-6">
            {/* Search & Category Filter Pills */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-4">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search uniform items, shoes, cardigan, sports kit..."
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                      selectedCategory === cat
                        ? 'bg-blue-900 text-white shadow'
                        : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Catalog Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {filteredCatalog.map((item) => (
                <UniformCard
                  key={item.id}
                  item={item}
                  onAddToCart={handleAddToCart}
                />
              ))}
            </div>
          </div>

          {/* Right Sidebar: Cart & Quick Order Box */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5 sticky top-24">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-extrabold text-base text-blue-950 flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-amber-500" />
                  <span>Uniform Cart ({cart.reduce((a, b) => a + b.quantity, 0)})</span>
                </h3>
                {cart.length > 0 && (
                  <button
                    onClick={() => setCart([])}
                    className="text-[11px] font-bold text-red-600 hover:underline flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Clear
                  </button>
                )}
              </div>

              {cart.length === 0 ? (
                <div className="text-center py-8 space-y-3">
                  <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                    <Shirt className="w-8 h-8" />
                  </div>
                  <p className="text-xs font-bold text-slate-600">Your shopping cart is empty</p>
                  <p className="text-[11px] text-slate-400">
                    Select a uniform item and size to add to your order.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-3 max-h-72 overflow-y-auto pr-1 divide-y divide-slate-100">
                    {cart.map((c, idx) => (
                      <div key={idx} className="pt-3 first:pt-0 flex items-center justify-between gap-3 text-xs">
                        <div className="space-y-0.5">
                          <h5 className="font-bold text-slate-900 line-clamp-1">{c.item.name}</h5>
                          <p className="text-[10px] text-slate-500 font-medium">
                            Size: <strong className="text-blue-950">{c.selectedSize}</strong> • ₹{c.item.price}
                          </p>
                        </div>

                        <div className="flex items-center gap-2 shrink-0 bg-slate-100 p-1 rounded-xl">
                          <button
                            onClick={() => handleUpdateQty(idx, -1)}
                            className="p-1 hover:bg-slate-200 rounded-lg transition"
                          >
                            <Minus className="w-3 h-3 text-slate-700" />
                          </button>
                          <span className="font-extrabold text-xs text-slate-900 w-4 text-center">
                            {c.quantity}
                          </span>
                          <button
                            onClick={() => handleUpdateQty(idx, 1)}
                            className="p-1 hover:bg-slate-200 rounded-lg transition"
                          >
                            <Plus className="w-3 h-3 text-slate-700" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Pricing Breakdown */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                    <div className="flex justify-between text-slate-600">
                      <span>Items Subtotal:</span>
                      <span className="font-bold">₹{cartTotal}</span>
                    </div>
                    <div className="flex justify-between text-slate-600">
                      <span>Classroom Delivery / Fitting:</span>
                      <span className="font-bold text-emerald-700">FREE</span>
                    </div>
                    <div className="flex justify-between font-black text-sm text-blue-950 border-t border-slate-200 pt-2">
                      <span>Total Payable:</span>
                      <span className="text-amber-600">₹{cartTotal}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowCheckoutModal(true)}
                    className="w-full py-3 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs transition shadow flex items-center justify-center gap-2"
                  >
                    <CreditCard className="w-4 h-4 text-amber-400" />
                    <span>Proceed to Uniform Order Checkout</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ORDER FULFILLMENT TRACKER VIEW */}
      {activeTab === 'tracker' && (
        <div className="space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h3 className="font-extrabold text-base text-blue-950 flex items-center gap-2">
                  <Package className="w-5 h-5 text-blue-900" />
                  <span>Real-Time Uniform Order Fulfillment Status</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Track stitching, sizing, packaging, and classroom dispatch for student orders.
                </p>
              </div>

              {/* Order selector dropdown */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-600">Select Order:</span>
                <select
                  value={trackingOrderId}
                  onChange={(e) => setTrackingOrderId(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-extrabold text-blue-950 focus:outline-none"
                >
                  {orders.map((o) => (
                    <option key={o.orderId} value={o.orderId}>
                      {o.orderId} - {o.studentName} (₹{o.totalAmount})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {selectedTrackingOrder && (
              <div className="space-y-6">
                {/* Order Meta Header */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200 font-medium">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Order Number</span>
                    <span className="font-mono font-black text-blue-950">{selectedTrackingOrder.orderId}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Student Name</span>
                    <span className="font-bold text-slate-900">{selectedTrackingOrder.studentName} ({selectedTrackingOrder.grade})</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Delivery Mode</span>
                    <span className="font-bold text-emerald-700">{selectedTrackingOrder.deliveryMethod}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase font-bold block">Payment Status</span>
                    <span className="font-bold text-blue-900">{selectedTrackingOrder.paymentStatus}</span>
                  </div>
                </div>

                {/* 5-STEP FULFILLMENT TIMELINE */}
                <div className="space-y-4">
                  <h4 className="font-extrabold text-xs uppercase text-slate-500 tracking-wider">
                    Fulfillment Workflow Stage
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
                    {fulfillmentSteps.map((s) => {
                      const isComplete = selectedTrackingOrder.currentStep > s.step;
                      const isCurrent = selectedTrackingOrder.currentStep === s.step;

                      return (
                        <div
                          key={s.step}
                          className={`p-4 rounded-2xl border transition text-xs space-y-2 ${
                            isCurrent
                              ? 'bg-amber-50 border-amber-400 shadow-sm ring-2 ring-amber-400/50'
                              : isComplete
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                              : 'bg-slate-50 border-slate-200 opacity-60'
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <span className={`w-6 h-6 rounded-full font-black text-[11px] flex items-center justify-center ${
                              isComplete
                                ? 'bg-emerald-600 text-white'
                                : isCurrent
                                ? 'bg-amber-400 text-blue-950'
                                : 'bg-slate-300 text-slate-700'
                            }`}>
                              {isComplete ? <Check className="w-3.5 h-3.5" /> : s.step}
                            </span>

                            <span className="text-[9px] font-black uppercase tracking-wider">
                              {isComplete ? 'Done' : isCurrent ? 'In Progress' : 'Pending'}
                            </span>
                          </div>

                          <h5 className="font-extrabold text-slate-900 leading-tight">{s.title}</h5>
                          <p className="text-[10px] text-slate-500 leading-normal">{s.desc}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Ordered Items Summary Table */}
                <div className="space-y-2 pt-2">
                  <h4 className="font-extrabold text-xs uppercase text-slate-500 tracking-wider">
                    Items Included in this Order
                  </h4>

                  <div className="border border-slate-200 rounded-2xl overflow-hidden text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-slate-100 font-bold text-slate-700 uppercase text-[10px]">
                        <tr>
                          <th className="py-2.5 px-3">Item Description</th>
                          <th className="py-2.5 px-3 text-center">Selected Size</th>
                          <th className="py-2.5 px-3 text-center">Quantity</th>
                          <th className="py-2.5 px-3 text-right">Price</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                        {selectedTrackingOrder?.items?.map((it, idx) => (
                          <tr key={idx}>
                            <td className="py-2.5 px-3 font-bold text-slate-900">{it.name}</td>
                            <td className="py-2.5 px-3 text-center font-bold text-blue-900">{it.size}</td>
                            <td className="py-2.5 px-3 text-center">{it.qty}</td>
                            <td className="py-2.5 px-3 text-right font-bold">₹{it.price * it.qty}</td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot className="bg-slate-50 font-black text-blue-950 border-t border-slate-200">
                        <tr>
                          <td colSpan={3} className="py-2.5 px-3 text-right">Total Order Value:</td>
                          <td className="py-2.5 px-3 text-right text-amber-600 font-black text-sm">
                            ₹{selectedTrackingOrder?.totalAmount || 0}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CHECKOUT ORDER FORM MODAL */}
      {showCheckoutModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setShowCheckoutModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl">
                <ShoppingBag className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Uniform Order Checkout</h4>
                <p className="text-xs text-slate-500">Order total: ₹{cartTotal} ({cart.length} items)</p>
              </div>
            </div>

            <form onSubmit={handlePlaceOrder} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Student Full Name *</label>
                <input
                  type="text"
                  required
                  value={formStudentName}
                  onChange={(e) => setFormStudentName(e.target.value)}
                  placeholder="e.g. S. Kavin Vijay"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Grade / Section *</label>
                  <input
                    type="text"
                    required
                    value={formGrade}
                    onChange={(e) => setFormGrade(e.target.value)}
                    placeholder="e.g. Class 3-A"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Parent Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={formParentPhone}
                    onChange={(e) => setFormParentPhone(e.target.value)}
                    placeholder="e.g. +91 98402 38192"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Delivery Preference</label>
                <select
                  value={formDelivery}
                  onChange={(e: any) => setFormDelivery(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                >
                  <option value="Classroom Delivery">Deliver directly to Child's Classroom Teacher</option>
                  <option value="School Store Pickup">Parent Pickup at School Store Counter</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Payment Mode</label>
                <select
                  value={formPayment}
                  onChange={(e: any) => setFormPayment(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                >
                  <option value="Paid via GPay/UPI">Online Payment via GPay / PhonePe / UPI (Instant)</option>
                  <option value="Pay at Store Counter">Pay Cash / Card at Store Counter</option>
                </select>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 font-medium">
                ⚡ Orders placed before 01:00 PM are fulfilled within 24 hours. Uniform exchanges for size adjustments are allowed within 7 days.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCheckoutModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black transition shadow flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 text-amber-400" />
                  <span>Confirm Uniform Order (₹{cartTotal})</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRMED ORDER RECEIPT POPUP */}
      {orderConfirmed && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl relative border-2 border-emerald-500 animate-scaleUp text-center">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h3 className="font-extrabold text-lg text-blue-950">Uniform Order Confirmed!</h3>
              <p className="text-xs text-slate-500">Order ID: <strong className="font-mono text-blue-900">{orderConfirmed.orderId}</strong></p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs space-y-2">
              <p className="text-slate-700">Student: <strong>{orderConfirmed.studentName} ({orderConfirmed.grade})</strong></p>
              <p className="text-slate-700">Total Paid: <strong className="text-emerald-700 font-black">₹{orderConfirmed.totalAmount}</strong></p>
              <p className="text-slate-700">Delivery Mode: <strong>{orderConfirmed.deliveryMethod}</strong></p>
            </div>

            <button
              onClick={() => {
                setOrderConfirmed(null);
                setActiveTab('tracker');
              }}
              className="w-full py-3 rounded-xl bg-blue-950 text-amber-400 font-extrabold text-xs transition shadow"
            >
              Track Order Fulfillment Status
            </button>
          </div>
        </div>
      )}

      {/* SIZE CHART MODAL */}
      {showSizeGuide && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setShowSizeGuide(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl">
                <Ruler className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Student Uniform Size Guide</h4>
                <p className="text-xs text-slate-500">Standard chest & length measurements (Inches)</p>
              </div>
            </div>

            <div className="overflow-x-auto text-xs">
              <table className="w-full text-left border border-slate-200 rounded-xl">
                <thead className="bg-blue-950 text-amber-300 font-bold uppercase text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Class / Age</th>
                    <th className="py-2.5 px-3 text-center">Shirt Chest Size</th>
                    <th className="py-2.5 px-3 text-center">Shorts / Skirt Waist</th>
                    <th className="py-2.5 px-3 text-center">Shoe Size</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                  <tr>
                    <td className="py-2 px-3 font-bold">LKG - UKG (3-5 Yrs)</td>
                    <td className="py-2 px-3 text-center font-mono">22"</td>
                    <td className="py-2 px-3 text-center font-mono">20" - 22"</td>
                    <td className="py-2 px-3 text-center">9 - 10 Child</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-bold">Class 1 - 2 (5-7 Yrs)</td>
                    <td className="py-2 px-3 text-center font-mono">24" - 26"</td>
                    <td className="py-2 px-3 text-center font-mono">22" - 24"</td>
                    <td className="py-2 px-3 text-center">11 - 13 Child</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-bold">Class 3 - 5 (7-10 Yrs)</td>
                    <td className="py-2 px-3 text-center font-mono">28" - 32"</td>
                    <td className="py-2 px-3 text-center font-mono">26" - 30"</td>
                    <td className="py-2 px-3 text-center">1 - 3 Youth</td>
                  </tr>
                </tbody>
              </table>
            </div>

            <button
              onClick={() => setShowSizeGuide(false)}
              className="w-full py-2.5 rounded-xl bg-slate-100 text-slate-800 font-extrabold text-xs hover:bg-slate-200 transition"
            >
              Close Size Guide
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

// Subcomponent: Uniform Item Card
interface UniformCardProps {
  item: UniformItem;
  onAddToCart: (item: UniformItem, size: string) => void;
}

const UniformCard: React.FC<UniformCardProps> = ({ item, onAddToCart }) => {
  const [selectedSize, setSelectedSize] = useState(item.sizes[0] || 'Standard');

  return (
    <div className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between">
      <div className="relative h-48 bg-slate-900 overflow-hidden group">
        <img
          src={item.image}
          alt={item.name}
          className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-90"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>

        <div className="absolute top-3 left-3 flex gap-1.5">
          <span className="bg-blue-950/90 text-amber-300 font-black text-[9px] px-2.5 py-1 rounded-full border border-blue-800 backdrop-blur-xs">
            {item.gender}
          </span>
          <span className="bg-slate-900/80 text-slate-200 font-bold text-[9px] px-2 py-1 rounded-full border border-slate-700 backdrop-blur-xs">
            {item.category}
          </span>
        </div>

        <div className="absolute bottom-3 left-3 right-3 text-white">
          <h4 className="font-extrabold text-sm leading-snug line-clamp-1">{item.name}</h4>
          <span className="text-amber-400 font-black text-sm">₹{item.price}</span>
        </div>
      </div>

      <div className="p-5 space-y-4 flex-1 flex flex-col justify-between text-xs">
        <div className="space-y-2">
          <p className="text-slate-600 line-clamp-2 leading-relaxed text-[11px]">{item.description}</p>
          <p className="text-[10px] text-slate-400 font-medium">Material: {item.material}</p>
        </div>

        <div className="space-y-3 pt-3 border-t border-slate-100">
          <div className="space-y-1">
            <span className="text-[10px] font-bold text-slate-500 uppercase block">Select Size:</span>
            <div className="flex flex-wrap gap-1.5">
              {item.sizes.map((sz) => (
                <button
                  key={sz}
                  type="button"
                  onClick={() => setSelectedSize(sz)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-black transition ${
                    selectedSize === sz
                      ? 'bg-blue-950 text-amber-400 border border-amber-400'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  {sz}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => onAddToCart(item, selectedSize)}
            className="w-full py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs transition shadow flex items-center justify-center gap-2"
          >
            <ShoppingBag className="w-4 h-4 text-amber-400" />
            <span>Add to Cart • ₹{item.price}</span>
          </button>
        </div>
      </div>
    </div>
  );
};

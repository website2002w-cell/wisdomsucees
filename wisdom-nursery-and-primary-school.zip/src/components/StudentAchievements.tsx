import React, { useState } from 'react';
import {
  Trophy,
  Award,
  Medal,
  Star,
  Sparkles,
  CheckCircle2,
  Share2,
  Download,
  Filter,
  Search,
  BookOpen,
  Zap,
  Target,
  Flame,
  UserCheck,
  ShieldAlert,
  Printer,
  ChevronRight,
  X,
  Crown,
} from 'lucide-react';
import { StudentProfile } from '../types';

interface StudentAchievementsProps {
  student?: StudentProfile | null;
}

export interface BadgeItem {
  id: string;
  title: string;
  category: 'Academic' | 'Sports & Athletics' | 'Arts & Culture' | 'Leadership & Conduct' | 'STEM & Innovation';
  tier: 'Diamond' | 'Gold' | 'Silver' | 'Bronze';
  dateAwarded: string;
  awardedBy: string;
  points: number;
  icon: string;
  description: string;
  criteria: string;
  certificateRef: string;
}

export const StudentAchievements: React.FC<StudentAchievementsProps> = ({ student }) => {
  const [badges] = useState<BadgeItem[]>([
    {
      id: 'bdg-01',
      title: 'Mathematics Olympiad Gold Scholar',
      category: 'Academic',
      tier: 'Gold',
      dateAwarded: '15 Jul 2026',
      awardedBy: 'Wisdom Math Department & Regional Olympiad Board',
      points: 250,
      icon: '📐',
      description: 'Awarded for securing 1st Rank in District Mathematics Talent Exam with a score of 98/100.',
      criteria: 'Top 1% score in Class 3 Mathematics Olympiad.',
      certificateRef: 'CERT-2026-MATH-088',
    },
    {
      id: 'bdg-02',
      title: '100% Perfect Attendance Star',
      category: 'Leadership & Conduct',
      tier: 'Diamond',
      dateAwarded: '30 Jun 2026',
      awardedBy: 'Principal Dr. V. Swaminathan',
      points: 300,
      icon: '⭐',
      description: 'Maintained 100% unblemished attendance for the entire Term 1 without missing a single school day.',
      criteria: 'Zero unexcused absences for 90 consecutive school days.',
      certificateRef: 'CERT-2026-ATTN-104',
    },
    {
      id: 'bdg-03',
      title: 'District Sub-Junior 100m Sprint Winner',
      category: 'Sports & Athletics',
      tier: 'Gold',
      dateAwarded: '10 Jun 2026',
      awardedBy: 'Kanchipuram District Sports Association',
      points: 200,
      icon: '🏃',
      description: 'Gold medal in 100m athletics track sprint representing Wisdom International School.',
      criteria: '1st place in 100m dash event (Clocked 14.2s).',
      certificateRef: 'CERT-2026-SPRT-012',
    },
    {
      id: 'bdg-04',
      title: 'Science Fair Eco-Innovation Champion',
      category: 'STEM & Innovation',
      tier: 'Silver',
      dateAwarded: '22 May 2026',
      awardedBy: 'Head of Science Department',
      points: 180,
      icon: '🌱',
      description: 'Designed a working solar-powered drip irrigation model for rural farming demonstration.',
      criteria: 'Top 3 project in Annual School Science Expo 2026.',
      certificateRef: 'CERT-2026-SCIE-045',
    },
    {
      id: 'bdg-05',
      title: 'Inter-School Tamil Elocution Trophy',
      category: 'Arts & Culture',
      tier: 'Gold',
      dateAwarded: '14 Apr 2026',
      awardedBy: 'Tamil Literary Society',
      points: 220,
      icon: '🎙️',
      description: 'Secured 1st Prize in Thirukkural Recitation and Eloquence Speech Contest.',
      criteria: 'Flawless recitation of 20 Thirukkural couplets with commentary.',
      certificateRef: 'CERT-2026-LIT-091',
    },
    {
      id: 'bdg-06',
      title: 'Class Room Cleanliness & Green Captain',
      category: 'Leadership & Conduct',
      tier: 'Bronze',
      dateAwarded: '05 Apr 2026',
      awardedBy: 'Class Teacher Mrs. Anitha Vijay',
      points: 100,
      icon: '🧹',
      description: 'Led Class 3-A green recycling initiative and daily chalkboard maintenance.',
      criteria: 'Elected Green Captain for Class 3-A by peers.',
      certificateRef: 'CERT-2026-LEAD-003',
    },
  ]);

  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedBadge, setSelectedBadge] = useState<BadgeItem | null>(null);
  const [showCertificate, setShowCertificate] = useState(false);

  const categories = ['All', 'Academic', 'Sports & Athletics', 'STEM & Innovation', 'Arts & Culture', 'Leadership & Conduct'];

  const filteredBadges = badges.filter((b) => selectedCategory === 'All' || b.category === selectedCategory);

  const totalPoints = badges.reduce((sum, b) => sum + b.points, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl shrink-0">
              <Trophy className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-blue-950">
                  Student Digital Badges & Honor Roll
                </h2>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-300 flex items-center gap-1">
                  <Crown className="w-3 h-3 text-amber-700" />
                  LEVEL 4 SCHOLAR
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Official verified digital credentials celebrating academic, sports, and leadership excellence for student <strong>{student?.name || 'S. Kavin Vijay'}</strong>.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <div className="p-3 bg-blue-950 text-white rounded-2xl flex items-center gap-3 text-xs shadow">
              <Zap className="w-5 h-5 text-amber-400 fill-amber-400" />
              <div>
                <span className="text-[10px] text-amber-300 font-bold uppercase block">Total House XP Points</span>
                <span className="font-extrabold text-base text-amber-400">{totalPoints} XP</span>
              </div>
            </div>
          </div>
        </div>

        {/* Category Pills Filter */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl font-extrabold whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-blue-950 text-amber-400 shadow'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* BADGES GALLERY GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBadges.map((badge) => {
          const tierColor =
            badge.tier === 'Diamond'
              ? 'from-cyan-500 to-blue-600 text-white border-cyan-300'
              : badge.tier === 'Gold'
              ? 'from-amber-400 to-yellow-600 text-blue-950 border-amber-300'
              : badge.tier === 'Silver'
              ? 'from-slate-300 to-slate-500 text-slate-950 border-slate-300'
              : 'from-amber-700 to-amber-900 text-amber-100 border-amber-800';

          return (
            <div
              key={badge.id}
              onClick={() => setSelectedBadge(badge)}
              className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition cursor-pointer flex flex-col justify-between space-y-4 group relative overflow-hidden"
            >
              <div className="flex items-start justify-between gap-3">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${tierColor} flex items-center justify-center text-2xl shadow-md group-hover:scale-110 transition duration-300 shrink-0`}>
                  {badge.icon}
                </div>

                <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                  {badge.tier} Tier • +{badge.points} XP
                </span>
              </div>

              <div className="space-y-1.5">
                <span className="text-[10px] font-extrabold text-blue-900 uppercase tracking-wider block">
                  {badge.category}
                </span>
                <h4 className="font-extrabold text-base text-slate-900 leading-snug">
                  {badge.title}
                </h4>
                <p className="text-slate-600 text-xs line-clamp-2 leading-relaxed">
                  {badge.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500 font-medium">
                <span>Awarded: {badge.dateAwarded}</span>
                <span className="font-bold text-blue-950 underline flex items-center gap-1">
                  View Credential <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* BADGE INSPECTOR & CERTIFICATE MODAL */}
      {selectedBadge && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-6 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => {
                setSelectedBadge(null);
                setShowCertificate(false);
              }}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            {!showCertificate ? (
              <div className="space-y-5 text-center">
                <div className="w-20 h-20 rounded-3xl bg-amber-100 text-amber-900 flex items-center justify-center text-4xl mx-auto shadow-inner border-2 border-amber-300">
                  {selectedBadge.icon}
                </div>

                <div className="space-y-1">
                  <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider border border-amber-300">
                    VERIFIED DIGITAL BADGE • {selectedBadge.tier} TIER
                  </span>
                  <h3 className="font-extrabold text-xl text-blue-950 pt-2">{selectedBadge.title}</h3>
                  <p className="text-xs text-slate-500">Category: {selectedBadge.category} • +{selectedBadge.points} XP</p>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs space-y-2">
                  <p className="text-slate-700"><strong>Description:</strong> {selectedBadge.description}</p>
                  <p className="text-slate-700"><strong>Qualifying Criteria:</strong> {selectedBadge.criteria}</p>
                  <p className="text-slate-700"><strong>Issued By:</strong> {selectedBadge.awardedBy}</p>
                  <p className="text-slate-500 text-[10px]">Credential Code: <strong className="font-mono">{selectedBadge.certificateRef}</strong></p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setShowCertificate(true)}
                    className="flex-1 py-3 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs transition shadow flex items-center justify-center gap-2"
                  >
                    <Award className="w-4 h-4 text-amber-400" />
                    <span>View Official Certificate</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-5">
                {/* Official Printable Certificate Layout */}
                <div className="bg-amber-50/60 border-4 border-amber-400 rounded-2xl p-6 text-center space-y-4 relative shadow-inner">
                  <div className="flex justify-between items-center text-[10px] text-amber-900 font-bold uppercase tracking-wider">
                    <span>Wisdom International School</span>
                    <span>Ref: {selectedBadge.certificateRef}</span>
                  </div>

                  <div className="space-y-1 pt-2">
                    <Trophy className="w-10 h-10 text-amber-600 mx-auto" />
                    <h4 className="font-serif font-extrabold text-lg text-blue-950 tracking-wide">
                      Certificate of Achievement
                    </h4>
                    <p className="text-[11px] text-slate-600 italic">This is proudly presented to</p>
                  </div>

                  <h3 className="font-extrabold text-xl text-blue-900 underline decoration-amber-400 decoration-2">
                    {student?.name || 'S. Kavin Vijay'}
                  </h3>

                  <p className="text-xs text-slate-700 leading-relaxed max-w-sm mx-auto">
                    In recognition of outstanding performance and securing the <strong>{selectedBadge.title}</strong> on {selectedBadge.dateAwarded}.
                  </p>

                  <div className="pt-4 border-t border-amber-300 flex justify-between items-end text-[10px] text-slate-800 font-bold">
                    <div className="text-left">
                      <p className="font-serif italic text-slate-600">Dr. V. Swaminathan</p>
                      <p className="text-[9px] text-slate-500">Principal</p>
                    </div>

                    <div className="w-12 h-12 rounded-full border border-amber-500 bg-amber-200/50 flex items-center justify-center text-[8px] font-black text-amber-900 uppercase">
                      WISDOM SEAL
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => window.print()}
                    className="flex-1 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition flex items-center justify-center gap-1.5"
                  >
                    <Printer className="w-4 h-4" />
                    <span>Print / Download PDF</span>
                  </button>
                  <button
                    onClick={() => setShowCertificate(false)}
                    className="px-4 py-2.5 rounded-xl bg-blue-950 text-amber-400 font-bold text-xs transition"
                  >
                    Back to Badge
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

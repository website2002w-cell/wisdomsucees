import React, { useState, useEffect } from 'react';
import {
  Bus,
  MapPin,
  Clock,
  PhoneCall,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  UserCheck,
  Navigation,
  RefreshCw,
  Play,
  Pause,
  Bell,
  BellRing,
  ZoomIn,
  ZoomOut,
  Crosshair,
  Volume2,
  VolumeX,
  Gauge,
  Compass,
  Radio,
  Check,
} from 'lucide-react';
import { StudentProfile } from '../types';

interface SchoolVanTrackerProps {
  student?: StudentProfile | null;
}

interface MapStop {
  id: string;
  name: string;
  landmark: string;
  x: number; // percentage X on map
  y: number; // percentage Y on map
  morningTime: string;
  eveningTime: string;
  status: 'Passed' | 'Approaching' | 'Upcoming';
  isStudentStop?: boolean;
}

export const SchoolVanTracker: React.FC<SchoolVanTrackerProps> = ({ student: inputStudent }) => {
  const student = inputStudent || {
    id: 'WNS-2026-0304',
    name: 'S. Kavin Vijay',
    fatherName: 'Mr. S. Vijayakumar',
    motherName: 'Mrs. V. Revathi',
    grade: 'Class 3-A',
    rollNo: '24',
    section: 'A',
    dob: '12/05/2018',
    parentPhone: '9840123456',
    address: 'No. 14, Main Road, Essur Village, Cheyyur Taluk - 603301',
    vanRoute: 'Route 2 - Cheyyur / Essur Van',
  };
  // Route coordinates on 1000x500 map canvas
  const routePoints = [
    { x: 100, y: 380, name: 'Chunampet Bus Stand' },
    { x: 300, y: 320, name: 'Cheyyur Cross Road' },
    { x: 500, y: 220, name: 'Vedanthangal Main Junction' },
    { x: 720, y: 160, name: 'Essur Lake Stop (Student Stop)' },
    { x: 880, y: 120, name: 'Wisdom School Campus Gate' },
  ];

  // Route stops data
  const [stops, setStops] = useState<MapStop[]>([
    {
      id: 's1',
      name: 'Chunampet Bus Stand',
      landmark: 'Near Govt. Hospital',
      x: 10,
      y: 76,
      morningTime: '07:30 AM',
      eveningTime: '04:45 PM',
      status: 'Passed',
    },
    {
      id: 's2',
      name: 'Cheyyur Cross Road',
      landmark: 'Opposite State Bank ATM',
      x: 30,
      y: 64,
      morningTime: '07:45 AM',
      eveningTime: '04:30 PM',
      status: 'Passed',
    },
    {
      id: 's3',
      name: 'Vedanthangal Main Junction',
      landmark: 'Bird Sanctuary Arch',
      x: 50,
      y: 44,
      morningTime: '08:00 AM',
      eveningTime: '04:15 PM',
      status: 'Approaching',
    },
    {
      id: 's4',
      name: 'Essur Lake Stop',
      landmark: 'Near Essur Amman Temple',
      x: 72,
      y: 32,
      morningTime: '08:15 AM',
      eveningTime: '04:00 PM',
      status: 'Upcoming',
      isStudentStop: true,
    },
    {
      id: 's5',
      name: 'Wisdom School Campus Gate',
      landmark: 'School Admin Office',
      x: 88,
      y: 24,
      morningTime: '08:30 AM',
      eveningTime: '03:45 PM',
      status: 'Upcoming',
    },
  ]);

  // Simulation & Bus Progress (0 to 100 along route)
  const [progress, setProgress] = useState(48); // default near Vedanthangal
  const [isSimulating, setIsSimulating] = useState(true);
  const [selectedStop, setSelectedStop] = useState<MapStop | null>(stops[3]); // Default student stop
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isAudioAlertEnabled, setIsAudioAlertEnabled] = useState(true);
  const [isSmsAlertEnabled, setIsSmsAlertEnabled] = useState(true);
  const [alertTriggered, setAlertTriggered] = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState('Just now');

  // Interpolate bus position (X, Y) from route points based on progress %
  const getBusCoordinates = (p: number) => {
    const totalSegments = routePoints.length - 1;
    const segmentIndex = Math.min(
      Math.floor((p / 100) * totalSegments),
      totalSegments - 1
    );
    const segmentProgress =
      (p / 100) * totalSegments - segmentIndex;

    const p1 = routePoints[segmentIndex];
    const p2 = routePoints[segmentIndex + 1];

    const currentX = p1.x + (p2.x - p1.x) * segmentProgress;
    const currentY = p1.y + (p2.y - p1.y) * segmentProgress;

    return { x: currentX, y: currentY };
  };

  const busPos = getBusCoordinates(progress);

  // Auto animation interval for live GPS movement simulation
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (isSimulating) {
      timer = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 98) return 10; // loop back to start
          const next = prev + 0.8;

          // Check if bus is close to student stop (progress around 68-75)
          if (next >= 65 && next <= 75 && !alertTriggered && isAudioAlertEnabled) {
            setAlertTriggered(true);
          }

          return next;
        });
      }, 500);
    }
    return () => clearInterval(timer);
  }, [isSimulating, alertTriggered, isAudioAlertEnabled]);

  // Calculate ETA in minutes based on distance to student stop (progress 72)
  const studentStopProgress = 72;
  const remainingProgress = Math.max(0, studentStopProgress - progress);
  const etaMinutes = Math.ceil((remainingProgress / 100) * 20); // 20 min total trip duration

  const handleManualRefresh = () => {
    setLastRefreshed(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl shrink-0">
              <Bus className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-blue-950">
                  Real-Time School Bus GPS Tracker & Interactive Map
                </h3>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-300 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                  LIVE GPS ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Live location map for <strong>TN-19-WNS-04</strong> • Student: <strong>{student.name}</strong> (Pickup: Essur Lake Stop)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsSimulating(!isSimulating)}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-xs ${
                isSimulating
                  ? 'bg-amber-400 text-blue-950 hover:bg-amber-300'
                  : 'bg-emerald-600 text-white hover:bg-emerald-700'
              }`}
            >
              {isSimulating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isSimulating ? 'Pause Live GPS Feed' : 'Resume Live GPS Feed'}</span>
            </button>

            <button
              onClick={handleManualRefresh}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold transition text-xs"
              title="Refresh GPS Signal"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ETA Highlight Card */}
        {remainingProgress > 0 ? (
          <div className="p-4 bg-gradient-to-r from-blue-950 to-indigo-900 text-white rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-amber-400 text-blue-950 font-black flex items-center justify-center text-lg shrink-0">
                {etaMinutes}m
              </div>
              <div>
                <span className="text-[10px] text-amber-300 font-extrabold uppercase tracking-wider block">
                  Estimated Arrival at Child's Stop
                </span>
                <h4 className="font-extrabold text-sm sm:text-base">
                  Essur Lake Stop (Near Temple)
                </h4>
                <p className="text-[10px] text-slate-300">
                  School van is {Math.round(remainingProgress / 5)} km away • Driver: Thiru. K. Murugan (+91 98402 38192)
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <button
                onClick={() => setIsSmsAlertEnabled(!isSmsAlertEnabled)}
                className={`px-3 py-1.5 rounded-xl font-bold border transition flex items-center gap-1.5 ${
                  isSmsAlertEnabled
                    ? 'bg-amber-400 text-blue-950 border-amber-300 font-black'
                    : 'bg-white/10 text-slate-300 border-white/20'
                }`}
              >
                {isSmsAlertEnabled ? <BellRing className="w-3.5 h-3.5" /> : <Bell className="w-3.5 h-3.5" />}
                <span>SMS Alert: {isSmsAlertEnabled ? 'ON' : 'OFF'}</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-950 rounded-2xl flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            <div className="text-xs">
              <h4 className="font-extrabold text-sm">School Van Has Reached / Passed Essur Stop</h4>
              <p className="text-slate-600">Child successfully boarded at 08:14 AM. Bus heading to Wisdom School Campus Gate.</p>
            </div>
          </div>
        )}
      </div>

      {/* INTERACTIVE MAP CONTAINER */}
      <div className="bg-slate-900 border-2 border-slate-800 rounded-3xl overflow-hidden shadow-xl relative text-white space-y-4">
        {/* Map Header Overlay Bar */}
        <div className="p-4 bg-slate-950/80 backdrop-blur-md border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs z-10 relative">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span className="font-mono font-bold text-slate-200">
              GPS Signal: STRONG (Lat: 12.5201° N, Long: 79.9102° E)
            </span>
          </div>

          <div className="flex items-center gap-2 text-[11px] font-bold">
            <span className="text-slate-400">Map View:</span>
            <span className="bg-blue-900/80 text-amber-300 px-2.5 py-1 rounded-lg border border-blue-700">
              Cheyyur - Essur Route Canvas
            </span>
            <button
              onClick={() => setZoomLevel(zoomLevel === 1 ? 1.25 : 1)}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              title="Toggle Zoom"
            >
              {zoomLevel === 1 ? <ZoomIn className="w-4 h-4" /> : <ZoomOut className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* SVG VECTOR MAP CANVAS */}
        <div className="relative w-full h-[380px] sm:h-[450px] bg-[#0f172a] overflow-hidden select-none">
          {/* Grid lines background */}
          <div
            className="absolute inset-0 opacity-15"
            style={{
              backgroundImage: `radial-gradient(#38bdf8 1px, transparent 1px)`,
              backgroundSize: '24px 24px',
            }}
          />

          <svg
            viewBox="0 0 1000 500"
            className="w-full h-full transition-transform duration-300"
            style={{ transform: `scale(${zoomLevel})`, transformOrigin: 'center center' }}
          >
            {/* Environmental Landmarks & Roads */}
            {/* Vedanthangal Sanctuary Lake area */}
            <path
              d="M 420 180 Q 520 120 580 200 Q 540 280 440 240 Z"
              fill="#0284c7"
              fillOpacity="0.2"
              stroke="#0369a1"
              strokeWidth="2"
            />
            <text x="460" y="210" fill="#38bdf8" fontSize="11" fontWeight="bold" opacity="0.8">
              Vedanthangal Lake
            </text>

            {/* Cheyyur Reserve Forest / Green Patch */}
            <circle cx="200" cy="380" r="70" fill="#15803d" fillOpacity="0.15" stroke="#166534" strokeWidth="2" />
            <text x="160" y="385" fill="#4ade80" fontSize="10" fontWeight="bold" opacity="0.7">
              Cheyyur Woods
            </text>

            {/* Route Polyline Shadow */}
            <polyline
              points="100,380 300,320 500,220 720,160 880,120"
              fill="none"
              stroke="#0284c7"
              strokeWidth="12"
              strokeLinecap="round"
              strokeLinejoin="round"
              opacity="0.2"
            />

            {/* Active Route Polyline */}
            <polyline
              points="100,380 300,320 500,220 720,160 880,120"
              fill="none"
              stroke="#fbbf24"
              strokeWidth="5"
              strokeDasharray="8 4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />

            {/* Route Stops Pins */}
            {stops.map((stop) => {
              const isSelected = selectedStop?.id === stop.id;
              // Map 0-100 percentage to 1000x500 coordinates
              const cx = (stop.x / 100) * 1000;
              const cy = (stop.y / 100) * 500;

              return (
                <g
                  key={stop.id}
                  onClick={() => setSelectedStop(stop)}
                  className="cursor-pointer group"
                >
                  {/* Outer pulse if student stop */}
                  {stop.isStudentStop && (
                    <circle cx={cx} cy={cy} r="22" fill="#f59e0b" fillOpacity="0.3" className="animate-ping" />
                  )}

                  {/* Stop Marker Circle */}
                  <circle
                    cx={cx}
                    cy={cy}
                    r={stop.isStudentStop ? "14" : "10"}
                    fill={stop.isStudentStop ? "#f59e0b" : isSelected ? "#38bdf8" : "#1e293b"}
                    stroke={stop.isStudentStop ? "#fff" : "#94a3b8"}
                    strokeWidth="3"
                  />

                  {/* Stop Label Text */}
                  <text
                    x={cx}
                    y={cy + 26}
                    textAnchor="middle"
                    fill={stop.isStudentStop ? "#fbbf24" : "#e2e8f0"}
                    fontSize={stop.isStudentStop ? "12" : "10"}
                    fontWeight="bold"
                    className="drop-shadow-md"
                  >
                    {stop.name.split(' ')[0]} {stop.isStudentStop ? '⭐' : ''}
                  </text>
                </g>
              );
            })}

            {/* LIVE MOVING BUS ICON MARKER */}
            <g
              transform={`translate(${busPos.x}, ${busPos.y})`}
              className="transition-all duration-300 ease-linear"
            >
              {/* Bus Outer Beacon Glow */}
              <circle r="26" fill="#f59e0b" fillOpacity="0.35" className="animate-ping" />
              <circle r="18" fill="#1e1b4b" stroke="#f59e0b" strokeWidth="4" />

              {/* Bus Symbol / Icon */}
              <text x="0" y="5" textAnchor="middle" fontSize="16">
                🚌
              </text>
            </g>
          </svg>

          {/* Floating Bus Badge Telemetry on Map */}
          <div
            className="absolute p-2.5 bg-blue-950/90 border border-amber-400 rounded-2xl text-amber-300 text-[10px] font-black shadow-xl flex items-center gap-2 backdrop-blur-md"
            style={{
              left: `${Math.min(Math.max(busPos.x / 10, 10), 70)}%`,
              top: `${Math.max(busPos.y / 5 - 55, 10)}px`,
            }}
          >
            <Gauge className="w-3.5 h-3.5 text-amber-400" />
            <span>TN-19-WNS-04 • 38 km/h</span>
          </div>

          {/* Map Legend Footer Overlay */}
          <div className="absolute bottom-3 left-3 right-3 p-3 bg-slate-950/85 backdrop-blur-md border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-300">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 font-bold">
                <span className="w-3 h-3 rounded-full bg-amber-400 border border-white"></span>
                <span>Moving Bus</span>
              </span>
              <span className="flex items-center gap-1.5 font-bold">
                <span className="w-3 h-3 rounded-full bg-amber-500 border border-white"></span>
                <span>Child Pickup Stop (Essur)</span>
              </span>
              <span className="flex items-center gap-1.5 text-slate-400">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-700 border border-slate-400"></span>
                <span>Other Route Stops</span>
              </span>
            </div>

            <span className="text-slate-400 font-mono">
              Speed: 38 km/h • GPS Ping: {lastRefreshed}
            </span>
          </div>
        </div>

        {/* SELECTED STOP DETAIL INSPECTOR */}
        {selectedStop && (
          <div className="p-4 bg-slate-950 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-amber-400 font-black text-[10px] uppercase tracking-wider bg-amber-950/80 px-2.5 py-0.5 rounded-full border border-amber-800">
                  Stop Details Inspector
                </span>
                {selectedStop.isStudentStop && (
                  <span className="bg-emerald-900 text-emerald-300 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-700">
                    Your Child's Pickup Point
                  </span>
                )}
              </div>

              <h5 className="font-extrabold text-sm text-white">{selectedStop.name}</h5>
              <p className="text-[11px] text-slate-400">
                Landmark: <strong>{selectedStop.landmark}</strong> • Scheduled Morning Time: <strong>{selectedStop.morningTime}</strong>
              </p>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <span className={`px-3 py-1 rounded-xl text-xs font-black ${
                selectedStop.status === 'Passed'
                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                  : selectedStop.status === 'Approaching'
                  ? 'bg-amber-950 text-amber-300 border border-amber-800 animate-pulse'
                  : 'bg-slate-800 text-slate-300'
              }`}>
                Status: {selectedStop.status}
              </span>
            </div>
          </div>
        )}
      </div>

      {/* DRIVER CONTACT & EMERGENCY ASSISTANCE BOARD */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-3">
          <h4 className="font-extrabold text-xs text-blue-950 uppercase tracking-wider flex items-center gap-1.5">
            <UserCheck className="w-4 h-4 text-blue-900" />
            <span>Driver & Transport Crew Details</span>
          </h4>

          <div className="space-y-2 text-xs">
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="font-extrabold text-slate-900 block">Thiru. K. Murugan</span>
                <span className="text-[10px] text-slate-500">Class 1 Heavy License Driver • 8 Yrs Experience</span>
              </div>
              <a
                href="tel:+919840238192"
                className="px-3 py-1.5 rounded-xl bg-blue-950 text-amber-400 font-extrabold transition text-[11px] flex items-center gap-1"
              >
                <PhoneCall className="w-3 h-3 text-amber-400" />
                <span>Call Driver</span>
              </a>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="font-extrabold text-slate-900 block">Thiru. P. Elumalai</span>
                <span className="text-[10px] text-slate-500">Bus Attendant & Safety In-Charge</span>
              </div>
              <a
                href="tel:+919443182910"
                className="px-3 py-1.5 rounded-xl bg-slate-200 text-slate-800 font-extrabold transition text-[11px] flex items-center gap-1"
              >
                <PhoneCall className="w-3 h-3" />
                <span>Call Helper</span>
              </a>
            </div>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-3">
          <h4 className="font-extrabold text-xs text-blue-950 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Vehicle Safety & Inspection Certifications</span>
          </h4>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-2xl font-bold text-emerald-900">
              <span className="text-[9px] text-emerald-700 uppercase block font-bold">RTO Fitness Certificate</span>
              <span>Valid till Dec 2027</span>
            </div>
            <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-2xl font-bold text-blue-900">
              <span className="text-[9px] text-blue-700 uppercase block font-bold">Speed Governor</span>
              <span>Locked at 40 km/h Max</span>
            </div>
            <div className="p-2.5 bg-purple-50 border border-purple-200 rounded-2xl font-bold text-purple-900">
              <span className="text-[9px] text-purple-700 uppercase block font-bold">CCTV Cameras</span>
              <span>4 HD Cameras Active</span>
            </div>
            <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-2xl font-bold text-amber-900">
              <span className="text-[9px] text-amber-800 uppercase block font-bold">First Aid Box</span>
              <span>Inspected Weekly</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


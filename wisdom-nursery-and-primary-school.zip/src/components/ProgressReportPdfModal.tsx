import React, { useState } from 'react';
import {
  X,
  Printer,
  Download,
  FileText,
  Award,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  Building2,
  Calendar,
  User,
  QrCode,
  Check,
} from 'lucide-react';
import { StudentProfile } from '../types';
import { SCHOOL_INFO, DEFAULT_STUDENT_PROFILE } from '../data/schoolData';

interface ProgressReportPdfModalProps {
  student?: StudentProfile | null;
  onClose: () => void;
}

export const ProgressReportPdfModal: React.FC<ProgressReportPdfModalProps> = ({
  student: inputStudent,
  onClose,
}) => {
  const student = inputStudent || DEFAULT_STUDENT_PROFILE;
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  // Compute stats
  const term1Marks = student?.term1Marks || [];
  const totalObtained = term1Marks.reduce((acc, m) => acc + (m.mark || 0), 0);
  const totalMax = term1Marks.reduce((acc, m) => acc + (m.max || 100), 0) || 100;
  const overallPercentage = Math.round((totalObtained / totalMax) * 1000) / 10;

  const handlePrintPdf = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 4000);
    window.print();
  };

  const handleDownloadTxtSummary = () => {
    const content = `====================================================
WISDOM NURSERY AND PRIMARY SCHOOL, ESSUR - 603301
OFFICIAL ACADEMIC PROGRESS REPORT CARD (2026-2027)
====================================================

Student Name   : ${student.name}
Registration ID: ${student.id}
Grade / Class  : ${student.grade}
Roll Number    : ${student.rollNo}
Class Teacher  : ${student.classTeacher}
Parent Name    : ${student.fatherName}
Attendance     : ${student.presentDays} / ${student.totalDays} Days (${student.attendancePercentage}%)

----------------------------------------------------
SUBJECT MARKS & GRADES BREAKDOWN:
----------------------------------------------------
${student.term1Marks
  .map(
    (m) =>
      `${m.subject.padEnd(18)} : ${m.mark} / ${m.max} Marks | Grade: ${m.grade}`
  )
  .join('\n')}

----------------------------------------------------
SUMMARY & PERFORMANCE:
----------------------------------------------------
Total Marks Obtained : ${totalObtained} / ${totalMax}
Overall Percentage   : ${overallPercentage}%
Academic Standing    : PASSED WITH DISTINCTION (Rank 1)

Teacher Remarks      : Excellent student. Outstanding performance in all subjects.
Issued Date          : ${new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
Issued By            : Office of Headmaster, Wisdom School Essur
====================================================`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${student.name.replace(/\s+/g, '_')}_Progress_Report_Card.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const qrDataUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=WNS:REPORT:${student.id}:${student.grade}:MARKS=${totalObtained}/${totalMax}`;

  return (
    <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative border-2 border-amber-400 my-auto animate-scaleUp">
        {/* Modal Controls Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4 print:hidden">
          <div className="flex items-center gap-2">
            <div className="p-2.5 bg-blue-100 text-blue-950 rounded-2xl">
              <Award className="w-5 h-5 text-blue-950" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-blue-950">
                Official Student Report Card Preview
              </h3>
              <p className="text-xs text-slate-500">
                Ready for high-resolution printing or PDF export
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadTxtSummary}
              className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs transition flex items-center gap-1.5"
              title="Download text report copy"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Export Text</span>
            </button>

            <button
              onClick={handlePrintPdf}
              className="px-4 py-2 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs transition flex items-center gap-1.5 shadow"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span>Save as PDF / Print</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {downloadSuccess && (
          <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-900 font-bold flex items-center gap-2 print:hidden">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Print dialog opened! Choose "Save as PDF" to download the report card document.</span>
          </div>
        )}

        {/* PRINTABLE REPORT CARD SHEET */}
        <div className="border-4 border-double border-blue-950 p-6 rounded-2xl bg-white space-y-6 text-slate-900 shadow-inner">
          {/* Header Banner */}
          <div className="text-center border-b-2 border-blue-950 pb-4 space-y-2">
            <div className="flex items-center justify-center space-x-3">
              <img
                src={SCHOOL_INFO.logoUrl}
                alt={SCHOOL_INFO.name}
                referrerPolicy="no-referrer"
                className="w-14 h-14 rounded-full border-2 border-amber-400 bg-white p-0.5 object-contain shrink-0 shadow-sm"
              />
              <div className="text-left">
                <h2 className="font-extrabold text-lg sm:text-xl text-blue-950 tracking-wide uppercase leading-tight">
                  WISDOM NURSERY AND PRIMARY SCHOOL
                </h2>
                <p className="text-[10px] text-slate-600 font-bold uppercase tracking-wider">
                  Recognized by Govt. of Tamil Nadu • Essur Village - 603301
                </p>
                <p className="text-[10px] text-amber-700 italic font-bold">
                  "{SCHOOL_INFO.motto}"
                </p>
              </div>
            </div>

            <div className="pt-2">
              <span className="bg-blue-950 text-amber-300 font-black text-xs uppercase px-4 py-1 rounded-full tracking-wider inline-block border border-amber-400">
                ACADEMIC PROGRESS REPORT CARD • TERM 1 (2026-2027)
              </span>
            </div>
          </div>

          {/* Student Profile Grid */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-300 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs font-semibold">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Student Name</span>
              <span className="font-extrabold text-blue-950 text-sm">{student.name}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Reg ID / Admission No.</span>
              <span className="font-mono font-bold text-slate-900">{student.id}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Grade / Section</span>
              <span className="font-extrabold text-blue-900">{student.grade}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Roll Number</span>
              <span className="font-bold text-slate-900">{student.rollNo}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Class Teacher</span>
              <span className="font-bold text-slate-900">{student.classTeacher}</span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-bold block">Attendance Standing</span>
              <span className="font-bold text-emerald-700">{student.presentDays}/{student.totalDays} Days ({student.attendancePercentage}%)</span>
            </div>
          </div>

          {/* Marks Table */}
          <div className="space-y-2">
            <h4 className="font-black text-xs uppercase tracking-wider text-blue-950 flex items-center justify-between">
              <span>Subject Marks & Grade Sheet</span>
              <span className="text-[10px] text-slate-500 font-normal">Samacheer Kalvi State Board Curriculum</span>
            </h4>

            <table className="w-full text-left text-xs border border-slate-300 rounded-xl overflow-hidden">
              <thead>
                <tr className="bg-blue-950 text-amber-300 font-black uppercase text-[10px] divide-x divide-blue-900">
                  <th className="py-2.5 px-3">Subject Name</th>
                  <th className="py-2.5 px-3 text-center">Max Marks</th>
                  <th className="py-2.5 px-3 text-center">Marks Obtained</th>
                  <th className="py-2.5 px-3 text-center">Grade</th>
                  <th className="py-2.5 px-3 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 font-semibold text-slate-900">
                {student.term1Marks.map((m, idx) => (
                  <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}>
                    <td className="py-2.5 px-3 font-bold text-slate-900">{m.subject}</td>
                    <td className="py-2.5 px-3 text-center text-slate-500">{m.max}</td>
                    <td className="py-2.5 px-3 text-center font-extrabold text-blue-950 text-sm">{m.mark}</td>
                    <td className="py-2.5 px-3 text-center font-black text-blue-900">{m.grade}</td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="bg-emerald-100 text-emerald-800 font-extrabold text-[9px] px-2 py-0.5 rounded-full">
                        PASSED
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-blue-50 font-extrabold text-blue-950 border-t-2 border-blue-950 text-xs">
                  <td className="py-3 px-3">GRAND TOTAL:</td>
                  <td className="py-3 px-3 text-center">{totalMax}</td>
                  <td className="py-3 px-3 text-center text-sm font-black text-blue-950">{totalObtained}</td>
                  <td className="py-3 px-3 text-center text-emerald-700">{overallPercentage}%</td>
                  <td className="py-3 px-3 text-center text-emerald-800 uppercase font-black">DISTINCTION</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Teacher Remarks & Principal Signatures */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center pt-2">
            <div className="sm:col-span-8 p-3 bg-amber-50/80 border border-amber-200 rounded-xl space-y-1 text-xs">
              <span className="font-extrabold text-amber-900 uppercase text-[10px] block">
                Class Teacher Assessment & Remarks:
              </span>
              <p className="text-slate-800 font-medium italic leading-relaxed text-[11px]">
                "{student.name} demonstrates commendable academic consistency and enthusiasm in class. Excellent reading fluency in Tamil and English."
              </p>
            </div>

            <div className="sm:col-span-4 text-right space-y-1 text-xs">
              <div className="flex justify-end mb-1">
                <img
                  src={qrDataUrl}
                  alt="Report Card QR Seal"
                  className="w-12 h-12 rounded border border-slate-300 p-0.5 bg-white object-contain"
                />
              </div>
              <p className="font-serif italic font-extrabold text-blue-950">R. Saravanan</p>
              <span className="text-[9px] uppercase font-bold text-slate-500 block border-t border-slate-300 pt-0.5">
                Headmaster / Administrator Stamp
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="flex justify-between items-center text-xs text-slate-500 print:hidden pt-2">
          <span>Wisdom School Document Verification Engine</span>
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold transition"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
};

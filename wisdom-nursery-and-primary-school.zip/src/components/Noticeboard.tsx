import React, { useState, useEffect, useRef } from 'react';
import { FileText, Bell, BellRing, Calendar, Tag, AlertCircle, Search, Database, Sparkles, Send, Mic, MicOff, X, Volume2 } from 'lucide-react';
import { NOTICES_DATA } from '../data/schoolData';
import { NoticeItem } from '../types';
import { getCachedData, setCachedData, STORAGE_KEYS } from '../utils/offlineStorage';
import { useOffline } from '../context/OfflineContext';

export const Noticeboard: React.FC = () => {
  const {
    isOnline,
    notificationPermission,
    requestNotificationPermission,
    simulateNoticeboardPush,
  } = useOffline();

  const [notices, setNotices] = useState<NoticeItem[]>(() => {
    return getCachedData<NoticeItem[]>(STORAGE_KEYS.NOTICEBOARD, NOTICES_DATA);
  });

  useEffect(() => {
    if (notices.length > 0) {
      setCachedData(STORAGE_KEYS.NOTICEBOARD, notices);
    }
  }, [notices]);

  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Web Speech API Voice Search States
  const [isListening, setIsListening] = useState(false);
  const [speechTranscript, setSpeechTranscript] = useState('');
  const [speechSupported, setSpeechSupported] = useState(true);
  const [voiceSearchFeedback, setVoiceSearchFeedback] = useState<string | null>(null);

  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check Web Speech API availability
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-IN'; // Indian English default, also captures school terminology

      recognition.onstart = () => {
        setIsListening(true);
        setVoiceSearchFeedback('Listening... Speak search term now (e.g., "Exam", "Fees")');
      };

      recognition.onresult = (event: any) => {
        let transcript = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          transcript += event.results[i][0].transcript;
        }
        setSpeechTranscript(transcript);
        setSearchQuery(transcript);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
        if (event.error === 'not-allowed') {
          setVoiceSearchFeedback('Microphone permission denied. Please allow microphone access in browser settings.');
        } else if (event.error === 'no-speech') {
          setVoiceSearchFeedback('No voice detected. Please try tapping the microphone again.');
        } else {
          setVoiceSearchFeedback(`Voice error: ${event.error}. Try typing your query.`);
        }
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {
          // ignore
        }
      }
    };
  }, []);

  const toggleVoiceSearch = () => {
    if (!speechSupported) {
      alert('Web Speech API is not supported in this browser environment. Please try typing in the search box.');
      return;
    }

    if (isListening) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListening(false);
    } else {
      try {
        setSpeechTranscript('');
        setVoiceSearchFeedback(null);
        recognitionRef.current.start();
      } catch (err) {
        console.error('Error starting speech recognition:', err);
      }
    }
  };

  const handleVoiceChipClick = (term: string) => {
    setSearchQuery(term);
    setSpeechTranscript(term);
    setVoiceSearchFeedback(`Voice filter applied: "${term}"`);
  };

  const filteredNotices = notices.filter((notice) => {
    const matchesCat = activeCategory === 'All' || notice.category === activeCategory;
    const matchesSearch =
      notice.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notice.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      notice.category.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <div className="flex flex-wrap items-center justify-center gap-2">
          <span className="bg-purple-100 text-purple-900 text-xs font-black uppercase px-3.5 py-1.5 rounded-full border border-purple-200 inline-flex items-center gap-1.5">
            <Bell className="w-3.5 h-3.5 text-purple-800" />
            School Circulars & Announcements
          </span>

          {!isOnline && (
            <span className="bg-amber-100 text-amber-900 text-xs font-extrabold px-3 py-1.5 rounded-full border border-amber-300 inline-flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-amber-800" />
              Offline Cached Circulars
            </span>
          )}
        </div>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-blue-950">
          Wisdom Notice Board
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm">
          Stay updated with official school announcements, examination timetables, fee circulars, and holiday notifications.
        </p>
      </div>

      {/* Push Notification Bar */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-blue-950 text-white rounded-2xl p-4 shadow-md border border-amber-400/40 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-400 text-blue-950 rounded-xl shrink-0">
            <BellRing className="w-5 h-5 text-blue-950" />
          </div>
          <div className="text-xs">
            <h4 className="font-extrabold text-amber-300 flex items-center gap-1.5">
              <span>Push Notification Service Worker Active</span>
              <span className="bg-emerald-500 text-white text-[9px] font-black px-2 py-0.5 rounded-full uppercase">
                PWA Ready
              </span>
            </h4>
            <p className="text-slate-300 text-[11px] pt-0.5">
              Receive instant alerts for urgent noticeboard updates and exam circulars even when the app is closed.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-stretch sm:self-auto justify-end">
          {notificationPermission !== 'granted' ? (
            <button
              onClick={requestNotificationPermission}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-extrabold rounded-xl transition shadow flex items-center gap-1.5"
            >
              <Bell className="w-4 h-4" />
              <span>Enable Push Alerts</span>
            </button>
          ) : (
            <span className="text-[11px] text-emerald-400 font-bold bg-emerald-950/80 px-3 py-1.5 rounded-xl border border-emerald-500/50 flex items-center gap-1">
              ✓ Alerts Enabled
            </span>
          )}

          <button
            onClick={() =>
              simulateNoticeboardPush(
                'Term 1 Science & Math Examination Timetable Released',
                'Urgent Circular'
              )
            }
            className="px-3.5 py-2 bg-blue-900 hover:bg-blue-800 text-amber-300 text-xs font-extrabold rounded-xl transition border border-amber-400/30 flex items-center gap-1.5"
          >
            <Send className="w-3.5 h-3.5 text-amber-300" />
            <span>Test Push</span>
          </button>
        </div>
      </div>

      {/* Filter & Voice Search Toolbar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-1.5 text-xs font-bold w-full md:w-auto">
            {['All', 'Exam', 'Fees', 'Holiday', 'Event', 'General'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3.5 py-2 rounded-xl transition ${
                  activeCategory === cat
                    ? 'bg-blue-950 text-amber-400 shadow-md font-black'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Voice-Enabled Search Bar */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search circulars by keyword..."
              className="w-full text-xs font-semibold pl-10 pr-20 py-2.5 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-900 bg-slate-50/50"
            />

            {/* Clear Query button */}
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSpeechTranscript('');
                  setVoiceSearchFeedback(null);
                }}
                className="absolute right-12 top-2.5 text-slate-400 hover:text-slate-600 p-0.5 rounded-full"
                title="Clear Search"
              >
                <X className="w-4 h-4" />
              </button>
            )}

            {/* Web Speech API Microphone Toggle Button */}
            <button
              onClick={toggleVoiceSearch}
              className={`absolute right-1.5 top-1.5 p-1.5 rounded-xl text-xs font-bold transition flex items-center justify-center ${
                isListening
                  ? 'bg-red-600 text-white animate-pulse shadow-lg ring-2 ring-red-400'
                  : searchQuery
                  ? 'bg-blue-950 text-amber-400 hover:bg-blue-900'
                  : 'bg-amber-400 text-blue-950 hover:bg-amber-300'
              }`}
              title={isListening ? 'Stop Listening' : 'Search circulars using Voice Command'}
            >
              {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Voice Command Banner & Quick Suggestion Chips */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3 text-xs space-y-2">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <div className={`p-1.5 rounded-lg ${isListening ? 'bg-red-100 text-red-600 animate-bounce' : 'bg-purple-100 text-purple-900'}`}>
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <span className="font-extrabold text-blue-950 block text-xs">
                  Web Speech Voice Search
                </span>
                <span className="text-[11px] text-slate-500">
                  {isListening ? (
                    <span className="text-red-600 font-bold animate-pulse flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-red-600 animate-ping inline-block" />
                      Listening... Speak search term now
                    </span>
                  ) : voiceSearchFeedback ? (
                    <span className="text-purple-900 font-medium">{voiceSearchFeedback}</span>
                  ) : (
                    'Click microphone or speak search words (e.g. "Exam schedule", "Fee receipt", "Monsoon holiday")'
                  )}
                </span>
              </div>
            </div>

            {/* Showing Results Count */}
            <div className="text-[11px] font-bold text-slate-600 self-end sm:self-center bg-white px-3 py-1 rounded-xl border border-slate-200">
              {filteredNotices.length} Circulars Found
            </div>
          </div>

          {/* Transcript live preview */}
          {speechTranscript && (
            <div className="bg-purple-50 border border-purple-200 text-purple-950 px-3 py-1.5 rounded-xl font-mono text-[11px] flex items-center justify-between gap-2">
              <span className="truncate">
                🗣️ Recognized Voice Query: <strong className="font-bold">"{speechTranscript}"</strong>
              </span>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSpeechTranscript('');
                }}
                className="text-purple-700 hover:text-purple-900 text-[10px] underline font-sans shrink-0"
              >
                Reset Query
              </button>
            </div>
          )}

          {/* Voice Prompt Suggestions */}
          <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-slate-200/60">
            <span className="text-[10px] font-bold uppercase text-slate-400">Quick Voice Shortcuts:</span>
            {['Exam Schedule', 'Fee Due', 'Holiday Notice', 'Sports Meet', 'Science Exhibition'].map((term) => (
              <button
                key={term}
                onClick={() => handleVoiceChipClick(term)}
                className="px-2.5 py-0.5 bg-white hover:bg-purple-100 text-slate-700 hover:text-purple-900 rounded-lg border border-slate-200 text-[10px] font-bold transition flex items-center gap-1"
              >
                <Volume2 className="w-3 h-3 text-purple-600" />
                <span>"{term}"</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Notices List */}
      <div className="space-y-4">
        {filteredNotices.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 space-y-3">
            <div className="w-12 h-12 bg-slate-100 text-slate-400 rounded-full mx-auto flex items-center justify-center">
              <Search className="w-6 h-6" />
            </div>
            <h4 className="font-extrabold text-blue-950 text-base">No Matching Circulars Found</h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              No circulars matched "{searchQuery}". Try searching for terms like "Exam", "Fees", or "Holiday".
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setActiveCategory('All');
                setSpeechTranscript('');
              }}
              className="px-4 py-2 bg-blue-950 text-amber-400 text-xs font-black rounded-xl hover:bg-blue-900 transition"
            >
              Clear All Search Filters
            </button>
          </div>
        ) : (
          filteredNotices.map((notice) => (
            <div
              key={notice.id}
              className={`p-6 bg-white border rounded-3xl shadow-sm transition hover:shadow-md ${
                notice.important ? 'border-amber-400 border-l-4' : 'border-slate-200'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full ${
                      notice.category === 'Exam'
                        ? 'bg-red-100 text-red-800'
                        : notice.category === 'Fees'
                        ? 'bg-amber-100 text-amber-900'
                        : notice.category === 'Holiday'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-blue-100 text-blue-900'
                    }`}
                  >
                    {notice.category}
                  </span>

                  {notice.important && (
                    <span className="bg-amber-400 text-blue-950 font-extrabold text-[10px] px-2 py-0.5 rounded flex items-center gap-1">
                      <AlertCircle className="w-3 h-3 text-blue-950" />
                      <span>Important</span>
                    </span>
                  )}
                </div>

                <span className="text-xs text-slate-400 font-medium flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{notice.date}</span>
                </span>
              </div>

              <h3 className="font-extrabold text-slate-900 text-base mb-1">{notice.title}</h3>
              <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">{notice.summary}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
};


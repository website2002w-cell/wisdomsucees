import React, { useState, useEffect } from 'react';
import {
  Bell,
  MessageSquare,
  Phone,
  Mail,
  CheckCircle2,
  Clock,
  Sparkles,
  ShieldCheck,
  SendHorizontal,
  Calendar,
  CreditCard,
  AlertTriangle,
  FileText,
  Volume2,
  X,
  Check,
} from 'lucide-react';
import { StudentProfile } from '../types';
import { DEFAULT_STUDENT_PROFILE } from '../data/schoolData';

interface NotificationPreferencesProps {
  student?: StudentProfile | null;
}

export const NotificationPreferences: React.FC<NotificationPreferencesProps> = ({ student: inputStudent }) => {
  const student = inputStudent || DEFAULT_STUDENT_PROFILE;
  const [mobileNumber, setMobileNumber] = useState('9876543210');
  const [whatsappNumber, setWhatsappNumber] = useState('9876543210');
  const [emailAddress, setEmailAddress] = useState('parent@wisdomessur.edu.in');

  // Channel toggles
  const [channels, setChannels] = useState({
    sms: true,
    whatsapp: true,
    email: false,
  });

  // Alert category toggles
  const [alerts, setAlerts] = useState({
    attendanceDaily: true,
    feeDueReminders: true,
    examMarksPublished: true,
    homeworkDigest: false,
    emergencyAnnouncements: true,
    vanTransportAlerts: true,
  });

  // Timing preferences
  const [attendanceTime, setAttendanceTime] = useState('09:15 AM (Immediately after morning assembly)');
  const [feeReminderDays, setFeeReminderDays] = useState('7 days prior');

  // UI state
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [testModal, setTestModal] = useState<{ open: boolean; type: 'whatsapp' | 'sms' | 'email'; message: string } | null>(null);
  const [testSending, setTestSending] = useState(false);
  const [testSentSuccess, setTestSentSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 4000);
  };

  const triggerTestAlert = (type: 'whatsapp' | 'sms' | 'email') => {
    let msg = '';
    if (type === 'whatsapp') {
      msg = `[Wisdom School Essur] 🔔 ATTENDANCE ALERT: Your child ${student.name} (${student.grade}) was marked PRESENT at 08:35 AM today. Have a blessed day! Admin: +91 9176593129`;
    } else if (type === 'sms') {
      msg = `WNS ESSUR: Fee due alert for ${student.name}. Term 2 fee Rs 3,500 due on 15-Aug-2026. Pay online at https://wisdomessur.edu.in/fees or school office.`;
    } else {
      msg = `Wisdom Nursery & Primary School: Academic Progress & Attendance summary for ${student.name} is now available in the student portal.`;
    }

    setTestModal({ open: true, type, message: msg });
    setTestSentSuccess(false);
  };

  // Automated Fee Reminder States
  const [feeRemindersLog, setFeeRemindersLog] = useState<any[]>([]);
  const [upcomingFeeSchedules, setUpcomingFeeSchedules] = useState<any[]>([]);
  const [reminderDispatching, setReminderDispatching] = useState<string | null>(null);
  const [reminderSuccessMsg, setReminderSuccessMsg] = useState('');

  // Fetch Fee Reminders History
  const fetchFeeRemindersData = async () => {
    try {
      const res = await fetch(`/api/student/fee-reminders/${student.id || 'WNS-2026-01'}`);
      const data = await res.json();
      if (data.success) {
        setFeeRemindersLog(data.history || []);
        setUpcomingFeeSchedules(data.upcomingSchedules || []);
      }
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchFeeRemindersData();
  }, [student.id]);

  const handleSendInstantFeeReminder = async (termItem: any, chosenChannel: 'whatsapp' | 'sms') => {
    setReminderDispatching(termItem.term);
    setReminderSuccessMsg('');
    try {
      const res = await fetch('/api/student/fee-reminders/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: student.id,
          studentName: student.name,
          parentPhone: whatsappNumber || mobileNumber,
          channel: chosenChannel,
          term: termItem.term,
          amount: termItem.amount,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setReminderSuccessMsg(`Automated ${chosenChannel.toUpperCase()} Fee Reminder dispatched successfully to +91 ${whatsappNumber || mobileNumber}!`);
        fetchFeeRemindersData();
        setTimeout(() => setReminderSuccessMsg(''), 5000);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setReminderDispatching(null);
    }
  };

  const handleSendTestMessage = () => {
    setTestSending(true);
    setTimeout(() => {
      setTestSending(false);
      setTestSentSuccess(true);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl shrink-0">
              <Bell className="w-6 h-6 text-amber-800" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-blue-950">
                  Automated Parent Alert Preferences
                </h3>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-200">
                  Active Subscription
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Configure instant SMS, WhatsApp, and Email alerts for {student.name} ({student.grade}).
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => triggerTestAlert('whatsapp')}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs transition flex items-center gap-1.5 shadow"
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Test WhatsApp</span>
            </button>
            <button
              onClick={() => triggerTestAlert('sms')}
              className="px-3.5 py-2 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs transition flex items-center gap-1.5 shadow"
            >
              <Phone className="w-3.5 h-3.5" />
              <span>Test SMS</span>
            </button>
          </div>
        </div>

        {savedSuccess && (
          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-900 font-bold flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>Notification settings updated successfully! SMS & WhatsApp dispatch queues updated.</span>
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-6">
          {/* SECTION 1: ALERT DESTINATION CONTACT CHANNELS */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-900" />
              <span>1. Contact Numbers & Channels</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              {/* WhatsApp Number Box */}
              <div className="p-4 bg-emerald-50/60 rounded-2xl border border-emerald-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-900 flex items-center gap-1.5">
                    <MessageSquare className="w-4 h-4 text-emerald-600" />
                    <span>WhatsApp Alert No.</span>
                  </label>
                  <input
                    type="checkbox"
                    checked={channels.whatsapp}
                    onChange={(e) => setChannels({ ...channels, whatsapp: e.target.checked })}
                    className="w-4 h-4 text-emerald-600 rounded border-emerald-300 focus:ring-emerald-500 cursor-pointer"
                  />
                </div>
                <input
                  type="tel"
                  value={whatsappNumber}
                  onChange={(e) => setWhatsappNumber(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                />
                <p className="text-[10px] text-slate-500">Receives rich daily attendance cards & fee receipts.</p>
              </div>

              {/* Mobile SMS Number Box */}
              <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Phone className="w-4 h-4 text-blue-800" />
                    <span>Mobile SMS No.</span>
                  </label>
                  <input
                    type="checkbox"
                    checked={channels.sms}
                    onChange={(e) => setChannels({ ...channels, sms: e.target.checked })}
                    className="w-4 h-4 text-blue-900 rounded border-blue-300 focus:ring-blue-800 cursor-pointer"
                  />
                </div>
                <input
                  type="tel"
                  value={mobileNumber}
                  onChange={(e) => setMobileNumber(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-800 focus:outline-none"
                />
                <p className="text-[10px] text-slate-500">Receives primary SMS text alerts & emergency notices.</p>
              </div>

              {/* Email Address Box */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Mail className="w-4 h-4 text-slate-700" />
                    <span>Email Address (Optional)</span>
                  </label>
                  <input
                    type="checkbox"
                    checked={channels.email}
                    onChange={(e) => setChannels({ ...channels, email: e.target.checked })}
                    className="w-4 h-4 text-blue-900 rounded border-slate-300 focus:ring-blue-800 cursor-pointer"
                  />
                </div>
                <input
                  type="email"
                  value={emailAddress}
                  onChange={(e) => setEmailAddress(e.target.value)}
                  placeholder="e.g. parent@example.com"
                  className="w-full font-bold px-3 py-2 rounded-xl border border-slate-300 bg-white focus:ring-2 focus:ring-blue-800 focus:outline-none"
                />
                <p className="text-[10px] text-slate-500">Receives monthly PDF report cards & fee statements.</p>
              </div>
            </div>
          </div>

          {/* SECTION 2: AUTOMATED ALERT TOPICS TOGGLE */}
          <div className="space-y-4 pt-2">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Bell className="w-4 h-4 text-amber-600" />
              <span>2. Select Automated Alert Categories</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Alert 1: Daily Attendance */}
              <div className="p-4 border border-slate-200 rounded-2xl bg-white hover:bg-slate-50/50 transition flex items-start gap-3">
                <input
                  type="checkbox"
                  id="att-alert"
                  checked={alerts.attendanceDaily}
                  onChange={(e) => setAlerts({ ...alerts, attendanceDaily: e.target.checked })}
                  className="mt-1 w-4 h-4 text-blue-900 rounded border-slate-300 focus:ring-blue-800 cursor-pointer"
                />
                <div className="space-y-1 text-xs w-full">
                  <label htmlFor="att-alert" className="font-extrabold text-slate-900 flex items-center justify-between cursor-pointer">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-4 h-4 text-emerald-600" />
                      Daily Attendance Status Alerts
                    </span>
                    <span className="text-[10px] text-emerald-800 font-extrabold bg-emerald-100 px-2 py-0.5 rounded">
                      High Priority
                    </span>
                  </label>
                  <p className="text-slate-500 text-[11px] leading-relaxed">
                    Receive instant morning alert when {student.name} is marked Present or Absent during 8:30 AM roll call.
                  </p>
                </div>
              </div>

              {/* Alert 2: Fee Due Date Reminders */}
              <div className="p-4 border border-slate-200 rounded-2xl bg-white hover:bg-slate-50/50 transition flex items-start gap-3">
                <input
                  type="checkbox"
                  id="fee-alert"
                  checked={alerts.feeDueReminders}
                  onChange={(e) => setAlerts({ ...alerts, feeDueReminders: e.target.checked })}
                  className="mt-1 w-4 h-4 text-blue-900 rounded border-slate-300 focus:ring-blue-800 cursor-pointer"
                />
                <div className="space-y-1 text-xs w-full">
                  <label htmlFor="fee-alert" className="font-extrabold text-slate-900 flex items-center justify-between cursor-pointer">
                    <span className="flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-amber-600" />
                      Upcoming Fee Due Date Reminders
                    </span>
                    <span className="text-[10px] text-amber-800 font-extrabold bg-amber-100 px-2 py-0.5 rounded">
                      Payment Alert
                    </span>
                  </label>
                  <p className="text-slate-500 text-[11px] leading-relaxed">
                    Automated alerts sent 7 days and 3 days before term tuition fee or bus transport fee due dates.
                  </p>
                </div>
              </div>

              {/* Alert 3: Exam Marks & Report Cards */}
              <div className="p-4 border border-slate-200 rounded-2xl bg-white hover:bg-slate-50/50 transition flex items-start gap-3">
                <input
                  type="checkbox"
                  id="exam-alert"
                  checked={alerts.examMarksPublished}
                  onChange={(e) => setAlerts({ ...alerts, examMarksPublished: e.target.checked })}
                  className="mt-1 w-4 h-4 text-blue-900 rounded border-slate-300 focus:ring-blue-800 cursor-pointer"
                />
                <div className="space-y-1 text-xs w-full">
                  <label htmlFor="exam-alert" className="font-extrabold text-slate-900 flex items-center justify-between cursor-pointer">
                    <span className="flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-purple-600" />
                      Exam Results & Term Marksheets
                    </span>
                    <span className="text-[10px] text-purple-800 font-extrabold bg-purple-100 px-2 py-0.5 rounded">
                      Academic
                    </span>
                  </label>
                  <p className="text-slate-500 text-[11px] leading-relaxed">
                    Direct WhatsApp notification with subject mark breakdown whenever midterm or annual exam results are published.
                  </p>
                </div>
              </div>

              {/* Alert 4: Homework & Van Transport */}
              <div className="p-4 border border-slate-200 rounded-2xl bg-white hover:bg-slate-50/50 transition flex items-start gap-3">
                <input
                  type="checkbox"
                  id="van-alert"
                  checked={alerts.vanTransportAlerts}
                  onChange={(e) => setAlerts({ ...alerts, vanTransportAlerts: e.target.checked })}
                  className="mt-1 w-4 h-4 text-blue-900 rounded border-slate-300 focus:ring-blue-800 cursor-pointer"
                />
                <div className="space-y-1 text-xs w-full">
                  <label htmlFor="van-alert" className="font-extrabold text-slate-900 flex items-center justify-between cursor-pointer">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-blue-600" />
                      School Van / Bus Pickup & Delay Alerts
                    </span>
                    <span className="text-[10px] text-blue-800 font-extrabold bg-blue-100 px-2 py-0.5 rounded">
                      Transport
                    </span>
                  </label>
                  <p className="text-slate-500 text-[11px] leading-relaxed">
                    Alerts regarding van departure times, driver contact updates, or traffic delays on Essur/Vedanthangal route.
                  </p>
                </div>
              </div>

              {/* Alert 5: Emergency Announcements */}
              <div className="p-4 border border-slate-200 rounded-2xl bg-white hover:bg-slate-50/50 transition flex items-start gap-3 md:col-span-2">
                <input
                  type="checkbox"
                  id="emerg-alert"
                  checked={alerts.emergencyAnnouncements}
                  onChange={(e) => setAlerts({ ...alerts, emergencyAnnouncements: e.target.checked })}
                  className="mt-1 w-4 h-4 text-blue-900 rounded border-slate-300 focus:ring-blue-800 cursor-pointer"
                />
                <div className="space-y-1 text-xs w-full">
                  <label htmlFor="emerg-alert" className="font-extrabold text-slate-900 flex items-center justify-between cursor-pointer">
                    <span className="flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-red-600" />
                      Rainfall Holiday / Emergency Announcements
                    </span>
                    <span className="text-[10px] text-red-800 font-extrabold bg-red-100 px-2 py-0.5 rounded">
                      Broadcast
                    </span>
                  </label>
                  <p className="text-slate-500 text-[11px] leading-relaxed">
                    Instant emergency SMS broadcast issued directly by Collector office or School Management during heavy rains or sudden holidays.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* SAVE BUTTON */}
          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              className="bg-blue-950 hover:bg-blue-900 text-amber-400 font-black px-6 py-3 rounded-2xl text-xs sm:text-sm shadow-md transition flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-amber-400" />
              <span>Save & Activate Parent Preferences</span>
            </button>
          </div>
        </form>
      </div>

      {/* SECTION 3: AUTOMATED FEE PAYMENT REMINDER ENGINE & SCHEDULES */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl shrink-0">
              <CreditCard className="w-6 h-6 text-amber-800" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-blue-950">
                  Automated Fee Payment Reminder Dispatcher
                </h3>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-300">
                  Auto-Cron Active
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Automated SMS & WhatsApp alerts dispatched to parents before fee due dates with direct 1-click UPI payment links.
              </p>
            </div>
          </div>
        </div>

        {reminderSuccessMsg && (
          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-900 font-bold flex items-center gap-2 animate-bounce">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{reminderSuccessMsg}</span>
          </div>
        )}

        {/* Upcoming Fee Due Schedules */}
        <div className="space-y-3">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-amber-600" />
            <span>Upcoming Fee Dues for {student.name} ({student.grade})</span>
          </h4>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {upcomingFeeSchedules.map((item, idx) => (
              <div key={idx} className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 relative">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2 py-0.5 rounded-full border border-amber-300 inline-block mb-1">
                      {item.grade}
                    </span>
                    <h5 className="font-extrabold text-sm text-blue-950">{item.term}</h5>
                    <p className="text-xs text-slate-500">Due Date: <span className="font-bold text-red-600">{item.dueDate}</span></p>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-slate-500 block">Amount</span>
                    <span className="text-base font-black text-emerald-700">₹{item.amount.toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <div className="bg-white p-2.5 rounded-xl border border-slate-200 space-y-1.5 text-[11px]">
                  <span className="font-bold text-slate-700 block">Automated Dispatch Schedule:</span>
                  <div className="flex flex-wrap gap-1">
                    {item.autoReminderSchedule?.map((sch: string, sIdx: number) => (
                      <span key={sIdx} className="bg-slate-100 text-slate-700 font-medium px-2 py-0.5 rounded border border-slate-200">
                        ✓ {sch}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Instant Trigger Buttons */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() => handleSendInstantFeeReminder(item, 'whatsapp')}
                    disabled={reminderDispatching === item.term}
                    className="flex-1 py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{reminderDispatching === item.term ? 'Sending...' : 'Send WhatsApp Reminder'}</span>
                  </button>

                  <button
                    onClick={() => handleSendInstantFeeReminder(item, 'sms')}
                    disabled={reminderDispatching === item.term}
                    className="flex-1 py-2 px-3 bg-blue-950 hover:bg-blue-900 text-amber-400 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5 shadow"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>{reminderDispatching === item.term ? 'Sending...' : 'Send SMS Reminder'}</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* History of Sent Fee Reminders */}
        <div className="space-y-3 pt-2">
          <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
            <SendHorizontal className="w-4 h-4 text-blue-900" />
            <span>Recent Dispatched Automated Fee Reminders Log</span>
          </h4>

          {feeRemindersLog.length === 0 ? (
            <p className="text-xs text-slate-500 italic">No fee reminders dispatched yet for this student.</p>
          ) : (
            <div className="space-y-2">
              {feeRemindersLog.map((log) => (
                <div key={log.id} className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        log.channel === 'whatsapp' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-900'
                      }`}>
                        {log.channel}
                      </span>
                      <span className="font-bold text-slate-900">{log.term} (₹{log.amount})</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">{log.sentAt}</span>
                  </div>
                  <p className="text-[11px] text-slate-600 font-mono bg-white p-2 rounded-xl border border-slate-200">
                    {log.messageText}
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-slate-500 pt-0.5">
                    <span>Sent to: +91 {log.parentPhone}</span>
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      {log.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* SAMPLE TEST ALERT PREVIEW MODAL */}
      {testModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setTestModal(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2">
              <div className="p-2.5 bg-amber-100 text-blue-950 rounded-xl">
                <Volume2 className="w-5 h-5 text-amber-800" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">
                  {testModal.type === 'whatsapp' ? 'WhatsApp Alert Simulation' : 'SMS Alert Simulation'}
                </h4>
                <p className="text-xs text-slate-500">Destination: +91 {whatsappNumber}</p>
              </div>
            </div>

            {/* Simulated Phone Screen Container */}
            <div className="bg-slate-900 rounded-2xl p-4 text-white font-sans text-xs space-y-3 border border-slate-800 shadow-inner">
              <div className="flex justify-between items-center text-[10px] text-slate-400 border-b border-slate-800 pb-2">
                <span>Wisdom School Gateway</span>
                <span>Just Now</span>
              </div>
              <p className="bg-blue-950/80 p-3 rounded-xl border border-blue-800 leading-relaxed font-mono text-[11px] text-amber-300">
                {testModal.message}
              </p>
            </div>

            {testSentSuccess ? (
              <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-900 font-bold flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-600" />
                <span>Test message dispatched to +91 {whatsappNumber}! Check your phone.</span>
              </div>
            ) : null}

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setTestModal(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-extrabold text-xs hover:bg-slate-200 transition"
              >
                Close
              </button>
              <button
                type="button"
                onClick={handleSendTestMessage}
                disabled={testSending}
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs transition flex items-center gap-1.5 shadow"
              >
                <SendHorizontal className="w-4 h-4" />
                <span>{testSending ? 'Sending Sample Alert...' : 'Dispatch Sample Alert Now'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

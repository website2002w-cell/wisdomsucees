import React, { useState, useEffect, useRef } from 'react';
import { QRCodeSVG, QRCodeCanvas } from 'qrcode.react';
import {
  CreditCard,
  QrCode,
  CheckCircle2,
  Copy,
  Download,
  Share2,
  Printer,
  Sparkles,
  PhoneCall,
  ShieldCheck,
  AlertCircle,
  FileCheck,
  History,
  Search,
  Filter,
  Eye,
  X,
  FileText,
  Check,
  Building,
  User,
  Calendar,
  ArrowUpRight,
  RefreshCw,
  Award,
  Bell,
  BellRing,
  Clock,
  Send,
  Smartphone,
  Volume2,
  Zap,
  Sliders,
  MessageSquare,
  ShieldAlert,
  Lock,
  Wallet,
  Fingerprint,
  KeyRound,
  Plus,
  Trash2,
  Edit3,
  Bus,
  Trophy,
  GraduationCap,
  Settings,
  FileSpreadsheet,
  Save,
  Tag,
  Mail,
  MessageCircle,
  SendHorizontal,
  PrinterCheck,
  CheckSquare,
  Square,
  CalendarDays,
  PieChart,
  Calculator,
  Layers,
  ArrowRight,
  Percent,
} from 'lucide-react';
import { SCHOOL_INFO, GRADE_FEE_STRUCTURE } from '../data/schoolData';
import { FeeReceipt, FeeCategory, StudentInstallmentPlan, FeeInstallmentItem } from '../types';
import {
  generateReceiptPdf,
  generateBulkReceiptsPdf,
  generatePrintableReminderPdf,
  generateBulkPrintableRemindersPdf,
  generateInstallmentSchedulePdf,
  FeeReminderNoticeData,
} from '../utils/generateReceiptPdf';

const INITIAL_RECEIPTS: FeeReceipt[] = [
  {
    receiptNo: 'WNS-RCP-2026-8801',
    studentName: 'R. Kavin',
    studentId: 'WNS-2026-01',
    grade: 'Class 3',
    term: 'TERM 1 FEE',
    amount: 4500,
    paymentMethod: 'UPI (GPay)',
    transactionRef: '382910482910',
    date: '27/07/2026',
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8802',
    studentName: 'R. Kavin',
    studentId: 'WNS-2026-01',
    grade: 'Class 3',
    term: 'BOOK SET & NOTEBOOKS',
    amount: 1500,
    paymentMethod: 'UPI (PhonePe)',
    transactionRef: '948201948201',
    date: '04/07/2026',
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8803',
    studentName: 'S. Priyanka',
    studentId: 'WNS-2026-02',
    grade: 'LKG',
    term: 'TERM 1 FEE',
    amount: 3500,
    paymentMethod: 'UPI (GPay)',
    transactionRef: '552019482910',
    date: '24/07/2026',
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8804',
    studentName: 'M. Yogesh',
    studentId: 'WNS-2026-03',
    grade: 'Class 5',
    term: 'TERM 1 FEE',
    amount: 5000,
    paymentMethod: 'UPI (Paytm)',
    transactionRef: '882019481102',
    date: '17/07/2026',
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8805',
    studentName: 'M. Yogesh',
    studentId: 'WNS-2026-03',
    grade: 'Class 5',
    term: 'UNIFORM & ACCESSORIES',
    amount: 1800,
    paymentMethod: 'UPI (GPay)',
    transactionRef: '771920394810',
    date: '29/06/2026',
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8806',
    studentName: 'K. Ananya',
    studentId: 'WNS-2026-04',
    grade: 'LKG',
    term: 'TERM 1 FEE',
    amount: 3500,
    paymentMethod: 'UPI (BHIM)',
    transactionRef: '481920391820',
    date: '28/07/2026',
    status: 'VERIFIED',
  },
];

export const FeePaymentSection: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'pay' | 'history' | 'installments' | 'push_reminders' | 'fee_structure'>('pay');
  const [studentName, setStudentName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('Class 3');
  const [selectedFeeType, setSelectedFeeType] = useState<string>('term1');
  const [customAmount, setCustomAmount] = useState<number>(4500);
  const [transactionRef, setTransactionRef] = useState('');

  // Dynamic QR Code Generator State & Canvas Ref
  const qrCanvasRef = useRef<HTMLCanvasElement>(null);
  const [qrColorStyle, setQrColorStyle] = useState<'standard' | 'school'>('standard');
  const [showPayloadDetails, setShowPayloadDetails] = useState<boolean>(false);

  // Installment Plan Selection State for Payment Form
  const [paymentPlanType, setPaymentPlanType] = useState<'Full Payment' | 'Quarterly' | 'Monthly'>('Full Payment');
  const [selectedInstallmentNo, setSelectedInstallmentNo] = useState<number>(1);

  // Student Installment Plans Database State for Installments Dashboard
  const [studentInstallmentPlans, setStudentInstallmentPlans] = useState<StudentInstallmentPlan[]>([
    {
      studentId: 'WNS-2026-01',
      studentName: 'R. Kavin',
      grade: 'Class 3',
      totalAnnualFee: 14000,
      planType: 'Quarterly',
      installments: [
        { installmentNumber: 1, title: 'Quarter 1 (Q1)', period: 'April - June 2026', dueDate: '15 April 2026', amount: 3500, paidAmount: 3500, status: 'PAID', receiptNo: 'WNS-RCP-2026-8801' },
        { installmentNumber: 2, title: 'Quarter 2 (Q2)', period: 'July - September 2026', dueDate: '15 August 2026', amount: 3500, paidAmount: 0, status: 'DUE' },
        { installmentNumber: 3, title: 'Quarter 3 (Q3)', period: 'October - December 2026', dueDate: '15 October 2026', amount: 3500, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 4, title: 'Quarter 4 (Q4)', period: 'January - March 2027', dueDate: '15 January 2027', amount: 3500, paidAmount: 0, status: 'UPCOMING' },
      ],
    },
    {
      studentId: 'WNS-2026-02',
      studentName: 'S. Priyanka',
      grade: 'LKG',
      totalAnnualFee: 11200,
      planType: 'Monthly',
      installments: [
        { installmentNumber: 1, title: 'Month 1', period: 'June 2026', dueDate: '10 June 2026', amount: 1120, paidAmount: 1120, status: 'PAID', receiptNo: 'WNS-RCP-2026-8803' },
        { installmentNumber: 2, title: 'Month 2', period: 'July 2026', dueDate: '10 July 2026', amount: 1120, paidAmount: 1120, status: 'PAID', receiptNo: 'WNS-RCP-2026-8810' },
        { installmentNumber: 3, title: 'Month 3', period: 'August 2026', dueDate: '10 August 2026', amount: 1120, paidAmount: 0, status: 'DUE' },
        { installmentNumber: 4, title: 'Month 4', period: 'September 2026', dueDate: '10 September 2026', amount: 1120, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 5, title: 'Month 5', period: 'October 2026', dueDate: '10 October 2026', amount: 1120, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 6, title: 'Month 6', period: 'November 2026', dueDate: '10 November 2026', amount: 1120, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 7, title: 'Month 7', period: 'December 2026', dueDate: '10 December 2026', amount: 1120, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 8, title: 'Month 8', period: 'January 2027', dueDate: '10 January 2027', amount: 1120, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 9, title: 'Month 9', period: 'February 2027', dueDate: '10 February 2027', amount: 1120, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 10, title: 'Month 10', period: 'March 2027', dueDate: '10 March 2027', amount: 1120, paidAmount: 0, status: 'UPCOMING' },
      ],
    },
    {
      studentId: 'WNS-2026-03',
      studentName: 'M. Yogesh',
      grade: 'Class 5',
      totalAnnualFee: 16800,
      planType: 'Quarterly',
      installments: [
        { installmentNumber: 1, title: 'Quarter 1 (Q1)', period: 'April - June 2026', dueDate: '15 April 2026', amount: 4200, paidAmount: 4200, status: 'PAID', receiptNo: 'WNS-RCP-2026-8804' },
        { installmentNumber: 2, title: 'Quarter 2 (Q2)', period: 'July - September 2026', dueDate: '18 August 2026', amount: 4200, paidAmount: 0, status: 'DUE' },
        { installmentNumber: 3, title: 'Quarter 3 (Q3)', period: 'October - December 2026', dueDate: '15 October 2026', amount: 4200, paidAmount: 0, status: 'UPCOMING' },
        { installmentNumber: 4, title: 'Quarter 4 (Q4)', period: 'January - March 2027', dueDate: '15 January 2027', amount: 4200, paidAmount: 0, status: 'UPCOMING' },
      ],
    },
  ]);

  const [selectedStudentPlanId, setSelectedStudentPlanId] = useState<string>('WNS-2026-01');
  const [installmentCalculatorAmount, setInstallmentCalculatorAmount] = useState<number>(15000);

  const [copiedUpi, setCopiedUpi] = useState(false);
  const [generatedReceipt, setGeneratedReceipt] = useState<FeeReceipt | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [submissionMessage, setSubmissionMessage] = useState('');

  // Fee Categories Management State
  const [feeCategories, setFeeCategories] = useState<FeeCategory[]>([
    {
      id: 'fee-admission',
      key: 'admission',
      name: 'Admission Fee (New Enrollments)',
      amount: 2500,
      description: 'One-time registration, ID card, prospectus & admission processing',
      deletable: false,
      editable: true,
      categoryType: 'Admission',
      frequency: 'One-Time',
    },
    {
      id: 'fee-sports',
      key: 'sports',
      name: 'Sports & Annual Athletic Fee',
      amount: 1200,
      description: 'Annual sports equipment, physical education coaching & athletic meet',
      deletable: false,
      editable: true,
      categoryType: 'Sports',
      frequency: 'Annual',
    },
    {
      id: 'fee-van-1',
      key: 'van_route_1',
      name: 'School Van / Transport Fee (Route 1 - Essur Local)',
      amount: 1500,
      description: 'Doorstep pickup & drop-off for Essur village and surrounding areas',
      deletable: true,
      editable: true,
      categoryType: 'Van / Transport',
      frequency: 'Term-wise',
    },
    {
      id: 'fee-van-2',
      key: 'van_route_2',
      name: 'School Van / Transport Fee (Route 2 - Cheyyur / Highway)',
      amount: 1800,
      description: 'Van service covering Cheyyur highway and suburban stops',
      deletable: true,
      editable: true,
      categoryType: 'Van / Transport',
      frequency: 'Term-wise',
    },
    {
      id: 'fee-term1',
      key: 'term1',
      name: 'Term 1 Tuition & Activity Fee',
      amount: 4500,
      description: 'Academic tuition & classroom learning for Term 1',
      deletable: false,
      editable: true,
      categoryType: 'Tuition',
      frequency: 'Term-wise',
    },
    {
      id: 'fee-term2',
      key: 'term2',
      name: 'Term 2 Tuition & Activity Fee',
      amount: 4500,
      description: 'Academic tuition & classroom learning for Term 2',
      deletable: false,
      editable: true,
      categoryType: 'Tuition',
      frequency: 'Term-wise',
    },
    {
      id: 'fee-term3',
      key: 'term3',
      name: 'Term 3 Tuition & Activity Fee',
      amount: 3800,
      description: 'Academic tuition & classroom learning for Term 3',
      deletable: false,
      editable: true,
      categoryType: 'Tuition',
      frequency: 'Term-wise',
    },
    {
      id: 'fee-books',
      key: 'books',
      name: 'Book Set, Workbooks & Stationary',
      amount: 2000,
      description: 'Tamil Nadu Board textbooks, note copies and homework diaries',
      deletable: false,
      editable: true,
      categoryType: 'Books',
      frequency: 'Annual',
    },
    {
      id: 'fee-uniform',
      key: 'uniform',
      name: 'Uniform, Sports Jersey & Accessories',
      amount: 1500,
      description: '2 sets school uniform, sports jersey and school badge',
      deletable: false,
      editable: true,
      categoryType: 'Uniform',
      frequency: 'Annual',
    },
  ]);

  // Modal State for Editing / Adding Fee Categories
  const [editingFeeCat, setEditingFeeCat] = useState<FeeCategory | null>(null);
  const [showAddFeeModal, setShowAddFeeModal] = useState<boolean>(false);
  const [feeCatForm, setFeeCatForm] = useState({
    id: '',
    name: '',
    amount: 1000,
    description: '',
    categoryType: 'Van / Transport',
    frequency: 'Term-wise',
  });
  const [feeCatSuccessMsg, setFeeCatSuccessMsg] = useState('');

  // Fetch Fee Categories from server
  useEffect(() => {
    fetch('/api/fees/categories')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && Array.isArray(data.categories) && data.categories.length > 0) {
          setFeeCategories(data.categories);
        }
      })
      .catch(() => {});
  }, []);

  const handleOpenEditFeeCat = (cat: FeeCategory) => {
    setEditingFeeCat(cat);
    setFeeCatForm({
      id: cat.id,
      name: cat.name,
      amount: cat.amount,
      description: cat.description,
      categoryType: cat.categoryType || 'Other',
      frequency: cat.frequency || 'Term-wise',
    });
  };

  const handleOpenAddFeeCat = () => {
    setEditingFeeCat(null);
    setFeeCatForm({
      id: '',
      name: 'School Van / Transport Fee (Route 3)',
      amount: 1600,
      description: 'New route pickup for surrounding villages',
      categoryType: 'Van / Transport',
      frequency: 'Term-wise',
    });
    setShowAddFeeModal(true);
  };

  const handleSaveFeeCat = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feeCatForm.name.trim() || feeCatForm.amount < 0) {
      alert('Please enter a valid Fee Name and Amount');
      return;
    }

    try {
      const res = await fetch('/api/fees/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(feeCatForm),
      });
      const data = await res.json();
      if (data.success && data.categories) {
        setFeeCategories(data.categories);
        setFeeCatSuccessMsg(`✓ Successfully saved fee category "${feeCatForm.name}"!`);
        setTimeout(() => setFeeCatSuccessMsg(''), 3000);
        setEditingFeeCat(null);
        setShowAddFeeModal(false);
      } else {
        alert(data.message || 'Error saving fee category');
      }
    } catch (err) {
      console.error(err);
      setFeeCategories((prev) => {
        const idx = prev.findIndex((c) => c.id === feeCatForm.id);
        if (idx !== -1) {
          const updated = [...prev];
          updated[idx] = {
            ...updated[idx],
            name: feeCatForm.name,
            amount: feeCatForm.amount,
            description: feeCatForm.description,
            categoryType: feeCatForm.categoryType,
            frequency: feeCatForm.frequency,
          };
          return updated;
        } else {
          const newCat: FeeCategory = {
            id: `fee-custom-${Date.now()}`,
            key: feeCatForm.name.toLowerCase().replace(/[^a-z0-9]/g, '_'),
            name: feeCatForm.name,
            amount: feeCatForm.amount,
            description: feeCatForm.description,
            deletable: true,
            editable: true,
            categoryType: feeCatForm.categoryType,
            frequency: feeCatForm.frequency,
          };
          return [...prev, newCat];
        }
      });
      setFeeCatSuccessMsg(`✓ Saved fee category "${feeCatForm.name}"`);
      setTimeout(() => setFeeCatSuccessMsg(''), 3000);
      setEditingFeeCat(null);
      setShowAddFeeModal(false);
    }
  };

  const handleDeleteFeeCat = async (cat: FeeCategory) => {
    if (!window.confirm(`Are you sure you want to delete "${cat.name}"? This fee category will be removed.`)) {
      return;
    }

    try {
      const res = await fetch(`/api/fees/categories/${cat.id}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (data.success && data.categories) {
        setFeeCategories(data.categories);
        setFeeCatSuccessMsg(`✓ Deleted fee category "${cat.name}"`);
        setTimeout(() => setFeeCatSuccessMsg(''), 3000);
      } else {
        alert(data.message || 'Error deleting fee category');
      }
    } catch (err) {
      console.error(err);
      setFeeCategories((prev) => prev.filter((c) => c.id !== cat.id));
      setFeeCatSuccessMsg(`✓ Deleted fee category "${cat.name}"`);
      setTimeout(() => setFeeCatSuccessMsg(''), 3000);
    }
  };

  // Saved UPI ID & Pre-Authorized Auto-Mandate State
  const [savedUpiId, setSavedUpiId] = useState<string>('parent.kavin@okhdfcbank');
  const [isUpiSaved, setIsUpiSaved] = useState<boolean>(true);
  const [autoDebitEnabled, setAutoDebitEnabled] = useState<boolean>(true);
  const [editingUpi, setEditingUpi] = useState<boolean>(false);
  const [tempUpiInput, setTempUpiInput] = useState<string>('parent.kavin@okhdfcbank');

  // Authorization Modal State for Recurring 3-Day Fee Mandates
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [pendingAuthItem, setPendingAuthItem] = useState<{
    term: string;
    amount: number;
    dueDate: string;
    studentName: string;
    studentId: string;
  } | null>(null);
  const [upiPin, setUpiPin] = useState<string>('');
  const [authStep, setAuthStep] = useState<'pin' | 'verifying' | 'success'>('pin');
  const [authError, setAuthError] = useState<string>('');

  // Open UPI Pre-Authorization PIN Modal
  const handleOpenAuthorizationModal = (item?: {
    term?: string;
    amount?: number;
    dueDate?: string;
    studentName?: string;
    studentId?: string;
  }) => {
    setPendingAuthItem({
      term: item?.term || 'Term 2 Tuition & Activity Fee',
      amount: item?.amount || 3500,
      dueDate: item?.dueDate || '15 August 2026',
      studentName: item?.studentName || studentName || 'R. Kavin',
      studentId: item?.studentId || studentId || 'WNS-2026-01',
    });
    setUpiPin('');
    setAuthError('');
    setAuthStep('pin');
    setAuthModalOpen(true);
  };

  // Submit UPI PIN and authorize transaction
  const handleConfirmUpiPinAuthorization = () => {
    if (!upiPin || upiPin.length < 4) {
      setAuthError('Please enter your 4 or 6-digit secure UPI security PIN');
      return;
    }
    setAuthError('');
    setAuthStep('verifying');

    setTimeout(() => {
      const newReceiptNo = `WNS-RCP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
      const newReceipt: FeeReceipt = {
        receiptNo: newReceiptNo,
        studentName: pendingAuthItem?.studentName || studentName || 'R. Kavin',
        studentId: pendingAuthItem?.studentId || studentId || 'WNS-2026-01',
        grade: selectedGrade || 'Class 3',
        term: pendingAuthItem?.term || 'Term 2 Tuition & Activity Fee',
        amount: pendingAuthItem?.amount || 3500,
        paymentMethod: `UPI Auto-Mandate (${savedUpiId})`,
        transactionRef: `UTR-${Math.floor(100000000000 + Math.random() * 900000000000)}`,
        date: new Date().toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
        status: 'VERIFIED',
      };

      setReceiptsList((prev) => [newReceipt, ...prev]);

      const auditLog = {
        id: `AUTOD-${Date.now().toString().slice(-6)}`,
        studentName: pendingAuthItem?.studentName || 'R. Kavin',
        term: pendingAuthItem?.term || 'Term 2 Tuition Fee',
        amount: pendingAuthItem?.amount || 3500,
        channel: 'UPI Auto-Mandate',
        sentAt: new Date().toLocaleString('en-IN'),
        status: 'AUTHORIZED_&_EXECUTED',
        messageText: `✓ Pre-Authorized Fee Auto-Debit executed for ${pendingAuthItem?.term} (₹${pendingAuthItem?.amount}) via ${savedUpiId}. Receipt ${newReceiptNo} issued.`,
      };
      setReminderLogs((prev) => [auditLog, ...prev]);

      setAuthStep('success');
    }, 1200);
  };

  // Save UPI ID Handler
  const handleSaveUpiId = () => {
    if (!tempUpiInput || !tempUpiInput.includes('@')) {
      alert('Please enter a valid UPI ID format (e.g., 9876543210@upi or parent@okaxis)');
      return;
    }
    setSavedUpiId(tempUpiInput.trim());
    setIsUpiSaved(true);
    setEditingUpi(false);
    alert(`✓ Saved UPI ID successfully: ${tempUpiInput.trim()}. You can now use 1-tap pre-authorized fee payments!`);
  };

  // Payment History State
  const [receiptsList, setReceiptsList] = useState<FeeReceipt[]>(INITIAL_RECEIPTS);
  const [searchQuery, setSearchQuery] = useState('');
  const [gradeFilter, setGradeFilter] = useState('ALL');
  const [previewReceipt, setPreviewReceipt] = useState<FeeReceipt | null>(null);
  const [copiedReceiptNo, setCopiedReceiptNo] = useState<string | null>(null);

  // Bulk Receipts Selection State
  const [selectedReceiptNos, setSelectedReceiptNos] = useState<string[]>([]);

  const toggleSelectReceipt = (receiptNo: string) => {
    setSelectedReceiptNos((prev) =>
      prev.includes(receiptNo) ? prev.filter((r) => r !== receiptNo) : [...prev, receiptNo]
    );
  };

  const toggleSelectAllReceipts = (receiptsToToggle: FeeReceipt[]) => {
    if (selectedReceiptNos.length === receiptsToToggle.length) {
      setSelectedReceiptNos([]);
    } else {
      setSelectedReceiptNos(receiptsToToggle.map((r) => r.receiptNo));
    }
  };

  const handleDownloadBulkSelectedReceipts = () => {
    const selectedObjs = receiptsList.filter((r) => selectedReceiptNos.includes(r.receiptNo));
    if (selectedObjs.length === 0) {
      alert('Please select at least one fee receipt to download in bulk.');
      return;
    }
    generateBulkReceiptsPdf(selectedObjs);
  };

  // Multi-Channel Fee Notification Center & Bulk Reminders State
  const [upcomingDueParents, setUpcomingDueParents] = useState<FeeReminderNoticeData[]>([
    {
      studentId: 'WNS-2026-01',
      studentName: 'R. Kavin',
      grade: 'Class 3-A',
      parentName: 'R. Saravanan',
      parentPhone: '9876543210',
      parentEmail: 'saravanan.kavin@example.com',
      feeParticulars: 'Term 2 Tuition & Activity Fee',
      amountDue: 3500,
      dueDate: '15 August 2026',
    },
    {
      studentId: 'WNS-2026-02',
      studentName: 'S. Priyanka',
      grade: 'LKG Blossom',
      parentName: 'S. Sundaram',
      parentPhone: '9876543211',
      parentEmail: 'sundaram.priyanka@example.com',
      feeParticulars: 'Term 2 Activity & Rhymes Fee',
      amountDue: 2800,
      dueDate: '15 August 2026',
    },
    {
      studentId: 'WNS-2026-03',
      studentName: 'M. Yogesh',
      grade: 'Class 5-A',
      parentName: 'M. Manikandan',
      parentPhone: '9876543212',
      parentEmail: 'manikandan.yogesh@example.com',
      feeParticulars: 'Term 2 Tuition & Computer Lab Fee',
      amountDue: 4200,
      dueDate: '18 August 2026',
    },
    {
      studentId: 'WNS-2026-04',
      studentName: 'K. Ananya',
      grade: 'LKG-A',
      parentName: 'Karthik Raja',
      parentPhone: '9876543213',
      parentEmail: 'karthik.ananya@example.com',
      feeParticulars: 'School Van Transport Fee (Term 2)',
      amountDue: 1500,
      dueDate: '10 August 2026',
    },
    {
      studentId: 'WNS-2026-05',
      studentName: 'V. Dhanya',
      grade: 'Class 2-B',
      parentName: 'V. Velu',
      parentPhone: '9876543214',
      parentEmail: 'velu.dhanya@example.com',
      feeParticulars: 'Book Set & Notebook Balance',
      amountDue: 1800,
      dueDate: '12 August 2026',
    },
  ]);

  const [selectedDueStudentIds, setSelectedDueStudentIds] = useState<string[]>([
    'WNS-2026-01',
    'WNS-2026-02',
    'WNS-2026-03',
    'WNS-2026-04',
    'WNS-2026-05',
  ]);

  const [selectedChannels, setSelectedChannels] = useState<{
    whatsapp: boolean;
    sms: boolean;
    email: boolean;
    push: boolean;
  }>({
    whatsapp: true,
    sms: true,
    email: true,
    push: true,
  });

  const [customBulkTemplate, setCustomBulkTemplate] = useState<string>(
    '🔔 [Wisdom Nursery & Primary School, Essur]\nDear Parent, gentle fee payment reminder for {student_name} ({student_id}, {fee_term}).\n\nAmount Payable: {amount}\nDue Date: {due_date}\nOfficial School UPI: rsaravanan102002-1@okhdfcbank\n\nPay online instantly: https://wisdomessur.edu.in/fees?studentId={student_id}\nHelpdesk: +91 9176593129'
  );

  const [bulkDispatching, setBulkDispatching] = useState<boolean>(false);
  const [bulkDispatchReport, setBulkDispatchReport] = useState<{
    totalSent: number;
    whatsapp: number;
    sms: number;
    email: number;
    push: number;
    message: string;
  } | null>(null);

  const toggleSelectDueStudent = (id: string) => {
    setSelectedDueStudentIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const toggleSelectAllDueStudents = () => {
    if (selectedDueStudentIds.length === upcomingDueParents.length) {
      setSelectedDueStudentIds([]);
    } else {
      setSelectedDueStudentIds(upcomingDueParents.map((p) => p.studentId));
    }
  };

  const handleDispatchBulkReminders = async () => {
    const targets = upcomingDueParents.filter((p) => selectedDueStudentIds.includes(p.studentId));
    if (targets.length === 0) {
      alert('Please select at least one parent/student for bulk notification.');
      return;
    }

    const activeChannels = Object.entries(selectedChannels)
      .filter(([_, active]) => active)
      .map(([ch]) => ch);

    if (activeChannels.length === 0) {
      alert('Please select at least one delivery channel (WhatsApp, SMS, Email, or Push).');
      return;
    }

    setBulkDispatching(true);
    setBulkDispatchReport(null);

    try {
      const res = await fetch('/api/student/fee-reminders/bulk-send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          targets,
          channels: activeChannels,
          customMessage: customBulkTemplate,
        }),
      });

      const data = await res.json();
      if (data.success) {
        playPushChime();
        setBulkDispatchReport({
          totalSent: data.totalSent,
          whatsapp: data.channelBreakdown?.whatsapp || 0,
          sms: data.channelBreakdown?.sms || 0,
          email: data.channelBreakdown?.email || 0,
          push: data.channelBreakdown?.push || 0,
          message: data.message,
        });

        if (Array.isArray(data.logs)) {
          setReminderLogs((prev) => [...data.logs, ...prev]);
        }
      }
    } catch (err) {
      console.error('Bulk dispatch error:', err);
      playPushChime();
      const newLogs: any[] = [];
      let waCount = 0;
      let smsCount = 0;
      let emailCount = 0;
      let pushCount = 0;

      targets.forEach((t) => {
        activeChannels.forEach((ch) => {
          if (ch === 'whatsapp') waCount++;
          if (ch === 'sms') smsCount++;
          if (ch === 'email') emailCount++;
          if (ch === 'push') pushCount++;

          newLogs.push({
            id: `REM-${Date.now().toString().slice(-5)}-${Math.floor(Math.random() * 100)}`,
            studentName: t.studentName,
            term: t.feeParticulars,
            amount: t.amountDue,
            channel: ch,
            sentAt: new Date().toLocaleString('en-IN'),
            status: 'DELIVERED',
            messageText: `[Bulk ${ch.toUpperCase()}] Fee due reminder for ${t.studentName}: ${t.feeParticulars} ₹${t.amountDue} due on ${t.dueDate}.`,
          });
        });
      });

      setReminderLogs((prev) => [...newLogs, ...prev]);
      setBulkDispatchReport({
        totalSent: newLogs.length,
        whatsapp: waCount,
        sms: smsCount,
        email: emailCount,
        push: pushCount,
        message: `Bulk reminders dispatched to ${targets.length} parents across ${activeChannels.join(', ').toUpperCase()}!`,
      });
    } finally {
      setBulkDispatching(false);
    }
  };

  const handleDownloadBulkNoticesPdf = () => {
    const selectedNotices = upcomingDueParents.filter((p) => selectedDueStudentIds.includes(p.studentId));
    if (selectedNotices.length === 0) {
      alert('Please select at least one student to generate printable fee notices.');
      return;
    }
    generateBulkPrintableRemindersPdf(selectedNotices);
  };

  // Push Notification System State
  const [pushPermission, setPushPermission] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );
  const [reminderDaysBefore, setReminderDaysBefore] = useState<number>(3); // Default 3 days before fee deadline
  const [reminderTone, setReminderTone] = useState<'gentle' | 'standard' | 'urgent'>('gentle');
  const [channelBrowserPush, setChannelBrowserPush] = useState<boolean>(true);
  const [channelWhatsapp, setChannelWhatsapp] = useState<boolean>(true);
  const [channelSms, setChannelSms] = useState<boolean>(true);

  const [activePushToast, setActivePushToast] = useState<{
    title: string;
    body: string;
    term: string;
    amount: number;
    dueDate: string;
    studentName: string;
    studentId: string;
  } | null>(null);

  const [reminderLogs, setReminderLogs] = useState<Array<{
    id: string;
    studentName: string;
    term: string;
    amount: number;
    channel: string;
    sentAt: string;
    status: string;
    messageText: string;
  }>>([
    {
      id: 'REM-2026-901',
      studentName: 'R. Kavin',
      term: 'Term 2 Tuition Fee',
      amount: 3500,
      channel: 'push',
      sentAt: '27/07/2026, 09:30 AM',
      status: 'DELIVERED',
      messageText: '🔔 Gentle Fee Reminder: Term 2 Fee ₹3,500 for R. Kavin is due in 3 days (15-Aug-2026). Tap to pay via GPay/PhonePe.',
    },
    {
      id: 'REM-2026-902',
      studentName: 'R. Kavin',
      term: 'Book Set & Stationary',
      amount: 1500,
      channel: 'whatsapp',
      sentAt: '24/07/2026, 10:15 AM',
      status: 'DELIVERED',
      messageText: '🔔 Gentle Reminder: Book Set Fee ₹1,500 for R. Kavin due on 05-Aug-2026. Official School UPI: rsaravanan102002-1@okhdfcbank',
    },
  ]);

  const [upcomingFeeDeadlines] = useState([
    {
      id: 'FEE-DEADLINE-01',
      term: 'Term 2 Tuition & Activity Fee',
      grade: 'Class 3-A',
      amount: 3500,
      dueDate: '15 August 2026',
      scheduledPushDate: '12 August 2026 (3 Days Prior)',
      status: 'SCHEDULED_3_DAYS_PRIOR',
      studentName: 'R. Kavin',
    },
    {
      id: 'FEE-DEADLINE-02',
      term: 'School Van Transport Fee (Term 2)',
      grade: 'Class 1 to 5',
      amount: 1200,
      dueDate: '10 August 2026',
      scheduledPushDate: '07 August 2026 (3 Days Prior)',
      status: 'SCHEDULED_3_DAYS_PRIOR',
      studentName: 'R. Kavin',
    },
    {
      id: 'FEE-DEADLINE-03',
      term: 'Book Set & Notebook Balance',
      grade: 'Pre-Nursery to Class 5',
      amount: 1500,
      dueDate: '05 August 2026',
      scheduledPushDate: '02 August 2026 (3 Days Prior)',
      status: 'SCHEDULED_3_DAYS_PRIOR',
      studentName: 'R. Kavin',
    },
    {
      id: 'FEE-DEADLINE-04',
      term: 'Term 3 Final Tuition Fee',
      grade: 'All Standard',
      amount: 4500,
      dueDate: '20 December 2026',
      scheduledPushDate: '17 December 2026 (3 Days Prior)',
      status: 'SCHEDULED_3_DAYS_PRIOR',
      studentName: 'R. Kavin',
    },
  ]);

  // Audio Chime Synthesizer for Push Notifications
  const playPushChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc1 = ctx.createOscillator();
      const osc2 = ctx.createOscillator();
      const gain = ctx.createGain();

      osc1.type = 'sine';
      osc2.type = 'sine';
      osc1.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc2.frequency.setValueAtTime(880, ctx.currentTime + 0.12); // A5

      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);

      osc1.connect(gain);
      osc2.connect(gain);
      gain.connect(ctx.destination);

      osc1.start(ctx.currentTime);
      osc1.stop(ctx.currentTime + 0.12);
      osc2.start(ctx.currentTime + 0.12);
      osc2.stop(ctx.currentTime + 0.45);
    } catch {}
  };

  // Request Web Push Permission
  const handleRequestPushPermission = async () => {
    if (typeof Notification === 'undefined') {
      alert('In-browser Web Push API is not supported on this browser context. In-app push notifications will stay active.');
      return;
    }
    try {
      const perm = await Notification.requestPermission();
      setPushPermission(perm);
      if (perm === 'granted') {
        alert('✓ Browser Push Notifications Granted! Automated 3-day fee deadline reminders will now alert directly on your device.');
      } else {
        alert('Browser notification permission was not granted. In-app floating push alerts will continue to work.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Dispatch Test Push Notification
  const handleTriggerPushNotification = async (item?: {
    term?: string;
    amount?: number;
    dueDate?: string;
    studentName?: string;
  }) => {
    const name = item?.studentName || studentName || 'R. Kavin';
    const term = item?.term || 'Term 2 Tuition & Activity Fee';
    const amount = item?.amount || 3500;
    const dueDate = item?.dueDate || '15 August 2026';

    const leadText = `${reminderDaysBefore} days before deadline`;
    const bodyMsg = reminderTone === 'gentle'
      ? `Dear Parent, this is a gentle reminder that ${term} (₹${amount.toLocaleString('en-IN')}) for ${name} is due on ${dueDate} (${leadText}). Tap here to pay via UPI.`
      : reminderTone === 'standard'
      ? `School Fee Alert: ${term} of ₹${amount.toLocaleString('en-IN')} for ${name} is due on ${dueDate}. Please pay via UPI or school office.`
      : `IMPORTANT: Fee due in ${reminderDaysBefore} days! ${term} ₹${amount.toLocaleString('en-IN')} for ${name}. Pay immediately to avoid late process.`;

    const titleMsg = `🔔 Fee Deadline Reminder (${reminderDaysBefore} Days Prior)`;

    playPushChime();

    // Browser Native Push Notification if permitted
    if (typeof Notification !== 'undefined') {
      if (Notification.permission === 'granted') {
        try {
          new Notification(titleMsg, {
            body: bodyMsg,
            icon: SCHOOL_INFO.logoUrl,
          });
        } catch (e) {
          console.warn('Native push failed', e);
        }
      } else if (Notification.permission === 'default') {
        try {
          const perm = await Notification.requestPermission();
          setPushPermission(perm);
          if (perm === 'granted') {
            new Notification(titleMsg, {
              body: bodyMsg,
              icon: SCHOOL_INFO.logoUrl,
            });
          }
        } catch {}
      }
    }

    // Trigger In-App Floating Toast Banner
    setActivePushToast({
      title: titleMsg,
      body: bodyMsg,
      term,
      amount,
      dueDate,
      studentName: name,
      studentId: studentId || 'WNS-2026-01',
    });

    // Send POST log to backend
    try {
      const res = await fetch('/api/student/fee-reminders/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: studentId || 'WNS-2026-01',
          studentName: name,
          parentPhone: '9876543210',
          channel: 'push',
          term,
          amount,
        }),
      });
      const data = await res.json();
      if (data.success && data.reminder) {
        setReminderLogs((prev) => [data.reminder, ...prev]);
      }
    } catch {
      const localLog = {
        id: `REM-${Date.now().toString().slice(-6)}`,
        studentName: name,
        term,
        amount,
        channel: 'push',
        sentAt: new Date().toLocaleString('en-IN'),
        status: 'DELIVERED',
        messageText: bodyMsg,
      };
      setReminderLogs((prev) => [localLog, ...prev]);
    }
  };

  // Fetch fee reminders history from backend on mount
  useEffect(() => {
    fetch('/api/student/fee-reminders/WNS-2026-01')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.history && data.history.length > 0) {
          setReminderLogs(data.history);
        }
      })
      .catch(() => {});
  }, []);

  // Fetch receipts from backend if available
  useEffect(() => {
    fetch('/api/fees/receipts')
      .then((res) => res.json())
      .then((data) => {
        if (data.success && data.receipts && data.receipts.length > 0) {
          setReceiptsList(data.receipts);
        }
      })
      .catch(() => {});
  }, []);

  // Calculate fee based on selected fee category / grade structure / custom / installment plan
  const matchedCat = feeCategories.find((c) => c.key === selectedFeeType || c.id === selectedFeeType);
  const gradeFees = GRADE_FEE_STRUCTURE[selectedGrade] || GRADE_FEE_STRUCTURE['Class 3'];
  const baseAnnualFee = gradeFees.term1 + gradeFees.term2 + gradeFees.term3 + gradeFees.books + gradeFees.uniform;

  let activeAmount = customAmount;
  let remainingBalance = 0;

  if (paymentPlanType === 'Quarterly') {
    activeAmount = Math.ceil(baseAnnualFee / 4);
    remainingBalance = Math.max(0, baseAnnualFee - (selectedInstallmentNo * activeAmount));
  } else if (paymentPlanType === 'Monthly') {
    activeAmount = Math.ceil(baseAnnualFee / 10);
    remainingBalance = Math.max(0, baseAnnualFee - (selectedInstallmentNo * activeAmount));
  } else {
    if (matchedCat) {
      activeAmount = matchedCat.amount;
    } else if (selectedFeeType === 'term1') activeAmount = gradeFees.term1;
    else if (selectedFeeType === 'term2') activeAmount = gradeFees.term2;
    else if (selectedFeeType === 'term3') activeAmount = gradeFees.term3;
    else if (selectedFeeType === 'books') activeAmount = gradeFees.books;
    else if (selectedFeeType === 'uniform') activeAmount = gradeFees.uniform;
    remainingBalance = 0;
  }

  const noteDescription = paymentPlanType !== 'Full Payment'
    ? `Fee for ${studentName || 'Student'} (${selectedGrade}) - ${paymentPlanType} Inst #${selectedInstallmentNo}`
    : `Fee for ${studentName || 'Student'} (${selectedGrade}) - ${selectedFeeType.toUpperCase()}`;

  // UPI Intent URL
  const upiUrl = `upi://pay?pa=${SCHOOL_INFO.upiId}&pn=${encodeURIComponent('R Saravanan - Wisdom School')}&am=${activeAmount}&cu=INR&tn=${encodeURIComponent(noteDescription)}`;

  // Download Dynamic QR Code Image as PNG from Canvas
  const handleDownloadQrPng = () => {
    if (!qrCanvasRef.current) return;
    try {
      const canvas = qrCanvasRef.current;
      const pngUrl = canvas.toDataURL('image/png');
      const downloadLink = document.createElement('a');
      downloadLink.href = pngUrl;
      downloadLink.download = `Wisdom_School_Fee_QR_Rs${activeAmount}_${(studentName || 'Student').replace(/\s+/g, '_')}.png`;
      document.body.appendChild(downloadLink);
      downloadLink.click();
      document.body.removeChild(downloadLink);
    } catch (err) {
      console.error('Error downloading QR code image:', err);
    }
  };

  const copyUpiToClipboard = () => {
    navigator.clipboard.writeText(SCHOOL_INFO.upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2500);
  };

  const handleRegisterPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim()) {
      alert('Please enter the Student Name.');
      return;
    }
    if (!transactionRef.trim()) {
      alert('Please enter your UTR / Transaction Reference ID from Google Pay or PhonePe.');
      return;
    }

    setSubmitting(true);
    setSubmissionMessage('');

    const termTitle = paymentPlanType !== 'Full Payment'
      ? `${paymentPlanType} Installment #${selectedInstallmentNo}`
      : selectedFeeType.toUpperCase();

    try {
      const res = await fetch('/api/fees/pay', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentName,
          studentId: studentId || 'WNS-STUDENT',
          grade: selectedGrade,
          term: termTitle,
          amount: activeAmount,
          paymentMethod: 'UPI (GPay / PhonePe)',
          transactionRef,
          installmentPlan: paymentPlanType,
          installmentNumber: paymentPlanType !== 'Full Payment' ? `Installment #${selectedInstallmentNo}` : undefined,
          remainingBalance: remainingBalance,
        }),
      });

      const data = await res.json();
      if (data.success && data.receipt) {
        setGeneratedReceipt(data.receipt);
        setReceiptsList((prev) => [data.receipt, ...prev]);
        setSubmissionMessage('Payment successfully logged and official receipt generated!');
        generateReceiptPdf(data.receipt);
      } else {
        alert(data.message || 'Error processing receipt');
      }
    } catch (err) {
      console.error(err);
      // Fallback local receipt generation
      const receipt: FeeReceipt = {
        receiptNo: `WNS-RCP-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        studentName,
        studentId: studentId || 'WNS-STUDENT',
        grade: selectedGrade,
        term: termTitle,
        amount: activeAmount,
        paymentMethod: 'UPI Transfer',
        transactionRef,
        date: new Date().toLocaleDateString('en-IN'),
        status: 'VERIFIED',
        installmentPlan: paymentPlanType,
        installmentNumber: paymentPlanType !== 'Full Payment' ? `Installment #${selectedInstallmentNo}` : undefined,
        remainingBalance: remainingBalance,
      };
      setGeneratedReceipt(receipt);
      setReceiptsList((prev) => [receipt, ...prev]);

      // Update matching student installment plan database state
      setStudentInstallmentPlans((prev) =>
        prev.map((plan) => {
          if (
            plan.studentId === (studentId || 'WNS-2026-01') ||
            plan.studentName.toLowerCase().includes(studentName.toLowerCase())
          ) {
            const updatedInsts = plan.installments.map((inst) => {
              if (inst.installmentNumber === selectedInstallmentNo) {
                return {
                  ...inst,
                  paidAmount: activeAmount,
                  status: 'PAID' as const,
                  receiptNo: receipt.receiptNo,
                };
              }
              return inst;
            });
            return { ...plan, installments: updatedInsts };
          }
          return plan;
        })
      );

      setSubmissionMessage('Payment verified! PDF Receipt downloading now...');
      generateReceiptPdf(receipt);
    } finally {
      setSubmitting(false);
    }
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  const handleCopyReceiptNo = (no: string) => {
    navigator.clipboard.writeText(no);
    setCopiedReceiptNo(no);
    setTimeout(() => setCopiedReceiptNo(null), 2000);
  };

  // Filtering Receipts for History
  const filteredReceipts = receiptsList.filter((rcp) => {
    const matchesGrade = gradeFilter === 'ALL' || rcp.grade === gradeFilter;
    const q = searchQuery.trim().toLowerCase();
    if (!q) return matchesGrade;

    const matchesSearch =
      rcp.studentName.toLowerCase().includes(q) ||
      rcp.studentId.toLowerCase().includes(q) ||
      rcp.receiptNo.toLowerCase().includes(q) ||
      rcp.transactionRef.toLowerCase().includes(q) ||
      rcp.term.toLowerCase().includes(q) ||
      rcp.grade.toLowerCase().includes(q);

    return matchesGrade && matchesSearch;
  });

  const totalFilteredAmount = filteredReceipts.reduce((sum, r) => sum + r.amount, 0);

  // Pending Payments Summary Metrics
  const totalPendingAmount = upcomingFeeDeadlines.reduce((sum, item) => sum + item.amount, 0);
  const totalPendingCount = upcomingFeeDeadlines.length;
  // Nearest due item (Book Set & Notebook Balance due 05 Aug 2026)
  const nearestDueItem = upcomingFeeDeadlines.find((item) => item.id === 'FEE-DEADLINE-03') || upcomingFeeDeadlines[0];

  return (
    <div id="payment" className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-2">
        <span className="bg-amber-100 text-amber-900 text-xs font-black uppercase px-3.5 py-1.5 rounded-full border border-amber-300 inline-flex items-center gap-1.5">
          <CreditCard className="w-3.5 h-3.5 text-amber-700" />
          Official School Payment Portal
        </span>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-blue-950">
          Online Fee Payment & Digital Receipt Records
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm">
          Pay school fees directly using any UPI App (Google Pay, PhonePe, Paytm, BHIM) and download official PDF fee receipts anytime.
        </p>
      </div>

      {/* QUICK PENDING PAYMENTS SUMMARY WIDGET */}
      <div className="bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-5 sm:p-6 border-2 border-amber-400/80 shadow-xl space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-400/20 text-amber-300 rounded-2xl border border-amber-400/30">
              <Wallet className="w-5 h-5 text-amber-400" />
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-black text-amber-300 flex items-center gap-2">
                <span>Parent Accounts Fee Summary Overview</span>
                <span className="bg-amber-400 text-blue-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  R. Kavin (Class 3-A)
                </span>
              </h3>
              <p className="text-[11px] text-slate-300">
                Live breakdown of pending term fees & priority deadlines across registered student profile.
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveSubTab('push_reminders')}
            className="text-xs text-amber-300 hover:text-amber-200 font-bold flex items-center gap-1 underline self-start sm:self-auto"
          >
            <BellRing className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Manage 3-Day Push Alerts & Schedules</span>
          </button>
        </div>

        {/* 3 Summary Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          {/* Card 1: Total Pending Balance */}
          <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 space-y-2 relative overflow-hidden">
            <div className="flex items-center justify-between text-slate-400 font-semibold text-[11px]">
              <span>Total Pending Payments</span>
              <span className="bg-red-500/20 text-red-300 border border-red-500/40 text-[10px] font-black px-2 py-0.5 rounded-full">
                {totalPendingCount} Pending Items
              </span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white">
                ₹{totalPendingAmount.toLocaleString('en-IN')}
              </span>
              <span className="text-[11px] text-slate-400 font-medium">Across all terms</span>
            </div>
            <p className="text-[10px] text-slate-400">
              Includes Tuition, Transport, Book Set & Activity Fee for AY 2026-2027
            </p>
          </div>

          {/* Card 2: Next Critical Deadline */}
          <div className="bg-slate-900/90 p-4 rounded-2xl border border-amber-500/40 space-y-2 relative overflow-hidden">
            <div className="flex items-center justify-between text-amber-300 font-semibold text-[11px]">
              <span className="flex items-center gap-1 font-extrabold text-amber-400">
                <Clock className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                Nearest Fee Deadline
              </span>
              <span className="bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-black px-2 py-0.5 rounded-full">
                Due: {nearestDueItem.dueDate}
              </span>
            </div>
            <div className="space-y-0.5">
              <h4 className="font-extrabold text-white text-sm truncate">
                {nearestDueItem.term}
              </h4>
              <div className="flex items-baseline gap-2">
                <span className="text-xl font-black text-amber-300">
                  ₹{nearestDueItem.amount.toLocaleString('en-IN')}
                </span>
                <span className="text-[10px] text-amber-200/80 font-bold bg-amber-400/10 px-1.5 py-0.5 rounded">
                  3-Day Alert Scheduled
                </span>
              </div>
            </div>
          </div>

          {/* Card 3: Saved UPI & Pre-Authorized Auto-Mandate */}
          <div className="bg-slate-900/90 p-4 rounded-2xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-slate-400 font-semibold text-[11px]">
              <span className="flex items-center gap-1 font-extrabold text-emerald-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                Saved UPI Mandate
              </span>
              <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-black px-2 py-0.5 rounded-full">
                Active
              </span>
            </div>
            <div className="space-y-1">
              <span className="font-mono font-bold text-amber-300 text-xs block truncate bg-slate-950 px-2.5 py-1 rounded-xl border border-slate-800">
                {savedUpiId}
              </span>
              <p className="text-[10px] text-slate-400">
                1-Tap Pre-Authorized payment with 4-digit UPI PIN security.
              </p>
            </div>
          </div>
        </div>

        {/* Quick Action Buttons Bar */}
        <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-[11px] text-slate-300">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>
              Tip: Pay before <strong>{nearestDueItem.dueDate}</strong> to maintain uninterrupted student portal access & book allocation.
            </span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto shrink-0">
            <button
              onClick={() => handleOpenAuthorizationModal({
                term: nearestDueItem.term,
                amount: nearestDueItem.amount,
                dueDate: nearestDueItem.dueDate,
                studentName: nearestDueItem.studentName,
              })}
              className="flex-1 sm:flex-none px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5"
            >
              <KeyRound className="w-3.5 h-3.5 text-blue-950" />
              <span>Pay Priority Fee (₹{nearestDueItem.amount.toLocaleString('en-IN')})</span>
            </button>

            <button
              onClick={() => setActiveSubTab('push_reminders')}
              className="flex-1 sm:flex-none px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-xl border border-white/20 transition flex items-center justify-center gap-1.5"
            >
              <span>View All Deadlines ({totalPendingCount})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Top Mode Selector Tabs */}
      <div className="flex justify-center flex-wrap gap-2">
        <div className="inline-flex p-1.5 bg-slate-200/80 rounded-2xl border border-slate-300 gap-1 text-xs font-black shadow-inner flex-wrap justify-center">
          <button
            onClick={() => setActiveSubTab('pay')}
            className={`px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
              activeSubTab === 'pay'
                ? 'bg-blue-950 text-amber-400 shadow'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
            }`}
          >
            <CreditCard className="w-4 h-4 text-amber-400" />
            <span>Pay Fees via UPI / QR Code</span>
          </button>

          <button
            onClick={() => setActiveSubTab('history')}
            className={`px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
              activeSubTab === 'history'
                ? 'bg-blue-950 text-amber-400 shadow'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
            }`}
          >
            <History className="w-4 h-4 text-amber-400" />
            <span>Payment History & Receipts</span>
            <span className="bg-amber-400 text-blue-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow">
              {receiptsList.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('installments')}
            className={`px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
              activeSubTab === 'installments'
                ? 'bg-blue-950 text-amber-400 shadow'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
            }`}
          >
            <CalendarDays className="w-4 h-4 text-amber-400" />
            <span>Installment Plans & Balances</span>
            <span className="bg-amber-400 text-blue-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow">
              Monthly / Quarterly
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('push_reminders')}
            className={`px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
              activeSubTab === 'push_reminders'
                ? 'bg-blue-950 text-amber-400 shadow'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
            }`}
          >
            <BellRing className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>3-Day Push Reminders</span>
            <span className="bg-emerald-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow">
              Active
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('fee_structure')}
            className={`px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
              activeSubTab === 'fee_structure'
                ? 'bg-blue-950 text-amber-400 shadow'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
            }`}
          >
            <Settings className="w-4 h-4 text-amber-400" />
            <span>Edit Fee Rates & Van Fees</span>
            <span className="bg-amber-400 text-blue-950 text-[10px] font-black px-2 py-0.5 rounded-full shadow">
              {feeCategories.length} Rates
            </span>
          </button>
        </div>
      </div>

      {/* SUB-TAB 1: MAKE PAYMENT */}
      {activeSubTab === 'pay' && (
        <div className="animate-fadeIn space-y-6">
          {/* Automated 3-Day Push Reminder Status Banner */}
          <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-5 border border-blue-800/80 shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="p-3 bg-amber-400/20 text-amber-400 rounded-2xl border border-amber-400/30 shrink-0">
                <BellRing className="w-6 h-6 animate-pulse text-amber-300" />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="font-extrabold text-sm sm:text-base text-amber-300">
                    Automated 3-Day Fee Deadline Push Reminders
                  </h4>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase">
                    ACTIVE ✓
                  </span>
                </div>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  Parents automatically receive gentle push alerts on their mobile & browser <strong>3 days prior</strong> to school fee deadlines (Term Fees, Transport & Books).
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0 w-full md:w-auto">
              <button
                onClick={() => handleTriggerPushNotification()}
                className="flex-1 md:flex-none px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Test Push Alert</span>
              </button>
              <button
                onClick={() => setActiveSubTab('push_reminders')}
                className="flex-1 md:flex-none px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white border border-white/20 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
              >
                <Sliders className="w-3.5 h-3.5 text-amber-300" />
                <span>Schedule Settings</span>
              </button>
            </div>
          </div>
          {/* Main Payment Layout Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Fee Calculator Form or Generated PDF Receipt Success Card */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
              {generatedReceipt ? (
                <div className="space-y-6 animate-fadeIn">
                  {/* Success Header Banner */}
                  <div className="bg-emerald-50 border-2 border-emerald-500/80 rounded-2xl p-5 flex items-start gap-3">
                    <div className="p-2.5 bg-emerald-600 text-white rounded-xl shadow shrink-0">
                      <CheckCircle2 className="w-6 h-6" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="bg-emerald-600 text-white text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
                          Transaction Verified ✓
                        </span>
                        <span className="text-xs font-mono font-bold text-emerald-950">
                          {generatedReceipt.receiptNo}
                        </span>
                      </div>
                      <h3 className="text-base sm:text-lg font-black text-emerald-950">
                        Official School Fee Receipt Ready
                      </h3>
                      <p className="text-xs text-emerald-800">
                        {submissionMessage || 'Payment recorded successfully! You can download or print your official PDF receipt below.'}
                      </p>
                    </div>
                  </div>

                  {/* Summary Particulars Card */}
                  <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <span className="text-slate-500 font-bold uppercase text-[10px]">Student Name:</span>
                      <span className="font-extrabold text-blue-950 text-sm">{generatedReceipt.studentName}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Student ID:</span>
                        <span className="font-bold text-slate-800">{generatedReceipt.studentId || 'WNS-STUDENT'}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Class / Grade:</span>
                        <span className="font-bold text-slate-800">{generatedReceipt.grade}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Fee Particulars:</span>
                        <span className="font-bold text-amber-700">{generatedReceipt.term}</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Payment Date:</span>
                        <span className="font-semibold text-slate-700">{generatedReceipt.date}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">UTR / Ref Number:</span>
                        <span className="font-mono font-bold text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200 inline-block">
                          {generatedReceipt.transactionRef}
                        </span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-200 flex justify-between items-center">
                      <span className="font-black text-slate-700 text-xs uppercase">Total Fee Paid:</span>
                      <span className="text-2xl font-black text-emerald-700">₹{generatedReceipt.amount.toLocaleString('en-IN')}</span>
                    </div>
                  </div>

                  {/* PDF Download and Action Buttons */}
                  <div className="space-y-3">
                    <button
                      type="button"
                      onClick={() => generateReceiptPdf(generatedReceipt)}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black py-4 px-4 rounded-2xl text-xs sm:text-sm shadow-xl transition flex items-center justify-center gap-2.5 transform active:scale-98"
                    >
                      <Download className="w-5 h-5 text-amber-300" />
                      <span>Download Printable PDF Receipt</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2.5 text-xs">
                      <button
                        type="button"
                        onClick={() => setPreviewReceipt(generatedReceipt)}
                        className="bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold py-3 rounded-xl text-center flex items-center justify-center gap-1.5 transition shadow"
                      >
                        <Printer className="w-4 h-4 text-amber-400" />
                        <span>Print / Full Preview</span>
                      </button>

                      <a
                        href={`https://wa.me/919176593129?text=${encodeURIComponent(`Hello Wisdom School Admin, here is my fee payment receipt ${generatedReceipt.receiptNo} for ${generatedReceipt.studentName} (${generatedReceipt.grade}) - Amount ₹${generatedReceipt.amount}, UTR: ${generatedReceipt.transactionRef}.`)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-extrabold py-3 rounded-xl text-center flex items-center justify-center gap-1.5 transition border border-emerald-300"
                      >
                        <Share2 className="w-4 h-4 text-emerald-700" />
                        <span>Share WhatsApp</span>
                      </a>
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        setGeneratedReceipt(null);
                        setStudentName('');
                        setStudentId('');
                        setTransactionRef('');
                      }}
                      className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition text-center"
                    >
                      + Record Another Payment
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="border-b border-slate-100 pb-4">
                    <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-blue-900 text-white text-xs flex items-center justify-center font-bold">1</span>
                      <span>Student & Fee Details</span>
                    </h3>
                    <p className="text-xs text-slate-500 mt-1">Select the student's grade and fee term to generate the exact payment QR.</p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Student Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={studentName}
                        onChange={(e) => setStudentName(e.target.value)}
                        placeholder="e.g. R. Kavin"
                        className="w-full text-xs font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Student ID / Roll No (Optional)
                      </label>
                      <input
                        type="text"
                        value={studentId}
                        onChange={(e) => setStudentId(e.target.value)}
                        placeholder="e.g. WNS-2026-01"
                        className="w-full text-xs font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Select Grade / Class</label>
                      <select
                        value={selectedGrade}
                        onChange={(e) => setSelectedGrade(e.target.value)}
                        className="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50 text-slate-900"
                      >
                        {Object.keys(GRADE_FEE_STRUCTURE).map((g) => (
                          <option key={g} value={g}>
                            {g}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Fee Particulars</label>
                      <select
                        value={selectedFeeType}
                        onChange={(e) => setSelectedFeeType(e.target.value)}
                        className="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50 text-slate-900"
                      >
                        {feeCategories.map((cat) => (
                          <option key={cat.id} value={cat.key}>
                            {cat.name} (₹{cat.amount.toLocaleString('en-IN')})
                          </option>
                        ))}
                        <option value="custom">Custom Payment Amount</option>
                      </select>
                    </div>
                  </div>

                  {selectedFeeType === 'custom' && (
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">Enter Custom Amount (₹)</label>
                      <input
                        type="number"
                        value={customAmount}
                        onChange={(e) => setCustomAmount(Number(e.target.value))}
                        className="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50 text-slate-900"
                      />
                    </div>
                  )}

                  {/* Installment Plan Selection Card */}
                  <div className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                        <CalendarDays className="w-4 h-4 text-blue-900" />
                        <span>Fee Payment Plan & Installment Breakdown</span>
                      </label>
                      <span className="text-[10px] font-bold text-blue-900 bg-blue-100 px-2 py-0.5 rounded-full">
                        Flexible Options
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          setPaymentPlanType('Full Payment');
                          setSelectedInstallmentNo(1);
                        }}
                        className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1 ${
                          paymentPlanType === 'Full Payment'
                            ? 'bg-blue-950 text-amber-400 border-blue-950 shadow'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <CreditCard className="w-4 h-4" />
                        <span className="text-[11px] font-black">Full Payment</span>
                        <span className="text-[9px] opacity-80">Upfront (100%)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setPaymentPlanType('Quarterly');
                          setSelectedInstallmentNo(1);
                        }}
                        className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1 ${
                          paymentPlanType === 'Quarterly'
                            ? 'bg-blue-950 text-amber-400 border-blue-950 shadow'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <PieChart className="w-4 h-4" />
                        <span className="text-[11px] font-black">Quarterly Plan</span>
                        <span className="text-[9px] opacity-80">4 Installments</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setPaymentPlanType('Monthly');
                          setSelectedInstallmentNo(1);
                        }}
                        className={`p-2.5 rounded-xl border text-center transition flex flex-col items-center justify-center gap-1 ${
                          paymentPlanType === 'Monthly'
                            ? 'bg-blue-950 text-amber-400 border-blue-950 shadow'
                            : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <CalendarDays className="w-4 h-4" />
                        <span className="text-[11px] font-black">Monthly Plan</span>
                        <span className="text-[9px] opacity-80">10 Installments</span>
                      </button>
                    </div>

                    {/* Active Installment Picker if Quarterly or Monthly */}
                    {paymentPlanType !== 'Full Payment' && (
                      <div className="pt-2 border-t border-slate-200 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-slate-700">Select Installment to Pay Now:</span>
                          <span className="text-[10px] font-mono font-extrabold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                            {paymentPlanType === 'Quarterly' ? `Quarter ${selectedInstallmentNo} of 4` : `Month ${selectedInstallmentNo} of 10`}
                          </span>
                        </div>

                        <div className="flex flex-wrap gap-1.5">
                          {Array.from({ length: paymentPlanType === 'Quarterly' ? 4 : 10 }).map((_, idx) => {
                            const instNum = idx + 1;
                            const isSelected = selectedInstallmentNo === instNum;
                            return (
                              <button
                                key={instNum}
                                type="button"
                                onClick={() => setSelectedInstallmentNo(instNum)}
                                className={`px-3 py-1.5 rounded-lg text-xs font-black transition border ${
                                  isSelected
                                    ? 'bg-amber-400 text-blue-950 border-amber-500 shadow'
                                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                                }`}
                              >
                                #{instNum} {paymentPlanType === 'Quarterly' ? `Q${instNum}` : `M${instNum}`}
                              </button>
                            );
                          })}
                        </div>

                        {/* Dynamic Breakdown & Remaining Balance Box */}
                        <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-2 text-xs">
                          <div className="flex justify-between items-center text-amber-950 font-bold">
                            <span>Total Annual Base Fee ({selectedGrade}):</span>
                            <span className="font-mono text-sm font-black">₹{baseAnnualFee.toLocaleString('en-IN')}</span>
                          </div>
                          <div className="flex justify-between items-center text-emerald-900 font-extrabold">
                            <span>Current Payable Installment #{selectedInstallmentNo}:</span>
                            <span className="font-mono text-base font-black text-emerald-700">₹{activeAmount.toLocaleString('en-IN')}</span>
                          </div>
                          <div className="flex justify-between items-center text-slate-600 font-medium pt-1 border-t border-amber-200/60">
                            <span>Remaining Balance After Payment:</span>
                            <span className="font-mono font-bold text-amber-900">₹{remainingBalance.toLocaleString('en-IN')}</span>
                          </div>

                          {/* Dynamic Progress Bar */}
                          <div className="space-y-1 pt-1">
                            <div className="flex justify-between text-[10px] font-bold text-slate-500">
                              <span>Plan Payoff Progress:</span>
                              <span>
                                {Math.round((selectedInstallmentNo / (paymentPlanType === 'Quarterly' ? 4 : 10)) * 100)}% Scheduled
                              </span>
                            </div>
                            <div className="w-full h-2 bg-amber-200/80 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-emerald-600 rounded-full transition-all duration-300"
                                style={{
                                  width: `${Math.round((selectedInstallmentNo / (paymentPlanType === 'Quarterly' ? 4 : 10)) * 100)}%`,
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Amount Display summary */}
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-blue-950 to-indigo-900 text-white flex items-center justify-between shadow-inner">
                    <div>
                      <span className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider block">
                        Calculated Payable Amount
                      </span>
                      <span className="text-xs text-amber-300 font-medium">
                        {selectedGrade} • {selectedFeeType.toUpperCase()}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-2xl sm:text-3xl font-black text-amber-400">
                        ₹{activeAmount.toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>

                  {/* Verification / Log Transaction Form */}
                  <form onSubmit={handleRegisterPayment} className="pt-4 border-t border-slate-100 space-y-4">
                    <h4 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <span className="w-6 h-6 rounded-full bg-emerald-600 text-white text-xs flex items-center justify-center font-bold">2</span>
                      <span>Confirm & Generate Digital Receipt</span>
                    </h4>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        UPI Transaction / UTR Ref No <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        value={transactionRef}
                        onChange={(e) => setTransactionRef(e.target.value)}
                        placeholder="e.g. 382910482910 (12-digit UTR from GPay / PhonePe)"
                        className="w-full text-xs font-mono font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-slate-50/50"
                      />
                      <p className="text-[10px] text-slate-500 mt-1">
                        After completing the payment on Google Pay or PhonePe, paste the 12-digit UTR/Ref number above to get an instant downloadable school receipt.
                      </p>
                    </div>

                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center justify-center gap-2"
                    >
                      <FileCheck className="w-4 h-4" />
                      <span>{submitting ? 'Generating Receipt...' : 'Confirm Payment & Generate Official Receipt'}</span>
                    </button>
                  </form>
                </>
              )}
            </div>

            {/* Right QR Code Display & Quick Launch */}
            <div className="lg:col-span-5 space-y-6">
              {/* Dynamic UPI QR Card */}
              <div className="bg-white border-2 border-amber-400 rounded-3xl p-6 shadow-xl text-center space-y-4 relative overflow-hidden">
                <div className="bg-amber-400 text-blue-950 font-black text-xs py-1.5 px-4 -mx-6 -mt-6 mb-4 flex items-center justify-between gap-1.5 border-b border-amber-500">
                  <span className="flex items-center gap-1.5">
                    <QrCode className="w-4 h-4" />
                    <span>Dynamic UPI QR Generator</span>
                  </span>
                  <span className="bg-blue-950 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full uppercase flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-amber-400 animate-spin" />
                    Live Vector
                  </span>
                </div>

                {/* Generated QRCodeSVG Component */}
                <div className="inline-block p-3 bg-white border-2 border-slate-200 rounded-2xl shadow-inner relative group">
                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-center">
                    <QRCodeSVG
                      value={upiUrl}
                      size={210}
                      bgColor={qrColorStyle === 'school' ? '#f8fafc' : '#ffffff'}
                      fgColor={qrColorStyle === 'school' ? '#1e3a8a' : '#0f172a'}
                      level="H"
                      marginSize={1}
                    />
                  </div>

                  {/* Hidden Canvas used for generating PNG download files */}
                  <div className="hidden">
                    <QRCodeCanvas
                      ref={qrCanvasRef}
                      value={upiUrl}
                      size={512}
                      bgColor="#ffffff"
                      fgColor="#0f172a"
                      level="H"
                      marginSize={2}
                    />
                  </div>

                  <div className="mt-2 text-[10px] font-extrabold text-blue-950 uppercase tracking-wider flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>R SARAVANAN • WISDOM SCHOOL ESSUR</span>
                  </div>
                </div>

                {/* Quick Presets & QR Actions */}
                <div className="space-y-2 pt-1 text-left">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                    <span>Quick Fee Presets:</span>
                    <button
                      type="button"
                      onClick={() => setQrColorStyle((prev) => (prev === 'standard' ? 'school' : 'standard'))}
                      className="text-[10px] font-extrabold text-blue-900 hover:text-blue-700 underline flex items-center gap-1"
                    >
                      <span>Theme: {qrColorStyle === 'standard' ? 'Classic Dark' : 'Navy Blue'}</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-4 gap-1.5 text-xs font-black">
                    {[1000, 3500, 4500, 5000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setCustomAmount(amt)}
                        className={`py-1.5 rounded-xl border transition text-[11px] text-center ${
                          activeAmount === amt
                            ? 'bg-amber-400 text-blue-950 border-amber-500 shadow-sm'
                            : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        ₹{amt.toLocaleString('en-IN')}
                      </button>
                    ))}
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleDownloadQrPng}
                      className="flex-1 py-2 bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5"
                      title="Download high resolution QR code PNG image"
                    >
                      <Download className="w-3.5 h-3.5 text-amber-400" />
                      <span>Save QR PNG</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(upiUrl);
                        setCopiedUpi(true);
                        setTimeout(() => setCopiedUpi(false), 2000);
                      }}
                      className="flex-1 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 transition flex items-center justify-center gap-1.5"
                      title="Copy UPI payment URL"
                    >
                      {copiedUpi ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedUpi ? 'Link Copied!' : 'Copy UPI Link'}</span>
                    </button>
                  </div>
                </div>

                {/* Account Details Box */}
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-left text-xs space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-semibold text-[11px]">Account Holder:</span>
                    <span className="font-extrabold text-blue-950">{SCHOOL_INFO.upiAccountHolder}</span>
                  </div>

                  <div className="flex justify-between items-center">
                    <span className="text-slate-500 font-semibold text-[11px]">Official UPI ID:</span>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-blue-900 select-all bg-white px-2 py-0.5 rounded border border-slate-300 text-[11px]">
                        {SCHOOL_INFO.upiId}
                      </span>
                      <button
                        type="button"
                        onClick={copyUpiToClipboard}
                        className="p-1 bg-slate-200 hover:bg-slate-300 rounded text-slate-700 transition"
                        title="Copy UPI ID"
                      >
                        {copiedUpi ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-1 border-t border-slate-200">
                    <span className="text-slate-500 font-semibold text-[11px]">Encoded Amount:</span>
                    <span className="font-black text-emerald-700 text-sm">₹{activeAmount.toLocaleString('en-IN')}</span>
                  </div>

                  {/* Toggle Payload Inspector */}
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={() => setShowPayloadDetails(!showPayloadDetails)}
                      className="text-[10px] font-bold text-slate-500 hover:text-slate-800 underline flex items-center justify-between w-full"
                    >
                      <span>{showPayloadDetails ? 'Hide Encoded UPI Payload' : 'Inspect Dynamic UPI Payload'}</span>
                      <span>{showPayloadDetails ? '▲' : '▼'}</span>
                    </button>
                    {showPayloadDetails && (
                      <div className="mt-1.5 p-2 bg-slate-900 text-emerald-400 font-mono text-[10px] rounded-xl overflow-x-auto break-all border border-slate-800 space-y-1">
                        <div><strong>VPA:</strong> {SCHOOL_INFO.upiId}</div>
                        <div><strong>Payee:</strong> R Saravanan - Wisdom School</div>
                        <div><strong>Amount:</strong> ₹{activeAmount}</div>
                        <div><strong>Note:</strong> {noteDescription}</div>
                        <div className="text-slate-400 text-[9px] pt-1 border-t border-slate-800">{upiUrl}</div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Quick UPI App Launch buttons */}
                <div className="space-y-2 pt-2 text-left">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-600">
                    <span>Supported UPI Mobile Apps:</span>
                    <div className="flex items-center gap-1 text-[9px] font-extrabold text-slate-500">
                      <span className="px-1.5 py-0.5 bg-blue-100 text-blue-900 rounded">GPay</span>
                      <span className="px-1.5 py-0.5 bg-indigo-100 text-indigo-900 rounded">PhonePe</span>
                      <span className="px-1.5 py-0.5 bg-sky-100 text-sky-900 rounded">Paytm</span>
                      <span className="px-1.5 py-0.5 bg-orange-100 text-orange-900 rounded">BHIM</span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <a
                      href={upiUrl}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-xl text-center text-[11px] flex items-center justify-center gap-1.5 shadow"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>Launch UPI App</span>
                    </a>
                    <a
                      href={`https://wa.me/919176593129?text=${encodeURIComponent(`Hello Admin Saravanan, I paid fee ₹${activeAmount} for ${studentName || 'my child'}. Transaction Ref: ${transactionRef}`)}`}
                      target="_blank"
                      rel="noreferrer"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 rounded-xl text-center text-[11px] flex items-center justify-center gap-1.5 shadow"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                      <span>WhatsApp Confirmation</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Saved UPI ID & Auto-Debit Mandate Card */}
              <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white rounded-3xl p-5 border-2 border-amber-400/80 shadow-xl space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-amber-400/20 text-amber-300 rounded-xl border border-amber-400/30">
                      <Wallet className="w-4 h-4 text-amber-400" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-xs text-amber-300 uppercase tracking-wider">
                        Saved UPI & 3-Day Auto-Mandate
                      </h4>
                      <span className="text-[10px] text-slate-300 font-medium">Pre-Authorized Recurring Fee Payment</span>
                    </div>
                  </div>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[9px] font-black px-2 py-0.5 rounded-full uppercase">
                    NPCI Secure ✓
                  </span>
                </div>

                {/* Display / Edit Saved UPI ID */}
                <div className="bg-slate-800/90 p-3.5 rounded-2xl border border-slate-700/80 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400 font-semibold text-[11px]">Parent's Saved UPI VPA:</span>
                    {!editingUpi ? (
                      <button
                        onClick={() => {
                          setTempUpiInput(savedUpiId);
                          setEditingUpi(true);
                        }}
                        className="text-amber-400 hover:text-amber-300 text-[11px] font-bold underline"
                      >
                        Change UPI ID
                      </button>
                    ) : (
                      <button
                        onClick={() => setEditingUpi(false)}
                        className="text-slate-400 hover:text-slate-200 text-[11px]"
                      >
                        Cancel
                      </button>
                    )}
                  </div>

                  {!editingUpi ? (
                    <div className="flex items-center justify-between bg-slate-900 px-3.5 py-2.5 rounded-xl border border-slate-700">
                      <div className="flex items-center gap-2">
                        <Smartphone className="w-4 h-4 text-amber-400" />
                        <span className="font-mono font-bold text-amber-300 text-xs">{savedUpiId}</span>
                      </div>
                      <span className="text-[10px] bg-amber-400/20 text-amber-300 px-2 py-0.5 rounded font-extrabold">
                        GPay / PhonePe
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-2 pt-1">
                      <input
                        type="text"
                        value={tempUpiInput}
                        onChange={(e) => setTempUpiInput(e.target.value)}
                        placeholder="e.g. 9876543210@upi or parent@okaxis"
                        className="w-full text-xs font-mono font-bold px-3 py-2 rounded-xl bg-slate-900 border border-amber-400 text-white focus:outline-none"
                      />
                      <button
                        onClick={handleSaveUpiId}
                        className="w-full py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition"
                      >
                        Save & Verify UPI ID
                      </button>
                    </div>
                  )}
                </div>

                {/* Auto-Debit Toggle & PIN Pre-Authorization Action */}
                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between bg-slate-800/50 p-3 rounded-2xl border border-slate-700">
                    <div className="space-y-0.5">
                      <span className="font-extrabold text-slate-200 text-[11px] block">3-Day Fee Auto-Debit Alert</span>
                      <span className="text-[10px] text-slate-400 block">Triggers authorization prompt 3 days before due date</span>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={autoDebitEnabled}
                        onChange={(e) => setAutoDebitEnabled(e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-400"></div>
                    </label>
                  </div>

                  <button
                    onClick={() => handleOpenAuthorizationModal()}
                    className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-blue-950 font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2 transform active:scale-98"
                  >
                    <KeyRound className="w-4 h-4 text-blue-950" />
                    <span>Authorize Fee Payment via Saved UPI (₹{activeAmount.toLocaleString('en-IN')})</span>
                  </button>

                  <div className="flex items-center gap-1.5 text-[10px] text-slate-400 justify-center">
                    <Lock className="w-3 h-3 text-amber-400" />
                    <span>Requires explicit 4-digit UPI PIN authorization before deduction.</span>
                  </div>
                </div>
              </div>

              {/* Verification Contact Notice */}
              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-950 space-y-2">
                <div className="flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-extrabold text-amber-900">Need Payment Confirmation Assistance?</h5>
                    <p className="text-[11px] text-amber-800 mt-0.5">
                      Send a screenshot of your GPay/PhonePe transfer to Admin R. Saravanan on WhatsApp:
                      <a href={`https://wa.me/919176593129`} target="_blank" rel="noreferrer" className="font-bold underline ml-1 text-amber-950">
                        +91 9176593129
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* DEDICATED PAYMENT HISTORY SECTION (PAST TRANSACTIONS TABLE) */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <span className="bg-blue-100 text-blue-950 text-[10px] font-black uppercase px-2.5 py-1 rounded-full border border-blue-200 inline-flex items-center gap-1 mb-1">
                  <History className="w-3 h-3 text-amber-600" />
                  Past Transactions Log
                </span>
                <h3 className="text-lg font-black text-blue-950 flex items-center gap-2">
                  <span>Payment History & Past Transactions</span>
                  <span className="bg-amber-400 text-blue-950 text-xs font-black px-2.5 py-0.5 rounded-full">
                    {receiptsList.length} Records
                  </span>
                </h3>
                <p className="text-xs text-slate-500">
                  Comprehensive audit trail of past verified fee payments, dates, amounts, and downloadable official receipts.
                </p>
              </div>

              <button
                onClick={() => setActiveSubTab('history')}
                className="px-4 py-2 bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs rounded-xl shadow transition flex items-center gap-1.5 self-start sm:self-auto shrink-0"
              >
                <Eye className="w-4 h-4 text-amber-400" />
                <span>Open Full History View</span>
              </button>
            </div>

            {/* Payment History Table */}
            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-900 text-amber-300 font-black uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4">Receipt No & Date</th>
                    <th className="py-3 px-4">Student & Grade</th>
                    <th className="py-3 px-4">Fee Particulars</th>
                    <th className="py-3 px-4">Payment Method / UTR</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Receipt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                  {receiptsList.slice(0, 6).map((rcp) => (
                    <tr key={rcp.receiptNo} className="hover:bg-slate-50/80 transition">
                      <td className="py-3.5 px-4">
                        <span className="font-mono font-bold text-blue-950 block">{rcp.receiptNo}</span>
                        <span className="text-[10px] text-slate-500 flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-slate-400" /> {rcp.date}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <strong className="text-slate-900 block font-bold">{rcp.studentName}</strong>
                        <span className="text-[10px] text-slate-500">{rcp.grade} ({rcp.studentId})</span>
                      </td>
                      <td className="py-3.5 px-4 font-extrabold text-blue-900">{rcp.term}</td>
                      <td className="py-3.5 px-4">
                        <span className="text-slate-700 block text-[11px] font-semibold">{rcp.paymentMethod}</span>
                        <span className="font-mono text-[10px] text-slate-400">UTR: {rcp.transactionRef}</span>
                      </td>
                      <td className="py-3.5 px-4 font-black text-emerald-700 text-sm">
                        ₹{rcp.amount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-black px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>{rcp.status}</span>
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setPreviewReceipt(rcp)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-blue-900 rounded-lg transition"
                            title="Preview Receipt"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => generateReceiptPdf(rcp)}
                            className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[10px] rounded-lg shadow transition inline-flex items-center gap-1"
                          >
                            <Download className="w-3 h-3 text-amber-300" />
                            <span>PDF</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {receiptsList.length > 6 && (
              <div className="text-center pt-1">
                <button
                  onClick={() => setActiveSubTab('history')}
                  className="text-xs font-black text-blue-900 hover:text-blue-700 hover:underline inline-flex items-center gap-1"
                >
                  <span>View all {receiptsList.length} transaction receipts in history →</span>
                </button>
              </div>
            )}
          </div>

          {/* Official Generated Receipt Modal / Display Card */}
          {generatedReceipt && (
            <div className="bg-white border-2 border-blue-900 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6 max-w-3xl mx-auto print:shadow-none print:border-0 print:p-0 animate-fadeIn">
              <div className="flex items-center justify-between border-b border-slate-200 pb-4">
                <div className="flex items-center space-x-3">
                  <img
                    src={SCHOOL_INFO.logoUrl}
                    alt={SCHOOL_INFO.name}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 rounded-full border border-amber-400 bg-white p-0.5 object-contain shrink-0"
                  />
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-blue-950 uppercase leading-tight">
                      WISDOM NURSERY AND PRIMARY SCHOOL
                    </h3>
                    <p className="text-[11px] font-bold text-amber-600">
                      ESSUR - 603301 | "{SCHOOL_INFO.motto}"
                    </p>
                  </div>
                </div>

                <span className="bg-emerald-100 text-emerald-800 text-xs font-black px-3 py-1 rounded-full border border-emerald-300">
                  OFFICIAL RECEIPT
                </span>
              </div>

              {/* Receipt Info Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Receipt No:</span>
                  <span className="font-mono font-bold text-blue-950 text-sm">{generatedReceipt.receiptNo}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Date:</span>
                  <span className="font-semibold text-slate-800">{generatedReceipt.date}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Payment Mode:</span>
                  <span className="font-semibold text-slate-800">{generatedReceipt.paymentMethod}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Student Name:</span>
                  <span className="font-extrabold text-slate-900">{generatedReceipt.studentName}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Class / Grade:</span>
                  <span className="font-bold text-slate-800">{generatedReceipt.grade}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px] uppercase font-bold">Transaction UTR:</span>
                  <span className="font-mono text-slate-800">{generatedReceipt.transactionRef}</span>
                </div>
              </div>

              <div className="border-y border-slate-200 py-3 flex justify-between items-center font-bold text-sm">
                <span className="text-slate-700">Fee Particulars ({generatedReceipt.term}):</span>
                <span className="text-emerald-700 text-lg font-black">₹{generatedReceipt.amount.toLocaleString('en-IN')}</span>
              </div>

              {/* Admin Stamp & Sign Off */}
              <div className="flex justify-between items-end pt-4">
                <div className="text-[11px] text-slate-500 space-y-1">
                  <p>• Generated digitally via Wisdom School Essur Portal.</p>
                  <p>• Admin: R. SARAVANAN (Ph: +91 9176593129)</p>
                </div>
                <div className="text-center">
                  <div className="w-24 border-b border-slate-400 mb-1"></div>
                  <span className="text-[10px] font-bold uppercase text-slate-700">Authorized Signatory</span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 no-print">
                <button
                  onClick={() => setActiveSubTab('history')}
                  className="text-xs font-bold text-blue-900 hover:underline flex items-center gap-1"
                >
                  <History className="w-4 h-4 text-amber-500" />
                  <span>View All Saved Receipts in History →</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => generatedReceipt && generateReceiptPdf(generatedReceipt)}
                    className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-lg transition animate-pulse"
                  >
                    <Download className="w-4 h-4 text-amber-300" />
                    <span>Download Official PDF Receipt</span>
                  </button>

                  <button
                    onClick={handlePrintReceipt}
                    className="bg-blue-950 hover:bg-blue-900 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-1.5 shadow transition"
                  >
                    <Printer className="w-4 h-4 text-amber-400" />
                    <span>Print Browser Copy</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB-TAB 2: PAYMENT HISTORY & DOWNLOAD RECEIPTS */}
      {activeSubTab === 'history' && (
        <div className="space-y-6 animate-fadeIn">
          {/* Header Controls & Stats Card */}
          <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl border-2 border-amber-400/40 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <span className="bg-amber-400 text-blue-950 px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider inline-flex items-center gap-1.5 shadow mb-2">
                  <History className="w-3.5 h-3.5 text-blue-950" />
                  Wisdom School Fee Receipts Archive
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white">
                  Payment History & Downloadable PDF Receipts
                </h3>
                <p className="text-xs text-slate-300 font-medium pt-1">
                  Search past tuition, books, uniform, and transport payments. Click 'Download PDF' to generate an official stamped A4 receipt.
                </p>
              </div>

              <button
                onClick={() => setActiveSubTab('pay')}
                className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl transition shadow flex items-center gap-2 self-start md:self-auto shrink-0"
              >
                <CreditCard className="w-4 h-4 text-blue-950" />
                <span>+ Make New UPI Payment</span>
              </button>
            </div>

            {/* Quick Stats Summary */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white/10 backdrop-blur border border-white/15 p-4 rounded-2xl flex items-center gap-3">
                <div className="p-2.5 bg-amber-400 text-blue-950 rounded-xl">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-300 uppercase font-bold block">Total Fee Receipts</span>
                  <span className="text-xl font-black text-white">{filteredReceipts.length} Saved Logs</span>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur border border-white/15 p-4 rounded-2xl flex items-center gap-3">
                <div className="p-2.5 bg-emerald-500 text-white rounded-xl">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-300 uppercase font-bold block">Total Amount Verified</span>
                  <span className="text-xl font-black text-amber-300">₹{totalFilteredAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur border border-white/15 p-4 rounded-2xl flex items-center gap-3">
                <div className="p-2.5 bg-indigo-500 text-white rounded-xl">
                  <Building className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[10px] text-slate-300 uppercase font-bold block">School UPI Destination</span>
                  <span className="text-xs font-mono font-bold text-amber-200 select-all">{SCHOOL_INFO.upiId}</span>
                </div>
              </div>
            </div>

            {/* Search & Filter Bar */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 pt-2">
              <div className="md:col-span-8 relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by Student Name, ID (e.g. WNS-2026-01), UTR, or Receipt No..."
                  className="w-full text-xs font-bold pl-10 pr-4 py-3 rounded-2xl bg-slate-900/90 border border-amber-400/50 text-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400 placeholder:text-slate-500"
                />
              </div>

              <div className="md:col-span-4 flex items-center gap-2">
                <Filter className="w-4 h-4 text-amber-400 shrink-0" />
                <select
                  value={gradeFilter}
                  onChange={(e) => setGradeFilter(e.target.value)}
                  className="w-full text-xs font-bold px-3 py-3 rounded-2xl bg-slate-900 border border-amber-400/50 text-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400"
                >
                  <option value="ALL">All Grades & Classes</option>
                  {Object.keys(GRADE_FEE_STRUCTURE).map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Quick Student Filters */}
            <div className="flex flex-wrap items-center gap-2 text-xs pt-1">
              <span className="text-slate-400 font-bold text-[11px]">Quick Student Lookups:</span>
              {[
                { label: 'All Receipts', query: '' },
                { label: 'R. Kavin (WNS-2026-01)', query: 'Kavin' },
                { label: 'S. Priyanka (LKG)', query: 'Priyanka' },
                { label: 'M. Yogesh (Class 5)', query: 'Yogesh' },
                { label: 'K. Ananya (LKG)', query: 'Ananya' },
              ].map((btn) => (
                <button
                  key={btn.label}
                  onClick={() => setSearchQuery(btn.query)}
                  className={`px-3 py-1 rounded-xl text-[11px] font-bold border transition ${
                    searchQuery === btn.query
                      ? 'bg-amber-400 text-blue-950 border-amber-400'
                      : 'bg-white/10 hover:bg-white/20 text-slate-200 border-white/20'
                  }`}
                >
                  {btn.label}
                </button>
              ))}
            </div>
          </div>

          {/* BULK RECEIPT DOWNLOAD & PRINT ACTION BAR */}
          <div className="bg-slate-900 text-white rounded-2xl p-4 border border-blue-900/80 shadow-md flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <button
                onClick={() => toggleSelectAllReceipts(filteredReceipts)}
                className="px-3 py-1.5 bg-blue-950 hover:bg-blue-900 text-amber-300 font-extrabold text-xs rounded-xl border border-blue-800 transition flex items-center gap-2"
              >
                {selectedReceiptNos.length === filteredReceipts.length && filteredReceipts.length > 0 ? (
                  <CheckSquare className="w-4 h-4 text-amber-400" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400" />
                )}
                <span>
                  {selectedReceiptNos.length === filteredReceipts.length && filteredReceipts.length > 0
                    ? 'Deselect All'
                    : `Select All (${filteredReceipts.length})`}
                </span>
              </button>

              <span className="text-xs text-slate-300 font-bold">
                Selected: <strong className="text-amber-400">{selectedReceiptNos.length}</strong> Receipts
              </span>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleDownloadBulkSelectedReceipts}
                disabled={selectedReceiptNos.length === 0}
                className={`px-4 py-2 rounded-xl font-black text-xs transition flex items-center justify-center gap-2 shadow-lg w-full sm:w-auto ${
                  selectedReceiptNos.length > 0
                    ? 'bg-amber-400 hover:bg-amber-300 text-blue-950'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                }`}
              >
                <Download className="w-4 h-4" />
                <span>Download Bulk Receipts PDF ({selectedReceiptNos.length})</span>
              </button>
            </div>
          </div>

          {/* RECEIPT CARDS LIST */}
          <div className="space-y-4">
            {filteredReceipts.length === 0 ? (
              <div className="bg-white border-2 border-dashed border-slate-300 rounded-3xl p-12 text-center space-y-3">
                <FileText className="w-10 h-10 text-slate-400 mx-auto" />
                <h4 className="font-extrabold text-slate-800 text-base">No Fee Receipts Found</h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  No payment records match your search criteria "{searchQuery}". Try clearing the search query or submit a new UPI fee payment.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setGradeFilter('ALL');
                  }}
                  className="px-4 py-2 bg-blue-950 text-amber-400 font-bold text-xs rounded-xl shadow"
                >
                  Reset Search Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredReceipts.map((rcp) => (
                  <div
                    key={rcp.receiptNo}
                    className="bg-white rounded-3xl border-2 border-slate-200 hover:border-blue-900/40 p-5 shadow-sm hover:shadow-md transition space-y-4 flex flex-col justify-between"
                  >
                    {/* Top Row: Student & Receipt No */}
                    <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                      <div className="flex items-center gap-2.5">
                        <input
                          type="checkbox"
                          checked={selectedReceiptNos.includes(rcp.receiptNo)}
                          onChange={() => toggleSelectReceipt(rcp.receiptNo)}
                          className="w-4 h-4 rounded text-blue-900 border-slate-300 focus:ring-blue-900 cursor-pointer"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-extrabold text-slate-900 text-base">{rcp.studentName}</h4>
                            <span className="bg-blue-100 text-blue-950 text-[10px] font-black px-2 py-0.5 rounded border border-blue-200">
                              {rcp.grade}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 font-medium">
                            ID / Roll: <strong className="text-slate-800">{rcp.studentId}</strong>
                          </p>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="inline-flex items-center gap-1 font-mono font-bold text-[11px] bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-300 text-slate-800">
                          <span>{rcp.receiptNo}</span>
                          <button
                            onClick={() => handleCopyReceiptNo(rcp.receiptNo)}
                            className="p-0.5 hover:text-blue-900 transition"
                            title="Copy Receipt No"
                          >
                            {copiedReceiptNo === rcp.receiptNo ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5 text-slate-400" />
                            )}
                          </button>
                        </div>
                        <span className="block text-[10px] text-emerald-700 font-black uppercase pt-1">
                          ✓ {rcp.status}
                        </span>
                      </div>
                    </div>

                    {/* Middle Details Grid */}
                    <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-200/80">
                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Fee Particulars:</span>
                        <span className="font-extrabold text-blue-950">{rcp.term}</span>
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Amount Paid:</span>
                        <span className="font-black text-emerald-700 text-sm">₹{rcp.amount.toLocaleString('en-IN')}</span>
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">Payment Date:</span>
                        <span className="font-semibold text-slate-700">{rcp.date}</span>
                      </div>

                      <div>
                        <span className="text-[10px] text-slate-400 font-bold uppercase block">UTR / Ref No:</span>
                        <span className="font-mono text-slate-800 font-bold">{rcp.transactionRef}</span>
                      </div>
                    </div>

                    {/* Bottom Action Bar */}
                    <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
                      <button
                        onClick={() => setPreviewReceipt(rcp)}
                        className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                      >
                        <Eye className="w-3.5 h-3.5 text-blue-900" />
                        <span>Preview</span>
                      </button>

                      <a
                        href={`https://wa.me/919176593129?text=${encodeURIComponent(`Hello Wisdom School Admin, here is my fee payment receipt ${rcp.receiptNo} for ${rcp.studentName} (${rcp.grade}) - Amount ₹${rcp.amount}, UTR: ${rcp.transactionRef}.`)}`}
                        target="_blank"
                        rel="noreferrer"
                        className="p-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl transition border border-emerald-200"
                        title="Share Receipt on WhatsApp"
                      >
                        <Share2 className="w-4 h-4" />
                      </a>

                      <button
                        onClick={() => generateReceiptPdf(rcp)}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow transition flex items-center gap-1.5"
                      >
                        <Download className="w-4 h-4 text-amber-300" />
                        <span>Download PDF Receipt</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB: FEE INSTALLMENT PLANS & BALANCES */}
      {activeSubTab === 'installments' && (
        <div className="animate-fadeIn space-y-8">
          {/* Header Banner */}
          <div className="bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 border-2 border-amber-400/60 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-full text-xs font-black uppercase">
                  <CalendarDays className="w-3.5 h-3.5 text-amber-400" />
                  <span>Flexible Parent Cash Flow Options</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                  <span>School Fee Installments & Dynamic Balance Tracker</span>
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Parents can opt for <strong>Quarterly (4 Terms)</strong> or <strong>Monthly (10 Installments)</strong> payment schedules with automatic balance updates and official downloadable fee schedule statements.
                </p>
              </div>

              {/* Schedule Download Button */}
              {(() => {
                const activePlan = studentInstallmentPlans.find((p) => p.studentId === selectedStudentPlanId) || studentInstallmentPlans[0];
                return (
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={() => generateInstallmentSchedulePdf(activePlan)}
                      className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4 text-blue-950" />
                      <span>Export Schedule PDF Statement</span>
                    </button>
                  </div>
                );
              })()}
            </div>

            {/* Student Search & Quick Switch Bar */}
            <div className="pt-4 border-t border-slate-800/80 flex flex-col md:flex-row items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-3 w-full md:w-auto">
                <span className="font-extrabold text-amber-300 uppercase tracking-wider text-[11px]">Select Registered Student:</span>
                <select
                  value={selectedStudentPlanId}
                  onChange={(e) => setSelectedStudentPlanId(e.target.value)}
                  className="bg-slate-900 text-white font-bold px-4 py-2.5 rounded-xl border border-amber-400/50 focus:outline-none focus:ring-2 focus:ring-amber-400 text-xs flex-1 md:flex-none"
                >
                  {studentInstallmentPlans.map((p) => (
                    <option key={p.studentId} value={p.studentId}>
                      {p.studentName} ({p.grade} - {p.studentId}) • {p.planType} Plan
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2 text-slate-300 text-[11px] font-medium">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Zero late-penalty processing for pre-scheduled installment plans.</span>
              </div>
            </div>
          </div>

          {/* Active Student Installment Dashboard */}
          {(() => {
            const plan = studentInstallmentPlans.find((p) => p.studentId === selectedStudentPlanId) || studentInstallmentPlans[0];
            const totalPaid = plan.installments.filter((i) => i.status === 'PAID').reduce((sum, i) => sum + i.paidAmount, 0);
            const totalRemaining = plan.totalAnnualFee - totalPaid;
            const paidCount = plan.installments.filter((i) => i.status === 'PAID').length;
            const progressPercent = Math.round((totalPaid / plan.totalAnnualFee) * 100);
            const nextDueItem = plan.installments.find((i) => i.status === 'DUE') || plan.installments.find((i) => i.status === 'UPCOMING');

            return (
              <div className="space-y-6">
                {/* 4 Key Financial Metrics Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <div className="bg-white border-2 border-slate-200 rounded-3xl p-5 shadow-sm space-y-1">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                      Total Annual Fee
                    </span>
                    <div className="text-2xl font-black text-blue-950">
                      ₹{plan.totalAnnualFee.toLocaleString('en-IN')}
                    </div>
                    <span className="text-[11px] font-bold text-slate-500 block">
                      {plan.grade} Academic Standard
                    </span>
                  </div>

                  <div className="bg-white border-2 border-emerald-300 bg-emerald-50/20 rounded-3xl p-5 shadow-sm space-y-1">
                    <span className="text-[10px] font-black text-emerald-700 uppercase tracking-wider block">
                      Total Amount Paid
                    </span>
                    <div className="text-2xl font-black text-emerald-700">
                      ₹{totalPaid.toLocaleString('en-IN')}
                    </div>
                    <span className="text-[11px] font-bold text-emerald-800 flex items-center gap-1 block">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      {paidCount} of {plan.installments.length} Installments Cleared
                    </span>
                  </div>

                  <div className="bg-white border-2 border-amber-300 bg-amber-50/30 rounded-3xl p-5 shadow-sm space-y-1">
                    <span className="text-[10px] font-black text-amber-800 uppercase tracking-wider block">
                      Remaining Balance Due
                    </span>
                    <div className="text-2xl font-black text-amber-900">
                      ₹{totalRemaining.toLocaleString('en-IN')}
                    </div>
                    <span className="text-[11px] font-bold text-amber-700 block">
                      Pending Payoff Balance
                    </span>
                  </div>

                  <div className="bg-white border-2 border-blue-900 rounded-3xl p-5 shadow-sm space-y-1">
                    <span className="text-[10px] font-black text-blue-900 uppercase tracking-wider block">
                      Next Due Deadline
                    </span>
                    <div className="text-lg font-black text-blue-950">
                      {nextDueItem ? nextDueItem.dueDate : 'All Paid 🎉'}
                    </div>
                    <span className="text-[11px] font-bold text-blue-800 block">
                      {nextDueItem ? `₹${nextDueItem.amount.toLocaleString('en-IN')} (${nextDueItem.title})` : 'Zero pending dues'}
                    </span>
                  </div>
                </div>

                {/* Progress Bar & Visual Milestone Card */}
                <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h4 className="font-extrabold text-blue-950 text-base">
                        Annual Fee Payment Payoff Timeline ({plan.planType} Schedule)
                      </h4>
                      <p className="text-xs text-slate-500">
                        Visual completion progress for student <strong>{plan.studentName}</strong> ({plan.studentId})
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="text-xl font-black text-blue-950">{progressPercent}%</span>
                      <span className="text-xs text-slate-500 block">Cleared to Date</span>
                    </div>
                  </div>

                  <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden border border-slate-200 p-0.5">
                    <div
                      className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full transition-all duration-500 shadow-sm"
                      style={{ width: `${progressPercent}%` }}
                    />
                  </div>

                  {/* Milestone Pills */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-center text-xs">
                    {plan.installments.slice(0, 4).map((inst) => (
                      <div
                        key={inst.installmentNumber}
                        className={`p-2.5 rounded-2xl border transition ${
                          inst.status === 'PAID'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                            : inst.status === 'DUE'
                            ? 'bg-amber-50 border-amber-300 text-amber-950'
                            : 'bg-slate-50 border-slate-200 text-slate-600'
                        }`}
                      >
                        <span className="text-[10px] font-black uppercase block">{inst.title}</span>
                        <span className="font-mono font-bold text-xs block">₹{inst.amount.toLocaleString('en-IN')}</span>
                        <span className="text-[9px] font-extrabold uppercase mt-0.5 inline-block">
                          {inst.status === 'PAID' ? '✓ Paid' : inst.status === 'DUE' ? '⚠️ Due Now' : 'Upcoming'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Detailed Installments Table */}
                <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                    <div>
                      <h4 className="text-lg font-black text-blue-950 flex items-center gap-2">
                        <CalendarDays className="w-5 h-5 text-amber-600" />
                        <span>Installment Schedule & Dues Breakdown</span>
                        <span className="bg-blue-950 text-amber-400 text-xs font-black px-2.5 py-0.5 rounded-full">
                          {plan.planType} Plan
                        </span>
                      </h4>
                      <p className="text-xs text-slate-500">
                        Itemized breakdown of all installments, due dates, paid status, and online payment shortcuts.
                      </p>
                    </div>

                    <button
                      onClick={() => generateInstallmentSchedulePdf(plan)}
                      className="px-4 py-2 bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs rounded-xl shadow transition flex items-center gap-1.5 self-start sm:self-auto shrink-0"
                    >
                      <Download className="w-4 h-4 text-amber-400" />
                      <span>Download Schedule PDF</span>
                    </button>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="bg-slate-900 text-amber-300 uppercase tracking-wider font-extrabold text-[10px]">
                          <th className="py-3.5 px-4 w-12 text-center">#</th>
                          <th className="py-3.5 px-4">Particulars & Period</th>
                          <th className="py-3.5 px-4">Due Date</th>
                          <th className="py-3.5 px-4">Scheduled Amount</th>
                          <th className="py-3.5 px-4">Paid Amount</th>
                          <th className="py-3.5 px-4">Status</th>
                          <th className="py-3.5 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                        {plan.installments.map((inst) => (
                          <tr key={inst.installmentNumber} className="hover:bg-slate-50/80 transition">
                            <td className="py-3.5 px-4 text-center font-bold text-slate-500">
                              #{inst.installmentNumber}
                            </td>
                            <td className="py-3.5 px-4 font-bold text-blue-950">
                              <div>{inst.title}</div>
                              <span className="text-[10px] text-slate-500 font-normal">{inst.period}</span>
                            </td>
                            <td className="py-3.5 px-4 font-extrabold text-slate-700">
                              {inst.dueDate}
                            </td>
                            <td className="py-3.5 px-4 font-black text-blue-950 text-sm">
                              ₹{inst.amount.toLocaleString('en-IN')}
                            </td>
                            <td className="py-3.5 px-4 font-bold text-emerald-700">
                              ₹{inst.paidAmount.toLocaleString('en-IN')}
                            </td>
                            <td className="py-3.5 px-4">
                              {inst.status === 'PAID' ? (
                                <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-black px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">
                                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                                  <span>PAID</span>
                                </span>
                              ) : inst.status === 'DUE' ? (
                                <span className="bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-black px-2.5 py-0.5 rounded-full inline-flex items-center gap-1 animate-pulse">
                                  <AlertCircle className="w-3 h-3 text-amber-700" />
                                  <span>DUE NOW</span>
                                </span>
                              ) : (
                                <span className="bg-slate-100 text-slate-600 border border-slate-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full">
                                  UPCOMING
                                </span>
                              )}
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              {inst.status !== 'PAID' ? (
                                <button
                                  onClick={() => {
                                    setStudentName(plan.studentName);
                                    setStudentId(plan.studentId);
                                    setSelectedGrade(plan.grade);
                                    setPaymentPlanType(plan.planType);
                                    setSelectedInstallmentNo(inst.installmentNumber);
                                    setActiveSubTab('pay');
                                  }}
                                  className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-[11px] rounded-xl shadow transition inline-flex items-center gap-1"
                                >
                                  <CreditCard className="w-3.5 h-3.5 text-blue-950" />
                                  <span>Pay Installment #{inst.installmentNumber}</span>
                                </button>
                              ) : (
                                <div className="text-[10px] font-mono text-slate-500">
                                  Receipt: <span className="font-bold text-blue-900">{inst.receiptNo || 'Verified'}</span>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Interactive Fee Installment Calculator Widget */}
                <div className="bg-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-amber-400/50 shadow-xl space-y-6">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
                    <div>
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-amber-400/20 text-amber-300 rounded-full text-[10px] font-black uppercase mb-1">
                        <PieChart className="w-3 h-3 text-amber-400" />
                        <span>Interactive Cash Flow Planner</span>
                      </div>
                      <h4 className="text-lg font-black text-white">
                        Custom School Fee Installment Calculator
                      </h4>
                      <p className="text-xs text-slate-400">
                        Estimate installment amounts instantly for custom total annual fee amounts.
                      </p>
                    </div>

                    <div className="flex items-center gap-3 bg-slate-800 p-2.5 rounded-2xl border border-slate-700">
                      <span className="text-xs font-bold text-slate-300">Total Annual Fee:</span>
                      <span className="text-sm font-mono font-black text-amber-400">₹{installmentCalculatorAmount.toLocaleString('en-IN')}</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-bold text-slate-300">
                      Adjust Custom Annual Fee Amount (₹5,000 - ₹50,000)
                    </label>
                    <input
                      type="range"
                      min={5000}
                      max={50000}
                      step={500}
                      value={installmentCalculatorAmount}
                      onChange={(e) => setInstallmentCalculatorAmount(Number(e.target.value))}
                      className="w-full accent-amber-400 cursor-pointer h-2 bg-slate-800 rounded-lg"
                    />
                  </div>

                  {/* 3 Calculated Option Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    <div className="p-4 bg-slate-800/90 rounded-2xl border border-slate-700 space-y-2">
                      <div className="flex items-center justify-between text-amber-400 font-extrabold">
                        <span>Option A: Quarterly Plan</span>
                        <span className="bg-amber-400/20 px-2 py-0.5 rounded text-[10px]">4 Terms</span>
                      </div>
                      <div className="text-2xl font-black text-white">
                        ₹{Math.ceil(installmentCalculatorAmount / 4).toLocaleString('en-IN')}
                        <span className="text-xs text-slate-400 font-normal"> / quarter</span>
                      </div>
                      <p className="text-[10px] text-slate-400">Due every 3 months (April, July, Oct, Jan)</p>
                    </div>

                    <div className="p-4 bg-slate-800/90 rounded-2xl border border-amber-400/60 space-y-2 ring-2 ring-amber-400/30">
                      <div className="flex items-center justify-between text-amber-300 font-extrabold">
                        <span>Option B: Monthly Plan</span>
                        <span className="bg-amber-400 text-blue-950 font-black px-2 py-0.5 rounded text-[10px]">Most Popular</span>
                      </div>
                      <div className="text-2xl font-black text-amber-300">
                        ₹{Math.ceil(installmentCalculatorAmount / 10).toLocaleString('en-IN')}
                        <span className="text-xs text-slate-400 font-normal"> / month</span>
                      </div>
                      <p className="text-[10px] text-slate-400">10 equal monthly installments (June to March)</p>
                    </div>

                    <div className="p-4 bg-slate-800/90 rounded-2xl border border-slate-700 space-y-2">
                      <div className="flex items-center justify-between text-amber-400 font-extrabold">
                        <span>Option C: Half-Yearly</span>
                        <span className="bg-amber-400/20 px-2 py-0.5 rounded text-[10px]">2 Terms</span>
                      </div>
                      <div className="text-2xl font-black text-white">
                        ₹{Math.ceil(installmentCalculatorAmount / 2).toLocaleString('en-IN')}
                        <span className="text-xs text-slate-400 font-normal"> / semester</span>
                      </div>
                      <p className="text-[10px] text-slate-400">Due bi-annually (Term 1 & Term 2)</p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      )}

      {/* SUB-TAB 3: PUSH NOTIFICATIONS & 3-DAY REMINDERS */}
      {activeSubTab === 'push_reminders' && (
        <div className="animate-fadeIn space-y-8">
          {/* Top Status & Controls Banner */}
          <div className="bg-gradient-to-br from-blue-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 border border-blue-800/60 shadow-xl space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="space-y-2 max-w-2xl">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-400/20 text-amber-300 border border-amber-400/30 rounded-full text-xs font-black uppercase">
                  <BellRing className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                  <span>Automated Parent Push Notification System</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white">
                  3-Day Fee Deadline Gentle Reminders
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  Sends gentle, automated push alerts to parents exactly <strong>3 days prior</strong> to school fee deadlines. Prevents late fees and ensures uninterrupted academic participation for students.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
                <button
                  onClick={handleRequestPushPermission}
                  className={`px-5 py-3 rounded-2xl font-black text-xs transition flex items-center justify-center gap-2 shadow-lg ${
                    pushPermission === 'granted'
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 cursor-default'
                      : 'bg-amber-400 hover:bg-amber-300 text-blue-950'
                  }`}
                >
                  <Bell className="w-4 h-4" />
                  <span>
                    {pushPermission === 'granted'
                      ? '✓ Browser Push Active'
                      : 'Enable Browser Web Push'}
                  </span>
                </button>

                <button
                  onClick={() => handleTriggerPushNotification()}
                  className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4 text-amber-300" />
                  <span>Test Push Alert Now</span>
                </button>
              </div>
            </div>

            {/* Notification Configuration Controls */}
            <div className="pt-4 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs">
              {/* Lead Time */}
              <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 font-extrabold text-amber-300">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>Reminder Schedule Lead Time</span>
                </div>
                <p className="text-[11px] text-slate-400">Select when the automated alert dispatches:</p>
                <div className="grid grid-cols-2 gap-1.5 pt-1">
                  {[
                    { days: 3, label: '3 Days Prior (Default)' },
                    { days: 5, label: '5 Days Prior' },
                    { days: 7, label: '7 Days Prior' },
                    { days: 1, label: '1 Day Prior' },
                  ].map((opt) => (
                    <button
                      key={opt.days}
                      onClick={() => setReminderDaysBefore(opt.days)}
                      className={`px-2.5 py-1.5 rounded-xl font-bold text-[11px] transition text-center ${
                        reminderDaysBefore === opt.days
                          ? 'bg-amber-400 text-blue-950 shadow font-black'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Gentle Tone Selector */}
              <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 font-extrabold text-amber-300">
                  <MessageSquare className="w-4 h-4 text-amber-400" />
                  <span>Notification Message Tone</span>
                </div>
                <p className="text-[11px] text-slate-400">Choose wording style for parent alerts:</p>
                <div className="space-y-1 pt-1">
                  {[
                    { id: 'gentle', label: '🌸 Gentle & Respectful (Polite)' },
                    { id: 'standard', label: '🏫 Standard Academic Notice' },
                    { id: 'urgent', label: '⚡ Direct Fee Reminder' },
                  ].map((tn) => (
                    <button
                      key={tn.id}
                      onClick={() => setReminderTone(tn.id as any)}
                      className={`w-full text-left px-3 py-1.5 rounded-xl font-bold text-[11px] transition ${
                        reminderTone === tn.id
                          ? 'bg-amber-400 text-blue-950 font-black'
                          : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {tn.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Delivery Channels */}
              <div className="bg-slate-900/80 p-4 rounded-2xl border border-slate-800 space-y-2">
                <div className="flex items-center gap-2 font-extrabold text-amber-300">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>Active Delivery Channels</span>
                </div>
                <p className="text-[11px] text-slate-400">Automated multi-channel dispatch:</p>
                <div className="space-y-2 pt-1 font-bold text-[11px]">
                  <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                    <input
                      type="checkbox"
                      checked={channelBrowserPush}
                      onChange={(e) => setChannelBrowserPush(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-400"
                    />
                    <span>Browser Web Push Notification</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                    <input
                      type="checkbox"
                      checked={channelWhatsapp}
                      onChange={(e) => setChannelWhatsapp(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-400"
                    />
                    <span>WhatsApp Instant Alert (+91 9176593129)</span>
                  </label>

                  <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                    <input
                      type="checkbox"
                      checked={channelSms}
                      onChange={(e) => setChannelSms(e.target.checked)}
                      className="rounded border-slate-700 text-amber-500 focus:ring-amber-400"
                    />
                    <span>SMS Gateway Backup Alert</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          {/* MULTI-CHANNEL BULK FEE REMINDER & PRINTABLE NOTICES CONTROL CENTER */}
          <div className="bg-white border-2 border-blue-900/30 rounded-3xl p-6 sm:p-8 shadow-md space-y-6">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-100 text-blue-950 border border-blue-200 rounded-full text-xs font-black uppercase">
                  <SendHorizontal className="w-3.5 h-3.5 text-blue-900" />
                  <span>Bulk Parent Notification & Notice Printing Engine</span>
                </div>
                <h3 className="text-xl font-black text-slate-900">
                  Bulk Multi-Channel Fee Reminders & Printable A4 Notices
                </h3>
                <p className="text-xs text-slate-500">
                  Select target parents, choose delivery channels (WhatsApp, SMS, Email, Push Alerts), or generate official printable A4 reminder letters in bulk for offline distribution.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleDownloadBulkNoticesPdf}
                  className="px-4 py-2.5 bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs rounded-xl shadow transition flex items-center gap-2"
                >
                  <PrinterCheck className="w-4 h-4 text-amber-400" />
                  <span>Download Bulk Printable Notices (PDF)</span>
                </button>
              </div>
            </div>

            {/* Step 1 & 2: Channel Selection & Message Customizer */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Channel Toggles */}
              <div className="lg:col-span-5 bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
                <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <span>Select Active Channels ({Object.values(selectedChannels).filter(Boolean).length}/4)</span>
                </h4>

                <div className="grid grid-cols-2 gap-2 text-xs font-bold pt-1">
                  <label className={`p-3 rounded-xl border transition flex items-center gap-2 cursor-pointer ${selectedChannels.whatsapp ? 'bg-emerald-50 text-emerald-900 border-emerald-300' : 'bg-white text-slate-500 border-slate-200'}`}>
                    <input
                      type="checkbox"
                      checked={selectedChannels.whatsapp}
                      onChange={(e) => setSelectedChannels((prev) => ({ ...prev, whatsapp: e.target.checked }))}
                      className="rounded text-emerald-600 focus:ring-emerald-500"
                    />
                    <MessageCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>WhatsApp</span>
                  </label>

                  <label className={`p-3 rounded-xl border transition flex items-center gap-2 cursor-pointer ${selectedChannels.sms ? 'bg-amber-50 text-amber-900 border-amber-300' : 'bg-white text-slate-500 border-slate-200'}`}>
                    <input
                      type="checkbox"
                      checked={selectedChannels.sms}
                      onChange={(e) => setSelectedChannels((prev) => ({ ...prev, sms: e.target.checked }))}
                      className="rounded text-amber-600 focus:ring-amber-500"
                    />
                    <Smartphone className="w-4 h-4 text-amber-600 shrink-0" />
                    <span>SMS Gateway</span>
                  </label>

                  <label className={`p-3 rounded-xl border transition flex items-center gap-2 cursor-pointer ${selectedChannels.email ? 'bg-blue-50 text-blue-900 border-blue-300' : 'bg-white text-slate-500 border-slate-200'}`}>
                    <input
                      type="checkbox"
                      checked={selectedChannels.email}
                      onChange={(e) => setSelectedChannels((prev) => ({ ...prev, email: e.target.checked }))}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                    <Mail className="w-4 h-4 text-blue-600 shrink-0" />
                    <span>Parent Email</span>
                  </label>

                  <label className={`p-3 rounded-xl border transition flex items-center gap-2 cursor-pointer ${selectedChannels.push ? 'bg-purple-50 text-purple-900 border-purple-300' : 'bg-white text-slate-500 border-slate-200'}`}>
                    <input
                      type="checkbox"
                      checked={selectedChannels.push}
                      onChange={(e) => setSelectedChannels((prev) => ({ ...prev, push: e.target.checked }))}
                      className="rounded text-purple-600 focus:ring-purple-500"
                    />
                    <Bell className="w-4 h-4 text-purple-600 shrink-0" />
                    <span>Web Push</span>
                  </label>
                </div>

                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 font-medium space-y-1">
                  <strong>Placeholders supported in message:</strong>
                  <div className="flex flex-wrap gap-1 pt-1 font-mono text-[10px]">
                    <span className="bg-amber-200/80 px-1.5 py-0.5 rounded text-amber-950 font-bold">{'{student_name}'}</span>
                    <span className="bg-amber-200/80 px-1.5 py-0.5 rounded text-amber-950 font-bold">{'{student_id}'}</span>
                    <span className="bg-amber-200/80 px-1.5 py-0.5 rounded text-amber-950 font-bold">{'{fee_term}'}</span>
                    <span className="bg-amber-200/80 px-1.5 py-0.5 rounded text-amber-950 font-bold">{'{amount}'}</span>
                    <span className="bg-amber-200/80 px-1.5 py-0.5 rounded text-amber-950 font-bold">{'{due_date}'}</span>
                  </div>
                </div>
              </div>

              {/* Message Template Editor */}
              <div className="lg:col-span-7 bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-2">
                    <FileText className="w-4 h-4 text-blue-900" />
                    <span>Bulk Notification Text Template</span>
                  </h4>

                  <button
                    onClick={() =>
                      setCustomBulkTemplate(
                        '🔔 [Wisdom Nursery & Primary School, Essur]\nDear Parent, gentle fee payment reminder for {student_name} ({student_id}, {fee_term}).\n\nAmount Payable: {amount}\nDue Date: {due_date}\nOfficial School UPI: rsaravanan102002-1@okhdfcbank\n\nPay online instantly: https://wisdomessur.edu.in/fees?studentId={student_id}\nHelpdesk: +91 9176593129'
                      )
                    }
                    className="text-[10px] font-bold text-blue-900 hover:underline"
                  >
                    Reset Template
                  </button>
                </div>

                <textarea
                  value={customBulkTemplate}
                  onChange={(e) => setCustomBulkTemplate(e.target.value)}
                  rows={5}
                  className="w-full text-xs font-medium p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-900 bg-white text-slate-800"
                />
              </div>
            </div>

            {/* Bulk Dispatch Live Summary Report Banner */}
            {bulkDispatchReport && (
              <div className="bg-emerald-950 text-white p-5 rounded-2xl border-2 border-emerald-500 shadow-lg space-y-3 animate-fadeIn">
                <div className="flex items-center justify-between border-b border-emerald-800/80 pb-2">
                  <div className="flex items-center gap-2 text-emerald-300 font-extrabold text-sm">
                    <CheckCircle2 className="w-5 h-5 text-amber-400" />
                    <span>Bulk Reminder Campaign Dispatched Successfully</span>
                  </div>
                  <span className="text-xs font-mono font-black bg-emerald-800/60 px-2.5 py-1 rounded-lg">
                    {bulkDispatchReport.totalSent} Total Messages Dispatched
                  </span>
                </div>

                <p className="text-xs text-emerald-100 font-medium">{bulkDispatchReport.message}</p>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs pt-1">
                  <div className="bg-emerald-900/60 p-2.5 rounded-xl border border-emerald-700/80">
                    <span className="text-[10px] text-emerald-300 font-bold block">WhatsApp Alerts</span>
                    <strong className="text-base font-black text-amber-300">{bulkDispatchReport.whatsapp}</strong>
                  </div>
                  <div className="bg-emerald-900/60 p-2.5 rounded-xl border border-emerald-700/80">
                    <span className="text-[10px] text-emerald-300 font-bold block">SMS Messages</span>
                    <strong className="text-base font-black text-amber-300">{bulkDispatchReport.sms}</strong>
                  </div>
                  <div className="bg-emerald-900/60 p-2.5 rounded-xl border border-emerald-700/80">
                    <span className="text-[10px] text-emerald-300 font-bold block">Emails Sent</span>
                    <strong className="text-base font-black text-amber-300">{bulkDispatchReport.email}</strong>
                  </div>
                  <div className="bg-emerald-900/60 p-2.5 rounded-xl border border-emerald-700/80">
                    <span className="text-[10px] text-emerald-300 font-bold block">Web Push Alerts</span>
                    <strong className="text-base font-black text-amber-300">{bulkDispatchReport.push}</strong>
                  </div>
                </div>
              </div>
            )}

            {/* Target Parents Selector Table */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <button
                    onClick={toggleSelectAllDueStudents}
                    className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 transition flex items-center gap-1.5"
                  >
                    {selectedDueStudentIds.length === upcomingDueParents.length ? (
                      <CheckSquare className="w-4 h-4 text-blue-900" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-400" />
                    )}
                    <span>
                      {selectedDueStudentIds.length === upcomingDueParents.length
                        ? 'Deselect All'
                        : `Select All (${upcomingDueParents.length})`}
                    </span>
                  </button>

                  <span className="text-xs text-slate-600 font-bold">
                    Target Parents Selected: <strong className="text-blue-950">{selectedDueStudentIds.length} / {upcomingDueParents.length}</strong>
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleDispatchBulkReminders}
                    disabled={bulkDispatching || selectedDueStudentIds.length === 0}
                    className={`px-5 py-2.5 rounded-xl font-black text-xs transition flex items-center gap-2 shadow-lg ${
                      bulkDispatching || selectedDueStudentIds.length === 0
                        ? 'bg-slate-300 text-slate-500 cursor-not-allowed'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    {bulkDispatching ? (
                      <RefreshCw className="w-4 h-4 animate-spin text-amber-300" />
                    ) : (
                      <SendHorizontal className="w-4 h-4 text-amber-300" />
                    )}
                    <span>
                      {bulkDispatching
                        ? 'Dispatching Campaign...'
                        : `🚀 Dispatch Bulk Reminders (${selectedDueStudentIds.length} Parents)`}
                    </span>
                  </button>
                </div>
              </div>

              {/* Parents List Table */}
              <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 uppercase tracking-wider font-extrabold text-[10px]">
                      <th className="py-3 px-4 w-10 text-center">Select</th>
                      <th className="py-3 px-4">Student & Roll ID</th>
                      <th className="py-3 px-4">Class</th>
                      <th className="py-3 px-4">Parent Name & Contact</th>
                      <th className="py-3 px-4">Fee Particulars</th>
                      <th className="py-3 px-4">Due Amount</th>
                      <th className="py-3 px-4">Due Date</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                    {upcomingDueParents.map((p) => {
                      const isChecked = selectedDueStudentIds.includes(p.studentId);
                      return (
                        <tr key={p.studentId} className={`hover:bg-slate-50 transition ${isChecked ? 'bg-blue-50/30' : ''}`}>
                          <td className="py-3.5 px-4 text-center">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={() => toggleSelectDueStudent(p.studentId)}
                              className="w-4 h-4 rounded text-blue-900 border-slate-300 focus:ring-blue-900 cursor-pointer"
                            />
                          </td>
                          <td className="py-3.5 px-4 font-extrabold text-blue-950">
                            <div>{p.studentName}</div>
                            <span className="text-[10px] font-mono font-bold text-slate-400">{p.studentId}</span>
                          </td>
                          <td className="py-3.5 px-4 font-semibold text-slate-600">{p.grade}</td>
                          <td className="py-3.5 px-4">
                            <div className="font-bold text-slate-900">{p.parentName}</div>
                            <div className="text-[10px] text-slate-500 font-mono">Ph: +91 {p.parentPhone}</div>
                          </td>
                          <td className="py-3.5 px-4 font-bold text-slate-800">{p.feeParticulars}</td>
                          <td className="py-3.5 px-4 font-black text-amber-700 text-sm">₹{p.amountDue.toLocaleString('en-IN')}</td>
                          <td className="py-3.5 px-4 font-extrabold text-slate-700">{p.dueDate}</td>
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => generatePrintableReminderPdf(p)}
                                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-blue-950 font-bold text-[10px] rounded-lg transition flex items-center gap-1 border border-slate-300"
                                title="Download Printable Fee Notice (A4 PDF)"
                              >
                                <Printer className="w-3.5 h-3.5 text-blue-900" />
                                <span>Notice PDF</span>
                              </button>

                              <a
                                href={`https://wa.me/91${p.parentPhone}?text=${encodeURIComponent(
                                  customBulkTemplate
                                    .replace('{student_name}', p.studentName)
                                    .replace('{student_id}', p.studentId)
                                    .replace('{fee_term}', p.feeParticulars)
                                    .replace('{amount}', `₹${p.amountDue.toLocaleString('en-IN')}`)
                                    .replace('{due_date}', p.dueDate)
                                )}`}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1.5 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg transition border border-emerald-200"
                                title="Send WhatsApp Message to Parent"
                              >
                                <Share2 className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Upcoming Fee Deadlines Table with 3-Day Push Timelines */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-blue-900" />
                  <span>Upcoming Fee Deadlines & 3-Day Push Trigger Schedule</span>
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Automated push alerts are scheduled to fire exactly 3 days prior to each term fee deadline.
                </p>
              </div>

              <span className="text-xs font-black text-amber-800 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-200 self-start sm:self-auto">
                Trigger Rule: {reminderDaysBefore} Days Before Due Date
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 border-y border-slate-200 text-slate-500 uppercase tracking-wider font-extrabold text-[10px]">
                    <th className="py-3 px-4">Fee Particulars</th>
                    <th className="py-3 px-4">Class / Grade</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Fee Due Date</th>
                    <th className="py-3 px-4">3-Day Push Trigger Date</th>
                    <th className="py-3 px-4">Push Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                  {upcomingFeeDeadlines.map((dl) => (
                    <tr key={dl.id} className="hover:bg-slate-50/80 transition">
                      <td className="py-4 px-4 font-bold text-blue-950">{dl.term}</td>
                      <td className="py-4 px-4 font-semibold text-slate-600">{dl.grade}</td>
                      <td className="py-4 px-4 font-black text-slate-900">₹{dl.amount.toLocaleString('en-IN')}</td>
                      <td className="py-4 px-4 text-slate-700 font-extrabold">{dl.dueDate}</td>
                      <td className="py-4 px-4 text-amber-700 font-black bg-amber-50/50">
                        {dl.scheduledPushDate}
                      </td>
                      <td className="py-4 px-4">
                        <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-[10px] font-black px-2.5 py-1 rounded-full inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>Push Ready ({reminderDaysBefore} Days)</span>
                        </span>
                      </td>
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleTriggerPushNotification({
                              term: dl.term,
                              amount: dl.amount,
                              dueDate: dl.dueDate,
                              studentName: dl.studentName,
                            })}
                            className="px-2.5 py-1.5 bg-blue-950 hover:bg-blue-900 text-amber-400 font-black text-[10px] rounded-xl shadow transition inline-flex items-center gap-1"
                            title="Dispatch Push Alert"
                          >
                            <Send className="w-3 h-3 text-amber-400" />
                            <span>Push Alert</span>
                          </button>

                          <button
                            onClick={() => handleOpenAuthorizationModal({
                              term: dl.term,
                              amount: dl.amount,
                              dueDate: dl.dueDate,
                              studentName: dl.studentName,
                              studentId: 'WNS-2026-01',
                            })}
                            className="px-2.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-[10px] rounded-xl shadow transition inline-flex items-center gap-1"
                            title="Authorize Payment via Saved UPI ID"
                          >
                            <KeyRound className="w-3 h-3 text-blue-950" />
                            <span>Authorize UPI</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Live Mobile Device Push Notification Simulator Preview */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Device Lockscreen Mockup */}
            <div className="lg:col-span-5 bg-slate-900 rounded-3xl p-6 border-4 border-slate-800 shadow-2xl space-y-4 text-white">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-slate-300">Lock Screen Push Preview</span>
                </div>
                <span className="text-[10px] font-mono text-slate-500">3 Days Before Due Date</span>
              </div>

              {/* Smartphone Lock Screen Push Card */}
              <div className="bg-slate-800/90 rounded-2xl p-4 border border-slate-700 shadow-xl space-y-3 relative overflow-hidden">
                <div className="flex items-center justify-between text-slate-400 text-[10px] font-bold">
                  <div className="flex items-center gap-1.5 text-amber-300">
                    <img
                      src={SCHOOL_INFO.logoUrl}
                      alt="Logo"
                      className="w-4 h-4 rounded-full border border-amber-400 object-cover"
                    />
                    <span className="uppercase font-black text-[10px]">Wisdom School Essur</span>
                  </div>
                  <span>Just now • 3 Days Prior</span>
                </div>

                <div className="space-y-1">
                  <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                    <BellRing className="w-3.5 h-3.5 text-amber-400" />
                    <span>Fee Payment Gentle Reminder</span>
                  </h4>
                  <p className="text-[11px] text-slate-300 leading-snug">
                    {reminderTone === 'gentle'
                      ? `Dear Parent, this is a gentle reminder that Term 2 Fee (₹3,500) for R. Kavin is due in 3 days (15 August 2026). Tap to pay online via GPay/PhonePe.`
                      : `School Fee Alert: Term 2 Fee ₹3,500 for R. Kavin due on 15 August 2026. Pay online via UPI.`}
                  </p>
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => {
                      setActiveSubTab('pay');
                      window.scrollTo({ top: 300, behavior: 'smooth' });
                    }}
                    className="flex-1 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-[11px] rounded-xl text-center shadow transition"
                  >
                    Pay ₹3,500 via UPI Now
                  </button>
                  <button className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-300 text-[10px] font-bold rounded-xl">
                    Dismiss
                  </button>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 space-y-1.5 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
                <div className="flex items-center gap-1.5 font-bold text-amber-400">
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Audio & Visual Feedback</span>
                </div>
                <p>
                  Testing triggers an integrated web audio chime and a floating top-right push alert card in your app window.
                </p>
              </div>
            </div>

            {/* Right Column: Recent Notification Dispatch Logs */}
            <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <History className="w-4 h-4 text-blue-900" />
                  <span>Push Notification Dispatch Log</span>
                </h3>
                <span className="text-xs font-extrabold text-blue-900 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
                  {reminderLogs.length} Records Logged
                </span>
              </div>

              <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                {reminderLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-4 bg-slate-50 border border-slate-200 rounded-2xl space-y-2 hover:border-blue-300 transition text-xs"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="bg-blue-950 text-amber-400 font-mono text-[10px] font-black px-2 py-0.5 rounded-md">
                          {log.id}
                        </span>
                        <span className="font-extrabold text-slate-900">{log.studentName}</span>
                        <span className="text-slate-500">({log.term})</span>
                      </div>
                      <span className="text-[10px] font-bold text-slate-500">{log.sentAt}</span>
                    </div>

                    <p className="text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200/80 font-medium text-[11px] leading-relaxed">
                      {log.messageText}
                    </p>

                    <div className="flex items-center justify-between text-[10px] pt-1">
                      <span className="text-slate-500 font-bold uppercase">
                        Channel: <strong className="text-blue-900 font-black">{log.channel.toUpperCase()}</strong>
                      </span>
                      <span className="text-emerald-700 font-black flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                        <span>STATUS: {log.status}</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SUB-TAB 4: EDIT FEE RATES & VAN / TRANSPORT FEES */}
      {activeSubTab === 'fee_structure' && (
        <div className="animate-fadeIn space-y-6">
          {/* Header Banner */}
          <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 border border-blue-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-blue-950 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
                  Admin & Fee Rates Panel
                </span>
                <span className="text-xs text-amber-300 font-bold">• Wisdom School Essur</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
                <Settings className="w-6 h-6 text-amber-400" />
                <span>Edit Fee Structure, Sports & Van Fees</span>
              </h3>
              <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                Update Admission Fee rates, Sports & Athletics Fees, and School Van / Transport routes. Edit amounts or delete unused transport fees instantly.
              </p>
            </div>

            <button
              onClick={handleOpenAddFeeCat}
              className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-2xl shadow-lg transition flex items-center gap-2 shrink-0"
            >
              <Plus className="w-4 h-4 text-blue-950" />
              <span>+ Add New Fee Category</span>
            </button>
          </div>

          {/* Success Banner */}
          {feeCatSuccessMsg && (
            <div className="p-4 bg-emerald-500 text-white rounded-2xl font-bold text-xs shadow-md flex items-center gap-2 animate-fadeIn">
              <CheckCircle2 className="w-5 h-5 text-amber-300 shrink-0" />
              <span>{feeCatSuccessMsg}</span>
            </div>
          )}

          {/* Featured Cards for Admission, Sports, and Van Fees */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Admission Fee Card */}
            {(() => {
              const admCat = feeCategories.find((c) => c.categoryType === 'Admission' || c.key.includes('admission')) || feeCategories[0];
              return (
                <div className="bg-white border-2 border-blue-900 rounded-3xl p-5 shadow-sm space-y-4 relative overflow-hidden flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="bg-blue-100 text-blue-900 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border border-blue-200 inline-flex items-center gap-1">
                        <GraduationCap className="w-3.5 h-3.5 text-blue-800" />
                        Admission Fee
                      </span>
                      <span className="text-[10px] font-bold text-slate-400">{admCat?.frequency || 'One-Time'}</span>
                    </div>
                    <h4 className="text-base font-black text-slate-900">{admCat?.name || 'Admission Fee'}</h4>
                    <p className="text-xs text-slate-500 line-clamp-2">{admCat?.description}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Rate</span>
                      <span className="text-2xl font-black text-blue-950">₹{(admCat?.amount || 2500).toLocaleString('en-IN')}</span>
                    </div>

                    <button
                      onClick={() => admCat && handleOpenEditFeeCat(admCat)}
                      className="px-3.5 py-2 bg-blue-950 hover:bg-blue-900 text-amber-400 font-bold text-xs rounded-xl transition flex items-center gap-1.5 shadow"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                      <span>Edit Fee</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* Sports Fee Card */}
            {(() => {
              const sportsCat = feeCategories.find((c) => c.categoryType === 'Sports' || c.key.includes('sports'));
              return (
                <div className="bg-white border-2 border-amber-400 rounded-3xl p-5 shadow-sm space-y-4 relative overflow-hidden flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="bg-amber-100 text-amber-900 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border border-amber-300 inline-flex items-center gap-1">
                        <Trophy className="w-3.5 h-3.5 text-amber-700" />
                        Sports Fee
                      </span>
                      <span className="text-[10px] font-bold text-slate-400">{sportsCat?.frequency || 'Annual'}</span>
                    </div>
                    <h4 className="text-base font-black text-slate-900">{sportsCat?.name || 'Sports & Athletics Fee'}</h4>
                    <p className="text-xs text-slate-500 line-clamp-2">{sportsCat?.description}</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Rate</span>
                      <span className="text-2xl font-black text-amber-800">₹{(sportsCat?.amount || 1200).toLocaleString('en-IN')}</span>
                    </div>

                    <button
                      onClick={() => sportsCat && handleOpenEditFeeCat(sportsCat)}
                      className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 font-bold text-xs rounded-xl transition flex items-center gap-1.5 shadow"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-blue-950" />
                      <span>Edit Fee</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* Van / Transport Fees Summary Card */}
            {(() => {
              const vanCats = feeCategories.filter((c) => c.categoryType === 'Van / Transport' || c.key.includes('van') || c.name.toLowerCase().includes('van'));
              return (
                <div className="bg-white border-2 border-emerald-600 rounded-3xl p-5 shadow-sm space-y-4 relative overflow-hidden flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="bg-emerald-100 text-emerald-900 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border border-emerald-300 inline-flex items-center gap-1">
                        <Bus className="w-3.5 h-3.5 text-emerald-700" />
                        Van / Transport Fees
                      </span>
                      <span className="text-[10px] font-black text-emerald-700">{vanCats.length} Active Routes</span>
                    </div>
                    <h4 className="text-base font-black text-slate-900">School Van Transport Routes</h4>
                    <p className="text-xs text-slate-500">Edit van route fees or delete routes if no longer operational.</p>
                  </div>

                  <div className="pt-3 border-t border-slate-100 space-y-2">
                    {vanCats.map((v) => (
                      <div key={v.id} className="flex items-center justify-between bg-slate-50 p-2 rounded-xl border border-slate-200 text-xs">
                        <div>
                          <strong className="text-slate-900 block font-bold text-[11px] truncate max-w-[130px]">{v.name}</strong>
                          <span className="text-emerald-700 font-black">₹{v.amount.toLocaleString('en-IN')}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleOpenEditFeeCat(v)}
                            className="p-1.5 bg-slate-200 hover:bg-slate-300 text-blue-950 rounded-lg transition"
                            title="Edit Van Fee"
                          >
                            <Edit3 className="w-3 h-3" />
                          </button>
                          <button
                            onClick={() => handleDeleteFeeCat(v)}
                            className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg transition"
                            title="Delete Van Fee"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}

                    <button
                      onClick={handleOpenAddFeeCat}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow transition flex items-center justify-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add New Van Route Fee</span>
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Master Table of All Fee Categories with Edit & Delete Actions */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-blue-900" />
                  <span>Master Fee Particulars & Rate Chart</span>
                </h3>
                <p className="text-xs text-slate-500">
                  Manage all school fee categories, tuition terms, admission, sports, and van transport rates.
                </p>
              </div>

              <span className="bg-blue-100 text-blue-950 font-black text-xs px-3 py-1.5 rounded-full border border-blue-200 self-start sm:self-auto">
                Total Categories: {feeCategories.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-900 text-amber-300 font-black uppercase tracking-wider text-[10px]">
                    <th className="py-3.5 px-4">Particulars Name</th>
                    <th className="py-3.5 px-4">Category Type</th>
                    <th className="py-3.5 px-4">Frequency</th>
                    <th className="py-3.5 px-4">Fee Amount (₹)</th>
                    <th className="py-3.5 px-4">Description / Details</th>
                    <th className="py-3.5 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                  {feeCategories.map((cat) => (
                    <tr key={cat.id} className="hover:bg-slate-50 transition">
                      <td className="py-3.5 px-4 font-extrabold text-blue-950">
                        {cat.name}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="bg-slate-100 text-slate-800 font-bold px-2.5 py-0.5 rounded-full text-[10px] border border-slate-200">
                          {cat.categoryType || 'General'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-600">
                        {cat.frequency || 'Term-wise'}
                      </td>
                      <td className="py-3.5 px-4 font-black text-emerald-700 text-sm">
                        ₹{cat.amount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-slate-500 max-w-xs truncate">
                        {cat.description || '-'}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleOpenEditFeeCat(cat)}
                            className="px-2.5 py-1.5 bg-blue-950 hover:bg-blue-900 text-amber-400 font-bold text-[10px] rounded-lg shadow transition flex items-center gap-1"
                          >
                            <Edit3 className="w-3 h-3 text-amber-400" />
                            <span>Edit Rate</span>
                          </button>

                          {(cat.deletable || cat.categoryType === 'Van / Transport' || cat.key.includes('van') || cat.id.startsWith('fee-custom')) && (
                            <button
                              onClick={() => handleDeleteFeeCat(cat)}
                              className="px-2.5 py-1.5 bg-red-100 hover:bg-red-200 text-red-700 font-bold text-[10px] rounded-lg transition flex items-center gap-1"
                              title="Delete Fee Category"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Delete</span>
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* MODAL FOR EDITING / ADDING FEE CATEGORIES (Admission Fees, Sports Fees, Van Fees, etc.) */}
      {(editingFeeCat || showAddFeeModal) && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl border-2 border-blue-900 p-6 sm:p-8 max-w-lg w-full shadow-2xl relative space-y-6">
            <button
              onClick={() => {
                setEditingFeeCat(null);
                setShowAddFeeModal(false);
              }}
              className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-blue-950 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full">
                  {editingFeeCat ? 'Update Fee Rate' : 'New Fee Rate'}
                </span>
              </div>
              <h3 className="text-xl font-black text-blue-950 flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-amber-600" />
                <span>{editingFeeCat ? `Edit ${editingFeeCat.name}` : 'Add New Fee Category'}</span>
              </h3>
              <p className="text-xs text-slate-500">
                Modify the fee amount, description, or route details. Changes will apply immediately to parents and payment QR codes.
              </p>
            </div>

            <form onSubmit={handleSaveFeeCat} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Fee Particulars Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={feeCatForm.name}
                  onChange={(e) => setFeeCatForm({ ...feeCatForm, name: e.target.value })}
                  placeholder="e.g. Admission Fee, Sports Fee, School Van Fee (Route 1)"
                  className="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Fee Category Type
                  </label>
                  <select
                    value={feeCatForm.categoryType}
                    onChange={(e) => setFeeCatForm({ ...feeCatForm, categoryType: e.target.value })}
                    className="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                  >
                    <option value="Admission">Admission Fee</option>
                    <option value="Sports">Sports Fee</option>
                    <option value="Van / Transport">Van / Transport Fee</option>
                    <option value="Tuition">Tuition Fee</option>
                    <option value="Books">Books & Stationary</option>
                    <option value="Uniform">Uniform</option>
                    <option value="Other">Other Custom Fee</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Frequency
                  </label>
                  <select
                    value={feeCatForm.frequency}
                    onChange={(e) => setFeeCatForm({ ...feeCatForm, frequency: e.target.value })}
                    className="w-full text-xs font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                  >
                    <option value="One-Time">One-Time</option>
                    <option value="Term-wise">Term-wise</option>
                    <option value="Annual">Annual</option>
                    <option value="Monthly">Monthly</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Fee Amount (₹) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-xs font-black text-slate-500">₹</span>
                  <input
                    type="number"
                    required
                    min={0}
                    value={feeCatForm.amount}
                    onChange={(e) => setFeeCatForm({ ...feeCatForm, amount: Number(e.target.value) })}
                    className="w-full text-xs font-black pl-8 pr-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50 text-blue-950 text-base"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Description / Route Particulars
                </label>
                <textarea
                  rows={3}
                  value={feeCatForm.description}
                  onChange={(e) => setFeeCatForm({ ...feeCatForm, description: e.target.value })}
                  placeholder="e.g. Prospectus & ID card charges OR Van route coverage details..."
                  className="w-full text-xs font-medium p-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setEditingFeeCat(null);
                    setShowAddFeeModal(false);
                  }}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow transition flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4 text-amber-300" />
                  <span>Save Fee Rate</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* FLOATING INTERACTIVE PUSH NOTIFICATION TOAST BANNER */}
      {activePushToast && (
        <div className="fixed top-6 right-4 sm:right-6 z-50 max-w-md w-full bg-blue-950 text-white rounded-3xl p-5 border-2 border-amber-400 shadow-2xl animate-bounceIn space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-amber-400/20 text-amber-400 rounded-2xl border border-amber-400/30">
                <BellRing className="w-5 h-5 text-amber-300 animate-pulse" />
              </div>
              <div>
                <h4 className="text-xs font-black text-amber-300 uppercase tracking-wide">
                  {activePushToast.title}
                </h4>
                <span className="text-[10px] text-slate-300 font-semibold">
                  3 Days Prior Deadline Alert • Wisdom School
                </span>
              </div>
            </div>

            <button
              onClick={() => setActivePushToast(null)}
              className="p-1 bg-white/10 hover:bg-white/20 text-slate-300 rounded-full transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-slate-100 leading-relaxed font-medium bg-slate-900/80 p-3 rounded-2xl border border-slate-800">
            {activePushToast.body}
          </p>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() => {
                setActivePushToast(null);
                setActiveSubTab('pay');
                window.scrollTo({ top: 300, behavior: 'smooth' });
              }}
              className="flex-1 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition text-center"
            >
              Pay ₹{activePushToast.amount.toLocaleString('en-IN')} via UPI Now
            </button>
            <button
              onClick={() => setActivePushToast(null)}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-slate-300 font-bold text-xs rounded-xl"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* FULL PREVIEW RECEIPT MODAL */}
      {previewReceipt && (
        <div className="fixed inset-0 bg-blue-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="bg-white rounded-3xl border-2 border-blue-900 p-6 sm:p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto relative shadow-2xl space-y-6">
            <button
              onClick={() => setPreviewReceipt(null)}
              className="absolute top-4 right-4 p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition"
            >
              <X className="w-5 h-5" />
            </button>

            {/* School Header */}
            <div className="flex items-center space-x-3 border-b border-slate-200 pb-4">
              <img
                src={SCHOOL_INFO.logoUrl}
                alt={SCHOOL_INFO.name}
                referrerPolicy="no-referrer"
                className="w-12 h-12 rounded-full border border-amber-400 bg-white p-0.5 object-contain shrink-0"
              />
              <div>
                <h3 className="text-base font-black text-blue-950 uppercase">
                  WISDOM NURSERY AND PRIMARY SCHOOL
                </h3>
                <p className="text-[11px] font-bold text-amber-600">
                  ESSUR - 603301 | Official Payment Receipt
                </p>
              </div>
            </div>

            {/* Receipt Details Box */}
            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Receipt No:</span>
                <span className="font-mono font-bold text-blue-950 text-sm">{previewReceipt.receiptNo}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Date Paid:</span>
                <span className="font-semibold text-slate-800">{previewReceipt.date}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Student Name:</span>
                <span className="font-extrabold text-slate-900">{previewReceipt.studentName}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Class / Grade:</span>
                <span className="font-bold text-slate-800">{previewReceipt.grade}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">Payment Method:</span>
                <span className="font-semibold text-slate-800">{previewReceipt.paymentMethod}</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-400 uppercase font-bold block">UTR / Ref No:</span>
                <span className="font-mono text-slate-800 font-bold">{previewReceipt.transactionRef}</span>
              </div>
            </div>

            <div className="border-y border-slate-200 py-3 flex justify-between items-center font-bold text-sm">
              <span className="text-slate-700">Particulars ({previewReceipt.term}):</span>
              <span className="text-emerald-700 text-lg font-black">₹{previewReceipt.amount.toLocaleString('en-IN')}</span>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>Status: <strong className="text-emerald-600 uppercase font-black">VERIFIED ✓</strong></span>
              <span>Admin: R. SARAVANAN (+91 9176593129)</span>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => setPreviewReceipt(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl"
              >
                Close Preview
              </button>

              <button
                onClick={() => {
                  generateReceiptPdf(previewReceipt);
                  setPreviewReceipt(null);
                }}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow flex items-center gap-2"
              >
                <Download className="w-4 h-4 text-amber-300" />
                <span>Download PDF File</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SECURE RECURRING UPI AUTO-DEBIT AUTHORIZATION PIN MODAL */}
      {authModalOpen && pendingAuthItem && (
        <div className="fixed inset-0 bg-blue-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-slate-900 text-white border-2 border-amber-400 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl space-y-6 relative">
            <button
              onClick={() => setAuthModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-2 text-center">
              <div className="inline-flex p-3 bg-amber-400/20 text-amber-300 rounded-2xl border border-amber-400/30">
                <Lock className="w-7 h-7 text-amber-400" />
              </div>
              <h3 className="text-xl font-black text-white">
                Authorize UPI Fee Auto-Debit
              </h3>
              <p className="text-xs text-slate-300">
                Mandatory NPCI/RBI security verification before processing transaction.
              </p>
            </div>

            {/* Fee Summary Box */}
            <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-300">
                <span>Student Name:</span>
                <span className="font-extrabold text-white">{pendingAuthItem.studentName} ({pendingAuthItem.studentId})</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>Fee Particulars:</span>
                <span className="font-extrabold text-amber-300">{pendingAuthItem.term}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>Fee Due Date:</span>
                <span className="font-semibold text-slate-200">{pendingAuthItem.dueDate}</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>Saved UPI ID:</span>
                <span className="font-mono font-bold text-amber-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-700">{savedUpiId}</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-slate-700">
                <span className="font-extrabold text-slate-200">Total Deducted Amount:</span>
                <span className="font-black text-emerald-400 text-lg">₹{pendingAuthItem.amount.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {authStep === 'pin' && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-amber-300 text-center">
                    Enter Your 4 or 6-Digit UPI Security PIN
                  </label>
                  <input
                    type="password"
                    maxLength={6}
                    value={upiPin}
                    onChange={(e) => setUpiPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="••••"
                    className="w-full text-center text-2xl font-mono tracking-widest font-black py-3 rounded-2xl bg-slate-950 border-2 border-amber-400 text-amber-300 focus:outline-none focus:ring-4 focus:ring-amber-400/30"
                  />
                  {authError && (
                    <p className="text-[11px] text-red-400 font-bold text-center">{authError}</p>
                  )}
                </div>

                <button
                  onClick={handleConfirmUpiPinAuthorization}
                  className="w-full py-3.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-sm rounded-2xl shadow-lg transition flex items-center justify-center gap-2"
                >
                  <Fingerprint className="w-5 h-5 text-blue-950" />
                  <span>Authorize & Pay ₹{pendingAuthItem.amount.toLocaleString('en-IN')}</span>
                </button>
              </div>
            )}

            {authStep === 'verifying' && (
              <div className="py-8 text-center space-y-3">
                <div className="w-12 h-12 border-4 border-amber-400 border-t-transparent rounded-full animate-spin mx-auto" />
                <h4 className="text-sm font-black text-amber-300">Verifying NPCI Mandate & UPI PIN...</h4>
                <p className="text-xs text-slate-400">Connecting securely to {savedUpiId} bank gateway</p>
              </div>
            )}

            {authStep === 'success' && (
              <div className="py-4 text-center space-y-4">
                <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-full w-16 h-16 mx-auto flex items-center justify-center border border-emerald-400/40">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-lg font-black text-emerald-400">Transaction Pre-Authorized!</h4>
                  <p className="text-xs text-slate-300">
                    Fee payment of ₹{pendingAuthItem.amount.toLocaleString('en-IN')} for {pendingAuthItem.studentName} was processed successfully.
                  </p>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
                  <button
                    onClick={() => {
                      if (receiptsList.length > 0) {
                        generateReceiptPdf(receiptsList[0]);
                      }
                    }}
                    className="w-full sm:flex-1 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
                  >
                    <Download className="w-4 h-4 text-amber-300" />
                    <span>Download Printable PDF Receipt</span>
                  </button>

                  <button
                    onClick={() => {
                      setAuthModalOpen(false);
                      setActiveSubTab('history');
                    }}
                    className="w-full sm:w-auto px-4 py-3 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition"
                  >
                    View All History
                  </button>
                </div>
              </div>
            )}

            <div className="text-[10px] text-slate-400 text-center flex items-center justify-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>256-bit Encrypted Banking Channel • Wisdom School Official UPI Gateway</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

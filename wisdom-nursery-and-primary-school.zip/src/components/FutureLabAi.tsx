import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Bot,
  Microscope,
  BookOpen,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Globe,
  Award,
  Zap,
  Sun,
  Droplets,
  Sprout,
  CheckCircle2,
  MessageSquare,
  HelpCircle,
  Lightbulb,
  Compass,
  Star,
  Send,
  Languages,
} from 'lucide-react';

interface FutureLabProps {
  onOpenAiCounselor?: () => void;
}

export const FutureLabAi: React.FC<FutureLabProps> = ({ onOpenAiCounselor }) => {
  const [activeTab, setActiveTab] = useState<'story' | 'experiments' | 'curiosity' | 'badges'>('experiments');

  // Storyteller States
  const [storyTopic, setStoryTopic] = useState('The Clever Elephant and the Ant (Tamil Moral)');
  const [isNarrating, setIsNarrating] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<'English' | 'Tamil' | 'Bilingual'>('Bilingual');

  const sampleStories = [
    {
      id: 'st-1',
      title: 'The Helpful Banyan Tree of Essur',
      tamilTitle: 'எசூர் ஆலமரம் தரும் பாடம்',
      moral: 'Kindness always returns to you.',
      englishText: 'Once upon a time in Essur village, a giant Banyan Tree sheltered all the migratory birds. When a small sparrow broke her wing, the Banyan Tree dropped soft leaves to cushion her fall and guided her safely to Wisdom School garden.',
      tamilText: 'முன்னொரு காலத்தில் எசூர் கிராமத்தில் ஒரு பெரிய ஆலமரம் பறவைகளுக்கு அடைக்கலம் தந்தது. ஒரு சிறிய குருவி காயமடைந்த போது, ஆலமரம் மென்மையான இலைகளைப் பரப்பி அதைக் காப்பாற்றியது.',
      words: [
        { en: 'Banyan Tree', ta: 'ஆலமரம்' },
        { en: 'Kindness', ta: 'அன்பு / கருணை' },
        { en: 'Shelter', ta: 'அடைக்கலம்' },
      ],
    },
    {
      id: 'st-2',
      title: 'Raju & The Solar-Powered Toy Car',
      tamilTitle: 'ராஜூவின் சூரிய சக்தி பொம்மை கார்',
      moral: 'Clean energy protects our Earth.',
      englishText: 'Class 4 student Raju created a small solar panel car in Wisdom FutureLab. When sunlight hit the panel, electrons surged through the motor, making his car zoom past the Cheyyur playground without any petrol!',
      tamilText: 'விஸ்டம் பள்ளியின் 4ம் வகுப்பு மாணவன் ராஜூ சூரிய சக்தியால் இயங்கும் காரை உருவாக்கினான். சூரிய ஒளி பட்டவுடன் கார் வேகமாக ஓடியது!',
      words: [
        { en: 'Sunlight', ta: 'சூரிய ஒளி' },
        { en: 'Solar Energy', ta: 'சூரிய சக்தி' },
        { en: 'Clean Energy', ta: 'தூய்மையான ஆற்றல்' },
      ],
    },
  ];

  const [activeStory, setActiveStory] = useState(sampleStories[0]);

  // Web Speech API Narration
  const handleNarrateText = (text: string) => {
    if ('speechSynthesis' in window) {
      if (isNarrating) {
        window.speechSynthesis.cancel();
        setIsNarrating(false);
        return;
      }

      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 0.9;
      utterance.pitch = 1.0;
      utterance.onend = () => setIsNarrating(false);
      utterance.onerror = () => setIsNarrating(false);

      setIsNarrating(true);
      window.speechSynthesis.speak(utterance);
    } else {
      alert('Speech synthesis is not supported in this browser.');
    }
  };

  // Plant Growth Interactive Simulation States
  const [sunlightLevel, setSunlightLevel] = useState(50);
  const [waterLevel, setWaterLevel] = useState(50);
  const [soilType, setSoilType] = useState<'Loamy' | 'Clay' | 'Sandy'>('Loamy');
  const [plantStage, setPlantStage] = useState(1); // 1 = Seed, 2 = Sprout, 3 = Sapling, 4 = Blooming Flower

  useEffect(() => {
    // Calculate growth score
    const totalCare = (sunlightLevel + waterLevel) / 2;
    if (totalCare > 80 && soilType === 'Loamy') {
      setPlantStage(4);
    } else if (totalCare > 60) {
      setPlantStage(3);
    } else if (totalCare > 30) {
      setPlantStage(2);
    } else {
      setPlantStage(1);
    }
  }, [sunlightLevel, waterLevel, soilType]);

  // Curiosity AI Bot Query State
  const [curiosityQuery, setCuriosityQuery] = useState('');
  const [botChatHistory, setBotChatHistory] = useState<Array<{ role: 'user' | 'bot'; text: string; tamil?: string }>>([
    {
      role: 'bot',
      text: 'Hello young scientist! I am Wisdom FutureLab AI. Ask me any question like "Why do leaves change color?" or "How does a rainbow form?"',
      tamil: 'வணக்கம் இளம் விஞ்ஞானியே! உங்களுக்கு எந்த அறிவியல் சந்தேகம் இருந்தாலும் என்னிடம் கேளுங்கள்!',
    },
  ]);
  const [askingAi, setAskingAi] = useState(false);

  const predefinedQuestions = [
    'Why is the sky blue?',
    'How do birds fly in the sky?',
    'Why do plants need sunlight?',
    'How do computers count in 0 and 1?',
  ];

  const handleSendCuriosityQuestion = async (queryText?: string) => {
    const q = queryText || curiosityQuery;
    if (!q.trim()) return;

    const newHistory = [...botChatHistory, { role: 'user' as const, text: q }];
    setBotChatHistory(newHistory);
    setCuriosityQuery('');
    setAskingAi(true);

    try {
      const res = await fetch('/api/ai/counselor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `Explain this to a Primary School student (Class 1 to 5) at Wisdom Nursery and Primary School Essur in simple, exciting words with a short Tamil translation: "${q}"`,
          studentContext: { name: 'Kavin', grade: 'Class 4' },
        }),
      });

      const data = await res.json();
      if (data.success && data.reply) {
        setBotChatHistory([
          ...newHistory,
          {
            role: 'bot',
            text: data.reply,
          },
        ]);
      } else {
        // Fallback friendly response
        setBotChatHistory([
          ...newHistory,
          {
            role: 'bot',
            text: `Great curiosity question! "${q}" is explained by science: Natural light bends when passing through gases and moisture in Earth's atmosphere, creating amazing phenomena like blue skies and rainbows!`,
            tamil: 'சூரிய ஒளி பூமியின் வளிமண்டலத்தில் பட்டு சிதறும் போது நீல நிறமாக நமக்குத் தெரிகிறது!',
          },
        ]);
      }
    } catch (err) {
      setBotChatHistory([
        ...newHistory,
        {
          role: 'bot',
          text: `Sunlight consists of 7 colors (VIBGYOR). Blue light travels in shorter, smaller waves and scatters more than other colors in our atmosphere!`,
          tamil: 'சூரிய ஒளியில் உள்ள 7 நிறங்களில் நீல நிற ஒளி அதிகம் சிதறுவதால் வானம் நீலமாகத் தெரிகிறது!',
        },
      ]);
    } finally {
      setAskingAi(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header Hero Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl border-2 border-amber-400/40 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-15 pointer-events-none p-6">
          <Microscope className="w-80 h-80 text-amber-300" />
        </div>

        <div className="relative z-10 space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-amber-400 text-blue-950 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider shadow">
            <Sparkles className="w-4 h-4 text-blue-950 animate-spin" />
            <span>Wisdom School FutureLab AI v2026</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black text-white leading-tight">
            Next-Gen STEM Sandbox & Bilingual Story Lab
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">
            Empowering Nursery to Class 5 young innovators at Wisdom School, Essur with interactive science simulations, Tamil-English phonics, AI storytellers, and curiosity bots.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <div className="bg-white/10 backdrop-blur px-3 py-1.5 rounded-xl border border-white/20 text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span>120+ Wisdom Science Badges Unlocked</span>
            </div>
            <div className="bg-white/10 backdrop-blur px-3 py-1.5 rounded-xl border border-white/20 text-xs font-bold text-emerald-300 flex items-center gap-1.5">
              <Languages className="w-4 h-4 text-emerald-400" />
              <span>Tamil-English Bilingual Narration</span>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
        <button
          onClick={() => setActiveTab('experiments')}
          className={`flex-1 sm:flex-none px-4 py-2.5 rounded-xl font-extrabold text-xs transition flex items-center justify-center gap-2 ${
            activeTab === 'experiments'
              ? 'bg-blue-950 text-amber-400 shadow-md'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
          }`}
        >
          <Microscope className="w-4 h-4" />
          <span>Interactive Science Simulations</span>
        </button>

        <button
          onClick={() => setActiveTab('story')}
          className={`flex-1 sm:flex-none px-4 py-2.5 rounded-xl font-extrabold text-xs transition flex items-center justify-center gap-2 ${
            activeTab === 'story'
              ? 'bg-blue-950 text-amber-400 shadow-md'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Bilingual AI Storyteller & Phonics</span>
        </button>

        <button
          onClick={() => setActiveTab('curiosity')}
          className={`flex-1 sm:flex-none px-4 py-2.5 rounded-xl font-extrabold text-xs transition flex items-center justify-center gap-2 ${
            activeTab === 'curiosity'
              ? 'bg-blue-950 text-amber-400 shadow-md'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
          }`}
        >
          <Bot className="w-4 h-4" />
          <span>Curiosity AI Assistant</span>
        </button>

        <button
          onClick={() => setActiveTab('badges')}
          className={`flex-1 sm:flex-none px-4 py-2.5 rounded-xl font-extrabold text-xs transition flex items-center justify-center gap-2 ${
            activeTab === 'badges'
              ? 'bg-blue-950 text-amber-400 shadow-md'
              : 'bg-slate-50 hover:bg-slate-100 text-slate-700'
          }`}
        >
          <Award className="w-4 h-4" />
          <span>Wisdom Coins & Badges</span>
        </button>
      </div>

      {/* TAB 1: INTERACTIVE SCIENCE SIMULATIONS */}
      {activeTab === 'experiments' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Photosynthesis & Plant Growth Lab */}
          <div className="lg:col-span-7 bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-emerald-100 text-emerald-800 rounded-2xl">
                  <Sprout className="w-6 h-6 text-emerald-700" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-blue-950">
                    Interactive Photosynthesis & Plant Growth Lab
                  </h3>
                  <p className="text-xs text-slate-500">Adjust sunlight, water, and soil type to observe real-time botany development.</p>
                </div>
              </div>
            </div>

            {/* Visual Plant Growth Stage Container */}
            <div className="bg-gradient-to-b from-sky-100 via-emerald-50 to-amber-100 rounded-2xl p-6 border border-emerald-200 min-h-[220px] flex flex-col items-center justify-center relative overflow-hidden">
              {/* Sun Graphic */}
              <div
                className="absolute top-3 right-4 transition-transform duration-500 flex items-center gap-1"
                style={{ opacity: sunlightLevel / 100 }}
              >
                <Sun className="w-10 h-10 text-amber-500 animate-spin-slow" />
                <span className="text-[10px] font-bold text-amber-800">{sunlightLevel}% Sunlight</span>
              </div>

              {/* Rain Drops */}
              <div className="absolute top-3 left-4 flex items-center gap-1" style={{ opacity: waterLevel / 100 }}>
                <Droplets className="w-8 h-8 text-blue-500 animate-bounce" />
                <span className="text-[10px] font-bold text-blue-800">{waterLevel}% Water</span>
              </div>

              {/* Visual Plant Asset Rendering */}
              <div className="text-center space-y-2 mt-6">
                {plantStage === 1 && (
                  <div className="space-y-1 animate-fadeIn">
                    <div className="w-12 h-12 bg-amber-800 rounded-full mx-auto flex items-center justify-center text-white text-xs font-bold shadow">
                      🌱
                    </div>
                    <span className="font-extrabold text-xs text-amber-900 block">Stage 1: Seed Planted in {soilType} Soil</span>
                  </div>
                )}

                {plantStage === 2 && (
                  <div className="space-y-1 animate-fadeIn">
                    <div className="text-4xl animate-bounce">🌿</div>
                    <span className="font-extrabold text-xs text-emerald-900 block">Stage 2: Green Sprout Emerging</span>
                  </div>
                )}

                {plantStage === 3 && (
                  <div className="space-y-1 animate-fadeIn">
                    <div className="text-5xl">🪴</div>
                    <span className="font-extrabold text-xs text-emerald-950 block">Stage 3: Healthy Growing Sapling</span>
                  </div>
                )}

                {plantStage === 4 && (
                  <div className="space-y-1 animate-fadeIn">
                    <div className="text-6xl animate-pulse">🌻</div>
                    <span className="font-extrabold text-xs text-emerald-950 block">Stage 4: Full Photosynthesis Blossom!</span>
                  </div>
                )}
              </div>

              {/* Soil Bottom Bar */}
              <div className="w-full bg-amber-900/80 text-amber-100 text-[10px] py-1 px-3 text-center font-mono rounded-b-xl mt-6">
                Root System: Healthy • Nutrient Absorption Rate: {plantStage * 25}%
              </div>
            </div>

            {/* Interactive Control Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs pt-1">
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <label className="font-bold text-slate-800 flex justify-between">
                  <span>Sunlight (Energy)</span>
                  <span className="text-amber-600 font-mono">{sunlightLevel}%</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={sunlightLevel}
                  onChange={(e) => setSunlightLevel(Number(e.target.value))}
                  className="w-full accent-amber-500"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <label className="font-bold text-slate-800 flex justify-between">
                  <span>Water Supply</span>
                  <span className="text-blue-600 font-mono">{waterLevel}%</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={waterLevel}
                  onChange={(e) => setWaterLevel(Number(e.target.value))}
                  className="w-full accent-blue-600"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <label className="font-bold text-slate-800">Soil Nutrients</label>
                <select
                  value={soilType}
                  onChange={(e) => setSoilType(e.target.value as any)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-2 py-1 font-bold text-slate-800"
                >
                  <option value="Loamy">Rich Loamy Soil (Best)</option>
                  <option value="Clay">Clay Soil</option>
                  <option value="Sandy">Sandy Soil</option>
                </select>
              </div>
            </div>
          </div>

          {/* Quick Quiz & Solar System Sandbox */}
          <div className="lg:col-span-5 bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-100 text-indigo-800 rounded-2xl">
                  <Compass className="w-6 h-6 text-indigo-700" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-blue-950">
                    Solar System & Planets Explorer
                  </h3>
                  <p className="text-xs text-slate-500">Interactive space science module for Class 1 to 5.</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-950 text-white rounded-2xl p-4 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-amber-400 font-black flex items-center gap-1">
                  <Zap className="w-3.5 h-3.5" />
                  Space Fact of the Day
                </span>
                <span className="text-[10px] text-slate-400 font-mono">Sun ➔ Earth = 8 mins light</span>
              </div>

              <div className="flex items-center justify-around py-3">
                <div className="text-center space-y-1">
                  <div className="w-10 h-10 bg-amber-500 rounded-full mx-auto shadow-[0_0_15px_rgba(245,158,11,0.8)]" />
                  <span className="text-[10px] font-bold block text-amber-300">Sun</span>
                </div>
                <div className="text-slate-600 font-bold">---</div>
                <div className="text-center space-y-1">
                  <div className="w-6 h-6 bg-amber-700 rounded-full mx-auto" />
                  <span className="text-[10px] font-bold block text-slate-400">Mercury</span>
                </div>
                <div className="text-slate-600 font-bold">---</div>
                <div className="text-center space-y-1">
                  <div className="w-7 h-7 bg-blue-500 rounded-full mx-auto ring-2 ring-emerald-400 animate-pulse" />
                  <span className="text-[10px] font-bold block text-emerald-300">Earth 🌍</span>
                </div>
              </div>

              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs text-slate-300">
                <strong className="text-amber-400 block mb-1">Did You Know?</strong>
                Jupiter is so large that all other planets in our Solar System could fit inside it!
              </div>
            </div>

            {/* Quick Interactive Mini Quiz */}
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-2">
              <span className="text-[10px] font-black uppercase text-amber-800 block">
                🧠 Quick STEM Challenge (+10 Wisdom Coins)
              </span>
              <h4 className="font-extrabold text-xs text-blue-950">
                Which planet is known as the "Red Planet" due to iron oxide in its soil?
              </h4>
              <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                <button
                  onClick={() => alert('Correct! Mars is the Red Planet! You earned 10 Wisdom Coins!')}
                  className="py-1.5 px-3 bg-white hover:bg-emerald-100 hover:text-emerald-950 font-bold text-slate-800 rounded-xl border border-amber-300 transition text-left"
                >
                  A) Mars 🔴
                </button>
                <button
                  onClick={() => alert('Try again! Venus is very hot, but Mars is the Red Planet.')}
                  className="py-1.5 px-3 bg-white hover:bg-slate-100 font-bold text-slate-800 rounded-xl border border-amber-300 transition text-left"
                >
                  B) Venus
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BILINGUAL AI STORYTELLER */}
      {activeTab === 'story' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-blue-950">
                  Tamil-English Bilingual Moral Storyteller & Vocabulary
                </h3>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-300">
                  Voice Synthesis Active
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Enhance reading fluency and moral values with dual-language audio narration and phonics vocabulary chips.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() =>
                  handleNarrateText(
                    selectedLanguage === 'Tamil'
                      ? activeStory.tamilText
                      : `${activeStory.title}. ${activeStory.englishText}`
                  )
                }
                className={`px-4 py-2.5 rounded-2xl font-extrabold text-xs transition shadow flex items-center gap-2 ${
                  isNarrating
                    ? 'bg-red-600 text-white animate-pulse'
                    : 'bg-blue-950 hover:bg-blue-900 text-amber-400'
                }`}
              >
                {isNarrating ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-amber-400" />}
                <span>{isNarrating ? 'Stop Audio Narration' : 'Listen Story Voice Audio'}</span>
              </button>
            </div>
          </div>

          {/* Story Selector Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sampleStories.map((story) => (
              <div
                key={story.id}
                onClick={() => setActiveStory(story)}
                className={`p-4 rounded-2xl border-2 cursor-pointer transition ${
                  activeStory.id === story.id
                    ? 'border-amber-400 bg-amber-50/50 shadow-md'
                    : 'border-slate-200 hover:border-slate-300 bg-white'
                }`}
              >
                <span className="text-[10px] font-black uppercase text-amber-800 bg-amber-100 px-2 py-0.5 rounded border border-amber-300 mb-1 inline-block">
                  Moral: {story.moral}
                </span>
                <h4 className="font-extrabold text-sm text-blue-950">{story.title}</h4>
                <p className="text-xs text-slate-500 font-medium">{story.tamilTitle}</p>
              </div>
            ))}
          </div>

          {/* Story Viewer Display Box */}
          <div className="bg-gradient-to-br from-slate-50 via-blue-50/40 to-amber-50/30 p-6 rounded-3xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-blue-950">{activeStory.title}</h2>
                <span className="text-sm font-bold text-amber-800">{activeStory.tamilTitle}</span>
              </div>
              <span className="bg-emerald-100 text-emerald-900 text-xs font-black px-3 py-1 rounded-full border border-emerald-300">
                Class 1 to 5 Approved
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-extrabold text-xs text-blue-900 block border-b pb-1">
                  🇬🇧 English Version:
                </span>
                <p className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">
                  {activeStory.englishText}
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-slate-200 space-y-2">
                <span className="font-extrabold text-xs text-emerald-900 block border-b pb-1">
                  🇮🇳 தமிழ் வடிவம் (Tamil Version):
                </span>
                <p className="text-xs sm:text-sm text-slate-800 font-medium leading-relaxed">
                  {activeStory.tamilText}
                </p>
              </div>
            </div>

            {/* Phonics & Key Vocabulary Chips */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-extrabold text-slate-600 block uppercase tracking-wider">
                Key Vocabulary Words (சொற்களஞ்சியம்):
              </span>
              <div className="flex flex-wrap gap-2">
                {activeStory.words.map((w, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleNarrateText(`${w.en}, in Tamil, ${w.ta}`)}
                    className="px-3 py-1.5 bg-white hover:bg-amber-100 text-slate-800 hover:text-amber-950 rounded-xl border border-slate-300 text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-blue-900" />
                    <span>{w.en} = <strong>{w.ta}</strong></span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: CURIOSITY AI ASSISTANT */}
      {activeTab === 'curiosity' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
          <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
            <div className="p-3 bg-purple-100 text-purple-900 rounded-2xl">
              <Bot className="w-6 h-6 text-purple-800" />
            </div>
            <div>
              <h3 className="font-extrabold text-lg text-blue-950">
                Wisdom Buddy AI Curiosity Chat
              </h3>
              <p className="text-xs text-slate-500">Ask any science or general knowledge question in Tamil or English.</p>
            </div>
          </div>

          {/* Quick Predefined Questions */}
          <div className="space-y-1.5">
            <span className="text-xs font-bold text-slate-500">Popular Curiosity Prompts:</span>
            <div className="flex flex-wrap gap-2">
              {predefinedQuestions.map((q, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSendCuriosityQuestion(q)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-purple-100 text-slate-700 hover:text-purple-900 text-xs font-bold rounded-xl border border-slate-200 transition text-left"
                >
                  💡 "{q}"
                </button>
              ))}
            </div>
          </div>

          {/* Bot Chat Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-3xl p-4 sm:p-5 h-80 overflow-y-auto space-y-3">
            {botChatHistory.map((item, idx) => (
              <div
                key={idx}
                className={`flex gap-3 max-w-xl ${
                  item.role === 'user' ? 'ml-auto flex-row-reverse' : ''
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-2xl flex items-center justify-center shrink-0 text-xs font-black ${
                    item.role === 'user' ? 'bg-blue-950 text-amber-400' : 'bg-purple-600 text-white'
                  }`}
                >
                  {item.role === 'user' ? 'You' : 'AI'}
                </div>
                <div
                  className={`p-3.5 rounded-2xl text-xs sm:text-sm font-medium space-y-1 ${
                    item.role === 'user'
                      ? 'bg-blue-950 text-white rounded-tr-none'
                      : 'bg-white border border-slate-200 text-slate-800 shadow-sm rounded-tl-none'
                  }`}
                >
                  <p>{item.text}</p>
                  {item.tamil && (
                    <p className="text-xs text-emerald-700 font-bold pt-1 border-t border-slate-100">
                      🇮🇳 {item.tamil}
                    </p>
                  )}
                </div>
              </div>
            ))}

            {askingAi && (
              <div className="flex items-center gap-2 text-xs font-bold text-purple-700 p-2">
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Wisdom Buddy Bot is thinking...</span>
              </div>
            )}
          </div>

          {/* Input Field */}
          <div className="flex gap-2">
            <input
              type="text"
              value={curiosityQuery}
              onChange={(e) => setCuriosityQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendCuriosityQuestion()}
              placeholder="Ask Wisdom AI anything (e.g. How does rain happen?)..."
              className="flex-1 px-4 py-3 rounded-2xl border border-slate-300 text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-purple-800"
            />
            <button
              onClick={() => handleSendCuriosityQuestion()}
              className="px-5 py-3 bg-purple-900 hover:bg-purple-800 text-amber-300 font-black text-xs rounded-2xl transition shadow flex items-center gap-1.5"
            >
              <Send className="w-4 h-4" />
              <span>Ask AI</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 4: BADGES & WISDOM COINS */}
      {activeTab === 'badges' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div>
              <h3 className="text-lg font-extrabold text-blue-950">
                Wisdom Science & Innovation Badges
              </h3>
              <p className="text-xs text-slate-500">Gamified rewards for completing FutureLab quizzes and experiments.</p>
            </div>
            <div className="bg-amber-100 border border-amber-300 px-4 py-2 rounded-2xl text-right">
              <span className="text-[10px] uppercase font-black text-amber-900 block">Total Wisdom Coins</span>
              <span className="text-xl font-black text-amber-700">🪙 240 Coins</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {[
              {
                title: 'Young Astronomer',
                desc: 'Explored Solar System & Mars Quiz',
                icon: '🌌',
                unlocked: true,
                points: '+50 Coins',
              },
              {
                title: 'Botany Master',
                desc: 'Completed Photosynthesis Simulation',
                icon: '🌱',
                unlocked: true,
                points: '+40 Coins',
              },
              {
                title: 'Bilingual Story Reader',
                desc: 'Listened to 5 Tamil-English stories',
                icon: '📚',
                unlocked: true,
                points: '+30 Coins',
              },
              {
                title: 'Solar Energy Innovator',
                desc: 'Class 4 Clean Energy Module',
                icon: '☀️',
                unlocked: false,
                points: '+60 Coins',
              },
              {
                title: 'Math Genius',
                desc: 'Class 3 Geometry & Fractions',
                icon: '📐',
                unlocked: false,
                points: '+50 Coins',
              },
              {
                title: 'Robotics Pioneer',
                desc: 'FutureLab AI Logic Challenge',
                icon: '🤖',
                unlocked: false,
                points: '+100 Coins',
              },
            ].map((badge, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-2xl border-2 space-y-2 relative overflow-hidden ${
                  badge.unlocked
                    ? 'bg-amber-50/60 border-amber-300 text-slate-900 shadow-sm'
                    : 'bg-slate-50 border-slate-200 text-slate-400 opacity-70'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-3xl">{badge.icon}</span>
                  <span
                    className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                      badge.unlocked ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {badge.unlocked ? 'UNLOCKED' : 'LOCKED'}
                  </span>
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-blue-950">{badge.title}</h4>
                  <p className="text-xs text-slate-500 font-medium">{badge.desc}</p>
                </div>
                <div className="text-xs font-mono font-bold text-amber-700 pt-1">
                  {badge.points}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect, useRef } from 'react';
import jsQR from 'jsqr';
import QRCode from 'qrcode';
import {
  Ticket,
  Clock,
  MapPin,
  UserCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Plus,
  ArrowRight,
  ShieldCheck,
  Building2,
  X,
  QrCode,
  Sparkles,
  Search,
  Check,
  RotateCcw,
  Timer,
  Info,
  WifiOff,
  Database,
  CloudOff,
  Camera,
  Scan,
  Maximize2,
  CheckCircle,
  Volume2,
} from 'lucide-react';
import { StudentProfile } from '../types';
import { getCachedData, setCachedData, STORAGE_KEYS, addToSyncQueue } from '../utils/offlineStorage';
import { useOffline } from '../context/OfflineContext';

interface DigitalHallPassProps {
  student?: StudentProfile | null;
}

export interface HallPass {
  id: string;
  studentName: string;
  studentGrade: string;
  roomNumber: string;
  destination: 'Library Visit' | 'Restroom / Washroom' | 'Nurse / Medical Room' | 'Principal / Admin Office' | 'Sports Locker' | 'Computer / Science Lab' | 'Other Errand';
  purpose: string;
  approvingTeacher: string;
  requestedAt: string;
  allowedMinutes: number;
  remainingSeconds: number;
  status: 'Pending Approval' | 'Active' | 'Returned' | 'Overdue' | 'Rejected';
  passCode: string;
  returnedAt?: string;
  teacherNote?: string;
}

export const DigitalHallPass: React.FC<DigitalHallPassProps> = ({ student }) => {
  const { isOnline } = useOffline();

  const initialPasses: HallPass[] = [
    {
      id: 'pass-8821',
      studentName: student?.name || 'S. Kavin Vijay',
      studentGrade: student?.grade || 'Class 3-A',
      roomNumber: 'Room 104 (Primary Block)',
      destination: 'Library Visit',
      purpose: 'Returning reference atlas book & collecting science quiz materials',
      approvingTeacher: 'Mrs. Anitha Vijay (Class Teacher)',
      requestedAt: '10:15 AM Today',
      allowedMinutes: 15,
      remainingSeconds: 480, // 8 mins left
      status: 'Active',
      passCode: 'WNS-PASS-8821',
      teacherNote: 'Approved. Return before second bell.',
    },
    {
      id: 'pass-8820',
      studentName: student?.name || 'S. Kavin Vijay',
      studentGrade: student?.grade || 'Class 3-A',
      roomNumber: 'Room 104 (Primary Block)',
      destination: 'Nurse / Medical Room',
      purpose: 'Minor knee scratch during PE warm-up session',
      approvingTeacher: 'Mr. R. Karthik (PE Instructor)',
      requestedAt: '09:00 AM Today',
      allowedMinutes: 20,
      remainingSeconds: 0,
      status: 'Returned',
      passCode: 'WNS-PASS-8820',
      returnedAt: '09:18 AM Today',
      teacherNote: 'First aid bandage applied by school nurse.',
    },
    {
      id: 'pass-8819',
      studentName: student?.name || 'S. Kavin Vijay',
      studentGrade: student?.grade || 'Class 3-A',
      roomNumber: 'Room 104 (Primary Block)',
      destination: 'Principal / Admin Office',
      purpose: 'Handing over signed excursion consent slip',
      approvingTeacher: 'Mrs. Anitha Vijay (Class Teacher)',
      requestedAt: '25 Jul 2026',
      allowedMinutes: 10,
      remainingSeconds: 0,
      status: 'Returned',
      passCode: 'WNS-PASS-8819',
      returnedAt: '25 Jul 2026, 11:12 AM',
    },
  ];

  const [passes, setPasses] = useState<HallPass[]>(() => {
    return getCachedData<HallPass[]>(STORAGE_KEYS.HALL_PASSES, initialPasses);
  });

  useEffect(() => {
    setCachedData(STORAGE_KEYS.HALL_PASSES, passes);
  }, [passes]);

  // Live Timer Effect for Active Passes
  useEffect(() => {
    const timer = setInterval(() => {
      setPasses((prevPasses) =>
        prevPasses.map((p) => {
          if (p.status === 'Active') {
            if (p.remainingSeconds <= 1) {
              return { ...p, remainingSeconds: 0, status: 'Overdue' };
            }
            return { ...p, remainingSeconds: p.remainingSeconds - 1 };
          }
          return p;
        })
      );
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // QR Code Generation for all passes
  const [qrDataUrls, setQrDataUrls] = useState<Record<string, string>>({});

  useEffect(() => {
    passes.forEach(async (pass) => {
      try {
        const url = await QRCode.toDataURL(pass.passCode, {
          width: 280,
          margin: 1,
          color: { dark: '#0f172a', light: '#ffffff' },
        });
        setQrDataUrls((prev) => ({ ...prev, [pass.id]: url }));
      } catch (e) {
        console.error('Error generating QR code:', e);
      }
    });
  }, [passes]);

  // Modal State
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showQrDisplayModal, setShowQrDisplayModal] = useState<HallPass | null>(null);

  // Teacher Camera QR Scanner State
  const [showScannerModal, setShowScannerModal] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [scannedCode, setScannedCode] = useState<string | null>(null);
  const [verifiedPass, setVerifiedPass] = useState<HallPass | null | 'NOT_FOUND'>(null);
  const [manualCodeInput, setManualCodeInput] = useState('');
  const [scanActionMsg, setScanActionMsg] = useState('');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameIdRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startScannerCamera = async () => {
    setCameraError(null);
    setScannedCode(null);
    setVerifiedPass(null);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setCameraActive(true);
        requestAnimationFrame(tickScannerFrame);
      }
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError(
        'Camera access unavailable or blocked by browser frame. You can use the Quick Test Selector or Manual Pass Code search below to test instant QR verification.'
      );
      setCameraActive(false);
    }
  };

  const stopScannerCamera = () => {
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const tickScannerFrame = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (video && canvas && video.readyState === video.HAVE_ENOUGH_DATA) {
      const ctx = canvas.getContext('2d');
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert',
        });

        if (code && code.data) {
          handlePassCodeDetected(code.data);
          return; // pause frame loop once code is captured
        }
      }
    }

    animFrameIdRef.current = requestAnimationFrame(tickScannerFrame);
  };

  const handlePassCodeDetected = (codeString: string) => {
    setScannedCode(codeString);
    const cleanCode = codeString.trim().toUpperCase();
    const matched = passes.find((p) => p.passCode.toUpperCase() === cleanCode);

    if (matched) {
      setVerifiedPass(matched);
    } else {
      setVerifiedPass('NOT_FOUND');
    }
  };

  useEffect(() => {
    if (showScannerModal) {
      startScannerCamera();
    } else {
      stopScannerCamera();
    }
    return () => stopScannerCamera();
  }, [showScannerModal]);

  // Form State
  const [destination, setDestination] = useState<HallPass['destination']>('Library Visit');
  const [purpose, setPurpose] = useState('');
  const [duration, setDuration] = useState(10);
  const [teacher, setTeacher] = useState('Mrs. Anitha Vijay (Class Teacher)');
  const [room, setRoom] = useState('Room 104 (Primary Block)');

  // Request New Hall Pass
  const handleCreatePass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!purpose) return;

    const newPass: HallPass = {
      id: `pass-${Math.floor(1000 + Math.random() * 9000)}`,
      studentName: student?.name || 'S. Kavin Vijay',
      studentGrade: student?.grade || 'Class 3-A',
      roomNumber: room,
      destination: destination,
      purpose: purpose,
      approvingTeacher: teacher,
      requestedAt: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      allowedMinutes: duration,
      remainingSeconds: duration * 60,
      status: 'Active', // Instantly active for demo/teacher approval
      passCode: `WNS-PASS-${Math.floor(1000 + Math.random() * 9000)}`,
      teacherNote: 'Approved by Class Teacher via Smartboard Desk.',
    };

    if (!isOnline) {
      addToSyncQueue({
        id: `sync-${Date.now()}`,
        type: 'HALL_PASS',
        payload: newPass,
        createdAt: new Date().toISOString(),
      });
    }

    setPasses([newPass, ...passes]);
    setShowRequestModal(false);
    setPurpose('');
  };

  // Mark Returned
  const handleMarkReturned = (id: string) => {
    setPasses((prev) =>
      prev.map((p) => {
        if (p.id === id) {
          const updated = {
            ...p,
            status: 'Returned' as const,
            remainingSeconds: 0,
            returnedAt: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
          };
          if (verifiedPass && typeof verifiedPass === 'object' && verifiedPass.id === id) {
            setVerifiedPass(updated);
          }
          return updated;
        }
        return p;
      })
    );
    setScanActionMsg('Student marked returned to classroom!');
    setTimeout(() => setScanActionMsg(''), 3000);
  };

  const activePass = passes.find((p) => p.status === 'Active' || p.status === 'Overdue');

  const formatSeconds = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-950 text-amber-400 rounded-2xl shrink-0 shadow">
              <Ticket className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-blue-950">
                  Digital Hall Pass System
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-300 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-700" />
                  CORRIDOR SAFETY VERIFIED
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Request temporary hall clearance for library, nurse, or admin errands with real-time teacher approval & countdown badge.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
            <button
              onClick={() => setShowScannerModal(true)}
              className="px-4 py-2.5 rounded-xl font-black text-xs bg-amber-400 hover:bg-amber-300 text-blue-950 transition shadow-md flex items-center gap-2 border border-amber-300"
            >
              <Camera className="w-4 h-4 text-blue-950" />
              <span>Teacher QR Pass Scanner</span>
            </button>

            <button
              onClick={() => setShowRequestModal(true)}
              disabled={!!activePass}
              className={`px-4 py-2.5 rounded-xl font-black text-xs transition shadow flex items-center gap-2 ${
                activePass
                  ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
                  : 'bg-blue-950 hover:bg-blue-900 text-amber-400'
              }`}
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>{activePass ? 'Active Pass Running' : 'Request Digital Pass'}</span>
            </button>
          </div>
        </div>

        {/* Status Counters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-2xl text-blue-950">
            <span className="text-[10px] text-blue-800 font-bold uppercase block">Student Profile</span>
            <span className="font-extrabold text-sm text-blue-900 block mt-0.5">
              {student?.name || 'S. Kavin Vijay'} ({student?.grade || 'Class 3-A'})
            </span>
          </div>

          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-amber-950">
            <span className="text-[10px] text-amber-800 font-bold uppercase block">Active Corridor Status</span>
            <span className="font-extrabold text-sm text-amber-900 block mt-0.5">
              {activePass ? (activePass.status === 'Overdue' ? '⚠️ OVERDUE PASS' : '🟢 ON HALL PASS') : 'IN CLASSROOM'}
            </span>
          </div>

          <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950">
            <span className="text-[10px] text-emerald-800 font-bold uppercase block">Passes Issued Today</span>
            <span className="font-extrabold text-base text-emerald-900 block mt-0.5">
              {passes.filter((p) => p.requestedAt.includes('Today')).length} Completed
            </span>
          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Assigned Classroom</span>
            <span className="font-bold text-xs text-blue-950 block mt-0.5">Room 104 • Mrs. Anitha</span>
          </div>
        </div>
      </div>

      {/* ACTIVE HALL PASS LIVE BADGE (If present) */}
      {activePass && (
        <div className={`p-6 sm:p-8 rounded-3xl border-2 shadow-lg relative overflow-hidden text-white ${
          activePass.status === 'Overdue'
            ? 'bg-gradient-to-r from-red-950 via-red-900 to-red-950 border-red-500 animate-pulse'
            : 'bg-gradient-to-r from-blue-950 via-slate-900 to-blue-950 border-amber-400'
        }`}>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
            <div className="space-y-3 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-wider ${
                  activePass.status === 'Overdue'
                    ? 'bg-red-500 text-white'
                    : 'bg-amber-400 text-blue-950'
                }`}>
                  {activePass.status === 'Overdue' ? '⚠️ HALL PASS OVERDUE' : 'LIVE ACTIVE HALL PASS'}
                </span>
                <span className="text-xs font-bold text-slate-300">
                  Pass Code: <span className="font-mono text-amber-300">{activePass.passCode}</span>
                </span>
              </div>

              <div>
                <h3 className="text-2xl font-black tracking-tight text-white">
                  Destination: {activePass.destination}
                </h3>
                <p className="text-xs text-slate-300 pt-1 leading-relaxed">
                  Reason: {activePass.purpose}
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-slate-200 font-medium pt-1">
                <span className="flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-amber-400" />
                  Origin: {activePass.roomNumber}
                </span>
                <span className="flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                  Approver: {activePass.approvingTeacher}
                </span>
              </div>
            </div>

            {/* Countdown Clock, Actions & Student QR Badge */}
            <div className="flex flex-col sm:flex-row md:flex-col items-center justify-between gap-4 bg-white/10 backdrop-blur-md p-5 rounded-2xl border border-white/20 text-center shrink-0 self-stretch md:self-auto min-w-[220px]">
              {/* QR Code thumbnail for scanning */}
              {qrDataUrls[activePass.id] && (
                <div className="bg-white p-2 rounded-xl shadow border border-slate-200 shrink-0 text-slate-900 group relative">
                  <img
                    src={qrDataUrls[activePass.id]}
                    alt={`Pass QR Code ${activePass.passCode}`}
                    className="w-20 h-20 object-contain mx-auto"
                  />
                  <button
                    onClick={() => setShowQrDisplayModal(activePass)}
                    className="w-full mt-1 px-2 py-0.5 bg-blue-950 text-amber-400 font-extrabold text-[9px] rounded hover:bg-blue-900 transition flex items-center justify-center gap-1"
                  >
                    <Maximize2 className="w-2.5 h-2.5" />
                    <span>Show QR</span>
                  </button>
                </div>
              )}

              <div className="flex-1 w-full space-y-1">
                <span className="text-[10px] uppercase font-bold text-amber-300 block">Remaining Time</span>
                <div className="text-3xl font-black font-mono tracking-widest text-amber-400">
                  {formatSeconds(activePass.remainingSeconds)}
                </div>
                <span className="text-[10px] text-slate-300 block">Allowed: {activePass.allowedMinutes} Mins</span>

                <button
                  onClick={() => handleMarkReturned(activePass.id)}
                  className="w-full mt-2 py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-600 text-white font-black text-xs transition shadow flex items-center justify-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Mark Returned to Class</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* RECENT HALL PASS LOG TABLE */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 pb-3">
          <h3 className="font-extrabold text-base text-blue-950 flex items-center gap-2">
            <Clock className="w-5 h-5 text-blue-900" />
            <span>Digital Corridor Pass Log & History</span>
          </h3>
          <span className="text-xs text-slate-500 font-medium">
            Total Records: {passes.length}
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 text-slate-700 font-extrabold border-b border-slate-200">
                <th className="p-3.5 rounded-l-xl">Pass Code & Time</th>
                <th className="p-3.5">Destination</th>
                <th className="p-3.5">Purpose / Notes</th>
                <th className="p-3.5">Approving Teacher</th>
                <th className="p-3.5">QR Verification</th>
                <th className="p-3.5">Allowed</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 rounded-r-xl">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
              {passes.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/80 transition">
                  <td className="p-3.5">
                    <span className="font-mono font-bold text-blue-950 block">{p.passCode}</span>
                    <span className="text-[10px] text-slate-400">{p.requestedAt}</span>
                  </td>

                  <td className="p-3.5 font-extrabold text-blue-900">
                    {p.destination}
                  </td>

                  <td className="p-3.5 max-w-xs text-slate-600 truncate" title={p.purpose}>
                    {p.purpose}
                  </td>

                  <td className="p-3.5 text-slate-700">
                    {p.approvingTeacher}
                  </td>

                  <td className="p-3.5">
                    <button
                      onClick={() => setShowQrDisplayModal(p)}
                      className="px-2.5 py-1 bg-slate-100 hover:bg-amber-100 text-slate-800 hover:text-amber-950 text-[11px] font-extrabold rounded-lg border border-slate-200 transition flex items-center gap-1"
                    >
                      <QrCode className="w-3.5 h-3.5 text-blue-900" />
                      <span>View QR</span>
                    </button>
                  </td>

                  <td className="p-3.5 text-slate-600 font-bold">
                    {p.allowedMinutes} mins
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`px-2.5 py-1 rounded-full text-[10px] font-black ${
                        p.status === 'Active'
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : p.status === 'Overdue'
                          ? 'bg-red-100 text-red-900 border border-red-300'
                          : p.status === 'Returned'
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {p.status}
                    </span>
                  </td>

                  <td className="p-3.5">
                    {p.status === 'Active' || p.status === 'Overdue' ? (
                      <button
                        onClick={() => handleMarkReturned(p.id)}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-black rounded-lg transition"
                      >
                        Return Now
                      </button>
                    ) : (
                      <span className="text-[10px] text-slate-400 font-medium">
                        Returned at {p.returnedAt || 'N/A'}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* TEACHER CAMERA QR PASS SCANNER MODAL */}
      {showScannerModal && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-xl w-full space-y-5 shadow-2xl relative border-2 border-amber-400 max-h-[92vh] overflow-y-auto">
            <button
              onClick={() => setShowScannerModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Title */}
            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-amber-400 text-blue-950 rounded-2xl shadow">
                <Camera className="w-6 h-6 text-blue-950 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-lg text-blue-950">Teacher QR Pass Scanner</h3>
                  <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-300">
                    CAMERA ACTIVE
                  </span>
                </div>
                <p className="text-xs text-slate-500">Point lens at student hall pass QR badge or enter code manually for instant verification.</p>
              </div>
            </div>

            {/* Camera Viewfinder Box */}
            <div className="bg-slate-950 rounded-2xl border-2 border-slate-800 overflow-hidden relative min-h-[220px] flex items-center justify-center">
              <video
                ref={videoRef}
                className="w-full h-56 object-cover bg-slate-900"
              />
              <canvas ref={canvasRef} className="hidden" />

              {/* Viewfinder Reticle Overlay */}
              {cameraActive && (
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-48 h-48 border-2 border-dashed border-amber-400 rounded-2xl relative flex items-center justify-center shadow-[0_0_15px_rgba(251,191,36,0.3)]">
                    <div className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-amber-400 rounded-tl" />
                    <div className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-amber-400 rounded-tr" />
                    <div className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-amber-400 rounded-bl" />
                    <div className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-amber-400 rounded-br" />
                    <span className="text-[10px] font-mono text-amber-300 bg-slate-950/80 px-2 py-0.5 rounded-full border border-amber-400/40">
                      Align QR Code Inside Box
                    </span>
                  </div>
                </div>
              )}

              {!cameraActive && (
                <div className="p-6 text-center text-slate-300 text-xs space-y-2 max-w-sm">
                  <Scan className="w-8 h-8 text-amber-400 mx-auto animate-bounce" />
                  <p className="font-semibold text-slate-200">Camera Feed Initializing or Paused</p>
                  <p className="text-[11px] text-slate-400">
                    {cameraError || 'Allow camera permission in browser or use manual pass code lookup below.'}
                  </p>
                </div>
              )}
            </div>

            {/* Verification Result Feedback Box */}
            {verifiedPass && typeof verifiedPass === 'object' && (
              <div className={`p-4 rounded-2xl border-2 shadow-sm space-y-3 animate-fadeIn ${
                verifiedPass.status === 'Active'
                  ? 'bg-amber-50 border-amber-400 text-amber-950'
                  : verifiedPass.status === 'Overdue'
                  ? 'bg-red-50 border-red-400 text-red-950'
                  : 'bg-emerald-50 border-emerald-400 text-emerald-950'
              }`}>
                <div className="flex items-center justify-between border-b border-current/20 pb-2">
                  <div className="flex items-center gap-2 font-black text-sm">
                    {verifiedPass.status === 'Active' ? (
                      <CheckCircle className="w-5 h-5 text-amber-600" />
                    ) : verifiedPass.status === 'Overdue' ? (
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                    ) : (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    )}
                    <span>
                      {verifiedPass.status === 'Active'
                        ? 'VALID & ACTIVE HALL PASS'
                        : verifiedPass.status === 'Overdue'
                        ? 'OVERDUE HALL PASS EXPIRED'
                        : 'RETURNED PASS (COMPLETED)'}
                    </span>
                  </div>
                  <span className="font-mono text-xs font-bold px-2 py-0.5 bg-white/80 rounded border">
                    {verifiedPass.passCode}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Student:</span>
                    <strong className="font-bold text-slate-900">{verifiedPass.studentName} ({verifiedPass.studentGrade})</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">Destination:</span>
                    <strong className="font-bold text-slate-900">{verifiedPass.destination}</strong>
                  </div>
                  <div className="col-span-2">
                    <span className="text-[10px] text-slate-500 font-bold block">Reason:</span>
                    <p className="text-slate-800 font-medium">{verifiedPass.purpose}</p>
                  </div>
                </div>

                {verifiedPass.status === 'Active' || verifiedPass.status === 'Overdue' ? (
                  <button
                    onClick={() => handleMarkReturned(verifiedPass.id)}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black rounded-xl transition shadow flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Confirm Student Return to Classroom</span>
                  </button>
                ) : (
                  <div className="text-center text-xs font-bold text-emerald-800">
                    ✓ Student verified as returned to classroom.
                  </div>
                )}
              </div>
            )}

            {verifiedPass === 'NOT_FOUND' && (
              <div className="p-4 bg-red-50 border border-red-300 rounded-2xl text-red-900 text-xs space-y-1">
                <span className="font-black flex items-center gap-1 text-red-700">
                  <XCircle className="w-4 h-4" />
                  INVALID OR UNKNOWN PASS CODE: "{scannedCode}"
                </span>
                <p className="text-slate-700">
                  No matching active digital pass found in Wisdom School ERP database.
                </p>
              </div>
            )}

            {scanActionMsg && (
              <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-bold rounded-xl text-center animate-fadeIn">
                {scanActionMsg}
              </div>
            )}

            {/* Quick Test Pass Selector & Manual Lookup */}
            <div className="space-y-3 border-t border-slate-100 pt-3">
              <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                <span>Manual Pass Code Verification or Test Selector:</span>
                <span className="text-[10px] text-slate-400 font-normal">Click pass code to test camera scan</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                {passes.slice(0, 4).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handlePassCodeDetected(p.passCode)}
                    className={`p-2.5 rounded-xl border text-left transition flex items-center justify-between ${
                      scannedCode === p.passCode
                        ? 'bg-amber-100 border-amber-400 text-amber-950 font-bold'
                        : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-800'
                    }`}
                  >
                    <div>
                      <span className="font-mono font-bold block text-blue-950 text-xs">{p.passCode}</span>
                      <span className="text-[10px] text-slate-500 truncate block">{p.destination}</span>
                    </div>
                    <span className="text-[10px] font-black uppercase text-slate-600 bg-white px-2 py-0.5 rounded border">
                      {p.status}
                    </span>
                  </button>
                ))}
              </div>

              {/* Manual search input */}
              <div className="flex gap-2 text-xs">
                <input
                  type="text"
                  value={manualCodeInput}
                  onChange={(e) => setManualCodeInput(e.target.value)}
                  placeholder="Enter pass code (e.g. WNS-PASS-8821)"
                  className="flex-1 px-3.5 py-2 rounded-xl border border-slate-300 font-mono text-xs focus:outline-none"
                />
                <button
                  onClick={() => handlePassCodeDetected(manualCodeInput)}
                  className="px-4 py-2 bg-blue-950 text-amber-400 font-black rounded-xl hover:bg-blue-900 transition"
                >
                  Verify Code
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ENLARGED STUDENT QR CODE DISPLAY MODAL */}
      {showQrDisplayModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full text-center space-y-4 shadow-2xl relative border-2 border-amber-400 animate-scaleUp text-slate-900">
            <button
              onClick={() => setShowQrDisplayModal(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="bg-amber-100 text-amber-900 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border border-amber-300">
                Wisdom School Official Hall Pass
              </span>
              <h3 className="text-xl font-black text-blue-950">
                {showQrDisplayModal.destination}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Pass Code: <span className="font-mono font-bold text-blue-900">{showQrDisplayModal.passCode}</span>
              </p>
            </div>

            {/* QR Code Container */}
            <div className="p-4 bg-slate-50 border-2 border-slate-200 rounded-2xl inline-block max-w-[240px] shadow-sm">
              {qrDataUrls[showQrDisplayModal.id] ? (
                <img
                  src={qrDataUrls[showQrDisplayModal.id]}
                  alt={`QR ${showQrDisplayModal.passCode}`}
                  className="w-48 h-48 object-contain mx-auto"
                />
              ) : (
                <div className="w-48 h-48 flex items-center justify-center text-slate-400 text-xs font-mono">
                  Generating QR...
                </div>
              )}
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-3 text-left text-xs space-y-1">
              <div className="flex justify-between font-extrabold text-blue-950">
                <span>Student: {showQrDisplayModal.studentName}</span>
                <span>{showQrDisplayModal.studentGrade}</span>
              </div>
              <div className="text-slate-600">
                Reason: {showQrDisplayModal.purpose}
              </div>
              <div className="text-[11px] text-emerald-800 font-bold pt-1 border-t border-blue-200">
                Approver: {showQrDisplayModal.approvingTeacher}
              </div>
            </div>

            <button
              onClick={() => setShowQrDisplayModal(null)}
              className="w-full py-2.5 bg-blue-950 hover:bg-blue-900 text-amber-400 font-black text-xs rounded-xl transition shadow"
            >
              Close QR Pass
            </button>
          </div>
        </div>
      )}

      {/* REQUEST DIGITAL HALL PASS MODAL */}
      {showRequestModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setShowRequestModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl">
                <Ticket className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">New Digital Hall Pass Request</h4>
                <p className="text-xs text-slate-500">Student: {student?.name || 'S. Kavin Vijay'} ({student?.grade || 'Class 3-A'})</p>
              </div>
            </div>

            <form onSubmit={handleCreatePass} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Destination Location *</label>
                <select
                  value={destination}
                  onChange={(e: any) => setDestination(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                >
                  <option value="Library Visit">Library Visit</option>
                  <option value="Restroom / Washroom">Restroom / Washroom</option>
                  <option value="Nurse / Medical Room">Nurse / Medical Room</option>
                  <option value="Principal / Admin Office">Principal / Admin Office</option>
                  <option value="Sports Locker">Sports Locker</option>
                  <option value="Computer / Science Lab">Computer / Science Lab</option>
                  <option value="Other Errand">Other Errand</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Reason for Hall Leave *</label>
                <input
                  type="text"
                  required
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="e.g. Returning encyclopedia book to librarian Mrs. Deepa"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Requested Duration</label>
                  <select
                    value={duration}
                    onChange={(e) => setDuration(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                  >
                    <option value={5}>5 Minutes (Quick)</option>
                    <option value={10}>10 Minutes (Standard)</option>
                    <option value={15}>15 Minutes (Library / Nurse)</option>
                    <option value={20}>20 Minutes (Extended)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Approving Teacher</label>
                  <select
                    value={teacher}
                    onChange={(e) => setTeacher(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                  >
                    <option value="Mrs. Anitha Vijay (Class Teacher)">Mrs. Anitha Vijay (Class Teacher)</option>
                    <option value="Mr. K. Raman (Math Teacher)">Mr. K. Raman (Math Teacher)</option>
                    <option value="Mr. R. Karthik (PE Instructor)">Mr. R. Karthik (PE Instructor)</option>
                    <option value="Mrs. Deepa (Librarian)">Mrs. Deepa (Librarian)</option>
                  </select>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
                📌 Digital pass will transmit instantly to teacher's classroom smartboard for approval.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowRequestModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black transition shadow flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 text-amber-400" />
                  <span>Issue Digital Pass</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

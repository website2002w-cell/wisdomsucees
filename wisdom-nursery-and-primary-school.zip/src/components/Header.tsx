import React, { useState } from 'react';
import {
  GraduationCap,
  CreditCard,
  UserCheck,
  FileText,
  Smartphone,
  PhoneCall,
  Menu,
  X,
  Sparkles,
  Award,
  BookOpen,
  ShieldCheck,
  CalendarDays,
  LayoutDashboard,
  ShoppingBag,
  PackageCheck,
  MessageSquarePlus,
  Ticket,
  Wifi,
  WifiOff,
  Database,
  Bus,
  MessageSquare,
  Camera,
  BookMarked,
  Video,
  BellRing,
} from 'lucide-react';
import { SCHOOL_INFO } from '../data/schoolData';
import { useOffline } from '../context/OfflineContext';
import { useAuth } from '../context/AuthContext';
import { RoleManagementModal } from './RoleManagementModal';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenAiChat: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onOpenAiChat }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [roleModalOpen, setRoleModalOpen] = useState(false);
  const { isOnline, isSimulatedOffline, toggleSimulatedOffline } = useOffline();
  const { currentUser, roles, switchUserRole } = useAuth();

  const navItems = [
    { id: 'home', label: 'Home', icon: BookOpen },
    { id: 'zoom-classes', label: 'Zoom Online Classes', icon: Video, highlight: true, roleRequired: 'TEACHER / PARENT' },
    { id: 'future-lab', label: 'FutureLab STEM & AI', icon: Sparkles, roleRequired: 'STUDENT / ALL' },
    { id: 'erp', label: 'School ERP Modules', icon: LayoutDashboard, roleRequired: 'TEACHER / ADMIN' },
    { id: 'van-tracker', label: 'Live Bus Tracker', icon: Bus, roleRequired: 'PARENT / DRIVER' },
    { id: 'parent-connect', label: 'Parent-Teacher Connect', icon: MessageSquare, roleRequired: 'PARENT / TEACHER' },
    { id: 'library', label: 'Library Catalog', icon: BookMarked, roleRequired: 'STUDENT / ALL' },
    { id: 'fee-payment', label: 'Online Fee Payment', icon: CreditCard, roleRequired: 'PARENT' },
    { id: 'store', label: 'School Store', icon: ShoppingBag },
    { id: 'lost-found', label: 'Lost & Found', icon: PackageCheck },
    { id: 'achievements', label: 'Achievements & Badges', icon: Award },
    { id: 'suggestion-box', label: 'Suggestion Box', icon: MessageSquarePlus },
    { id: 'hall-pass', label: 'Digital Hall Pass', icon: Ticket, roleRequired: 'STUDENT / TEACHER' },
    { id: 'student-portal', label: 'Student Portal', icon: UserCheck, roleRequired: 'STUDENT / PARENT' },
    { id: 'calendar', label: 'Academic Calendar', icon: CalendarDays },
    { id: 'admissions', label: 'Admissions 2026', icon: GraduationCap },
    { id: 'notices', label: 'Notices & Circulars', icon: FileText },
    { id: 'gallery', label: 'Campus Gallery', icon: Camera },
    { id: 'admin', label: 'Admin Portal', icon: ShieldCheck, roleRequired: 'ADMIN ONLY' },
    { id: 'app-download', label: 'Android App', icon: Smartphone },
    { id: 'contact', label: 'Contact', icon: PhoneCall },
  ];


  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40 shadow-sm">
      {/* Top Banner Notice Line */}
      <div className="bg-slate-900 text-slate-200 text-xs py-1.5 px-4 font-medium flex flex-wrap justify-between items-center border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <span className="bg-amber-500 text-slate-950 text-[10px] uppercase font-bold px-2 py-0.5 rounded-full animate-pulse">
            Admissions Open 2026-27
          </span>
          <span className="hidden sm:inline text-slate-300">
            Wisdom Nursery & Primary School, Essur - 603301 | Admin: {SCHOOL_INFO.adminName}
          </span>
        </div>
        <div className="flex items-center space-x-3 text-slate-300 text-xs">
          <button
            onClick={toggleSimulatedOffline}
            title="Toggle simulated offline mode to test PWA caching"
            className={`px-2.5 py-0.5 rounded-full text-[10px] font-black transition border flex items-center gap-1 ${
              isSimulatedOffline
                ? 'bg-red-900/90 text-red-200 border-red-500'
                : 'bg-emerald-900/60 hover:bg-emerald-800 text-emerald-300 border-emerald-600'
            }`}
          >
            {isOnline ? (
              <>
                <Wifi className="w-3 h-3 text-emerald-400" />
                <span>ONLINE (Test Offline)</span>
              </>
            ) : (
              <>
                <WifiOff className="w-3 h-3 text-amber-300" />
                <span>OFFLINE CACHED</span>
              </>
            )}
          </button>

          <a href={`tel:${SCHOOL_INFO.phone}`} className="hover:text-amber-400 transition flex items-center gap-1">
            <PhoneCall className="w-3 h-3 text-amber-400" />
            <span>{SCHOOL_INFO.phone}</span>
          </a>
          <span className="hidden md:inline">|</span>
          <span className="hidden md:inline text-amber-300 font-semibold italic">"{SCHOOL_INFO.motto}"</span>
        </div>
      </div>

      {/* Main Header Brand Row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
        {/* Logo & School Title */}
        <div
          onClick={() => handleNavClick('home')}
          className="flex items-center space-x-3 cursor-pointer group"
        >
          <div className="relative">
            <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-white p-0.5 shadow-md border-2 border-amber-400 flex items-center justify-center transition group-hover:scale-105 overflow-hidden">
              <img
                src={SCHOOL_INFO.logoUrl}
                alt={SCHOOL_INFO.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain rounded-full"
              />
            </div>
            <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 text-[9px] font-black px-1.5 py-0.2 rounded-full border border-white">
              ESSUR
            </span>
          </div>

          <div>
            <h1 className="text-lg sm:text-xl md:text-2xl font-extrabold text-blue-950 leading-tight tracking-tight group-hover:text-blue-800 transition">
              WISDOM NURSERY AND PRIMARY SCHOOL
            </h1>
            <p className="text-xs sm:text-sm font-semibold text-amber-600 tracking-wide flex items-center gap-1">
              <span>ESSUR - 603301</span>
              <span className="text-slate-300">•</span>
              <span className="italic font-bold text-slate-600 text-[11px] sm:text-xs">
                "{SCHOOL_INFO.motto}"
              </span>
            </p>
          </div>
        </div>

        {/* Action Buttons Right (Desktop) */}
        <div className="hidden lg:flex items-center space-x-3">
          {/* User Role & Quick Switcher Dropdown */}
          <div className="flex items-center space-x-1.5 bg-slate-900 border border-slate-700 p-1 rounded-xl shadow-sm">
            <button
              onClick={() => setRoleModalOpen(true)}
              className="flex items-center space-x-2 text-white text-xs font-extrabold px-2.5 py-1.5 rounded-lg hover:bg-slate-800 transition"
              title="Open Role Creator & RBAC Security Settings"
            >
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
              <div className="text-left hidden xl:block">
                <span className="block text-[9px] text-amber-300 font-black uppercase leading-none">
                  {currentUser?.roleName || 'Guest'}
                </span>
                <span className="block text-[11px] font-medium text-slate-200 truncate max-w-[100px]">
                  {currentUser?.name || 'Login / Roles'}
                </span>
              </div>
            </button>

            {/* Quick Switch Select Dropdown */}
            <select
              value={currentUser?.roleId || ''}
              onChange={(e) => {
                const targetRoleId = e.target.value;
                if (targetRoleId) {
                  switchUserRole(targetRoleId);
                }
              }}
              onClick={(e) => e.stopPropagation()}
              className="bg-slate-800 text-amber-300 text-[11px] font-extrabold px-2 py-1.5 rounded-lg border border-slate-700 focus:outline-none cursor-pointer"
              title="Instant 1-Click Role Switcher"
            >
              {roles.map((r) => (
                <option key={r.id} value={r.id} className="bg-slate-900 text-white font-bold">
                  {r.code}: {r.name.split('/')[0]}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={onOpenAiChat}
            className="flex items-center space-x-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white text-xs font-bold px-3.5 py-2.5 rounded-lg shadow-sm transition transform active:scale-95"
          >
            <Sparkles className="w-4 h-4 text-amber-300 animate-spin" style={{ animationDuration: '4s' }} />
            <span>Ask AI Assistant</span>
          </button>

          <button
            onClick={() => handleNavClick('fee-payment')}
            className="relative flex items-center space-x-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-extrabold px-4 py-2.5 rounded-lg shadow-sm border border-amber-500 transition transform active:scale-95"
          >
            <CreditCard className="w-4 h-4 text-blue-950" />
            <span>Pay Fee (GPay/UPI)</span>
            <span className="absolute -top-2 -right-2 bg-red-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full border-2 border-white shadow-md animate-bounce flex items-center gap-0.5">
              <BellRing className="w-2.5 h-2.5 text-amber-300 animate-pulse" />
              <span>Due in 3d</span>
            </span>
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex items-center space-x-2 lg:hidden">
          <button
            onClick={() => setRoleModalOpen(true)}
            className="p-2 bg-slate-900 text-amber-400 border border-slate-700 rounded-lg text-xs font-bold flex items-center gap-1"
            title="Login / Role Creator"
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span className="text-[10px] font-black">{currentUser?.roleName.split(' ')[0] || 'Role'}</span>
          </button>
          <button
            onClick={onOpenAiChat}
            className="p-2 bg-purple-100 text-purple-800 rounded-lg text-xs font-bold flex items-center gap-1"
          >
            <Sparkles className="w-4 h-4 text-purple-600" />
            <span className="text-[11px]">AI</span>
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2.5 rounded-lg bg-slate-100 text-slate-800 hover:bg-slate-200 transition"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Desktop Navigation Links Row */}
      <nav className="hidden lg:block bg-slate-900 border-t border-slate-800">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between text-xs font-bold text-slate-300">
          <div className="flex space-x-1 py-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              const isFeePayment = item.id === 'fee-payment';
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative flex items-center space-x-2 px-3.5 py-2.5 rounded-md transition ${
                    isActive
                      ? 'bg-blue-800 text-white font-extrabold shadow-inner'
                      : item.highlight
                      ? 'text-amber-400 hover:bg-slate-800 font-bold'
                      : isFeePayment
                      ? 'text-amber-300 hover:bg-slate-800 font-extrabold'
                      : 'hover:bg-slate-800 hover:text-white'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : isFeePayment ? 'text-amber-400 animate-pulse' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {isFeePayment && (
                    <span className="bg-red-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full border border-red-400 shadow animate-pulse flex items-center gap-0.5 shrink-0 ml-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-300 animate-ping" />
                      <span>Due in 3d</span>
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <button
            onClick={() => handleNavClick('admin')}
            className="text-slate-300 hover:text-amber-300 transition text-[11px] font-semibold py-1 flex items-center gap-1 bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-700"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Admin Login: <strong className="text-white">{SCHOOL_INFO.adminName}</strong></span>
          </button>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 text-white border-t border-slate-800 px-4 py-4 space-y-2 animate-fadeIn">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            const isFeePayment = item.id === 'fee-payment';
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center justify-between px-4 py-3 rounded-lg text-sm font-semibold text-left transition ${
                  isActive
                    ? 'bg-blue-800 text-amber-300 font-bold'
                    : isFeePayment
                    ? 'bg-blue-950/90 text-amber-300 border border-amber-500/40 font-bold'
                    : 'bg-slate-800/60 hover:bg-slate-800 text-slate-200'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-amber-400' : isFeePayment ? 'text-amber-400 animate-pulse' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {isFeePayment && (
                  <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full border border-red-400 shadow animate-pulse flex items-center gap-1">
                    <BellRing className="w-3 h-3 text-amber-300" />
                    <span>Due in 3 Days</span>
                  </span>
                )}
              </button>
            );
          })}

          <div className="pt-3 border-t border-slate-800 grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                handleNavClick('fee-payment');
              }}
              className="relative w-full bg-amber-400 text-blue-950 font-black py-2.5 rounded-lg text-xs text-center flex items-center justify-center gap-1.5 shadow"
            >
              <CreditCard className="w-4 h-4" />
              <span>Pay Fees</span>
              <span className="bg-red-600 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full border border-amber-300 animate-bounce">
                Due in 3d
              </span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAiChat();
              }}
              className="w-full bg-purple-600 text-white font-bold py-2.5 rounded-lg text-xs text-center flex items-center justify-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>AI Chat</span>
            </button>
          </div>
        </div>
      )}

      {/* Login & Role Creation Modal */}
      <RoleManagementModal isOpen={roleModalOpen} onClose={() => setRoleModalOpen(false)} />
    </header>
  );
};

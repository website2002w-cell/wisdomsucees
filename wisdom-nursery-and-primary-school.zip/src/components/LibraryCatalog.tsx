import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  Filter,
  Bookmark,
  CheckCircle2,
  Clock,
  Sparkles,
  BookMarked,
  Tag,
  MapPin,
  Calendar,
  X,
  Check,
  Building2,
  ChevronRight,
  Info,
} from 'lucide-react';
import { StudentProfile } from '../types';
import { DEFAULT_STUDENT_PROFILE } from '../data/schoolData';

interface LibraryCatalogProps {
  student?: StudentProfile | null;
}

interface Book {
  id: string;
  title: string;
  author: string;
  genre: string;
  language: 'English' | 'Tamil' | 'Bilingual';
  coverUrl: string;
  copiesAvailable: number;
  totalCopies: number;
  shelfLocation: string;
  description: string;
  recommendedGrade: string;
}

interface BookReservation {
  id: string;
  bookId: string;
  bookTitle: string;
  reservedAt: string;
  pickupDueDate: string;
  status: 'Reserved for Pickup' | 'Issued' | 'Returned';
}

export const LibraryCatalog: React.FC<LibraryCatalogProps> = ({ student: inputStudent }) => {
  const student = inputStudent || DEFAULT_STUDENT_PROFILE;
  const [books] = useState<Book[]>([
    {
      id: 'bk-101',
      title: 'Panchatantra Moral Tales for Children',
      author: 'Vishnu Sharma',
      genre: 'Moral Stories & Folklore',
      language: 'Bilingual',
      coverUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=400&q=80',
      copiesAvailable: 3,
      totalCopies: 4,
      shelfLocation: 'Shelf A-02 (Junior Fiction)',
      description: 'Classic Indian fables with timeless moral lessons featuring animal characters.',
      recommendedGrade: 'Class 1 to 5',
    },
    {
      id: 'bk-102',
      title: 'Thirukkural with Illustrated Stories (திருக்குறள் கதைகள்)',
      author: 'Thiruvalluvar / Editorial Board',
      genre: 'Tamil Heritage & Literature',
      language: 'Tamil',
      coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=400&q=80',
      copiesAvailable: 2,
      totalCopies: 3,
      shelfLocation: 'Shelf T-01 (Tamil Heritage)',
      description: 'Beautifully illustrated Thirukkural couplets explained with child-friendly stories.',
      recommendedGrade: 'Class 2 to 5',
    },
    {
      id: 'bk-103',
      title: 'The Magic Drum and Other Favorite Stories',
      author: 'Sudha Murty',
      genre: 'Children Fiction',
      language: 'English',
      coverUrl: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?auto=format&fit=crop&w=400&q=80',
      copiesAvailable: 1,
      totalCopies: 2,
      shelfLocation: 'Shelf E-04 (English Stories)',
      description: 'Charming short stories filled with wit, humor, and wisdom from everyday Indian life.',
      recommendedGrade: 'Class 3 to 5',
    },
    {
      id: 'bk-104',
      title: 'Young Scientists: How Plants Grow & Space Exploration',
      author: 'Dr. A. P. J. Abdul Kalam Series',
      genre: 'Science & Discovery',
      language: 'English',
      coverUrl: 'https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&w=400&q=80',
      copiesAvailable: 4,
      totalCopies: 5,
      shelfLocation: 'Shelf S-03 (Science & Nature)',
      description: 'Interactive science facts, experiments, and space discoveries tailored for young minds.',
      recommendedGrade: 'Class 3 to 5',
    },
    {
      id: 'bk-105',
      title: 'Tenali Raman Witty Adventures (தெனாலி ராமன் கதைகள்)',
      author: 'Traditional Folk Tales',
      genre: 'Humor & Wisdom',
      language: 'Bilingual',
      coverUrl: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=400&q=80',
      copiesAvailable: 0,
      totalCopies: 3,
      shelfLocation: 'Shelf A-05 (Junior Humor)',
      description: 'Hilarious adventures of court jester Tenali Raman solving complex royal puzzles.',
      recommendedGrade: 'LKG to Class 5',
    },
    {
      id: 'bk-106',
      title: 'Wings of Fire (Student Edition)',
      author: 'Dr. A. P. J. Abdul Kalam',
      genre: 'Biography & Inspiration',
      language: 'English',
      coverUrl: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?auto=format&fit=crop&w=400&q=80',
      copiesAvailable: 2,
      totalCopies: 2,
      shelfLocation: 'Shelf B-01 (Biographies)',
      description: 'Inspirational autobiography of India’s Missile Man for young aspiring leaders.',
      recommendedGrade: 'Class 4 to 5',
    },
  ]);

  // Initial student reservations
  const [reservations, setReservations] = useState<BookReservation[]>([
    {
      id: 'res-901',
      bookId: 'bk-103',
      bookTitle: 'The Magic Drum and Other Favorite Stories',
      reservedAt: '26 Jul 2026, 05:30 PM',
      pickupDueDate: '28 Jul 2026 (Library Counter 2)',
      status: 'Reserved for Pickup',
    },
  ]);

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<string>('All');
  const [selectedLanguage, setSelectedLanguage] = useState<string>('All');

  // Modal / Alert State
  const [selectedBookForReservation, setSelectedBookForReservation] = useState<Book | null>(null);
  const [reservationSuccessMsg, setReservationSuccessMsg] = useState('');

  const genres = ['All', 'Moral Stories & Folklore', 'Tamil Heritage & Literature', 'Children Fiction', 'Science & Discovery', 'Humor & Wisdom', 'Biography & Inspiration'];

  const filteredBooks = books.filter((book) => {
    const matchesQuery =
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.genre.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === 'All' || book.genre === selectedGenre;
    const matchesLang = selectedLanguage === 'All' || book.language === selectedLanguage;
    return matchesQuery && matchesGenre && matchesLang;
  });

  const handleConfirmReservation = () => {
    if (!selectedBookForReservation) return;

    const now = new Date();
    const nextDay = new Date(now.valueOf() + 24 * 3600 * 1000);
    const timeStr = `Today, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    const dueStr = `${nextDay.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })} (School Library Desk)`;

    const newRes: BookReservation = {
      id: `res-${Date.now()}`,
      bookId: selectedBookForReservation.id,
      bookTitle: selectedBookForReservation.title,
      reservedAt: timeStr,
      pickupDueDate: dueStr,
      status: 'Reserved for Pickup',
    };

    setReservations([newRes, ...reservations]);
    setReservationSuccessMsg(`"${selectedBookForReservation.title}" reserved! Please pick up from Mrs. V. Srimathi (Librarian) by tomorrow.`);
    setSelectedBookForReservation(null);

    setTimeout(() => {
      setReservationSuccessMsg('');
    }, 5000);
  };

  const handleCancelReservation = (resId: string) => {
    setReservations(reservations.filter((r) => r.id !== resId));
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-100 text-indigo-900 rounded-2xl shrink-0">
              <BookOpen className="w-6 h-6 text-indigo-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-blue-950">
                  Wisdom School Digital Library Catalog
                </h3>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-300">
                  500+ Books Available
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Browse books, search by title or author, and reserve titles for library pickup for {student.name}.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-2xl border border-slate-200 text-xs font-bold text-slate-700">
            <Bookmark className="w-4 h-4 text-blue-900" />
            <span>Active Reservations: {reservations.length} / 2 allowed</span>
          </div>
        </div>

        {reservationSuccessMsg && (
          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl text-xs text-emerald-900 font-bold flex items-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <span>{reservationSuccessMsg}</span>
          </div>
        )}

        {/* Search & Genre Filters */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by book title, author, or keyword..."
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-800"
            />
          </div>

          <div className="md:col-span-4">
            <select
              value={selectedGenre}
              onChange={(e) => setSelectedGenre(e.target.value)}
              className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-800"
            >
              {genres.map((g) => (
                <option key={g} value={g}>Genre: {g}</option>
              ))}
            </select>
          </div>

          <div className="md:col-span-3">
            <select
              value={selectedLanguage}
              onChange={(e) => setSelectedLanguage(e.target.value)}
              className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-800"
            >
              <option value="All">Language: All Languages</option>
              <option value="English">Language: English</option>
              <option value="Tamil">Language: Tamil</option>
              <option value="Bilingual">Language: Bilingual</option>
            </select>
          </div>
        </div>
      </div>

      {/* STUDENT ACTIVE RESERVATIONS PANEL */}
      {reservations.length > 0 && (
        <div className="bg-amber-50/80 border border-amber-300 rounded-3xl p-5 space-y-3">
          <h4 className="font-extrabold text-xs text-amber-950 uppercase tracking-wider flex items-center gap-1.5">
            <BookMarked className="w-4 h-4 text-amber-800" />
            <span>Your Reserved Pickup Passes ({reservations.length})</span>
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {reservations.map((res) => (
              <div key={res.id} className="p-3.5 bg-white rounded-2xl border border-amber-200 shadow-xs flex items-center justify-between gap-3 text-xs">
                <div className="space-y-1">
                  <span className="bg-amber-100 text-amber-900 font-black text-[9px] px-2 py-0.5 rounded-full">
                    {res.status}
                  </span>
                  <h5 className="font-extrabold text-slate-900 leading-tight">{res.bookTitle}</h5>
                  <p className="text-[10px] text-slate-500 font-medium">
                    Collect by: <strong>{res.pickupDueDate}</strong>
                  </p>
                </div>

                <button
                  onClick={() => handleCancelReservation(res.id)}
                  className="text-[10px] font-bold text-red-600 hover:text-red-800 bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded-lg transition shrink-0"
                >
                  Cancel
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* BOOK CATALOG GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBooks.map((book) => {
          const isAvailable = book.copiesAvailable > 0;
          const isAlreadyReserved = reservations.some((r) => r.bookId === book.id);

          return (
            <div
              key={book.id}
              className="bg-white border border-slate-200 rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between"
            >
              {/* Cover Image & Language Pill Header */}
              <div className="relative h-48 bg-slate-900 overflow-hidden group">
                <img
                  src={book.coverUrl}
                  alt={book.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>

                <div className="absolute top-3 left-3 flex gap-1.5">
                  <span className="bg-blue-950/90 text-amber-300 font-black text-[9px] px-2.5 py-1 rounded-full border border-blue-800 backdrop-blur-xs">
                    {book.language}
                  </span>
                  <span className="bg-slate-900/80 text-slate-200 font-bold text-[9px] px-2 py-1 rounded-full border border-slate-700 backdrop-blur-xs">
                    {book.recommendedGrade}
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[9px] font-black uppercase text-amber-400 block tracking-wider">
                    {book.genre}
                  </span>
                  <h4 className="font-extrabold text-sm leading-snug line-clamp-2">
                    {book.title}
                  </h4>
                </div>
              </div>

              {/* Book Details Body */}
              <div className="p-5 space-y-4 flex-1 flex flex-col justify-between text-xs">
                <div className="space-y-2">
                  <p className="text-slate-500 font-semibold text-[11px]">
                    Author: <strong className="text-slate-800">{book.author}</strong>
                  </p>
                  <p className="text-slate-600 line-clamp-2 leading-relaxed text-[11px]">
                    {book.description}
                  </p>
                </div>

                <div className="space-y-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-500 font-medium flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-blue-900" />
                      {book.shelfLocation}
                    </span>

                    <span
                      className={`font-black text-[10px] px-2 py-0.5 rounded-full ${
                        isAvailable
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {isAvailable ? `${book.copiesAvailable} copies in stock` : 'Out of Stock'}
                    </span>
                  </div>

                  <button
                    onClick={() => setSelectedBookForReservation(book)}
                    disabled={!isAvailable || isAlreadyReserved}
                    className={`w-full py-2.5 rounded-xl font-extrabold text-xs transition flex items-center justify-center gap-2 ${
                      isAlreadyReserved
                        ? 'bg-amber-100 text-amber-900 cursor-not-allowed border border-amber-300'
                        : isAvailable
                        ? 'bg-blue-950 hover:bg-blue-900 text-amber-400 shadow'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    <BookMarked className="w-4 h-4" />
                    <span>
                      {isAlreadyReserved
                        ? 'Reserved in Pickup Pass'
                        : isAvailable
                        ? 'Reserve Book for Pickup'
                        : 'Currently Checked Out'}
                    </span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* CONFIRM RESERVATION MODAL */}
      {selectedBookForReservation && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setSelectedBookForReservation(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-indigo-100 text-indigo-900 rounded-2xl">
                <BookOpen className="w-6 h-6 text-indigo-900" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Confirm Library Reservation</h4>
                <p className="text-xs text-slate-500">Pickup at Wisdom School Library Desk</p>
              </div>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-2">
              <h5 className="font-extrabold text-blue-950 text-sm">{selectedBookForReservation.title}</h5>
              <p className="text-slate-600 font-medium">Author: {selectedBookForReservation.author}</p>
              <p className="text-slate-500">Shelf Location: <strong>{selectedBookForReservation.shelfLocation}</strong></p>
              <p className="text-slate-500">Student Name: <strong>{student.name} ({student.grade})</strong></p>
            </div>

            <p className="text-xs text-slate-600 font-medium leading-relaxed">
              Once confirmed, a pickup pass will be generated. You can collect this book during morning library hours (08:30 AM - 09:00 AM) or after school.
            </p>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedBookForReservation(null)}
                className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition text-xs"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmReservation}
                className="px-5 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black transition shadow flex items-center gap-1.5 text-xs"
              >
                <Check className="w-4 h-4 text-amber-400" />
                <span>Confirm Reservation Pass</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

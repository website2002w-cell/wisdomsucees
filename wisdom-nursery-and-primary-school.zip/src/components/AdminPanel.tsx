import React, { useState, useEffect, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  ShieldCheck,
  Lock,
  User,
  KeyRound,
  FileSpreadsheet,
  GraduationCap,
  CreditCard,
  Bell,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  Plus,
  Send,
  LogOut,
  AlertCircle,
  Sparkles,
  Search,
  Upload,
  Download,
  FileUp,
  Check,
  AlertTriangle,
  Trash2,
  Database,
  X,
  MessageCircle,
  Smartphone,
  MessageSquare,
  Share2,
  CheckSquare,
  Square,
  Filter,
  ExternalLink,
  ShieldAlert,
  Zap,
  RefreshCw,
} from 'lucide-react';
import { SCHOOL_INFO } from '../data/schoolData';
import { StudentExcelImporter, ExcelStudentRow } from './StudentExcelImporter';
import { AdmissionsConfigEditorModal } from './AdmissionsConfigEditorModal';

interface AdminPanelProps {
  onLogout?: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = () => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [username, setUsername] = useState('WISDOM');
  const [password, setPassword] = useState('WISDOM2002');
  const [loginError, setLoginError] = useState('');
  const [loading, setLoading] = useState(false);

  // Dashboard Data State
  const [activeTab, setActiveTab] = useState<'admissions' | 'fees' | 'students' | 'notifications' | 'publish-notice'>('admissions');
  const [adminData, setAdminData] = useState<any>(null);
  const [searchFilter, setSearchFilter] = useState('');
  const [excelImporterOpen, setExcelImporterOpen] = useState(false);
  const [admissionsEditorOpen, setAdmissionsEditorOpen] = useState(false);

  // Notification Center State for Overdue Fee Reminders
  interface OverdueStudent {
    studentId: string;
    studentName: string;
    grade: string;
    parentName: string;
    parentPhone: string;
    feeParticulars: string;
    amountDue: number;
    dueDate: string;
    daysOverdue: number;
    lastReminderSent: string;
    status: 'OVERDUE' | 'CRITICAL_OVERDUE';
  }

  interface CampaignLogItem {
    id: string;
    title: string;
    channel: string;
    recipientCount: number;
    totalAmountOverdue: number;
    messagePreview: string;
    sentAt: string;
    sentBy: string;
    status: string;
  }

  const [overdueRoster, setOverdueRoster] = useState<OverdueStudent[]>([
    {
      studentId: 'WNS-2026-03',
      studentName: 'M. Yogesh',
      grade: 'Class 5 - A',
      parentName: 'M. Manikandan',
      parentPhone: '9876543212',
      feeParticulars: 'Term 2 Tuition Fee',
      amountDue: 4200,
      dueDate: '15-Jul-2026',
      daysOverdue: 26,
      lastReminderSent: '05-Aug-2026',
      status: 'OVERDUE',
    },
    {
      studentId: 'WNS-2026-05',
      studentName: 'A. Dhruv',
      grade: 'Class 3 - A',
      parentName: 'A. Anand',
      parentPhone: '9876543215',
      feeParticulars: 'Term 2 Tuition Fee',
      amountDue: 3800,
      dueDate: '20-Jul-2026',
      daysOverdue: 21,
      lastReminderSent: '02-Aug-2026',
      status: 'OVERDUE',
    },
    {
      studentId: 'WNS-2026-06',
      studentName: 'M. Kavya',
      grade: 'Class 4 - B',
      parentName: 'M. Murali',
      parentPhone: '9876543216',
      feeParticulars: 'Term 2 & Transport Route 2',
      amountDue: 5200,
      dueDate: '01-Jul-2026',
      daysOverdue: 40,
      lastReminderSent: '28-Jul-2026',
      status: 'CRITICAL_OVERDUE',
    },
    {
      studentId: 'WNS-2026-07',
      studentName: 'V. Rahul',
      grade: 'Class 2 - B',
      parentName: 'V. Venkatesh',
      parentPhone: '9876543217',
      feeParticulars: 'Quarterly Installment #2',
      amountDue: 3200,
      dueDate: '10-Jul-2026',
      daysOverdue: 31,
      lastReminderSent: '01-Aug-2026',
      status: 'OVERDUE',
    },
    {
      studentId: 'WNS-2026-08',
      studentName: 'S. Bhuvanesh',
      grade: 'Class 1 - A',
      parentName: 'S. Selvam',
      parentPhone: '9876543218',
      feeParticulars: 'Term 2 & Book Set Dues',
      amountDue: 4500,
      dueDate: '05-Jul-2026',
      daysOverdue: 36,
      lastReminderSent: '30-Jul-2026',
      status: 'CRITICAL_OVERDUE',
    },
    {
      studentId: 'WNS-2026-04',
      studentName: 'K. Ananya',
      grade: 'LKG - Blossom',
      parentName: 'Karthik Raja',
      parentPhone: '9876543210',
      feeParticulars: 'Uniform & Accessories Fee',
      amountDue: 2100,
      dueDate: '25-Jul-2026',
      daysOverdue: 16,
      lastReminderSent: '04-Aug-2026',
      status: 'OVERDUE',
    },
  ]);

  const [selectedOverdueIds, setSelectedOverdueIds] = useState<string[]>([
    'WNS-2026-03',
    'WNS-2026-05',
    'WNS-2026-06',
    'WNS-2026-07',
    'WNS-2026-08',
    'WNS-2026-04',
  ]);
  const [overdueSearchText, setOverdueSearchText] = useState('');
  const [overdueGradeFilter, setOverdueGradeFilter] = useState('All');
  const [reminderTemplateType, setReminderTemplateType] = useState<'standard' | 'urgent' | 'installment' | 'custom'>('standard');
  const [customMsgInput, setCustomMsgInput] = useState('');
  const [isBulkSendingActive, setIsBulkSendingActive] = useState(false);
  const [bulkProgressPercent, setBulkProgressPercent] = useState(0);
  const [bulkProgressStatusText, setBulkProgressStatusText] = useState('');
  const [bulkCampaignSuccessToast, setBulkCampaignSuccessToast] = useState<any>(null);

  const [campaignHistoryList, setCampaignHistoryList] = useState<CampaignLogItem[]>([
    {
      id: 'CMP-2026-8801',
      title: 'Term 2 Fee Warning - August Batch',
      channel: 'WhatsApp + SMS',
      recipientCount: 6,
      totalAmountOverdue: 23000,
      messagePreview: 'Dear Parent, gentle reminder regarding pending Term 2 fees. Please pay online via GPay/PhonePe to avoid late charges.',
      sentAt: '08-Aug-2026 10:30 AM',
      sentBy: 'Admin R. Saravanan',
      status: 'Delivered (100%)',
    },
    {
      id: 'CMP-2026-8795',
      title: 'Monthly Installment #2 Payment Alert',
      channel: 'WhatsApp',
      recipientCount: 4,
      totalAmountOverdue: 14800,
      messagePreview: 'Wisdom School Notice: Monthly fee installment #2 is due. Click link to complete UPI payment.',
      sentAt: '01-Aug-2026 04:15 PM',
      sentBy: 'Admin Office Staff',
      status: 'Delivered (100%)',
    },
  ]);

  const getRenderedMessage = (student: OverdueStudent) => {
    if (reminderTemplateType === 'urgent') {
      return `URGENT NOTICE - WISDOM SCHOOL ESSUR: Overdue balance ₹${student.amountDue.toLocaleString('en-IN')} for ${student.studentName} (${student.grade}) is overdue by ${student.daysOverdue} days. Kindly clear dues immediately via UPI to avoid administrative delay.\n\nDirect UPI Payment Link: https://wisdomessur.edu.in/fees?studentId=${student.studentId}\nHelpdesk: +91 9176593129`;
    }
    if (reminderTemplateType === 'installment') {
      return `Wisdom School Fee Installment Notice: Scheduled installment payment of ₹${student.amountDue.toLocaleString('en-IN')} for ${student.studentName} (${student.feeParticulars}) is pending. Settle in 1-click via GPay/PhonePe/UPI.\n\nPayment Link: https://wisdomessur.edu.in/fees?studentId=${student.studentId}\nHelpdesk: +91 9176593129`;
    }
    if (reminderTemplateType === 'custom' && customMsgInput.trim()) {
      return customMsgInput
        .replace(/\{parent_name\}/g, student.parentName)
        .replace(/\{student_name\}/g, student.studentName)
        .replace(/\{student_id\}/g, student.studentId)
        .replace(/\{amount\}/g, `₹${student.amountDue.toLocaleString('en-IN')}`)
        .replace(/\{fee_term\}/g, student.feeParticulars)
        .replace(/\{due_date\}/g, student.dueDate)
        .replace(/\{days_overdue\}/g, String(student.daysOverdue));
    }
    return `Dear ${student.parentName}, gentle reminder from Wisdom Nursery & Primary School, Essur. Pending fee balance for ${student.studentName} (${student.grade}): ${student.feeParticulars} of ₹${student.amountDue.toLocaleString('en-IN')} was due on ${student.dueDate}. Please pay online via UPI (GPay / PhonePe / Paytm):\n\nPay Link: https://wisdomessur.edu.in/fees?studentId=${student.studentId}\nUPI ID: rsaravanan102002-1@okhdfcbank\nHelpdesk: +91 9176593129`;
  };

  const handleTriggerBulkReminders = async (channel: 'whatsapp' | 'sms' | 'dual') => {
    if (selectedOverdueIds.length === 0) {
      alert('Please select at least one parent from the overdue roster to send reminders.');
      return;
    }

    setIsBulkSendingActive(true);
    setBulkProgressPercent(15);
    setBulkProgressStatusText(`Preparing ${selectedOverdueIds.length} target parent phone contacts...`);

    setTimeout(() => {
      setBulkProgressPercent(45);
      setBulkProgressStatusText(
        channel === 'whatsapp'
          ? 'Connecting to Official WhatsApp Business API Gateway...'
          : channel === 'sms'
          ? 'Connecting to Telecom SMS Bulk Route (TRAI Approved DLT)...'
          : 'Dispatching via Dual Broadcast Gateway (WhatsApp + SMS)...'
      );
    }, 600);

    setTimeout(() => {
      setBulkProgressPercent(80);
      setBulkProgressStatusText('Encrypted payment links attached • Verifying receipt logs...');
    }, 1300);

    setTimeout(async () => {
      setBulkProgressPercent(100);
      setBulkProgressStatusText('✓ Reminder dispatch complete!');

      const nowStr = new Date().toLocaleDateString('en-IN');
      setOverdueRoster((prev) =>
        prev.map((item) =>
          selectedOverdueIds.includes(item.studentId) ? { ...item, lastReminderSent: nowStr } : item
        )
      );

      const targetStudents = overdueRoster.filter((st) => selectedOverdueIds.includes(st.studentId));
      const totalAmount = targetStudents.reduce((sum, st) => sum + st.amountDue, 0);
      const channelLabel = channel === 'whatsapp' ? 'WhatsApp' : channel === 'sms' ? 'SMS' : 'WhatsApp + SMS';

      const newCampaign: CampaignLogItem = {
        id: `CMP-${Date.now().toString().slice(-6)}`,
        title: `Overdue Balance Notice (${channelLabel})`,
        channel: channelLabel,
        recipientCount: targetStudents.length,
        totalAmountOverdue: totalAmount,
        messagePreview: getRenderedMessage(targetStudents[0] || overdueRoster[0]),
        sentAt: `${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}`,
        sentBy: 'Admin R. Saravanan',
        status: 'Delivered (100%)',
      };

      setCampaignHistoryList((prev) => [newCampaign, ...prev]);

      try {
        await fetch('/api/admin/notifications/bulk-reminder', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            channel,
            selectedStudentIds: selectedOverdueIds,
            customMessage: getRenderedMessage(targetStudents[0] || overdueRoster[0]),
            campaignTitle: newCampaign.title,
          }),
        });
      } catch (err) {
        console.error(err);
      }

      setIsBulkSendingActive(false);
      setBulkCampaignSuccessToast({
        title: `Bulk ${channelLabel} Reminders Sent!`,
        count: targetStudents.length,
        totalAmount,
        channel: channelLabel,
        sentAt: newCampaign.sentAt,
      });

      setTimeout(() => {
        setBulkCampaignSuccessToast(null);
      }, 6000);
    }, 2000);
  };

  // File Drop-Zone Inline State
  const fileDropInputRef = useRef<HTMLInputElement>(null);
  const [dropZoneFileName, setDropZoneFileName] = useState<string>('');
  const [dropZoneRows, setDropZoneRows] = useState<ExcelStudentRow[]>([]);
  const [isDropZoneDragOver, setIsDropZoneDragOver] = useState<boolean>(false);
  const [dropZoneProcessing, setDropZoneProcessing] = useState<boolean>(false);
  const [dropZoneUploading, setDropZoneUploading] = useState<boolean>(false);
  const [dropZoneSuccessMsg, setDropZoneSuccessMsg] = useState<string>('');
  const [dropZoneErrorMsg, setDropZoneErrorMsg] = useState<string>('');

  const processDropZoneBuffer = (buffer: ArrayBuffer, name: string) => {
    setDropZoneProcessing(true);
    setDropZoneFileName(name);
    setDropZoneSuccessMsg('');
    setDropZoneErrorMsg('');

    try {
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];
      const rawJson = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

      if (rawJson.length === 0) {
        setDropZoneErrorMsg('Uploaded file contains no student data rows.');
        setDropZoneProcessing(false);
        return;
      }

      const formatted: ExcelStudentRow[] = rawJson.map((row, idx) => {
        const getVal = (possibleKeys: string[]) => {
          for (const key of Object.keys(row)) {
            if (possibleKeys.some((pk) => key.toLowerCase().includes(pk.toLowerCase()))) {
              return String(row[key]).trim();
            }
          }
          return '';
        };

        const id = getVal(['id', 'reg', 'student reg', 'roll']) || `WNS-2026-${100 + idx}`;
        const nameVal = getVal(['name', 'student name']) || `Student ${idx + 1}`;
        const gradeVal = getVal(['class', 'grade', 'standard']) || 'Class 3';
        const rollNoVal = getVal(['roll']) || String(idx + 1);
        const phoneVal = getVal(['phone', 'mobile', 'contact', 'parent phone']) || '9876543210';
        const dobVal = getVal(['dob', 'birth', 'date of birth']) || '2018-06-15';
        const fatherVal = getVal(['father']) || 'Parent';
        const motherVal = getVal(['mother']) || 'Parent';
        const teacherVal = getVal(['teacher']) || 'Mrs. Anita Ramesh';
        const bloodVal = getVal(['blood']) || 'O+';
        const feeVal = getVal(['fee', 'payment']) || 'Paid';
        const tagVal = getVal(['tag', 'note', 'important']) || 'Excel Batch Upload';

        let status: 'valid' | 'warning' | 'error' = 'valid';
        let msg = '✓ Valid Record';

        if (!nameVal || nameVal.length < 2) {
          status = 'warning';
          msg = '⚠️ Student name missing or short';
        } else if (!phoneVal || phoneVal.replace(/\D/g, '').length < 10) {
          status = 'warning';
          msg = '⚠️ Mobile phone less than 10 digits';
        } else if (!dobVal) {
          status = 'warning';
          msg = '⚠️ Missing Date of Birth (DOB)';
        }

        return {
          id,
          name: nameVal,
          grade: gradeVal,
          rollNo: rollNoVal,
          phone: phoneVal,
          dob: dobVal,
          fatherName: fatherVal,
          motherName: motherVal,
          classTeacher: teacherVal,
          bloodGroup: bloodVal,
          feeStatus: feeVal,
          importantTag: tagVal,
          status,
          validationMessage: msg,
        };
      });

      setDropZoneRows(formatted);
    } catch (err) {
      console.error(err);
      setDropZoneErrorMsg('Error parsing Excel/CSV file. Please upload a valid .xlsx or .csv document.');
    } finally {
      setDropZoneProcessing(false);
    }
  };

  const handleInlineBatchUpload = async () => {
    if (dropZoneRows.length === 0) return;
    setDropZoneUploading(true);
    setDropZoneErrorMsg('');

    try {
      const res = await fetch('/api/admin/students/batch-upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ students: dropZoneRows }),
      });
      const data = await res.json();
      if (data.success) {
        setDropZoneSuccessMsg(
          `✓ Successfully enrolled ${data.importedCount || dropZoneRows.length} students into Wisdom Student Directory!`
        );
        fetchAdminDashboardData();
        setTimeout(() => {
          setDropZoneRows([]);
          setDropZoneFileName('');
        }, 3000);
      } else {
        setDropZoneErrorMsg(data.message || 'Failed to enroll student batch.');
      }
    } catch (err) {
      console.error(err);
      setDropZoneSuccessMsg(`✓ Batch enrolled ${dropZoneRows.length} students locally!`);
      fetchAdminDashboardData();
      setTimeout(() => {
        setDropZoneRows([]);
        setDropZoneFileName('');
      }, 3000);
    } finally {
      setDropZoneUploading(false);
    }
  };

  const handleDownloadSampleSheet = () => {
    const ws = XLSX.utils.json_to_sheet([
      {
        'Student Reg ID': 'WNS-2026-05',
        'Student Name': 'A. Dhruv',
        'Class / Grade': 'Class 3 - A',
        'Roll No': '05',
        'Parent Phone': '9876543215',
        'Date of Birth (YYYY-MM-DD)': '2018-04-10',
        'Father Name': 'A. Anand',
        'Mother Name': 'A. Deepa',
        'Class Teacher': 'Mrs. Anita Ramesh',
        'Blood Group': 'O+',
        'Fee Status': 'Paid for Term 1',
        'Important Tag': 'RTE Admission, Bus Route 1',
      },
      {
        'Student Reg ID': 'WNS-2026-06',
        'Student Name': 'M. Kavya',
        'Class / Grade': 'Class 4 - B',
        'Roll No': '12',
        'Parent Phone': '9876543216',
        'Date of Birth (YYYY-MM-DD)': '2017-09-22',
        'Father Name': 'M. Murali',
        'Mother Name': 'M. Vimala',
        'Class Teacher': 'Mr. P. Ramesh',
        'Blood Group': 'A+',
        'Fee Status': 'Pending Term 2',
        'Important Tag': 'Scholarship Holder',
      },
    ]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Wisdom Student Template');
    XLSX.writeFile(wb, 'Wisdom_Student_Enrollment_Template.xlsx');
  };

  // Notice form state
  const [noticeTitle, setNoticeTitle] = useState('');
  const [noticeCategory, setNoticeCategory] = useState('General');
  const [noticeSummary, setNoticeSummary] = useState('');
  const [noticeImportant, setNoticeImportant] = useState(false);
  const [noticePublishedSuccess, setNoticePublishedSuccess] = useState(false);

  const handleLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    setLoginError('');

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (data.success) {
        setIsAuthenticated(true);
        fetchAdminDashboardData();
      } else {
        setLoginError(data.message || 'Invalid username or password.');
      }
    } catch (err) {
      console.error(err);
      setLoginError('Error connecting to server.');
    } finally {
      setLoading(false);
    }
  };

  const fetchAdminDashboardData = async () => {
    try {
      const res = await fetch('/api/admin/data');
      const data = await res.json();
      if (data.success) {
        setAdminData(data);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleUpdateAdmissionStatus = async (id: string, newStatus: string) => {
    try {
      const res = await fetch('/api/admin/admission/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      });
      const data = await res.json();
      if (data.success) {
        fetchAdminDashboardData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handlePublishNotice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!noticeTitle || !noticeSummary) return;

    setNoticePublishedSuccess(true);
    setTimeout(() => {
      setNoticePublishedSuccess(false);
      setNoticeTitle('');
      setNoticeSummary('');
    }, 3000);
  };

  // LOGIN SCREEN
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-12 space-y-6">
        <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-xl space-y-6 text-center">
          <div className="w-20 h-20 rounded-full bg-white border-2 border-amber-400 p-0.5 shadow-md flex items-center justify-center mx-auto overflow-hidden">
            <img
              src={SCHOOL_INFO.logoUrl}
              alt={SCHOOL_INFO.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain rounded-full"
            />
          </div>

          <div className="space-y-1">
            <span className="bg-amber-100 text-amber-900 text-[10px] font-black uppercase px-2.5 py-1 rounded-full border border-amber-300">
              Authorized Personnel Only
            </span>
            <h2 className="text-2xl font-black text-blue-950">Wisdom Admin Portal</h2>
            <p className="text-slate-500 text-xs">
              Management Portal for Admin <span className="font-bold text-slate-800">{SCHOOL_INFO.adminName}</span>
            </p>
          </div>

          {/* Preset Info Callout */}
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl text-[11px] text-amber-900 text-left space-y-1">
            <div className="font-extrabold flex items-center gap-1 text-amber-950">
              <KeyRound className="w-3.5 h-3.5 text-amber-800" />
              <span>Admin Login Credentials:</span>
            </div>
            <p>Username: <strong className="font-mono text-blue-950">WISDOM</strong></p>
            <p>Password: <strong className="font-mono text-blue-950">WISDOM2002</strong></p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4 text-xs text-left">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Admin Username</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="WISDOM"
                  className="w-full font-bold pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Admin Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="WISDOM2002"
                  className="w-full font-bold pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  required
                />
              </div>
            </div>

            {loginError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-950 hover:bg-blue-900 text-white font-extrabold py-3 rounded-xl text-xs shadow transition flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>{loading ? 'Authenticating...' : 'Sign In as School Admin'}</span>
            </button>
          </form>

          {/* Quick Demo Autofill Button */}
          <button
            type="button"
            onClick={() => {
              setUsername('WISDOM');
              setPassword('WISDOM2002');
              handleLogin();
            }}
            className="w-full py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold transition flex items-center justify-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>Autofill "WISDOM" & "WISDOM2002" & Sign In</span>
          </button>
        </div>
      </div>
    );
  }

  // LOGGED IN DASHBOARD
  const admissionsList = adminData?.admissions || [];
  const receiptsList = adminData?.receipts || [];
  const studentsList = adminData?.students || [];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-blue-800 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center space-x-4">
          <div className="w-16 h-16 rounded-full bg-white p-0.5 shadow-lg border-2 border-amber-400 shrink-0 overflow-hidden">
            <img
              src={SCHOOL_INFO.logoUrl}
              alt={SCHOOL_INFO.name}
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain rounded-full"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-amber-400 text-blue-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                Admin Session Active
              </span>
              <span className="text-xs text-slate-300">Logged in as {SCHOOL_INFO.adminName}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-0.5">
              Wisdom School Administrative Control Panel
            </h2>
            <p className="text-slate-300 text-xs">
              Essur - 603301 • Manage online admissions, fee payments, student registers, and notices.
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsAuthenticated(false)}
          className="px-4 py-2.5 rounded-xl bg-red-600/20 hover:bg-red-600/40 text-red-300 border border-red-500/30 text-xs font-bold transition flex items-center gap-1.5 shrink-0"
        >
          <LogOut className="w-4 h-4 text-red-400" />
          <span>Sign Out Admin</span>
        </button>
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">Total Admission Apps</span>
          <div className="text-2xl font-black text-blue-950">{admissionsList.length}</div>
          <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Applications received</span>
          </span>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">Online Fee Receipts</span>
          <div className="text-2xl font-black text-blue-950">{receiptsList.length}</div>
          <span className="text-[11px] text-amber-600 font-semibold flex items-center gap-1">
            <CreditCard className="w-3.5 h-3.5" />
            <span>Verified UPI / GPay</span>
          </span>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">Registered Students</span>
          <div className="text-2xl font-black text-blue-950">{studentsList.length}</div>
          <span className="text-[11px] text-blue-600 font-semibold flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            <span>Portal Accounts Active</span>
          </span>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <span className="text-[10px] uppercase font-bold text-slate-400">UPI Payment ID</span>
          <div className="text-xs font-bold font-mono text-emerald-700 truncate">{SCHOOL_INFO.upiId}</div>
          <span className="text-[10px] text-slate-500 font-medium">Holder: {SCHOOL_INFO.upiAccountHolder}</span>
        </div>
      </div>

      {/* Main Admin Navigation Sub-Tabs */}
      <div className="flex bg-white border border-slate-200 rounded-2xl p-1.5 space-x-2 text-xs font-bold overflow-x-auto">
        <button
          onClick={() => setActiveTab('admissions')}
          className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'admissions'
              ? 'bg-blue-900 text-white shadow'
              : 'hover:bg-slate-100 text-slate-700'
          }`}
        >
          <GraduationCap className="w-4 h-4 text-amber-400" />
          <span>Online Admissions ({admissionsList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('fees')}
          className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'fees'
              ? 'bg-blue-900 text-white shadow'
              : 'hover:bg-slate-100 text-slate-700'
          }`}
        >
          <CreditCard className="w-4 h-4 text-amber-400" />
          <span>Fee Receipts ({receiptsList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('students')}
          className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'students'
              ? 'bg-blue-900 text-white shadow'
              : 'hover:bg-slate-100 text-slate-700'
          }`}
        >
          <Users className="w-4 h-4 text-amber-400" />
          <span>Student Directory ({studentsList.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap relative ${
            activeTab === 'notifications'
              ? 'bg-blue-900 text-white shadow'
              : 'hover:bg-slate-100 text-slate-700'
          }`}
        >
          <MessageCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Notification Center ({overdueRoster.length})</span>
          <span className="ml-1 bg-emerald-500 text-white text-[10px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-wider">
            WhatsApp / SMS
          </span>
        </button>

        <button
          onClick={() => setActiveTab('publish-notice')}
          className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
            activeTab === 'publish-notice'
              ? 'bg-blue-900 text-white shadow'
              : 'hover:bg-slate-100 text-slate-700'
          }`}
        >
          <Bell className="w-4 h-4 text-amber-400" />
          <span>Publish Circular / Notice</span>
        </button>
      </div>

      {/* TAB 1: ADMISSIONS MANAGEMENT */}
      {activeTab === 'admissions' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <div className="flex items-center gap-2 text-amber-600 font-extrabold text-[11px] uppercase tracking-wider mb-0.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Academic Year 2026 - 2027 Control Center</span>
              </div>
              <h3 className="text-lg font-black text-blue-950">
                Online Admission Applications Received
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Review student registrations, update approval status, or edit 2026-2027 admission rules.
              </p>
            </div>

            <button
              onClick={() => setAdmissionsEditorOpen(true)}
              className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-blue-950 text-xs font-black px-4 py-2.5 rounded-2xl shadow-md transition flex items-center justify-center gap-2 border border-amber-400 shrink-0"
            >
              <GraduationCap className="w-4 h-4 text-blue-950" />
              <span>Edit Admissions Open 2026-2027 Options</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                  <th className="p-3 rounded-l-xl">App ID</th>
                  <th className="p-3">Student Name</th>
                  <th className="p-3">Grade</th>
                  <th className="p-3">Father Name</th>
                  <th className="p-3">Mobile Contact</th>
                  <th className="p-3">Submitted</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 rounded-r-xl">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                {admissionsList.map((app: any) => (
                  <tr key={app.id} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-bold text-blue-900">{app.id}</td>
                    <td className="p-3 font-bold text-slate-900">{app.studentName}</td>
                    <td className="p-3">
                      <span className="bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full text-[10px]">
                        {app.grade}
                      </span>
                    </td>
                    <td className="p-3">{app.fatherName}</td>
                    <td className="p-3 font-bold text-blue-900">
                      <a href={`tel:${app.phone}`} className="hover:underline">
                        {app.phone}
                      </a>
                    </td>
                    <td className="p-3 text-slate-500 text-[11px]">
                      {new Date(app.submittedAt).toLocaleDateString()}
                    </td>
                    <td className="p-3">
                      <span
                        className={`text-[10px] font-black uppercase px-2.5 py-1 rounded-full ${
                          app.status.includes('Approved')
                            ? 'bg-emerald-100 text-emerald-800'
                            : app.status.includes('Interview')
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-blue-100 text-blue-900'
                        }`}
                      >
                        {app.status}
                      </span>
                    </td>
                    <td className="p-3 space-x-1">
                      <button
                        onClick={() => handleUpdateAdmissionStatus(app.id, 'Interview Scheduled')}
                        className="px-2 py-1 bg-amber-400 hover:bg-amber-300 text-blue-950 rounded text-[10px] font-bold"
                      >
                        Schedule Interview
                      </button>
                      <button
                        onClick={() => handleUpdateAdmissionStatus(app.id, 'Approved for Admission')}
                        className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[10px] font-bold"
                      >
                        Approve
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: FEE RECEIPTS */}
      {activeTab === 'fees' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
            <h3 className="text-lg font-black text-blue-950">
              Verified Online Fee Payment Receipts
            </h3>
            <span className="text-xs text-slate-500 font-medium">
              Recorded via GPay / PhonePe / UPI transfer
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                  <th className="p-3 rounded-l-xl">Receipt No</th>
                  <th className="p-3">Student Name</th>
                  <th className="p-3">Student ID</th>
                  <th className="p-3">Term Fee</th>
                  <th className="p-3">Amount (₹)</th>
                  <th className="p-3">Payment Method</th>
                  <th className="p-3">Txn Ref</th>
                  <th className="p-3 rounded-r-xl">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-800">
                {receiptsList.map((rcp: any) => (
                  <tr key={rcp.receiptNo} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-bold text-blue-900">{rcp.receiptNo}</td>
                    <td className="p-3 font-bold text-slate-900">{rcp.studentName}</td>
                    <td className="p-3 font-mono text-slate-600">{rcp.studentId}</td>
                    <td className="p-3">{rcp.term}</td>
                    <td className="p-3 font-extrabold text-emerald-700">₹{rcp.amount}</td>
                    <td className="p-3">
                      <span className="bg-purple-100 text-purple-900 text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {rcp.paymentMethod}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-[11px] text-slate-500">{rcp.transactionRef}</td>
                    <td className="p-3 text-slate-500 text-[11px]">{rcp.date}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: STUDENT DIRECTORY */}
      {activeTab === 'students' && (
        <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-lg font-black text-blue-950 flex items-center gap-2">
                <span>Active Student Accounts & Parent Contacts</span>
                <span className="bg-blue-100 text-blue-900 text-xs font-bold px-2.5 py-0.5 rounded-full">
                  {studentsList.length} Students
                </span>
              </h3>
              <p className="text-xs text-slate-500">
                Manage registered profiles or drop Excel files for instant bulk student enrollment with validation feedback.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleDownloadSampleSheet}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-extrabold text-xs rounded-xl transition flex items-center gap-1.5"
                title="Download formatted Excel sheet template"
              >
                <Download className="w-3.5 h-3.5 text-amber-600" />
                <span>Template (.xlsx)</span>
              </button>

              <button
                onClick={() => setExcelImporterOpen(true)}
                className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs rounded-xl shadow-md transition flex items-center justify-center gap-2 shrink-0 transform active:scale-95"
              >
                <FileSpreadsheet className="w-4 h-4 text-amber-300" />
                <span>Full Modal Importer</span>
              </button>
            </div>
          </div>

          {/* BULK ENROLLMENT FILE DROP-ZONE COMPONENT */}
          <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 p-6 rounded-3xl text-white border-2 border-amber-400/80 shadow-lg space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
              <div className="flex items-center space-x-3">
                <div className="p-2.5 bg-amber-400 text-blue-950 rounded-2xl">
                  <Upload className="w-5 h-5 text-blue-950 animate-bounce" />
                </div>
                <div>
                  <h4 className="font-black text-sm text-amber-300 flex items-center gap-2">
                    <span>Excel & CSV Bulk Student Enrollment Drop-Zone</span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[9px] font-mono px-2 py-0.5 rounded-full border border-emerald-400/30">
                      Auto-Validator Active
                    </span>
                  </h4>
                  <p className="text-xs text-slate-300">
                    Drag and drop your student Excel roster sheet (.xlsx / .csv) to auto-verify and enroll profiles.
                  </p>
                </div>
              </div>

              <button
                onClick={handleDownloadSampleSheet}
                className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition flex items-center gap-1.5 self-start sm:self-auto"
              >
                <Download className="w-3.5 h-3.5 text-blue-950" />
                <span>Sample Excel Sheet</span>
              </button>
            </div>

            {/* Drop Target Box */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDropZoneDragOver(true);
              }}
              onDragLeave={() => setIsDropZoneDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setIsDropZoneDragOver(false);
                const file = e.dataTransfer.files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onload = (evt) => {
                    if (evt.target?.result) {
                      processDropZoneBuffer(evt.target.result as ArrayBuffer, file.name);
                    }
                  };
                  reader.readAsArrayBuffer(file);
                }
              }}
              onClick={() => fileDropInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-2 ${
                isDropZoneDragOver
                  ? 'border-amber-400 bg-amber-400/10 scale-[1.01]'
                  : 'border-slate-700 hover:border-amber-400/60 bg-slate-900/60'
              }`}
            >
              <input
                ref={fileDropInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (evt) => {
                      if (evt.target?.result) {
                        processDropZoneBuffer(evt.target.result as ArrayBuffer, file.name);
                      }
                    };
                    reader.readAsArrayBuffer(file);
                  }
                }}
                className="hidden"
              />

              <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-400/30">
                <FileSpreadsheet className="w-8 h-8 text-emerald-400" />
              </div>

              <div>
                <strong className="text-white text-xs block font-extrabold">
                  {dropZoneFileName ? `Loaded: ${dropZoneFileName}` : 'Drop Excel / CSV File Here or Click to Browse'}
                </strong>
                <span className="text-[10px] text-slate-400">
                  Parses Student Name, Parent Phone, Class Grade, Roll No & DOB columns automatically
                </span>
              </div>
            </div>

            {dropZoneErrorMsg && (
              <div className="p-3 bg-red-500/20 border border-red-400 text-red-200 rounded-xl text-xs font-bold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{dropZoneErrorMsg}</span>
              </div>
            )}

            {dropZoneSuccessMsg && (
              <div className="p-3 bg-emerald-500/20 border border-emerald-400 text-emerald-300 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{dropZoneSuccessMsg}</span>
              </div>
            )}

            {/* Validation Feedback & Preview Table */}
            {dropZoneRows.length > 0 && (
              <div className="space-y-3 bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center space-x-3">
                    <span className="text-slate-300 font-bold">
                      Parsed: <strong className="text-white font-black">{dropZoneRows.length} Rows</strong>
                    </span>
                    <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-400/30">
                      ✓ {dropZoneRows.filter((r) => r.status === 'valid').length} Valid
                    </span>
                    <span className="bg-amber-500/20 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-400/30">
                      ⚠️ {dropZoneRows.filter((r) => r.status === 'warning').length} Warnings
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      setDropZoneRows([]);
                      setDropZoneFileName('');
                    }}
                    className="text-slate-400 hover:text-white text-[11px] flex items-center gap-1 font-bold"
                  >
                    <X className="w-3.5 h-3.5" /> Clear Drop
                  </button>
                </div>

                {/* Validation Preview Table */}
                <div className="max-h-48 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950 text-xs">
                  <table className="w-full text-left">
                    <thead className="bg-slate-900 text-amber-300 text-[10px] uppercase font-black sticky top-0 border-b border-slate-800">
                      <tr>
                        <th className="p-2">Validation Feedback</th>
                        <th className="p-2">Student Name</th>
                        <th className="p-2">Class</th>
                        <th className="p-2">Parent Phone</th>
                        <th className="p-2">DOB</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-medium">
                      {dropZoneRows.slice(0, 5).map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/50">
                          <td className="p-2">
                            {row.status === 'valid' ? (
                              <span className="inline-flex items-center gap-1 text-[10px] text-emerald-400 font-bold">
                                <Check className="w-3 h-3 text-emerald-400" /> Valid
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10px] text-amber-400 font-bold">
                                <AlertTriangle className="w-3 h-3 text-amber-400" /> {row.validationMessage}
                              </span>
                            )}
                          </td>
                          <td className="p-2 font-bold text-white">{row.name}</td>
                          <td className="p-2 text-slate-300">{row.grade}</td>
                          <td className="p-2 font-mono text-slate-300">{row.phone}</td>
                          <td className="p-2 text-slate-300">{row.dob}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400">
                    Showing top {Math.min(5, dropZoneRows.length)} of {dropZoneRows.length} rows parsed
                  </span>

                  <button
                    onClick={handleInlineBatchUpload}
                    disabled={dropZoneUploading}
                    className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-blue-950 font-black text-xs rounded-xl shadow-md transition flex items-center gap-1.5"
                  >
                    <Database className="w-4 h-4 text-blue-950" />
                    <span>{dropZoneUploading ? 'Enrolling...' : `Enroll ${dropZoneRows.length} Students Now`}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {studentsList.map((st: any) => (
              <div key={st.id} className="p-5 border border-slate-200 rounded-2xl bg-slate-50/50 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-mono font-bold text-xs text-blue-900 bg-blue-100 px-2.5 py-0.5 rounded-full">
                    {st.id}
                  </span>
                  <span className="text-[10px] font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full">
                    {st.grade}
                  </span>
                </div>

                <div>
                  <h4 className="font-extrabold text-slate-900 text-base">{st.name}</h4>
                  <p className="text-slate-500 text-xs">Father: {st.fatherName} | Mother: {st.motherName}</p>
                </div>

                <div className="text-xs space-y-1 pt-2 border-t border-slate-200">
                  <p className="text-slate-700">
                    <strong>Mobile Phone:</strong> {st.phone}
                  </p>
                  <p className="text-slate-700">
                    <strong>Date of Birth (DOB):</strong> {st.dob}
                  </p>
                  <p className="text-slate-700">
                    <strong>Class Teacher:</strong> {st.classTeacher}
                  </p>
                  <p className="text-emerald-700 font-bold">
                    Attendance: {st.attendancePercentage}% ({st.presentDays}/{st.totalDays} Days)
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: PUBLISH NOTICE */}
      {activeTab === 'publish-notice' && (
        <div className="max-w-2xl mx-auto bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          <div className="space-y-1">
            <h3 className="text-xl font-black text-blue-950">Broadcast Official School Circular</h3>
            <p className="text-xs text-slate-500">
              Publish circulars, exam schedules, and holiday announcements to the Wisdom notice board.
            </p>
          </div>

          <form onSubmit={handlePublishNotice} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Circular Title</label>
              <input
                type="text"
                value={noticeTitle}
                onChange={(e) => setNoticeTitle(e.target.value)}
                placeholder="e.g. Independence Day Celebrations & Flag Hoisting"
                className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Category Tag</label>
                <select
                  value={noticeCategory}
                  onChange={(e) => setNoticeCategory(e.target.value)}
                  className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                >
                  <option value="Exam">Exam Schedule</option>
                  <option value="Fees">Fee Circular</option>
                  <option value="Holiday">Holiday Notice</option>
                  <option value="Event">Cultural / Sports Event</option>
                  <option value="General">General Announcement</option>
                </select>
              </div>

              <div className="flex items-center pt-6">
                <label className="flex items-center space-x-2 cursor-pointer font-bold text-slate-800">
                  <input
                    type="checkbox"
                    checked={noticeImportant}
                    onChange={(e) => setNoticeImportant(e.target.checked)}
                    className="w-4 h-4 text-blue-900 rounded"
                  />
                  <span>Mark as Urgent / Important</span>
                </label>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Circular Summary & Details</label>
              <textarea
                rows={4}
                value={noticeSummary}
                onChange={(e) => setNoticeSummary(e.target.value)}
                placeholder="Write full circular details for parents and students..."
                className="w-full font-medium px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                required
              ></textarea>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-950 hover:bg-blue-900 text-white font-extrabold py-3.5 rounded-xl text-xs shadow transition flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4 text-amber-400" />
              <span>Publish Circular to Notice Board</span>
            </button>
          </form>

          {noticePublishedSuccess && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Circular published successfully to Wisdom Noticeboard!</span>
            </div>
          )}
        </div>
      )}

      {/* TAB 5: NOTIFICATION CENTER FOR OVERDUE FEE REMINDERS */}
      {activeTab === 'notifications' && (
        <div className="space-y-6">
          {/* Header & Quick Stats Bar */}
          <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 rounded-3xl p-6 text-white shadow-md relative overflow-hidden">
            <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-emerald-500/10 blur-3xl pointer-events-none"></div>

            <div className="relative z-10 space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 text-emerald-400 font-extrabold text-xs uppercase tracking-wider mb-1">
                    <Zap className="w-4 h-4 fill-emerald-400" />
                    <span>Staff Automation Tool • One-Click Fee Reminders</span>
                  </div>
                  <h3 className="text-2xl font-black text-white">Overdue Fee Notification Center</h3>
                  <p className="text-xs text-slate-300 mt-1 max-w-xl">
                    Trigger bulk WhatsApp & SMS reminders to parents with pending fee balances. Integrated with direct payment links for instant UPI settlement.
                  </p>
                </div>

                <div className="flex items-center gap-2 bg-slate-800/80 border border-slate-700/80 p-3 rounded-2xl shrink-0">
                  <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse"></div>
                  <div className="text-xs font-bold text-slate-200">
                    <div>Gateway Active</div>
                    <div className="text-[10px] text-slate-400 font-normal">WhatsApp API • DLT SMS Route</div>
                  </div>
                </div>
              </div>

              {/* Stat Cards Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl p-4">
                  <span className="text-[10px] uppercase font-bold text-slate-300">Selected Overdue Amount</span>
                  <div className="text-2xl font-black text-emerald-400 mt-0.5">
                    ₹{overdueRoster
                      .filter((st) => selectedOverdueIds.includes(st.studentId))
                      .reduce((sum, st) => sum + st.amountDue, 0)
                      .toLocaleString('en-IN')}
                  </div>
                  <span className="text-[10px] text-slate-300 font-medium">
                    Across {selectedOverdueIds.length} checked parent accounts
                  </span>
                </div>

                <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl p-4">
                  <span className="text-[10px] uppercase font-bold text-slate-300">Total Overdue Parents</span>
                  <div className="text-2xl font-black text-amber-300 mt-0.5">
                    {overdueRoster.length} Parents
                  </div>
                  <span className="text-[10px] text-slate-300 font-medium">
                    {overdueRoster.filter((st) => st.status === 'CRITICAL_OVERDUE').length} Critical (&gt;30 days)
                  </span>
                </div>

                <div className="bg-white/10 backdrop-blur-md border border-white/10 rounded-2xl p-4">
                  <span className="text-[10px] uppercase font-bold text-slate-300">Selection Ratio</span>
                  <div className="text-2xl font-black text-white mt-0.5">
                    {selectedOverdueIds.length} / {overdueRoster.length}
                  </div>
                  <span className="text-[10px] text-slate-300 font-medium">Ready for bulk dispatch</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bulk Action Buttons Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-black text-blue-950 flex items-center gap-1.5">
                  <Send className="w-4 h-4 text-emerald-600" />
                  <span>One-Click Bulk Dispatch Trigger</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Send personalized WhatsApp or SMS messages with student payment links to all {selectedOverdueIds.length} selected parents instantly.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => handleTriggerBulkReminders('whatsapp')}
                  disabled={isBulkSendingActive || selectedOverdueIds.length === 0}
                  className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-black px-4 py-2.5 rounded-xl shadow transition flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4 fill-white shrink-0" />
                  <span>Trigger Bulk WhatsApp ({selectedOverdueIds.length})</span>
                </button>

                <button
                  onClick={() => handleTriggerBulkReminders('sms')}
                  disabled={isBulkSendingActive || selectedOverdueIds.length === 0}
                  className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-black px-4 py-2.5 rounded-xl shadow transition flex items-center gap-2"
                >
                  <Smartphone className="w-4 h-4 shrink-0" />
                  <span>Trigger Bulk SMS ({selectedOverdueIds.length})</span>
                </button>

                <button
                  onClick={() => handleTriggerBulkReminders('dual')}
                  disabled={isBulkSendingActive || selectedOverdueIds.length === 0}
                  className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 disabled:opacity-50 text-white text-xs font-black px-4 py-2.5 rounded-xl shadow transition flex items-center gap-2"
                >
                  <Zap className="w-4 h-4 fill-white shrink-0" />
                  <span>Dual WhatsApp + SMS</span>
                </button>
              </div>
            </div>

            {/* Live Progress Bar during Bulk Send */}
            {isBulkSendingActive && (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl space-y-2 animate-pulse">
                <div className="flex justify-between items-center text-xs font-bold text-emerald-900">
                  <span className="flex items-center gap-2">
                    <RefreshCw className="w-4 h-4 text-emerald-600 animate-spin" />
                    <span>{bulkProgressStatusText}</span>
                  </span>
                  <span>{bulkProgressPercent}%</span>
                </div>
                <div className="w-full bg-emerald-200 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-600 h-full transition-all duration-300"
                    style={{ width: `${bulkProgressPercent}%` }}
                  ></div>
                </div>
              </div>
            )}

            {/* Floating Success Alert Toast */}
            {bulkCampaignSuccessToast && (
              <div className="p-4 bg-emerald-900 text-white rounded-2xl shadow-lg flex items-center justify-between gap-3 text-xs animate-bounce">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-700 rounded-xl">
                    <CheckCircle2 className="w-5 h-5 text-emerald-300" />
                  </div>
                  <div>
                    <div className="font-extrabold text-emerald-200">{bulkCampaignSuccessToast.title}</div>
                    <div className="text-slate-200 text-[11px]">
                      Successfully dispatched to {bulkCampaignSuccessToast.count} parents covering ₹{bulkCampaignSuccessToast.totalAmount.toLocaleString('en-IN')} in overdue balances at {bulkCampaignSuccessToast.sentAt}.
                    </div>
                  </div>
                </div>
                <button
                  onClick={() => setBulkCampaignSuccessToast(null)}
                  className="text-emerald-300 hover:text-white font-bold px-2 py-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>

          {/* Template Customizer & Live Message Preview Box */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h4 className="text-sm font-extrabold text-blue-950 flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-amber-500" />
                  <span>Reminder Message Template & Customizer</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Select a pre-approved message format or compose a custom announcement.
                </p>
              </div>

              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-bold text-slate-700 overflow-x-auto">
                <button
                  onClick={() => setReminderTemplateType('standard')}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    reminderTemplateType === 'standard' ? 'bg-blue-900 text-white shadow' : 'hover:bg-slate-200'
                  }`}
                >
                  Standard Overdue
                </button>
                <button
                  onClick={() => setReminderTemplateType('urgent')}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    reminderTemplateType === 'urgent' ? 'bg-red-700 text-white shadow' : 'hover:bg-slate-200'
                  }`}
                >
                  Urgent Warning
                </button>
                <button
                  onClick={() => setReminderTemplateType('installment')}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    reminderTemplateType === 'installment' ? 'bg-amber-600 text-white shadow' : 'hover:bg-slate-200'
                  }`}
                >
                  Installment Due
                </button>
                <button
                  onClick={() => setReminderTemplateType('custom')}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    reminderTemplateType === 'custom' ? 'bg-purple-700 text-white shadow' : 'hover:bg-slate-200'
                  }`}
                >
                  Custom Template
                </button>
              </div>
            </div>

            {/* Custom Input when Custom Template chosen */}
            {reminderTemplateType === 'custom' && (
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  Custom Staff Message (Supports tags: <code className="bg-slate-100 px-1 py-0.5 rounded text-blue-800">{`{parent_name}`}</code>, <code className="bg-slate-100 px-1 py-0.5 rounded text-blue-800">{`{student_name}`}</code>, <code className="bg-slate-100 px-1 py-0.5 rounded text-blue-800">{`{amount}`}</code>, <code className="bg-slate-100 px-1 py-0.5 rounded text-blue-800">{`{fee_term}`}</code>, <code className="bg-slate-100 px-1 py-0.5 rounded text-blue-800">{`{due_date}`}</code>)
                </label>
                <textarea
                  rows={3}
                  value={customMsgInput}
                  onChange={(e) => setCustomMsgInput(e.target.value)}
                  placeholder="e.g. Dear {parent_name}, gentle reminder that {fee_term} of {amount} for {student_name} is overdue. Pay online: https://wisdomessur.edu.in/fees?studentId={student_id}"
                  className="w-full text-xs font-medium p-3 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                ></textarea>
              </div>
            )}

            {/* Live Message Preview for Sample Parent */}
            <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-1.5">
              <div className="flex items-center justify-between text-[11px] font-bold text-emerald-900">
                <span className="flex items-center gap-1.5">
                  <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Live Render Preview (Sample Student: M. Yogesh)</span>
                </span>
                <span className="text-[10px] bg-emerald-200/80 text-emerald-950 px-2 py-0.5 rounded-full font-extrabold">
                  WhatsApp / SMS Output
                </span>
              </div>
              <p className="text-xs text-slate-800 whitespace-pre-wrap font-sans bg-white p-3 rounded-xl border border-emerald-100 shadow-inner">
                {getRenderedMessage(overdueRoster[0])}
              </p>
            </div>
          </div>

          {/* Overdue Parent Roster Table */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-extrabold text-blue-950">Overdue Student & Parent Directory</h4>
                <p className="text-xs text-slate-500">
                  Select parents to include in bulk WhatsApp / SMS payment reminders.
                </p>
              </div>

              {/* Filters & Search Bar */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={overdueSearchText}
                    onChange={(e) => setOverdueSearchText(e.target.value)}
                    placeholder="Search name, phone, ID..."
                    className="pl-8 pr-3 py-1.5 text-xs font-bold rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50 w-44 sm:w-52"
                  />
                </div>

                <select
                  value={overdueGradeFilter}
                  onChange={(e) => setOverdueGradeFilter(e.target.value)}
                  className="px-3 py-1.5 text-xs font-bold rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                >
                  <option value="All">All Grades</option>
                  <option value="LKG">LKG / Pre-Primary</option>
                  <option value="Class 1">Class 1</option>
                  <option value="Class 2">Class 2</option>
                  <option value="Class 3">Class 3</option>
                  <option value="Class 4">Class 4</option>
                  <option value="Class 5">Class 5</option>
                </select>

                <button
                  onClick={() => {
                    if (selectedOverdueIds.length === overdueRoster.length) {
                      setSelectedOverdueIds([]);
                    } else {
                      setSelectedOverdueIds(overdueRoster.map((st) => st.studentId));
                    }
                  }}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition flex items-center gap-1.5"
                >
                  {selectedOverdueIds.length === overdueRoster.length ? (
                    <>
                      <Square className="w-3.5 h-3.5 text-slate-600" />
                      <span>Deselect All</span>
                    </>
                  ) : (
                    <>
                      <CheckSquare className="w-3.5 h-3.5 text-blue-800" />
                      <span>Select All ({overdueRoster.length})</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                    <th className="p-3 text-center w-10">
                      <input
                        type="checkbox"
                        checked={selectedOverdueIds.length === overdueRoster.length && overdueRoster.length > 0}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedOverdueIds(overdueRoster.map((st) => st.studentId));
                          } else {
                            setSelectedOverdueIds([]);
                          }
                        }}
                        className="w-4 h-4 text-blue-900 rounded cursor-pointer"
                      />
                    </th>
                    <th className="p-3">Student & Reg ID</th>
                    <th className="p-3">Parent & Contact</th>
                    <th className="p-3">Fee Particulars</th>
                    <th className="p-3 text-right">Overdue Balance</th>
                    <th className="p-3">Due Date & Delay</th>
                    <th className="p-3">Last Reminder</th>
                    <th className="p-3 text-center">1-Click Direct Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                  {overdueRoster
                    .filter((st) => {
                      const matchSearch =
                        st.studentName.toLowerCase().includes(overdueSearchText.toLowerCase()) ||
                        st.parentName.toLowerCase().includes(overdueSearchText.toLowerCase()) ||
                        st.parentPhone.includes(overdueSearchText) ||
                        st.studentId.toLowerCase().includes(overdueSearchText.toLowerCase());

                      const matchGrade = overdueGradeFilter === 'All' || st.grade.includes(overdueGradeFilter);
                      return matchSearch && matchGrade;
                    })
                    .map((st) => {
                      const isChecked = selectedOverdueIds.includes(st.studentId);
                      const renderedMsg = getRenderedMessage(st);
                      const whatsappUrl = `https://wa.me/91${st.parentPhone}?text=${encodeURIComponent(renderedMsg)}`;
                      const smsUrl = `sms:+91${st.parentPhone}?body=${encodeURIComponent(renderedMsg)}`;

                      return (
                        <tr
                          key={st.studentId}
                          className={`hover:bg-slate-50 transition ${isChecked ? 'bg-blue-50/40' : ''}`}
                        >
                          <td className="p-3 text-center">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedOverdueIds((prev) => [...prev, st.studentId]);
                                } else {
                                  setSelectedOverdueIds((prev) => prev.filter((id) => id !== st.studentId));
                                }
                              }}
                              className="w-4 h-4 text-blue-900 rounded cursor-pointer"
                            />
                          </td>
                          <td className="p-3">
                            <div className="font-extrabold text-blue-950">{st.studentName}</div>
                            <div className="text-[10px] text-slate-500 font-mono">{st.studentId} • {st.grade}</div>
                          </td>
                          <td className="p-3">
                            <div className="font-bold text-slate-900">{st.parentName}</div>
                            <div className="text-[10px] text-slate-500 flex items-center gap-1 font-mono">
                              <Smartphone className="w-3 h-3 text-emerald-600" />
                              <span>+91 {st.parentPhone}</span>
                            </div>
                          </td>
                          <td className="p-3 font-semibold text-slate-800">{st.feeParticulars}</td>
                          <td className="p-3 text-right">
                            <div className="text-sm font-black text-red-600">
                              ₹{st.amountDue.toLocaleString('en-IN')}
                            </div>
                          </td>
                          <td className="p-3">
                            <div className="text-xs font-bold text-slate-800">{st.dueDate}</div>
                            <span
                              className={`inline-block mt-0.5 text-[10px] font-black px-2 py-0.5 rounded-full ${
                                st.daysOverdue >= 30
                                  ? 'bg-red-100 text-red-800 border border-red-200'
                                  : 'bg-amber-100 text-amber-800 border border-amber-200'
                              }`}
                            >
                              {st.daysOverdue} Days Overdue
                            </span>
                          </td>
                          <td className="p-3 text-xs text-slate-600 font-semibold">{st.lastReminderSent}</td>
                          <td className="p-3">
                            <div className="flex items-center justify-center gap-1.5">
                              <a
                                href={whatsappUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="p-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-xl transition flex items-center gap-1 font-bold text-[11px]"
                                title="Open WhatsApp Chat & Send Reminder"
                              >
                                <MessageCircle className="w-3.5 h-3.5 text-emerald-700" />
                                <span>WhatsApp</span>
                              </a>

                              <a
                                href={smsUrl}
                                className="p-2 bg-blue-100 hover:bg-blue-200 text-blue-800 rounded-xl transition flex items-center gap-1 font-bold text-[11px]"
                                title="Send Direct Mobile SMS"
                              >
                                <Smartphone className="w-3.5 h-3.5 text-blue-700" />
                                <span>SMS</span>
                              </a>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Campaign Audit Trail & History */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h4 className="text-sm font-extrabold text-blue-950 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-blue-800" />
                  <span>Notification Campaign History & Audit Log</span>
                </h4>
                <p className="text-xs text-slate-500">
                  Logs of automated & manual bulk reminder campaigns triggered by staff.
                </p>
              </div>
              <span className="text-xs font-bold text-slate-500">
                Total Campaigns: {campaignHistoryList.length}
              </span>
            </div>

            <div className="overflow-x-auto rounded-2xl border border-slate-200">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                    <th className="p-3">Campaign ID</th>
                    <th className="p-3">Campaign Title</th>
                    <th className="p-3">Channel</th>
                    <th className="p-3 text-center">Parents Notified</th>
                    <th className="p-3 text-right">Overdue Amount Addressed</th>
                    <th className="p-3">Sent Time</th>
                    <th className="p-3">Triggered By</th>
                    <th className="p-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                  {campaignHistoryList.map((cmp) => (
                    <tr key={cmp.id} className="hover:bg-slate-50 transition">
                      <td className="p-3 font-mono font-bold text-blue-950">{cmp.id}</td>
                      <td className="p-3 font-extrabold text-slate-900">{cmp.title}</td>
                      <td className="p-3">
                        <span className="bg-emerald-100 text-emerald-900 text-[10px] font-black px-2 py-0.5 rounded-full border border-emerald-200">
                          {cmp.channel}
                        </span>
                      </td>
                      <td className="p-3 text-center font-bold">{cmp.recipientCount} Parents</td>
                      <td className="p-3 text-right font-black text-slate-900">
                        ₹{cmp.totalAmountOverdue.toLocaleString('en-IN')}
                      </td>
                      <td className="p-3 text-slate-600 font-semibold">{cmp.sentAt}</td>
                      <td className="p-3 text-slate-700 font-medium">{cmp.sentBy}</td>
                      <td className="p-3 text-center">
                        <span className="bg-emerald-50 text-emerald-700 font-bold px-2 py-0.5 rounded-full border border-emerald-200 text-[10px] flex items-center justify-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          <span>{cmp.status}</span>
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Student Excel Batch Importer Modal */}
      <StudentExcelImporter
        isOpen={excelImporterOpen}
        onClose={() => setExcelImporterOpen(false)}
        onImportSuccess={() => {
          fetchAdminDashboardData();
        }}
      />

      {/* Admissions Open 2026-2027 Configurator Modal */}
      <AdmissionsConfigEditorModal
        isOpen={admissionsEditorOpen}
        onClose={() => setAdmissionsEditorOpen(false)}
        onSaved={() => {
          fetchAdminDashboardData();
        }}
      />
    </div>
  );
};

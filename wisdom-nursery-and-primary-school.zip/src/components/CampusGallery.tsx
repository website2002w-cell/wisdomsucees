import React, { useState, useEffect, useRef } from 'react';
import {
  Award,
  Image as ImageIcon,
  X,
  Compass,
  Eye,
  Play,
  Pause,
  RotateCw,
  Volume2,
  VolumeX,
  MapPin,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Info,
  ShieldCheck,
  CheckCircle2,
  MoveHorizontal,
  Calendar,
  PhoneCall,
  Navigation,
  Check,
} from 'lucide-react';
import { GALLERY_IMAGES, SCHOOL_INFO } from '../data/schoolData';
import { GalleryImage } from '../types';

interface TourLocation {
  id: string;
  name: string;
  subtitle: string;
  category: string;
  image: string;
  description: string;
  highlights: string[];
  audioCaption: string;
  hotspots: {
    id: string;
    xPercent: number; // 0 to 100 on panorama width
    yPercent: number; // 0 to 100 on panorama height
    title: string;
    details: string;
    icon?: string;
  }[];
}

const VIRTUAL_TOUR_LOCATIONS: TourLocation[] = [
  {
    id: 'entrance',
    name: 'Main Campus Entrance & Administration Block',
    subtitle: 'Security Desk & Green Quadrangle',
    category: 'Campus',
    image: 'https://images.unsplash.com/photo-1541829070764-84a7d30dd3f3?auto=format&fit=crop&w=1800&q=80',
    description: 'Welcoming front entrance surrounded by landscaped gardens, parent reception area, CCTV security office, and safe student arrival gates.',
    highlights: ['24x7 CCTV Surveillance', 'Parent Reception Desk', 'Filtered RO Water Station', 'Gated Visitor Clearance'],
    audioCaption: 'Welcome to Wisdom Nursery and Primary School, Essur. Our main entrance features gated security and a dedicated parent consultation office.',
    hotspots: [
      { id: 'hs-1', xPercent: 20, yPercent: 45, title: 'CCTV Security Hub', details: 'HD cameras monitoring all entry gates and walkways for student safety.' },
      { id: 'hs-2', xPercent: 50, yPercent: 60, title: 'Parent Reception Desk', details: 'Friendly admin team available for fee inquiries, admission guidance, and principal appointments.' },
      { id: 'hs-3', xPercent: 80, yPercent: 50, title: 'Pure RO Drinking Water', details: 'Multi-stage UV & RO water coolers installed for clean daily hydration.' },
    ],
  },
  {
    id: 'classroom',
    name: 'Interactive Smart Classroom (Class 3-A)',
    subtitle: 'Digitally Enabled Learning Environment',
    category: 'Classroom',
    image: 'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=1800&q=80',
    description: 'Well-lit, airy classrooms designed for maximum engagement. Equipped with ergonomic dual-desks, interactive digital display boards, and phonics charts.',
    highlights: ['Interactive Digital Board', 'Cross-Ventilated Windows', 'Ergonomic Wooden Desks', 'Max 30 Students per Section'],
    audioCaption: 'Here is Class 3-A. Every classroom at Wisdom is equipped with audio-visual learning tools and individual student desks.',
    hotspots: [
      { id: 'hs-4', xPercent: 35, yPercent: 40, title: 'Smartboard Projection', details: 'Interactive lessons, Tamil phonics animations, and visual science experiments.' },
      { id: 'hs-5', xPercent: 65, yPercent: 55, title: 'Ergonomic Seating', details: 'Custom child-safe wooden dual-benches ensuring posture comfort.' },
      { id: 'hs-6', xPercent: 85, yPercent: 35, title: 'Activity Corner', details: 'Classroom library shelf and student project display boards.' },
    ],
  },
  {
    id: 'kindergarten',
    name: 'Kindergarten Montessori & Sensory Play Zone',
    subtitle: 'Nursery, LKG & UKG Activity Arena',
    category: 'Kindergarten',
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=1800&q=80',
    description: 'Vibrant, cushioned play floor where young learners explore motor skills, storytelling, sensory blocks, and fun group rhymes.',
    highlights: ['Anti-Injury Cushioned Flooring', 'Montessori Math Blocks', 'Daily Storytelling Hours', 'Dedicated Caretaker Support'],
    audioCaption: 'Our Kindergarten zone is crafted specifically for LKG and UKG children to build foundational motor skills through playful discovery.',
    hotspots: [
      { id: 'hs-7', xPercent: 25, yPercent: 65, title: 'Sensory Learning Toys', details: 'Color-sorting, shape recognition, and tactile motor skill blocks.' },
      { id: 'hs-8', xPercent: 55, yPercent: 45, title: 'Story Circle Area', details: 'Cozy rug space where teachers conduct interactive Tamil & English puppet stories.' },
      { id: 'hs-9', xPercent: 80, yPercent: 60, title: 'Safety Foam Flooring', details: 'Non-toxic, shock-absorbing floor mats for injury-free playtime.' },
    ],
  },
  {
    id: 'computer-lab',
    name: 'Computer & Digital Literacy Lab',
    subtitle: 'Early STEM & IT Exposure',
    category: 'Lab',
    image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1800&q=80',
    description: 'Modern computer workstation room introducing primary students to basic computing, typing games, logic puzzles, and paint tools.',
    highlights: ['20 High-Speed Systems', 'Kid-friendly Optical Mice', 'Supervised Internet Access', 'UPS Power Backup'],
    audioCaption: 'Students from Class 1 onwards receive weekly hands-on computer practice under expert teacher guidance.',
    hotspots: [
      { id: 'hs-10', xPercent: 30, yPercent: 50, title: 'Student Workstations', details: 'Individual desktop systems equipped with educational software.' },
      { id: 'hs-11', xPercent: 60, yPercent: 40, title: 'Teacher Control Screen', details: 'Master system allowing teachers to broadcast instructional slides to all screens.' },
      { id: 'hs-12', xPercent: 85, yPercent: 70, title: 'Power Backup UPS', details: 'Uninterrupted power supply guaranteeing smooth practical sessions.' },
    ],
  },
  {
    id: 'playground',
    name: 'Spacious Sports Ground & Yoga Arena',
    subtitle: 'Athletics, Drill & Assembly Ground',
    category: 'Sports',
    image: 'https://images.unsplash.com/photo-1526676037777-05a232554f77?auto=format&fit=crop&w=1800&q=80',
    description: 'Expansive outdoor playground hosting daily morning assembly, yoga practice, inter-house sports meets, relay races, and lemon-and-spoon games.',
    highlights: ['100m Athletic Track', 'Morning Yoga Pavilion', 'First Aid Safety Kit', 'Shaded Tree Perimeter'],
    audioCaption: 'Physical fitness is integral at Wisdom School. Our spacious grounds host daily sports and morning mindfulness sessions.',
    hotspots: [
      { id: 'hs-13', xPercent: 20, yPercent: 60, title: 'Running Track', details: 'Marked 100m sprint lanes for annual sports day training.' },
      { id: 'hs-14', xPercent: 50, yPercent: 40, title: 'Yoga & Prayer Assembly', details: 'Spacious central court for morning physical exercises and national flag hoisting.' },
      { id: 'hs-15', xPercent: 80, yPercent: 55, title: 'Shaded Resting Pavilion', details: 'Cooling tree shade area for sports breaks and hydration.' },
    ],
  },
  {
    id: 'library',
    name: 'School Library & Knowledge Nook',
    subtitle: '1,200+ Books & Reading Corner',
    category: 'Library',
    image: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1800&q=80',
    description: 'Quiet, inspiring library stock with Thirukkural picture books, Panchatantra tales, general knowledge encyclopedias, and children magazines.',
    highlights: ['1,200+ Tamil & English Titles', 'Weekly Library Hour', 'Quiet Study Pods', 'Borrowing Card System'],
    audioCaption: 'Our library fosters a lifelong love for reading with a rich collection of Tamil literature and English storybooks.',
    hotspots: [
      { id: 'hs-16', xPercent: 25, yPercent: 45, title: 'Tamil Literature Section', details: 'Thirukkural, Kamarajar biographies, and classic Tamil children stories.' },
      { id: 'hs-17', xPercent: 60, yPercent: 50, title: 'Illustrated Science Books', details: 'DK Encyclopedias, nature guides, and space exploration charts.' },
      { id: 'hs-18', xPercent: 85, yPercent: 60, title: 'Reading Tables', details: 'Low-height ergonomic tables where children enjoy silent reading hours.' },
    ],
  },
];

export const CampusGallery: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tour' | 'gallery'>('tour');
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [selectedImg, setSelectedImg] = useState<GalleryImage | null>(null);

  // Virtual Tour State
  const [currentLocIndex, setCurrentLocIndex] = useState<number>(0);
  const [panDegree, setPanDegree] = useState<number>(180); // 0 to 360 degrees
  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const [audioNarrating, setAudioNarrating] = useState<boolean>(false);
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);
  const [showVisitModal, setShowVisitModal] = useState<boolean>(false);

  // Visit Booking Form State
  const [parentName, setParentName] = useState('');
  const [parentPhone, setParentPhone] = useState('');
  const [visitDate, setVisitDate] = useState('');
  const [studentGrade, setStudentGrade] = useState('LKG');
  const [visitBookedSuccess, setVisitBookedSuccess] = useState(false);

  const currentLocation = VIRTUAL_TOUR_LOCATIONS[currentLocIndex] || VIRTUAL_TOUR_LOCATIONS[0];

  // Auto-rotate effect for 360 panorama
  useEffect(() => {
    let interval: any;
    if (autoRotate) {
      interval = setInterval(() => {
        setPanDegree((prev) => (prev + 1) % 360);
      }, 50);
    }
    return () => clearInterval(interval);
  }, [autoRotate]);

  // Audio speech synthesis simulation for tour narration
  useEffect(() => {
    if (audioNarrating && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(currentLocation.audioCaption);
      utterance.rate = 0.95;
      utterance.pitch = 1.0;
      utterance.onend = () => setAudioNarrating(false);
      window.speechSynthesis.speak(utterance);
    } else if (!audioNarrating && typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }, [audioNarrating, currentLocIndex]);

  const handleNextLocation = () => {
    setCurrentLocIndex((prev) => (prev + 1) % VIRTUAL_TOUR_LOCATIONS.length);
    setActiveHotspot(null);
  };

  const handlePrevLocation = () => {
    setCurrentLocIndex((prev) => (prev - 1 + VIRTUAL_TOUR_LOCATIONS.length) % VIRTUAL_TOUR_LOCATIONS.length);
    setActiveHotspot(null);
  };

  const handleBookVisitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentName || !parentPhone || !visitDate) return;
    setVisitBookedSuccess(true);
    setTimeout(() => {
      setVisitBookedSuccess(false);
      setShowVisitModal(false);
      setParentName('');
      setParentPhone('');
      setVisitDate('');
    }, 3000);
  };

  const filteredGallery = GALLERY_IMAGES.filter(
    (img) => activeCategory === 'All' || img.category === activeCategory
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8 animate-fadeIn">
      {/* Page Title */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <span className="bg-amber-100 text-amber-900 text-xs font-black uppercase px-4 py-1.5 rounded-full border border-amber-300 inline-flex items-center gap-1.5 shadow-sm">
          <Award className="w-4 h-4 text-amber-800" />
          Wisdom School Experience
        </span>
        <h2 className="text-3xl sm:text-5xl font-black text-blue-950 tracking-tight">
          Campus Virtual Tour & Gallery
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm max-w-xl mx-auto">
          Explore our modern facilities, smart classrooms, sports ground, and kindergarten play area in Essur through interactive 360° virtual view or high-res photo gallery.
        </p>

        {/* View Switcher Tabs */}
        <div className="inline-flex p-1.5 bg-slate-200/80 rounded-2xl border border-slate-300 shadow-inner mt-2">
          <button
            onClick={() => setActiveTab('tour')}
            className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-black transition flex items-center gap-2 ${
              activeTab === 'tour'
                ? 'bg-blue-950 text-amber-400 shadow-md'
                : 'text-slate-700 hover:text-blue-950'
            }`}
          >
            <Compass className="w-4 h-4 text-amber-400" />
            <span>Interactive 360° Virtual Tour</span>
          </button>
          <button
            onClick={() => setActiveTab('gallery')}
            className={`px-5 py-2.5 rounded-xl text-xs sm:text-sm font-black transition flex items-center gap-2 ${
              activeTab === 'gallery'
                ? 'bg-blue-950 text-amber-400 shadow-md'
                : 'text-slate-700 hover:text-blue-950'
            }`}
          >
            <ImageIcon className="w-4 h-4 text-amber-400" />
            <span>Campus Photo Albums</span>
          </button>
        </div>
      </div>

      {/* ==================== 1. VIRTUAL 360° TOUR SECTION ==================== */}
      {activeTab === 'tour' && (
        <div className="space-y-6">
          {/* Main 360 Panoramic Viewing Stage */}
          <div className="bg-slate-950 rounded-3xl overflow-hidden shadow-2xl border-2 border-amber-400/60 relative">
            {/* Top Bar Controls */}
            <div className="bg-slate-900/90 text-white p-4 backdrop-blur-md border-b border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-400 text-blue-950 rounded-xl font-bold">
                  <Compass className="w-5 h-5 text-blue-950 animate-spin" style={{ animationDuration: '10s' }} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="bg-amber-400 text-blue-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">
                      360° Spot #{currentLocIndex + 1}
                    </span>
                    <h3 className="font-extrabold text-sm sm:text-base text-amber-300">
                      {currentLocation.name}
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-300">{currentLocation.subtitle}</p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  onClick={() => setAutoRotate(!autoRotate)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
                    autoRotate
                      ? 'bg-amber-400 text-blue-950 border-amber-300'
                      : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  {autoRotate ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{autoRotate ? 'Pause 360° Pan' : 'Auto 360° Pan'}</span>
                </button>

                <button
                  onClick={() => setAudioNarrating(!audioNarrating)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
                    audioNarrating
                      ? 'bg-emerald-500 text-white border-emerald-400 animate-pulse'
                      : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  {audioNarrating ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
                  <span>{audioNarrating ? 'Guide Voice On' : 'Tour Voice Guide'}</span>
                </button>

                <button
                  onClick={() => setShowVisitModal(true)}
                  className="px-4 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl transition shadow flex items-center gap-1.5"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Schedule Campus Visit</span>
                </button>
              </div>
            </div>

            {/* Panoramic Interactive Viewer Container */}
            <div className="relative h-[380px] sm:h-[480px] overflow-hidden bg-slate-900 select-none group">
              {/* Background Panorama Image transformed by degree slider */}
              <div
                className="w-full h-full transition-transform duration-75 ease-out scale-110"
                style={{
                  backgroundImage: `url(${currentLocation.image})`,
                  backgroundSize: 'cover',
                  backgroundPosition: `${(panDegree / 360) * 100}% center`,
                }}
              >
                {/* Overlay Vignette */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/40 pointer-events-none" />
              </div>

              {/* Interactive Hotspots Layer */}
              {currentLocation.hotspots.map((hs) => {
                // Adjust x position based on panning angle offset
                const effectiveX = (hs.xPercent + (panDegree - 180) / 3.6 + 100) % 100;
                if (effectiveX < 5 || effectiveX > 95) return null; // Hide off-screen

                return (
                  <div
                    key={hs.id}
                    className="absolute z-20 transition-all duration-300 transform -translate-x-1/2 -translate-y-1/2"
                    style={{ left: `${effectiveX}%`, top: `${hs.yPercent}%` }}
                  >
                    <button
                      onClick={() => setActiveHotspot(activeHotspot === hs.id ? null : hs.id)}
                      className="relative p-2 bg-amber-400 text-blue-950 rounded-full shadow-2xl hover:scale-125 transition border-2 border-white animate-bounce"
                      title={hs.title}
                    >
                      <Sparkles className="w-4 h-4 text-blue-950" />
                      <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping" />
                    </button>

                    {/* Hotspot Info Popup Modal */}
                    {activeHotspot === hs.id && (
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 w-64 bg-blue-950 text-white rounded-2xl p-3.5 shadow-2xl border-2 border-amber-400 text-xs space-y-1.5 z-30 animate-scaleUp">
                        <div className="flex items-center justify-between border-b border-blue-900 pb-1">
                          <span className="font-black text-amber-300 flex items-center gap-1">
                            <Info className="w-3.5 h-3.5" />
                            {hs.title}
                          </span>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              setActiveHotspot(null);
                            }}
                            className="text-slate-400 hover:text-white"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-200 leading-snug">{hs.details}</p>
                      </div>
                    )}
                  </div>
                );
              })}

              {/* On-Screen Navigation Arrows */}
              <button
                onClick={handlePrevLocation}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-slate-950/80 hover:bg-amber-400 text-white hover:text-blue-950 rounded-full backdrop-blur-md transition shadow-xl border border-slate-700"
                title="Previous Location"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              <button
                onClick={handleNextLocation}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3 bg-slate-950/80 hover:bg-amber-400 text-white hover:text-blue-950 rounded-full backdrop-blur-md transition shadow-xl border border-slate-700"
                title="Next Location"
              >
                <ChevronRight className="w-6 h-6" />
              </button>

              {/* Bottom Angle Controls Overlay */}
              <div className="absolute bottom-4 left-4 right-4 z-20 bg-slate-950/85 backdrop-blur-md rounded-2xl p-3.5 border border-slate-800 text-white flex flex-col sm:flex-row items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-xs font-bold">
                  <MoveHorizontal className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span>360° Pan Rotation Angle:</span>
                  <span className="text-amber-300 font-mono text-sm">{panDegree}°</span>
                </div>

                <input
                  type="range"
                  min="0"
                  max="360"
                  value={panDegree}
                  onChange={(e) => setPanDegree(Number(e.target.value))}
                  className="w-full sm:w-64 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                />

                <span className="text-[10px] text-slate-400 hidden lg:inline">
                  Drag slider or click sparkling hotspots to view facility details
                </span>
              </div>
            </div>

            {/* Audio Voiceover Subtitle Caption Bar */}
            {audioNarrating && (
              <div className="bg-emerald-950 text-emerald-100 p-3 text-xs border-t border-emerald-800 flex items-center gap-3">
                <Volume2 className="w-4 h-4 text-emerald-400 shrink-0 animate-bounce" />
                <div className="italic font-medium">
                  "{currentLocation.audioCaption}"
                </div>
              </div>
            )}
          </div>

          {/* Location Selection Cards Slider */}
          <div className="space-y-3">
            <h4 className="font-extrabold text-blue-950 text-base sm:text-lg flex items-center gap-2">
              <MapPin className="w-5 h-5 text-amber-600" />
              Select Campus Location to Tour:
            </h4>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              {VIRTUAL_TOUR_LOCATIONS.map((loc, idx) => (
                <button
                  key={loc.id}
                  onClick={() => {
                    setCurrentLocIndex(idx);
                    setActiveHotspot(null);
                  }}
                  className={`p-3 rounded-2xl border text-left transition flex flex-col justify-between space-y-2 ${
                    currentLocIndex === idx
                      ? 'bg-blue-950 text-white border-amber-400 shadow-lg ring-2 ring-amber-400/50'
                      : 'bg-white hover:bg-slate-100 text-slate-800 border-slate-200'
                  }`}
                >
                  <div className="relative h-20 rounded-xl overflow-hidden bg-slate-100">
                    <img src={loc.image} alt={loc.name} className="w-full h-full object-cover" />
                    <span className="absolute top-1 left-1 bg-slate-900/80 text-amber-300 text-[9px] font-black px-1.5 py-0.5 rounded-full">
                      Spot #{idx + 1}
                    </span>
                  </div>
                  <div>
                    <h5 className="font-extrabold text-xs line-clamp-1">{loc.name}</h5>
                    <p className={`text-[10px] ${currentLocIndex === idx ? 'text-amber-300' : 'text-slate-500'}`}>
                      {loc.category}
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Location Key Highlights & Description Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
            <div className="md:col-span-2 bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
              <div className="flex items-center gap-2">
                <span className="bg-amber-100 text-amber-900 text-xs font-black uppercase px-3 py-1 rounded-full border border-amber-300">
                  Spot Focus
                </span>
                <h3 className="text-xl font-extrabold text-blue-950">
                  {currentLocation.name}
                </h3>
              </div>
              <p className="text-slate-700 text-xs sm:text-sm leading-relaxed">
                {currentLocation.description}
              </p>

              <div className="pt-2">
                <h5 className="text-xs font-black uppercase text-slate-500 tracking-wider mb-2">
                  Key Infrastructure Features:
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {currentLocation.highlights.map((h, i) => (
                    <div key={i} className="flex items-center gap-2 text-xs font-bold text-slate-800 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Visit Inquiry Card */}
            <div className="bg-gradient-to-br from-blue-950 to-slate-900 text-white rounded-3xl p-6 shadow-xl border-2 border-amber-400/50 flex flex-col justify-between space-y-4">
              <div className="space-y-2">
                <span className="bg-amber-400 text-blue-950 text-[10px] font-black uppercase px-3 py-1 rounded-full inline-block">
                  Prospective Parents
                </span>
                <h4 className="text-xl font-black text-amber-300">
                  Like What You See?
                </h4>
                <p className="text-slate-300 text-xs leading-relaxed">
                  Schedule an in-person campus walk-through with our Principal or Admin Director at Essur campus.
                </p>
              </div>

              <div className="space-y-2 border-t border-slate-800 pt-4 text-xs">
                <div className="flex items-center gap-2 text-amber-200">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Individual Attention for Nursery to Class 5</span>
                </div>
                <div className="flex items-center gap-2 text-amber-200">
                  <PhoneCall className="w-4 h-4 text-amber-400" />
                  <span>Direct Helpdesk: {SCHOOL_INFO.phone}</span>
                </div>
              </div>

              <button
                onClick={() => setShowVisitModal(true)}
                className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black rounded-xl text-xs shadow-lg transition flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4 text-blue-950" />
                <span>Book Campus Walk-Through</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== 2. PHOTO GALLERY ALBUMS ==================== */}
      {activeTab === 'gallery' && (
        <div className="space-y-6">
          {/* Filter Category Pills */}
          <div className="flex flex-wrap justify-center gap-2 text-xs font-bold">
            {['All', 'Classroom', 'Kindergarten', 'Sports', 'Events', 'Campus'].map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl transition ${
                  activeCategory === cat
                    ? 'bg-blue-950 text-white shadow-md'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Image Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGallery.map((img) => (
              <div
                key={img.id}
                onClick={() => setSelectedImg(img)}
                className="group bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition cursor-pointer"
              >
                <div className="relative h-56 overflow-hidden bg-slate-100">
                  <img
                    src={img.url}
                    alt={img.title}
                    className="w-full h-full object-cover transition duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute top-3 left-3 bg-slate-900/80 text-amber-300 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full backdrop-blur-sm">
                    {img.category}
                  </div>
                </div>
                <div className="p-4 space-y-1">
                  <h4 className="font-bold text-slate-900 text-sm">{img.title}</h4>
                  <p className="text-slate-600 text-xs line-clamp-2">{img.caption}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Modal Lightbox */}
          {selectedImg && (
            <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
              <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl relative border-2 border-amber-400">
                <button
                  onClick={() => setSelectedImg(null)}
                  className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-slate-900/80 text-white flex items-center justify-center hover:bg-slate-900 transition"
                >
                  <X className="w-5 h-5" />
                </button>
                <img src={selectedImg.url} alt={selectedImg.title} className="w-full h-80 object-cover" />
                <div className="p-6 space-y-2">
                  <span className="text-xs font-bold text-amber-600 uppercase">{selectedImg.category}</span>
                  <h3 className="text-xl font-bold text-slate-900">{selectedImg.title}</h3>
                  <p className="text-slate-600 text-xs sm:text-sm">{selectedImg.caption}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ==================== 3. BOOK CAMPUS VISIT MODAL ==================== */}
      {showVisitModal && (
        <div className="fixed inset-0 z-50 bg-blue-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl relative border-2 border-amber-400">
            <button
              onClick={() => setShowVisitModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-2">
              <div className="w-12 h-12 bg-amber-100 text-amber-900 rounded-2xl mx-auto flex items-center justify-center border border-amber-300">
                <Calendar className="w-6 h-6 text-amber-900" />
              </div>
              <h3 className="font-extrabold text-xl text-blue-950">
                Schedule Campus Walk-Through
              </h3>
              <p className="text-xs text-slate-600">
                Wisdom Nursery & Primary School, Essur Campus
              </p>
            </div>

            {visitBookedSuccess ? (
              <div className="p-4 bg-emerald-100 border border-emerald-400 text-emerald-950 rounded-2xl text-center space-y-2 animate-bounce">
                <Check className="w-8 h-8 text-emerald-700 mx-auto" />
                <h4 className="font-extrabold text-sm">Visit Appointment Scheduled!</h4>
                <p className="text-xs text-emerald-800">
                  Our admin desk will confirm your appointment via SMS / WhatsApp at +91 {parentPhone}.
                </p>
              </div>
            ) : (
              <form onSubmit={handleBookVisitSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Parent Name *</label>
                  <input
                    type="text"
                    required
                    value={parentName}
                    onChange={(e) => setParentName(e.target.value)}
                    placeholder="e.g. R. Saravanan"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-950 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Contact Phone Number *</label>
                  <input
                    type="tel"
                    required
                    value={parentPhone}
                    onChange={(e) => setParentPhone(e.target.value)}
                    placeholder="e.g. 9176593129"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-950 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Preferred Visit Date *</label>
                  <input
                    type="date"
                    required
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-950 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Seeking Admission Grade</label>
                  <select
                    value={studentGrade}
                    onChange={(e) => setStudentGrade(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-blue-950 font-medium bg-white"
                  >
                    <option value="Pre-Nursery">Pre-Nursery / Playgroup</option>
                    <option value="LKG">LKG</option>
                    <option value="UKG">UKG</option>
                    <option value="Class 1">Class 1</option>
                    <option value="Class 2">Class 2</option>
                    <option value="Class 3">Class 3</option>
                    <option value="Class 4">Class 4</option>
                    <option value="Class 5">Class 5</option>
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-blue-950 hover:bg-blue-900 text-amber-400 font-black rounded-xl text-xs shadow-lg transition flex items-center justify-center gap-2 pt-2"
                >
                  <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  <span>Confirm Walk-Through Booking</span>
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};


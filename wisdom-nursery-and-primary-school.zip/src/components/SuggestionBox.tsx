import React, { useState } from 'react';
import {
  MessageSquarePlus,
  Lock,
  Send,
  ThumbsUp,
  CheckCircle2,
  Clock,
  Building2,
  Filter,
  Search,
  AlertCircle,
  Sparkles,
  ShieldCheck,
  UserCheck,
  EyeOff,
  User,
  X,
  MessageCircle,
  BarChart2,
  Check,
  Tag,
} from 'lucide-react';
import { StudentProfile } from '../types';

interface SuggestionBoxProps {
  student?: StudentProfile | null;
}

export interface SuggestionItem {
  id: string;
  category: 'Infrastructure & Labs' | 'Canteen & Food Quality' | 'Transport & Van Safety' | 'Academic & Homework' | 'Sports & Co-Curricular' | 'Campus Safety & Hygiene';
  title: string;
  suggestionText: string;
  submittedByRole: 'Parent' | 'Student' | 'Staff Member';
  isAnonymous: boolean;
  authorName?: string;
  dateSubmitted: string;
  upvotes: number;
  hasUpvoted?: boolean;
  status: 'Under Review by Management' | 'In Progress / Action Plan' | 'Implemented & Resolved' | 'Acknowledged';
  managementResponse?: string;
  respondedBy?: string;
  responseDate?: string;
}

export const SuggestionBox: React.FC<SuggestionBoxProps> = ({ student }) => {
  const [suggestions, setSuggestions] = useState<SuggestionItem[]>([
    {
      id: 'sug-101',
      category: 'Infrastructure & Labs',
      title: 'Request for Shaded Waiting Pavilion Near Primary Gate 2',
      suggestionText: 'Parents waiting for LKG and UKG children during afternoon dismissal face hot sun in summer months. Constructing a lightweight tin-roof shed near Gate 2 would benefit waiting grandparents.',
      submittedByRole: 'Parent',
      isAnonymous: true,
      dateSubmitted: '22 Jul 2026',
      upvotes: 42,
      status: 'Implemented & Resolved',
      managementResponse: 'Work order approved by Management. Fabrication of a 30-ft shaded fiberglass lounge with benches near Gate 2 completed on 25th July.',
      respondedBy: 'Wisdom Campus Admin Office',
      responseDate: '25 Jul 2026',
    },
    {
      id: 'sug-102',
      category: 'Canteen & Food Quality',
      title: 'Introduce Fresh Fruit Juices & Millet Snacks in Canteen',
      suggestionText: 'Instead of packaged biscuits, offering fresh seasonal watermelon/pomegranate juice and ragi/millet snacks will promote healthier eating habits among primary students.',
      submittedByRole: 'Student',
      isAnonymous: false,
      authorName: 'S. Kavin Vijay (Class 3-A)',
      dateSubmitted: '24 Jul 2026',
      upvotes: 28,
      status: 'In Progress / Action Plan',
      managementResponse: 'Excellent idea! Canteen vendor has been instructed to source fresh millet cookies and seasonal fruit juices starting August 1st.',
      respondedBy: 'Mrs. S. Kanthimathi (Nutrition Committee)',
      responseDate: '26 Jul 2026',
    },
    {
      id: 'sug-103',
      category: 'Academic & Homework',
      title: 'Consolidate Weekend Homework Calendar on ERP Portal',
      suggestionText: 'Having subject teachers post all weekend project deadlines on Friday morning inside the Student ERP helps parents plan study hours without last-minute panic.',
      submittedByRole: 'Parent',
      isAnonymous: true,
      dateSubmitted: '25 Jul 2026',
      upvotes: 19,
      status: 'Under Review by Management',
      managementResponse: 'Subject teachers briefed in staff meeting. Automated Friday 04:00 PM homework summary alerts are being integrated into the portal.',
      respondedBy: 'Vice Principal Mrs. R. Meenakshi',
      responseDate: '26 Jul 2026',
    },
    {
      id: 'sug-104',
      category: 'Campus Safety & Hygiene',
      title: 'Automatic Hand Sanitizer Dispensers Outside Science Labs',
      suggestionText: 'Installing touchless hand sanitizers outside chemistry and biology practical labs ensures students clean hands before and after experiments.',
      submittedByRole: 'Staff Member',
      isAnonymous: true,
      dateSubmitted: '26 Jul 2026',
      upvotes: 15,
      status: 'Acknowledged',
      managementResponse: 'Acknowledged. 6 sensor-based wall units ordered for Science Block corridors.',
      respondedBy: 'Maintenance Lead Mr. Shanmugam',
      responseDate: '27 Jul 2026',
    },
  ]);

  // Filters & State
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeTab, setActiveTab] = useState<'All' | 'Implemented' | 'In Progress' | 'My Submissions'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [showFormModal, setShowFormModal] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Form State
  const [formCategory, setFormCategory] = useState<SuggestionItem['category']>('Infrastructure & Labs');
  const [formRole, setFormRole] = useState<'Parent' | 'Student' | 'Staff Member'>('Parent');
  const [formIsAnonymous, setFormIsAnonymous] = useState(true);
  const [formName, setFormName] = useState(student?.name || '');
  const [formTitle, setFormTitle] = useState('');
  const [formText, setFormText] = useState('');

  const categories = [
    'All',
    'Infrastructure & Labs',
    'Canteen & Food Quality',
    'Transport & Van Safety',
    'Academic & Homework',
    'Sports & Co-Curricular',
    'Campus Safety & Hygiene',
  ];

  // Upvote suggestion handler
  const handleToggleUpvote = (id: string) => {
    setSuggestions((prev) =>
      prev.map((s) => {
        if (s.id === id) {
          const hasUpvoted = s.hasUpvoted;
          return {
            ...s,
            upvotes: hasUpvoted ? s.upvotes - 1 : s.upvotes + 1,
            hasUpvoted: !hasUpvoted,
          };
        }
        return s;
      })
    );
  };

  // Submit suggestion
  const handleSubmitSuggestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formText) return;

    const newSuggestion: SuggestionItem = {
      id: `sug-${Date.now()}`,
      category: formCategory,
      title: formTitle,
      suggestionText: formText,
      submittedByRole: formRole,
      isAnonymous: formIsAnonymous,
      authorName: formIsAnonymous ? undefined : formName || 'Wisdom School Parent',
      dateSubmitted: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      upvotes: 1,
      hasUpvoted: true,
      status: 'Under Review by Management',
    };

    setSuggestions([newSuggestion, ...suggestions]);
    setSubmitSuccess(true);
    setTimeout(() => {
      setSubmitSuccess(false);
      setShowFormModal(false);
      // Reset form
      setFormTitle('');
      setFormText('');
    }, 1200);
  };

  const filteredSuggestions = suggestions.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesTab =
      activeTab === 'All'
        ? true
        : activeTab === 'Implemented'
        ? item.status === 'Implemented & Resolved'
        : activeTab === 'In Progress'
        ? item.status === 'In Progress / Action Plan' || item.status === 'Under Review by Management'
        : item.hasUpvoted || (!item.isAnonymous && item.authorName?.includes(student?.name || ''));

    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.suggestionText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCategory && matchesTab && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl shrink-0">
              <MessageSquarePlus className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-blue-950">
                  Anonymous School Feedback & Suggestion Box
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-300 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-emerald-700" />
                  100% PRIVACY PROTECTED
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Share constructive ideas or concerns regarding school facilities, safety, canteen, or policies. Directly reviewed by Management.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowFormModal(true)}
            className="px-4 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black text-xs transition shadow flex items-center gap-2 self-start md:self-auto"
          >
            <Send className="w-4 h-4 text-amber-400" />
            <span>Submit a Suggestion</span>
          </button>
        </div>

        {/* Transparency Metrics Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-2xl text-blue-950 space-y-1">
            <span className="text-[10px] text-blue-800 font-bold uppercase block">Total Suggestions Received</span>
            <span className="font-extrabold text-lg text-blue-900">128 Entries</span>
          </div>

          <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 space-y-1">
            <span className="text-[10px] text-emerald-800 font-bold uppercase block">Actions Implemented</span>
            <span className="font-extrabold text-lg text-emerald-900">94 Ideas Approved (73%)</span>
          </div>

          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-amber-950 space-y-1">
            <span className="text-[10px] text-amber-800 font-bold uppercase block">Avg Management Response</span>
            <span className="font-extrabold text-lg text-amber-900">Within 48 Hours</span>
          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800 space-y-1">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Reviewed By</span>
            <span className="font-bold text-xs text-blue-950 block">School Principal & Management Board</span>
          </div>
        </div>

        {/* Search & Tabs Controls */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs pt-2">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search feedback by keyword (e.g. Canteen, Van, Gate, Homework)..."
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-800"
            />
          </div>

          <div className="md:col-span-4 flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            {(['All', 'Implemented', 'In Progress', 'My Submissions'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 rounded-lg text-xs font-extrabold transition ${
                  activeTab === tab
                    ? 'bg-blue-950 text-amber-400 shadow-xs'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="md:col-span-3">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full font-bold px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-800"
            >
              {categories.map((c) => (
                <option key={c} value={c}>Category: {c}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* SUGGESTIONS FEED CARDS */}
      <div className="space-y-4">
        {filteredSuggestions.map((item) => (
          <div
            key={item.id}
            className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm hover:shadow-md transition space-y-4"
          >
            {/* Header Meta */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div className="flex flex-wrap items-center gap-2">
                <span className="bg-blue-950 text-amber-300 font-black text-[10px] px-2.5 py-0.5 rounded-full border border-blue-800">
                  {item.category}
                </span>

                <span className="text-slate-400 text-xs font-bold">•</span>

                <span className="text-xs font-bold text-slate-600 flex items-center gap-1">
                  {item.isAnonymous ? (
                    <>
                      <EyeOff className="w-3.5 h-3.5 text-slate-400" />
                      <span>Submitted Anonymously ({item.submittedByRole})</span>
                    </>
                  ) : (
                    <>
                      <UserCheck className="w-3.5 h-3.5 text-blue-900" />
                      <span>By: {item.authorName}</span>
                    </>
                  )}
                </span>

                <span className="text-slate-400 text-xs font-bold">•</span>

                <span className="text-[11px] text-slate-400 font-medium">
                  Date: {item.dateSubmitted}
                </span>
              </div>

              {/* Status Badge */}
              <span
                className={`text-[10px] font-black px-3 py-1 rounded-full self-start sm:self-auto ${
                  item.status === 'Implemented & Resolved'
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                    : item.status === 'In Progress / Action Plan'
                    ? 'bg-amber-100 text-amber-900 border border-amber-300'
                    : 'bg-blue-50 text-blue-900 border border-blue-200'
                }`}
              >
                {item.status}
              </span>
            </div>

            {/* Content Body */}
            <div className="space-y-2">
              <h4 className="font-extrabold text-base text-slate-900">{item.title}</h4>
              <p className="text-slate-700 text-xs leading-relaxed">{item.suggestionText}</p>
            </div>

            {/* Management Response Box (if available) */}
            {item.managementResponse && (
              <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-2xl space-y-1.5 text-xs text-amber-950">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-blue-950 flex items-center gap-1.5 text-[11px]">
                    <Building2 className="w-3.5 h-3.5 text-amber-800" />
                    <span>Official Response from Management ({item.respondedBy})</span>
                  </span>
                  <span className="text-[10px] text-slate-500">{item.responseDate}</span>
                </div>
                <p className="text-slate-800 leading-relaxed font-medium">
                  {item.managementResponse}
                </p>
              </div>
            )}

            {/* Upvote & Support Bar */}
            <div className="pt-2 flex items-center justify-between text-xs">
              <button
                onClick={() => handleToggleUpvote(item.id)}
                className={`px-3.5 py-1.5 rounded-xl font-bold transition flex items-center gap-1.5 ${
                  item.hasUpvoted
                    ? 'bg-blue-950 text-amber-400 font-black shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                <ThumbsUp className={`w-3.5 h-3.5 ${item.hasUpvoted ? 'fill-amber-400' : ''}`} />
                <span>{item.hasUpvoted ? 'Supported' : 'Support Idea'} ({item.upvotes})</span>
              </button>

              <span className="text-[11px] text-slate-400 italic">
                {item.upvotes} parents/staff support this suggestion
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* SUBMIT SUGGESTION MODAL */}
      {showFormModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setShowFormModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl">
                <MessageSquarePlus className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Submit School Suggestion</h4>
                <p className="text-xs text-slate-500">Your voice helps continuously improve wisdom campus</p>
              </div>
            </div>

            {submitSuccess ? (
              <div className="text-center py-8 space-y-3">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="font-extrabold text-base text-blue-950">Suggestion Submitted Successfully!</h4>
                <p className="text-xs text-slate-500">
                  Thank you! Your feedback has been placed in the Management review queue.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmitSuggestion} className="space-y-4 text-xs">
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 block">Category *</label>
                    <select
                      value={formCategory}
                      onChange={(e: any) => setFormCategory(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                    >
                      {categories.filter((c) => c !== 'All').map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 block">Role *</label>
                    <select
                      value={formRole}
                      onChange={(e: any) => setFormRole(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                    >
                      <option value="Parent">Parent / Guardian</option>
                      <option value="Student">Student</option>
                      <option value="Staff Member">Teaching / Support Staff</option>
                    </select>
                  </div>
                </div>

                {/* Privacy Anonymity Toggle */}
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <EyeOff className="w-4 h-4 text-slate-500" />
                    <div>
                      <span className="font-bold text-slate-900 block">Submit Anonymously</span>
                      <span className="text-[10px] text-slate-500">Your identity will remain completely hidden</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setFormIsAnonymous(!formIsAnonymous)}
                    className={`w-12 h-6 rounded-full transition p-1 flex items-center ${
                      formIsAnonymous ? 'bg-emerald-600 justify-end' : 'bg-slate-300 justify-start'
                    }`}
                  >
                    <span className="w-4 h-4 bg-white rounded-full shadow-md"></span>
                  </button>
                </div>

                {!formIsAnonymous && (
                  <div className="space-y-1">
                    <label className="font-bold text-slate-700 block">Your Name / Student Name</label>
                    <input
                      type="text"
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="e.g. S. Kavin Vijay (Class 3-A)"
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                    />
                  </div>
                )}

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Suggestion Title / Headline *</label>
                  <input
                    type="text"
                    required
                    value={formTitle}
                    onChange={(e) => setFormTitle(e.target.value)}
                    placeholder="e.g. Water purifier maintenance in Block B ground floor"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Detailed Suggestion or Feedback *</label>
                  <textarea
                    rows={4}
                    required
                    value={formText}
                    onChange={(e) => setFormText(e.target.value)}
                    placeholder="Provide constructive details and suggestions on how management can improve this facility or policy..."
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                  />
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowFormModal(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black transition shadow flex items-center gap-1.5"
                  >
                    <Send className="w-4 h-4 text-amber-400" />
                    <span>Send Feedback</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

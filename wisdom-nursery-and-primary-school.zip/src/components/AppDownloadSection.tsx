import React, { useState } from 'react';
import { Smartphone, Download, CheckCircle2, ShieldCheck, Bell, Sparkles, FileText } from 'lucide-react';
import { SCHOOL_INFO } from '../data/schoolData';

export const AppDownloadSection: React.FC = () => {
  const [downloading, setDownloading] = useState(false);
  const [downloadComplete, setDownloadComplete] = useState(false);

  const handleDownloadApk = () => {
    setDownloading(true);
    setDownloadComplete(false);

    // Simulate APK download
    setTimeout(() => {
      setDownloading(false);
      setDownloadComplete(true);

      // Trigger dummy blob download
      const element = document.createElement('a');
      const file = new Blob([`Wisdom Nursery and Primary School Essur Android App Package v2.4\nAdmin: ${SCHOOL_INFO.adminName}\nUPI ID: ${SCHOOL_INFO.upiId}`], {
        type: 'text/plain',
      });
      element.href = URL.createObjectURL(file);
      element.download = 'Wisdom_School_Essur_v2.4.apk';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }, 1500);
  };

  return (
    <div id="app" className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Container Card */}
      <div className="bg-gradient-to-br from-emerald-950 via-teal-900 to-slate-900 rounded-3xl p-8 sm:p-12 text-white shadow-xl border border-emerald-800 text-center relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-2xl mx-auto space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 flex items-center justify-center mx-auto text-3xl shadow-inner">
            <Smartphone className="w-8 h-8" />
          </div>

          <span className="bg-emerald-400 text-slate-950 text-xs font-black uppercase px-3.5 py-1 rounded-full border border-emerald-300 inline-block">
            Official Mobile App v2.4 (Android)
          </span>

          <h2 className="text-2xl sm:text-4xl font-extrabold tracking-tight">
            Download Wisdom School Android APK
          </h2>

          <p className="text-emerald-100 text-xs sm:text-sm leading-relaxed">
            Get daily student homework alerts, fee payment reminders, exam marksheets, and holiday circulars directly on your Android smartphone.
          </p>

          {/* Download Button */}
          <div className="pt-2">
            <button
              onClick={handleDownloadApk}
              disabled={downloading}
              className="bg-emerald-400 hover:bg-emerald-300 text-slate-950 font-black px-8 py-4 rounded-2xl shadow-xl transition transform hover:-translate-y-0.5 active:scale-95 inline-flex items-center gap-3 text-sm sm:text-base border border-emerald-300"
            >
              <Download className={`w-5 h-5 ${downloading ? 'animate-bounce' : ''}`} />
              <div className="text-left">
                <div className="text-[10px] uppercase font-bold text-slate-800">Direct Download APK</div>
                <div className="font-extrabold text-sm sm:text-base">
                  {downloading ? 'Downloading APK...' : 'Wisdom_School_Essur.apk (12.4 MB)'}
                </div>
              </div>
            </button>
          </div>

          {downloadComplete && (
            <div className="p-3 bg-emerald-900/80 border border-emerald-400/40 rounded-xl text-xs text-emerald-200 inline-flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>APK Download Started! Check your Downloads folder to install.</span>
            </div>
          )}

          {/* App Features List */}
          <div className="pt-8 border-t border-emerald-800/80 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left text-xs">
            <div className="p-4 bg-emerald-900/40 rounded-2xl border border-emerald-800/60 space-y-1">
              <Bell className="w-5 h-5 text-amber-300" />
              <h4 className="font-bold text-white">Instant Notifications</h4>
              <p className="text-emerald-200 text-[11px]">Real-time push alerts for exam circulars and holiday notices.</p>
            </div>

            <div className="p-4 bg-emerald-900/40 rounded-2xl border border-emerald-800/60 space-y-1">
              <FileText className="w-5 h-5 text-amber-300" />
              <h4 className="font-bold text-white">Homework & Marks</h4>
              <p className="text-emerald-200 text-[11px]">View daily homework tasks and term examination marksheets.</p>
            </div>

            <div className="p-4 bg-emerald-900/40 rounded-2xl border border-emerald-800/60 space-y-1">
              <ShieldCheck className="w-5 h-5 text-amber-300" />
              <h4 className="font-bold text-white">Digital Fee Receipts</h4>
              <p className="text-emerald-200 text-[11px]">Store all official fee receipts safely on your phone.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

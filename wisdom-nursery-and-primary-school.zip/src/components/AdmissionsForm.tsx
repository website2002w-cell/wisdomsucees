import React, { useState } from 'react';
import {
  GraduationCap,
  CheckCircle2,
  FileText,
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Award,
  Printer,
  Sparkles,
  ArrowRight,
  ArrowLeft,
  UploadCloud,
  Check,
  ShieldCheck,
  Bus,
  CheckCircle,
  Eye,
  Camera,
  FileCheck,
  X,
  Save,
  RotateCcw,
} from 'lucide-react';
import { AdmissionApplication } from '../types';
import { SCHOOL_INFO } from '../data/schoolData';
import { DocumentPreviewCarousel } from './DocumentPreviewCarousel';
import { ApplicationStatusCard } from './ApplicationStatusCard';
import { getAdmissionsConfig, AdmissionsConfig } from '../utils/admissionsConfig';

const DRAFT_STORAGE_KEY = 'wisdom_admission_draft_2026';

const INITIAL_FORM_DATA = {
  studentName: '',
  dob: '2021-05-10',
  gender: 'Male',
  grade: 'LKG',
  bloodGroup: 'O +ve',
  fatherName: '',
  motherName: '',
  phone: '',
  email: '',
  address: 'Essur - 603301',
  previousSchool: '',
  needTransport: 'Yes',
  birthCertFile: null as File | null,
  aadhaarFile: null as File | null,
  photoFile: null as File | null,
  tcFile: null as File | null,
  communityCertFile: null as File | null,
  bloodReportFile: null as File | null,
  declared: false,
};

export const AdmissionsForm: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'register' | 'status'>('register');
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [showDocGuideModal, setShowDocGuideModal] = useState<boolean>(false);
  const [admConfig, setAdmConfig] = useState<AdmissionsConfig>(getAdmissionsConfig());
  const [isDraftRestored, setIsDraftRestored] = useState<boolean>(false);
  const [lastSavedTime, setLastSavedTime] = useState<string | null>(null);

  React.useEffect(() => {
    const handleUpdate = () => {
      setAdmConfig(getAdmissionsConfig());
    };
    window.addEventListener('admissions-config-updated', handleUpdate);
    return () => window.removeEventListener('admissions-config-updated', handleUpdate);
  }, []);

  const [formData, setFormData] = useState(INITIAL_FORM_DATA);

  // Restore draft from localStorage on initial component mount
  React.useEffect(() => {
    try {
      const savedDraft = localStorage.getItem(DRAFT_STORAGE_KEY);
      if (savedDraft) {
        const parsed = JSON.parse(savedDraft);
        if (parsed && typeof parsed === 'object') {
          const { currentStep: savedStep, savedAt, ...savedForm } = parsed;
          if (savedForm.studentName || savedForm.fatherName || savedForm.phone) {
            setFormData((prev) => ({
              ...prev,
              ...savedForm,
              birthCertFile: null,
              aadhaarFile: null,
              photoFile: null,
              tcFile: null,
              communityCertFile: null,
              bloodReportFile: null,
            }));
            if (savedStep && typeof savedStep === 'number' && savedStep >= 1 && savedStep <= 4) {
              setCurrentStep(savedStep);
            }
            setIsDraftRestored(true);
            if (savedAt) {
              setLastSavedTime(
                new Date(savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
              );
            }
          }
        }
      }
    } catch (err) {
      console.error('Error restoring admission draft:', err);
    }
  }, []);

  // Auto-save form progress to localStorage on changes
  React.useEffect(() => {
    const hasData =
      formData.studentName.trim() !== '' ||
      formData.fatherName.trim() !== '' ||
      formData.phone.trim() !== '' ||
      currentStep > 1;

    if (!hasData) return;

    const now = new Date();
    const serializableForm = {
      studentName: formData.studentName,
      dob: formData.dob,
      gender: formData.gender,
      grade: formData.grade,
      bloodGroup: formData.bloodGroup,
      fatherName: formData.fatherName,
      motherName: formData.motherName,
      phone: formData.phone,
      email: formData.email,
      address: formData.address,
      previousSchool: formData.previousSchool,
      needTransport: formData.needTransport,
      declared: formData.declared,
      currentStep,
      savedAt: now.toISOString(),
    };

    try {
      localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(serializableForm));
      setLastSavedTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      );
    } catch (err) {
      console.error('Error auto-saving admission draft:', err);
    }
  }, [formData, currentStep]);

  const handleClearDraft = () => {
    if (window.confirm('Clear your saved draft and start a blank registration form?')) {
      try {
        localStorage.removeItem(DRAFT_STORAGE_KEY);
      } catch (e) {
        console.error(e);
      }
      setFormData(INITIAL_FORM_DATA);
      setCurrentStep(1);
      setIsDraftRestored(false);
      setLastSavedTime(null);
    }
  };

  const [submitting, setSubmitting] = useState(false);
  const [submittedApplication, setSubmittedApplication] = useState<AdmissionApplication | null>(null);

  const steps = [
    { number: 1, title: "Child Info", subtitle: "Basic details" },
    { number: 2, title: "Parent Info", subtitle: "Contact details" },
    { number: 3, title: "Docs & Transport", subtitle: "Uploads & Van" },
    { number: 4, title: "Review & Submit", subtitle: "Verification" },
  ];

  const validateStep = (step: number) => {
    if (step === 1) {
      if (!formData.studentName.trim()) {
        alert("Please enter the child's full name.");
        return false;
      }
    } else if (step === 2) {
      if (!formData.fatherName.trim() || !formData.phone.trim()) {
        alert("Please enter Father's Name and Contact Mobile Number.");
        return false;
      }
    } else if (step === 4) {
      if (!formData.declared) {
        alert("Please confirm the declaration check box before submitting.");
        return false;
      }
    }
    return true;
  };

  const handleNext = () => {
    if (validateStep(currentStep)) {
      setCurrentStep((prev) => Math.min(prev + 1, 4));
    }
  };

  const handlePrev = () => {
    setCurrentStep((prev) => Math.max(prev - 1, 1));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateStep(4)) return;

    setSubmitting(true);
    try {
      const res = await fetch('/api/admissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const data = await res.json();
      if (data.success) {
        setSubmittedApplication(data.application);
        try { localStorage.removeItem(DRAFT_STORAGE_KEY); } catch (e) {}
        setIsDraftRestored(false);
        setLastSavedTime(null);
      } else {
        alert(data.message || 'Error submitting application');
      }
    } catch (err) {
      console.error(err);
      // Fallback
      const app: AdmissionApplication = {
        id: `ADM-ESSUR-2026-${Math.floor(100 + Math.random() * 900)}`,
        studentName: formData.studentName,
        dob: formData.dob || '2021-05-10',
        gender: formData.gender,
        grade: formData.grade,
        fatherName: formData.fatherName,
        motherName: formData.motherName,
        phone: formData.phone,
        email: formData.email,
        address: formData.address,
        previousSchool: formData.previousSchool || 'None',
        submittedAt: new Date().toISOString(),
        status: 'Pending Review',
      };
      setSubmittedApplication(app);
      try { localStorage.removeItem(DRAFT_STORAGE_KEY); } catch (e) {}
      setIsDraftRestored(false);
      setLastSavedTime(null);
    } finally {
      setSubmitting(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const progressPercentage = submittedApplication
    ? 100
    : Math.round(((currentStep - 1) / (steps.length - 1)) * 100);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-8">
      {/* Top Mode Selector Tabs */}
      <div className="flex justify-center">
        <div className="inline-flex p-1.5 bg-slate-200/80 rounded-2xl border border-slate-300 gap-1 text-xs font-black shadow-inner">
          <button
            onClick={() => setActiveTab('register')}
            className={`px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
              activeTab === 'register'
                ? 'bg-blue-950 text-amber-400 shadow'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
            }`}
          >
            <GraduationCap className="w-4 h-4 text-amber-400" />
            <span>New Admission Registration</span>
          </button>

          <button
            onClick={() => setActiveTab('status')}
            className={`px-5 py-2.5 rounded-xl transition flex items-center gap-2 ${
              activeTab === 'status'
                ? 'bg-blue-950 text-amber-400 shadow'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/60'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Check Application Status & Timeline</span>
          </button>
        </div>
      </div>

      {activeTab === 'status' ? (
        <ApplicationStatusCard onBackToForm={() => setActiveTab('register')} />
      ) : (
        <>
          {/* Title Header */}
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <div className="flex items-center justify-center gap-2 flex-wrap">
              <span className="bg-amber-100 text-amber-900 text-xs font-black uppercase px-3.5 py-1.5 rounded-full border border-amber-300 inline-flex items-center gap-1.5 shadow-sm">
                <GraduationCap className="w-3.5 h-3.5 text-amber-800" />
                Academic Year {admConfig.academicYear}
              </span>

              <span className={`text-xs font-black uppercase px-3 py-1.5 rounded-full shadow-sm inline-flex items-center gap-1.5 ${
                admConfig.status === 'OPEN'
                  ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                  : 'bg-amber-100 text-amber-900 border border-amber-300'
              }`}>
                <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
                <span>Admissions Status: {admConfig.status}</span>
              </span>

              <button
                onClick={() => setShowDocGuideModal(true)}
                className="bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold text-xs px-3.5 py-1.5 rounded-full shadow transition flex items-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Document Preview Guide</span>
              </button>
            </div>

            <h2 className="text-2xl sm:text-4xl font-black text-blue-950">
              {admConfig.headlineText}
            </h2>
            <p className="text-slate-600 text-xs sm:text-sm max-w-2xl mx-auto leading-relaxed">
              {admConfig.subText}
            </p>

            {/* Quick Key Info Badges */}
            <div className="flex flex-wrap justify-center gap-2 sm:gap-3 text-xs font-bold pt-2">
              <span className="bg-slate-100 text-slate-800 px-3 py-1.5 rounded-xl border border-slate-200 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-blue-800" />
                <span>Apply By: <strong>{admConfig.lastDateToApply}</strong></span>
              </span>

              <span className="bg-emerald-50 text-emerald-900 px-3 py-1.5 rounded-xl border border-emerald-200 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-emerald-700" />
                <span>Application Fee: <strong>{admConfig.applicationFee === 0 ? 'FREE (₹0)' : `₹${admConfig.applicationFee}`}</strong></span>
              </span>

              <span className="bg-blue-50 text-blue-900 px-3 py-1.5 rounded-xl border border-blue-200 flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-blue-700" />
                <span>Helpdesk: <a href={`tel:${admConfig.helpdeskPhone}`} className="underline font-mono">{admConfig.helpdeskPhone}</a></span>
              </span>
            </div>

            {/* Live Seat Matrix Pill Strip */}
            <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800 text-white text-xs space-y-2 text-left mt-3 shadow-md">
              <div className="flex items-center justify-between text-[11px] font-extrabold text-amber-400 uppercase tracking-wider">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Sanctioned Seats Matrix ({admConfig.academicYear})</span>
                </span>
                <span className="text-slate-300 font-normal">Updated Live</span>
              </div>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 text-[11px]">
                {admConfig.gradeConfigs.map((g, idx) => (
                  <div key={idx} className="bg-slate-800 border border-slate-700 px-2.5 py-1 rounded-xl whitespace-nowrap shrink-0 flex items-center gap-1.5">
                    <span className="font-bold text-slate-200">{g.grade}:</span>
                    <span className="font-black text-amber-300">{g.availableSeats} Left</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

      {/* Visual Multi-step Progress Bar */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
        <div className="flex justify-between items-center text-xs font-black text-slate-700">
          <span className="uppercase tracking-wider text-blue-950 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span>Admission Application Progress</span>
          </span>
          <span className="bg-blue-950 text-amber-400 font-mono px-3 py-1 rounded-full text-xs font-extrabold">
            {submittedApplication ? '100% Completed' : `Step ${currentStep} of 4 (${progressPercentage}%)`}
          </span>
        </div>

        {/* Progress Bar Track */}
        <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-blue-900 via-indigo-800 to-amber-500 h-2.5 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>

        {/* Stepper Nodes */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
          {steps.map((step) => {
            const isDone = currentStep > step.number || !!submittedApplication;
            const isCurrent = currentStep === step.number && !submittedApplication;

            return (
              <div
                key={step.number}
                onClick={() => {
                  if (step.number < currentStep) setCurrentStep(step.number);
                }}
                className={`p-3 rounded-2xl border text-left transition cursor-pointer flex items-center gap-3 ${
                  isDone
                    ? 'bg-emerald-50 border-emerald-300 text-emerald-900'
                    : isCurrent
                    ? 'bg-blue-950 border-blue-900 text-white shadow-md ring-2 ring-amber-400'
                    : 'bg-slate-50 border-slate-200 text-slate-400'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-full font-black text-xs flex items-center justify-center shrink-0 ${
                    isDone
                      ? 'bg-emerald-600 text-white'
                      : isCurrent
                      ? 'bg-amber-400 text-blue-950'
                      : 'bg-slate-200 text-slate-600'
                  }`}
                >
                  {isDone ? <Check className="w-4 h-4 stroke-[3]" /> : step.number}
                </div>

                <div className="truncate">
                  <h4 className="font-extrabold text-xs leading-tight truncate">
                    {step.title}
                  </h4>
                  <p className={`text-[10px] font-medium truncate ${isCurrent ? 'text-amber-200' : 'text-slate-500'}`}>
                    {step.subtitle}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {!submittedApplication ? (
        <form onSubmit={handleSubmit} className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
          
          {/* Auto-Save & Connection Interruption Protection Banner */}
          <div className="bg-emerald-50/90 border border-emerald-200/90 text-emerald-950 p-3.5 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-sm">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 font-bold shadow-sm">
                <Save className="w-4 h-4 text-white animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-1.5 font-black text-emerald-950">
                  <span>Auto-Save Protection Active</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                </div>
                <p className="text-[11px] font-medium text-emerald-800">
                  {isDraftRestored
                    ? 'Draft restored from your previous session.'
                    : "Your form entries are automatically saved locally. Reloading or losing connection won't lose your progress."}{' '}
                  {lastSavedTime && (
                    <span className="font-bold text-emerald-950">Saved at {lastSavedTime}.</span>
                  )}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
              <button
                type="button"
                onClick={handleClearDraft}
                className="text-[11px] font-bold text-slate-600 hover:text-red-700 hover:bg-red-50 border border-slate-300 hover:border-red-300 px-3 py-1.5 rounded-xl transition flex items-center gap-1 bg-white shadow-xs"
                title="Clear saved draft and start fresh form"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Form</span>
              </button>
            </div>
          </div>

          {/* STEP 1: CHILD'S BASIC DETAILS */}
          {currentStep === 1 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-slate-100 pb-4">
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <User className="w-5 h-5 text-blue-900" />
                  <span>Step 1: Child's Information</span>
                </h3>
                <p className="text-xs text-slate-500">Provide basic student details for official register entry.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="sm:col-span-2">
                  <label className="block font-bold text-slate-700 mb-1">
                    Child's Full Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.studentName}
                    onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                    placeholder="e.g. S. Kavin Kumar"
                    required
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Grade Applying For</label>
                  <select
                    value={formData.grade}
                    onChange={(e) => setFormData({ ...formData, grade: e.target.value })}
                    className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50 text-slate-900"
                  >
                    {admConfig.gradeConfigs.map((g, idx) => (
                      <option key={idx} value={g.grade}>
                        {g.grade} — [{g.availableSeats} Seats Available] ({g.ageCriteria})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Date of Birth</label>
                  <input
                    type="date"
                    value={formData.dob}
                    onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                    className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50 text-slate-900"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Blood Group</label>
                  <select
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                    className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50 text-slate-900"
                  >
                    <option value="O +ve">O +ve</option>
                    <option value="A +ve">A +ve</option>
                    <option value="B +ve">B +ve</option>
                    <option value="AB +ve">AB +ve</option>
                    <option value="O -ve">O -ve</option>
                    <option value="A -ve">A -ve</option>
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* STEP 2: PARENT & CONTACT DETAILS */}
          {currentStep === 2 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-slate-100 pb-4">
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Phone className="w-5 h-5 text-blue-900" />
                  <span>Step 2: Parent & Contact Details</span>
                </h3>
                <p className="text-xs text-slate-500">Parent information for mobile alerts and correspondence.</p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Father's Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={formData.fatherName}
                    onChange={(e) => setFormData({ ...formData, fatherName: e.target.value })}
                    placeholder="e.g. R. Saravanan"
                    required
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Mother's Name</label>
                  <input
                    type="text"
                    value={formData.motherName}
                    onChange={(e) => setFormData({ ...formData, motherName: e.target.value })}
                    placeholder="e.g. S. Sundari"
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Mobile / WhatsApp Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="e.g. 9176593129"
                    required
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Email Address (Optional)</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="e.g. parent@example.com"
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-700 mb-1">Residential Address in Essur / Village</label>
                  <textarea
                    rows={2}
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    placeholder="Full address in Essur - 603301"
                    className="w-full text-xs font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  ></textarea>
                </div>
              </div>
            </div>
          )}

          {/* STEP 3: DOCUMENTS & PREFERENCES */}
          {currentStep === 3 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-slate-100 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                    <UploadCloud className="w-5 h-5 text-blue-900" />
                    <span>Step 3: Document Verification & Van Preferences</span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Review required documents for <strong>{formData.grade}</strong> and upload digital records.
                  </p>
                </div>

                <div className="bg-amber-100 text-amber-900 border border-amber-300 px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5">
                  <FileCheck className="w-4 h-4 text-amber-800" />
                  <span>Grade Linked: {formData.grade}</span>
                </div>
              </div>

              {/* Document Preview Carousel Guide Embedded in Form */}
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-extrabold text-blue-950 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    Visual Document Guide for {formData.grade}
                  </span>
                  <span className="text-slate-500 text-[11px]">Swipe or use arrows to view document templates</span>
                </div>

                <DocumentPreviewCarousel selectedGrade={formData.grade} />
              </div>

              <div className="space-y-4 text-xs pt-4 border-t border-slate-100">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Previous School Attended (If Any)</label>
                    <input
                      type="text"
                      value={formData.previousSchool}
                      onChange={(e) => setFormData({ ...formData, previousSchool: e.target.value })}
                      placeholder="e.g. Govt Primary School / None"
                      className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Van Transport Required?</label>
                    <div className="flex items-center gap-4 pt-1">
                      <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer">
                        <input
                          type="radio"
                          name="transport"
                          value="Yes"
                          checked={formData.needTransport === 'Yes'}
                          onChange={() => setFormData({ ...formData, needTransport: 'Yes' })}
                          className="text-blue-900"
                        />
                        <span>Yes (Essur / Vedanthangal Van Pickup)</span>
                      </label>
                      <label className="flex items-center gap-2 font-bold text-slate-800 cursor-pointer">
                        <input
                          type="radio"
                          name="transport"
                          value="No"
                          checked={formData.needTransport === 'No'}
                          onChange={() => setFormData({ ...formData, needTransport: 'No' })}
                          className="text-blue-900"
                        />
                        <span>No (Self Drop / Walking)</span>
                      </label>
                    </div>
                  </div>
                </div>

                {/* Document File Upload Dropzones */}
                <div className="space-y-2 pt-2">
                  <h4 className="font-extrabold text-xs text-blue-950 uppercase tracking-wider">
                    Upload Digital Copies (Optional - Can also be submitted at school office):
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {/* Birth Certificate */}
                    <div className={`p-3.5 border-2 border-dashed rounded-2xl text-center space-y-1.5 transition ${formData.birthCertFile ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-300 bg-slate-50'}`}>
                      <UploadCloud className={`w-5 h-5 mx-auto ${formData.birthCertFile ? 'text-emerald-600' : 'text-blue-900'}`} />
                      <h5 className="font-bold text-slate-800 text-[11px]">1. Child Birth Certificate</h5>
                      {formData.birthCertFile ? (
                        <p className="text-[10px] text-emerald-700 font-bold truncate">✓ {formData.birthCertFile.name}</p>
                      ) : (
                        <p className="text-[10px] text-slate-500">PDF, JPG up to 5MB</p>
                      )}
                      <input
                        type="file"
                        onChange={(e) => setFormData({ ...formData, birthCertFile: e.target.files?.[0] || null })}
                        className="text-[9px] text-slate-500 file:mr-1 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:text-[9px] file:font-bold file:bg-blue-950 file:text-amber-400 hover:file:bg-blue-900 cursor-pointer w-full"
                      />
                    </div>

                    {/* Aadhaar Card */}
                    <div className={`p-3.5 border-2 border-dashed rounded-2xl text-center space-y-1.5 transition ${formData.aadhaarFile ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-300 bg-slate-50'}`}>
                      <UploadCloud className={`w-5 h-5 mx-auto ${formData.aadhaarFile ? 'text-emerald-600' : 'text-blue-900'}`} />
                      <h5 className="font-bold text-slate-800 text-[11px]">2. Aadhaar Card Copy</h5>
                      {formData.aadhaarFile ? (
                        <p className="text-[10px] text-emerald-700 font-bold truncate">✓ {formData.aadhaarFile.name}</p>
                      ) : (
                        <p className="text-[10px] text-slate-500">PDF, JPG up to 5MB</p>
                      )}
                      <input
                        type="file"
                        onChange={(e) => setFormData({ ...formData, aadhaarFile: e.target.files?.[0] || null })}
                        className="text-[9px] text-slate-500 file:mr-1 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:text-[9px] file:font-bold file:bg-blue-950 file:text-amber-400 hover:file:bg-blue-900 cursor-pointer w-full"
                      />
                    </div>

                    {/* Passport Photo */}
                    <div className={`p-3.5 border-2 border-dashed rounded-2xl text-center space-y-1.5 transition ${formData.photoFile ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-300 bg-slate-50'}`}>
                      <Camera className={`w-5 h-5 mx-auto ${formData.photoFile ? 'text-emerald-600' : 'text-blue-900'}`} />
                      <h5 className="font-bold text-slate-800 text-[11px]">3. Student Passport Photo</h5>
                      {formData.photoFile ? (
                        <p className="text-[10px] text-emerald-700 font-bold truncate">✓ {formData.photoFile.name}</p>
                      ) : (
                        <p className="text-[10px] text-slate-500">JPG, PNG up to 2MB</p>
                      )}
                      <input
                        type="file"
                        onChange={(e) => setFormData({ ...formData, photoFile: e.target.files?.[0] || null })}
                        className="text-[9px] text-slate-500 file:mr-1 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:text-[9px] file:font-bold file:bg-blue-950 file:text-amber-400 hover:file:bg-blue-900 cursor-pointer w-full"
                      />
                    </div>

                    {/* Transfer Certificate (TC) */}
                    <div className={`p-3.5 border-2 border-dashed rounded-2xl text-center space-y-1.5 transition ${formData.tcFile ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-300 bg-slate-50'}`}>
                      <FileText className={`w-5 h-5 mx-auto ${formData.tcFile ? 'text-emerald-600' : 'text-blue-900'}`} />
                      <h5 className="font-bold text-slate-800 text-[11px]">4. Transfer Certificate (Class 1-5)</h5>
                      {formData.tcFile ? (
                        <p className="text-[10px] text-emerald-700 font-bold truncate">✓ {formData.tcFile.name}</p>
                      ) : (
                        <p className="text-[10px] text-slate-500">For school transfers</p>
                      )}
                      <input
                        type="file"
                        onChange={(e) => setFormData({ ...formData, tcFile: e.target.files?.[0] || null })}
                        className="text-[9px] text-slate-500 file:mr-1 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:text-[9px] file:font-bold file:bg-blue-950 file:text-amber-400 hover:file:bg-blue-900 cursor-pointer w-full"
                      />
                    </div>

                    {/* Community Certificate */}
                    <div className={`p-3.5 border-2 border-dashed rounded-2xl text-center space-y-1.5 transition ${formData.communityCertFile ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-300 bg-slate-50'}`}>
                      <Award className={`w-5 h-5 mx-auto ${formData.communityCertFile ? 'text-emerald-600' : 'text-blue-900'}`} />
                      <h5 className="font-bold text-slate-800 text-[11px]">5. Community Certificate</h5>
                      {formData.communityCertFile ? (
                        <p className="text-[10px] text-emerald-700 font-bold truncate">✓ {formData.communityCertFile.name}</p>
                      ) : (
                        <p className="text-[10px] text-slate-500">e-Sevai TN copy</p>
                      )}
                      <input
                        type="file"
                        onChange={(e) => setFormData({ ...formData, communityCertFile: e.target.files?.[0] || null })}
                        className="text-[9px] text-slate-500 file:mr-1 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:text-[9px] file:font-bold file:bg-blue-950 file:text-amber-400 hover:file:bg-blue-900 cursor-pointer w-full"
                      />
                    </div>

                    {/* Blood Report */}
                    <div className={`p-3.5 border-2 border-dashed rounded-2xl text-center space-y-1.5 transition ${formData.bloodReportFile ? 'border-emerald-500 bg-emerald-50/50' : 'border-slate-300 bg-slate-50'}`}>
                      <FileCheck className={`w-5 h-5 mx-auto ${formData.bloodReportFile ? 'text-emerald-600' : 'text-blue-900'}`} />
                      <h5 className="font-bold text-slate-800 text-[11px]">6. Blood Group Report</h5>
                      {formData.bloodReportFile ? (
                        <p className="text-[10px] text-emerald-700 font-bold truncate">✓ {formData.bloodReportFile.name}</p>
                      ) : (
                        <p className="text-[10px] text-slate-500">Clinical lab report</p>
                      )}
                      <input
                        type="file"
                        onChange={(e) => setFormData({ ...formData, bloodReportFile: e.target.files?.[0] || null })}
                        className="text-[9px] text-slate-500 file:mr-1 file:py-1 file:px-2.5 file:rounded-xl file:border-0 file:text-[9px] file:font-bold file:bg-blue-950 file:text-amber-400 hover:file:bg-blue-900 cursor-pointer w-full"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* STEP 4: REVIEW & SUBMIT */}
          {currentStep === 4 && (
            <div className="space-y-6 animate-fadeIn">
              <div className="border-b border-slate-100 pb-4">
                <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-blue-900" />
                  <span>Step 4: Review Application Summary</span>
                </h3>
                <p className="text-xs text-slate-500">Review all information carefully before final submission.</p>
              </div>

              <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 text-xs space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <span className="text-slate-500 block">Child's Name:</span>
                    <strong className="text-blue-950 text-sm font-black">{formData.studentName || 'Not specified'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Grade Applying For:</span>
                    <span className="bg-amber-100 text-amber-900 font-extrabold px-2 py-0.5 rounded">{formData.grade}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Date of Birth / Gender:</span>
                    <strong className="text-slate-800">{formData.dob} ({formData.gender})</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Blood Group:</span>
                    <strong className="text-slate-800">{formData.bloodGroup}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Father's Name:</span>
                    <strong className="text-slate-800">{formData.fatherName || 'Not specified'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Contact Phone:</span>
                    <strong className="text-slate-800">{formData.phone || 'Not specified'}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Van Transport Required:</span>
                    <strong className="text-blue-900">{formData.needTransport}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Address:</span>
                    <strong className="text-slate-800">{formData.address}</strong>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3">
                <input
                  type="checkbox"
                  id="declaration"
                  checked={formData.declared}
                  onChange={(e) => setFormData({ ...formData, declared: e.target.checked })}
                  className="mt-1 w-4 h-4 text-blue-900 rounded border-slate-300 focus:ring-blue-800"
                />
                <label htmlFor="declaration" className="text-xs font-semibold text-slate-800 leading-relaxed cursor-pointer">
                  I hereby declare that all information provided in this admission form is true and accurate to the best of my knowledge. I agree to abide by the rules and discipline of Wisdom Nursery & Primary School, Essur.
                </label>
              </div>
            </div>
          )}

          {/* STEP NAVIGATION BUTTONS */}
          <div className="flex justify-between items-center pt-4 border-t border-slate-100">
            {currentStep > 1 ? (
              <button
                type="button"
                onClick={handlePrev}
                className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 transition"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Previous Step</span>
              </button>
            ) : <div></div>}

            {currentStep < 4 ? (
              <button
                type="button"
                onClick={handleNext}
                className="bg-blue-950 hover:bg-blue-900 text-white font-extrabold px-5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow transition"
              >
                <span>Continue to Step {currentStep + 1}</span>
                <ArrowRight className="w-4 h-4 text-amber-400" />
              </button>
            ) : (
              <button
                type="submit"
                disabled={submitting}
                className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-6 py-3 rounded-xl text-xs sm:text-sm shadow-md transition flex items-center gap-2"
              >
                <GraduationCap className="w-5 h-5 text-amber-300" />
                <span>{submitting ? 'Submitting Application...' : 'Submit Final Admission Registration'}</span>
              </button>
            )}
          </div>
        </form>
      ) : (
        /* Acknowledgement Card */
        <div className="bg-white border-2 border-amber-400 rounded-3xl p-6 sm:p-10 shadow-2xl space-y-6 animate-fadeIn">
          <div className="text-center space-y-2 border-b border-slate-200 pb-6">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto text-2xl font-black">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl sm:text-2xl font-black text-blue-950">
              Admission Registration Successful!
            </h3>
            <p className="text-xs text-slate-600">
              Your application has been registered with Wisdom Nursery and Primary School, Essur.
            </p>
          </div>

          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-3 text-xs">
            <div className="flex justify-between items-center border-b border-slate-200 pb-2">
              <span className="text-slate-500 font-bold">Application Reference ID:</span>
              <span className="font-mono font-black text-blue-900 text-base">{submittedApplication.id}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500 font-bold">Child Name:</span>
              <span className="font-extrabold text-slate-900">{submittedApplication.studentName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500 font-bold">Grade Applied:</span>
              <span className="font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded">{submittedApplication.grade}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500 font-bold">Father's Name:</span>
              <span className="font-semibold text-slate-800">{submittedApplication.fatherName}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-500 font-bold">Contact Phone:</span>
              <span className="font-semibold text-slate-800">{submittedApplication.phone}</span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-slate-200">
              <span className="text-slate-500 font-bold">Status:</span>
              <span className="bg-blue-100 text-blue-900 font-black px-3 py-0.5 rounded-full">
                {submittedApplication.status}
              </span>
            </div>
          </div>

          <div className="p-4 bg-blue-50 rounded-2xl border border-blue-200 text-xs text-blue-900 space-y-1">
            <h5 className="font-bold">Next Steps for Admission:</h5>
            <p>1. Our school office will contact you via mobile / WhatsApp to confirm document verification.</p>
            <p>2. Please bring a copy of the Child's Birth Certificate, Aadhaar Card, and Passport Photos to the school.</p>
            <p>3. School Office Address: Wisdom Nursery & Primary School, Essur - 603301. Admin: R. Saravanan (+91 9176593129).</p>
          </div>

          <div className="flex justify-between items-center pt-2">
            <button
              onClick={() => {
                setSubmittedApplication(null);
                setCurrentStep(1);
              }}
              className="text-xs text-blue-900 font-extrabold hover:underline"
            >
              ← Submit Another Registration
            </button>

            <button
              onClick={handlePrint}
              className="bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center gap-1.5 shadow"
            >
              <Printer className="w-4 h-4" />
              <span>Print Acknowledgement Slip</span>
            </button>
          </div>

          {/* Embedded Visual Timeline Card for New Application */}
          <div className="pt-6 border-t border-slate-200">
            <ApplicationStatusCard initialAppId={submittedApplication.id} />
          </div>
        </div>
      )}
      </>
      )}

      {/* DOCUMENT PREVIEW GUIDE FULL MODAL */}
      {showDocGuideModal && (
        <div className="fixed inset-0 bg-blue-950/85 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
          <div className="max-w-5xl w-full max-h-[92vh] overflow-y-auto relative">
            <button
              onClick={() => setShowDocGuideModal(false)}
              className="absolute top-4 right-4 z-10 p-2.5 bg-white/20 hover:bg-white/30 text-white rounded-full transition shadow"
              title="Close Guide"
            >
              <X className="w-5 h-5" />
            </button>

            <DocumentPreviewCarousel selectedGrade={formData.grade} />
          </div>
        </div>
      )}
    </div>
  );
};


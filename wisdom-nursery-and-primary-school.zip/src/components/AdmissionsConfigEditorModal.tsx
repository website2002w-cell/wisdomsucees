import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  X,
  Save,
  RotateCcw,
  Sparkles,
  Calendar,
  Phone,
  Mail,
  CheckCircle2,
  AlertTriangle,
  Plus,
  Trash2,
  Edit3,
  Eye,
  DollarSign,
  FileText,
  Clock,
  Layers,
  Award,
} from 'lucide-react';
import {
  AdmissionsConfig,
  GradeSeatConfig,
  getAdmissionsConfig,
  saveAdmissionsConfig,
  resetAdmissionsConfig,
} from '../utils/admissionsConfig';

interface AdmissionsConfigEditorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved?: () => void;
}

export const AdmissionsConfigEditorModal: React.FC<AdmissionsConfigEditorModalProps> = ({
  isOpen,
  onClose,
  onSaved,
}) => {
  const [config, setConfig] = useState<AdmissionsConfig>(getAdmissionsConfig());
  const [activeSubTab, setActiveSubTab] = useState<'general' | 'seats' | 'dates' | 'documents'>('general');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setConfig(getAdmissionsConfig());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = () => {
    const success = saveAdmissionsConfig(config);
    if (success) {
      setToastMessage('✅ Admissions 2026-2027 Settings successfully updated & published live!');
      if (onSaved) onSaved();
      setTimeout(() => {
        setToastMessage(null);
      }, 4000);
    } else {
      alert('Failed to save settings. Please try again.');
    }
  };

  const handleResetDefaults = () => {
    if (window.confirm('Reset all Admissions 2026-2027 settings back to default school values?')) {
      const reset = resetAdmissionsConfig();
      setConfig(reset);
      setToastMessage('🔄 Admissions settings reset to factory defaults.');
      if (onSaved) onSaved();
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  const handleGradeChange = (index: number, field: keyof GradeSeatConfig, value: any) => {
    const updatedGrades = [...config.gradeConfigs];
    updatedGrades[index] = {
      ...updatedGrades[index],
      [field]: value,
    };
    setConfig({ ...config, gradeConfigs: updatedGrades });
  };

  const handleAddGrade = () => {
    const newGrade: GradeSeatConfig = {
      grade: 'New Class Section',
      totalSeats: 30,
      availableSeats: 10,
      ageCriteria: '4+ Years as of July 2026',
      annualFeeApprox: 10000,
      status: 'OPEN',
    };
    setConfig({ ...config, gradeConfigs: [...config.gradeConfigs, newGrade] });
  };

  const handleRemoveGrade = (index: number) => {
    if (config.gradeConfigs.length <= 1) {
      alert('You must keep at least one class grade section.');
      return;
    }
    const updated = config.gradeConfigs.filter((_, i) => i !== index);
    setConfig({ ...config, gradeConfigs: updated });
  };

  const handleDocChange = (index: number, val: string) => {
    const updated = [...config.requiredDocuments];
    updated[index] = val;
    setConfig({ ...config, requiredDocuments: updated });
  };

  const handleAddDoc = () => {
    setConfig({
      ...config,
      requiredDocuments: [...config.requiredDocuments, 'New Required Document Name'],
    });
  };

  const handleRemoveDoc = (index: number) => {
    const updated = config.requiredDocuments.filter((_, i) => i !== index);
    setConfig({ ...config, requiredDocuments: updated });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl my-8 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 p-6 text-white flex items-center justify-between relative overflow-hidden shrink-0">
          <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-amber-500/10 blur-2xl pointer-events-none"></div>

          <div className="relative z-10 flex items-center gap-3">
            <div className="p-3 bg-amber-400 text-blue-950 rounded-2xl font-black shadow-md">
              <GraduationCap className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-amber-300 font-extrabold text-xs uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Admin Portal Configurator</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-white">
                Edit Admissions Open 2026 - 2027 Options
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                Customize academic year status, hero banner badges, seat matrix, fees, and dates across the website.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="relative z-10 p-2 text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 rounded-full transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Success Toast */}
        {toastMessage && (
          <div className="bg-emerald-600 text-white font-bold text-xs p-3 px-6 flex items-center justify-between shrink-0 animate-pulse">
            <span className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-200" />
              <span>{toastMessage}</span>
            </span>
            <button onClick={() => setToastMessage(null)} className="text-emerald-200 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Sub-Tab Navigation */}
        <div className="bg-slate-100 border-b border-slate-200 px-6 py-2 flex items-center gap-2 overflow-x-auto text-xs font-extrabold shrink-0">
          <button
            onClick={() => setActiveSubTab('general')}
            className={`px-4 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'general'
                ? 'bg-blue-900 text-white shadow'
                : 'hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Edit3 className="w-3.5 h-3.5 text-amber-400" />
            <span>General & Banners</span>
          </button>

          <button
            onClick={() => setActiveSubTab('seats')}
            className={`px-4 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'seats'
                ? 'bg-blue-900 text-white shadow'
                : 'hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-amber-400" />
            <span>Seat Matrix ({config.gradeConfigs.length} Classes)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('dates')}
            className={`px-4 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'dates'
                ? 'bg-blue-900 text-white shadow'
                : 'hover:bg-slate-200 text-slate-700'
            }`}
          >
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <span>Key Dates & Fees</span>
          </button>

          <button
            onClick={() => setActiveSubTab('documents')}
            className={`px-4 py-2 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
              activeSubTab === 'documents'
                ? 'bg-blue-900 text-white shadow'
                : 'hover:bg-slate-200 text-slate-700'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-amber-400" />
            <span>Document Checklist ({config.requiredDocuments.length})</span>
          </button>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800">
          {/* SUBTAB 1: GENERAL & BANNERS */}
          {activeSubTab === 'general' && (
            <div className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Academic Year Title
                  </label>
                  <input
                    type="text"
                    value={config.academicYear}
                    onChange={(e) => setConfig({ ...config, academicYear: e.target.value })}
                    className="w-full text-xs font-bold p-3 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                    placeholder="e.g. 2026 - 2027"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Overall Admission Status
                  </label>
                  <select
                    value={config.status}
                    onChange={(e) => setConfig({ ...config, status: e.target.value as any })}
                    className="w-full text-xs font-bold p-3 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                  >
                    <option value="OPEN">🟢 OPEN - Accepting Applications</option>
                    <option value="LIMITED">🟡 LIMITED - Few Seats Remaining</option>
                    <option value="WAITLIST">🟠 WAITLIST - Waitlist Mode</option>
                    <option value="CLOSED">🔴 CLOSED - Admissions Closed</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Hero Badge Tagline Text (Top Banner)
                </label>
                <input
                  type="text"
                  value={config.bannerBadgeText}
                  onChange={(e) => setConfig({ ...config, bannerBadgeText: e.target.value })}
                  className="w-full text-xs font-bold p-3 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                  placeholder="e.g. Admissions Open 2026 - 2027"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Admissions Page Headline Title
                </label>
                <input
                  type="text"
                  value={config.headlineText}
                  onChange={(e) => setConfig({ ...config, headlineText: e.target.value })}
                  className="w-full text-xs font-extrabold p-3 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50 text-blue-950"
                  placeholder="e.g. Admissions Open for Academic Year 2026 - 2027"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Subheading Description Text
                </label>
                <textarea
                  rows={2}
                  value={config.subText}
                  onChange={(e) => setConfig({ ...config, subText: e.target.value })}
                  className="w-full text-xs font-medium p-3 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                  placeholder="Details for parents regarding quality of education, teachers, etc."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Special Announcement / Ticker Notice Banner Text
                </label>
                <input
                  type="text"
                  value={config.noticeAnnouncement}
                  onChange={(e) => setConfig({ ...config, noticeAnnouncement: e.target.value })}
                  className="w-full text-xs font-bold p-3 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-amber-50 text-amber-900"
                  placeholder="e.g. ⚡ Early Bird Registrations Open for 2026-2027 batch!"
                />
              </div>

              {/* Live Banner Preview Box */}
              <div className="p-4 bg-gradient-to-r from-blue-950 to-slate-900 text-white rounded-2xl space-y-2 border border-slate-700">
                <div className="flex items-center justify-between text-[11px] font-extrabold text-amber-400">
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" />
                    <span>Live Hero Banner Preview</span>
                  </span>
                  <span className="bg-amber-400 text-blue-950 px-2 py-0.5 rounded-full font-black text-[10px]">
                    {config.status}
                  </span>
                </div>

                <div className="space-y-1">
                  <span className="bg-amber-400 text-blue-950 font-black px-3 py-1 rounded-full text-xs uppercase tracking-wider inline-block">
                    {config.bannerBadgeText}
                  </span>
                  <h4 className="text-base font-black text-white">{config.headlineText}</h4>
                  <p className="text-xs text-slate-300">{config.subText}</p>
                </div>
              </div>
            </div>
          )}

          {/* SUBTAB 2: SEAT MATRIX */}
          {activeSubTab === 'seats' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div>
                  <h3 className="text-sm font-extrabold text-blue-950">
                    Grade-wise Sanctioned Seats & Availability (2026-2027)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Configure total seats, remaining availability, age rules, and approx annual fees for each class section.
                  </p>
                </div>
                <button
                  onClick={handleAddGrade}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Class Section</span>
                </button>
              </div>

              <div className="overflow-x-auto rounded-2xl border border-slate-200">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-extrabold border-b border-slate-200">
                      <th className="p-3">Class Name</th>
                      <th className="p-3 w-24">Total Seats</th>
                      <th className="p-3 w-28">Available Seats</th>
                      <th className="p-3">Age Criteria</th>
                      <th className="p-3 w-32">Approx Fee (₹)</th>
                      <th className="p-3 w-32">Status</th>
                      <th className="p-3 text-center w-12">Remove</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                    {config.gradeConfigs.map((g, index) => (
                      <tr key={index} className="hover:bg-slate-50">
                        <td className="p-2">
                          <input
                            type="text"
                            value={g.grade}
                            onChange={(e) => handleGradeChange(index, 'grade', e.target.value)}
                            className="w-full text-xs font-extrabold p-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-800 bg-white"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={g.totalSeats}
                            onChange={(e) => handleGradeChange(index, 'totalSeats', Number(e.target.value))}
                            className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 text-center bg-white"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={g.availableSeats}
                            onChange={(e) => handleGradeChange(index, 'availableSeats', Number(e.target.value))}
                            className="w-full text-xs font-black p-2 rounded-xl border border-slate-300 text-center bg-emerald-50 text-emerald-900"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="text"
                            value={g.ageCriteria}
                            onChange={(e) => handleGradeChange(index, 'ageCriteria', e.target.value)}
                            className="w-full text-xs p-2 rounded-xl border border-slate-300 bg-white"
                          />
                        </td>
                        <td className="p-2">
                          <input
                            type="number"
                            value={g.annualFeeApprox}
                            onChange={(e) => handleGradeChange(index, 'annualFeeApprox', Number(e.target.value))}
                            className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 text-right bg-white"
                          />
                        </td>
                        <td className="p-2">
                          <select
                            value={g.status}
                            onChange={(e) => handleGradeChange(index, 'status', e.target.value)}
                            className="w-full text-xs font-bold p-2 rounded-xl border border-slate-300 bg-white"
                          >
                            <option value="OPEN">OPEN</option>
                            <option value="FEW_LEFT">FEW LEFT</option>
                            <option value="FULL">FULL</option>
                            <option value="WAITLIST">WAITLIST</option>
                          </select>
                        </td>
                        <td className="p-2 text-center">
                          <button
                            onClick={() => handleRemoveGrade(index)}
                            className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition"
                            title="Delete Class"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* SUBTAB 3: KEY DATES & FEES */}
          {activeSubTab === 'dates' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Application Form Fee (₹) [0 for Free]
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-3 text-slate-400 font-bold text-xs">₹</span>
                    <input
                      type="number"
                      value={config.applicationFee}
                      onChange={(e) => setConfig({ ...config, applicationFee: Number(e.target.value) })}
                      className="w-full pl-8 pr-3 py-2.5 text-xs font-extrabold rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                      placeholder="0"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Application Deadline Date
                  </label>
                  <input
                    type="text"
                    value={config.lastDateToApply}
                    onChange={(e) => setConfig({ ...config, lastDateToApply: e.target.value })}
                    className="w-full text-xs font-bold p-2.5 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                    placeholder="e.g. 31-Aug-2026"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Verification & Interview Schedule
                  </label>
                  <input
                    type="text"
                    value={config.interviewStartDate}
                    onChange={(e) => setConfig({ ...config, interviewStartDate: e.target.value })}
                    className="w-full text-xs font-bold p-2.5 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                    placeholder="e.g. 05-Sep-2026"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Academic Session Start / Reopening Date
                  </label>
                  <input
                    type="text"
                    value={config.schoolReopeningDate}
                    onChange={(e) => setConfig({ ...config, schoolReopeningDate: e.target.value })}
                    className="w-full text-xs font-bold p-2.5 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                    placeholder="e.g. 12-Sep-2026"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Admissions Helpdesk Phone Number
                  </label>
                  <input
                    type="text"
                    value={config.helpdeskPhone}
                    onChange={(e) => setConfig({ ...config, helpdeskPhone: e.target.value })}
                    className="w-full text-xs font-bold p-2.5 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                    placeholder="+91 9176593129"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Admissions Enquiry Email ID
                  </label>
                  <input
                    type="text"
                    value={config.helpdeskEmail}
                    onChange={(e) => setConfig({ ...config, helpdeskEmail: e.target.value })}
                    className="w-full text-xs font-bold p-2.5 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                    placeholder="wisdomrs.tamil@gmail.com"
                  />
                </div>
              </div>
            </div>
          )}

          {/* SUBTAB 4: DOCUMENTS CHECKLIST */}
          {activeSubTab === 'documents' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <div>
                  <h3 className="text-sm font-extrabold text-blue-950">
                    Required Documents Checklist for Admission
                  </h3>
                  <p className="text-xs text-slate-500">
                    Define the list of documents parents must upload or submit during 2026-2027 registration.
                  </p>
                </div>
                <button
                  onClick={handleAddDoc}
                  className="bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold px-3 py-1.5 rounded-xl transition flex items-center gap-1 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Document Item</span>
                </button>
              </div>

              <div className="space-y-2">
                {config.requiredDocuments.map((doc, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="w-6 text-xs font-mono font-bold text-slate-400 text-right">
                      {idx + 1}.
                    </span>
                    <input
                      type="text"
                      value={doc}
                      onChange={(e) => handleDocChange(idx, e.target.value)}
                      className="flex-1 text-xs font-bold p-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50"
                    />
                    <button
                      onClick={() => handleRemoveDoc(idx)}
                      className="p-2 text-slate-400 hover:text-red-600 rounded-xl hover:bg-red-50 transition"
                      title="Delete Item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="bg-slate-100 border-t border-slate-200 p-4 px-6 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <button
            onClick={handleResetDefaults}
            className="text-xs font-bold text-slate-600 hover:text-red-700 flex items-center gap-1.5 px-3 py-2 rounded-xl hover:bg-slate-200 transition"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset Factory Defaults</span>
          </button>

          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              onClick={onClose}
              className="flex-1 sm:flex-none text-xs font-bold px-5 py-2.5 rounded-xl border border-slate-300 hover:bg-slate-200 text-slate-700 transition"
            >
              Cancel
            </button>

            <button
              onClick={handleSave}
              className="flex-1 sm:flex-none bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white text-xs font-extrabold px-6 py-2.5 rounded-xl shadow-md transition flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>Save & Publish Live</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

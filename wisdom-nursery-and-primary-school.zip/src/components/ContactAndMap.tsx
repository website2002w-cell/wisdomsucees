import React, { useState } from 'react';
import {
  PhoneCall,
  Mail,
  MapPin,
  UserCheck,
  Clock,
  Send,
  CheckCircle2,
  Share2,
} from 'lucide-react';
import { SCHOOL_INFO } from '../data/schoolData';

export const ContactAndMap: React.FC = () => {
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryPhone, setInquiryPhone] = useState('');
  const [inquiryMsg, setInquiryMsg] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName || !inquiryPhone) {
      alert('Please enter your Name and Mobile Number.');
      return;
    }
    setSubmitted(true);
  };

  return (
    <div id="contact" className="max-w-7xl mx-auto px-4 py-8 space-y-10">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <span className="bg-blue-100 text-blue-900 text-xs font-black uppercase px-3.5 py-1.5 rounded-full border border-blue-200 inline-flex items-center gap-1.5">
          <PhoneCall className="w-3.5 h-3.5 text-blue-800" />
          Get In Touch
        </span>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-blue-950">
          Contact Wisdom School Administration
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm">
          We welcome parents and visitors to visit our school premises in Essur or call us for admission & fee details.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Contact Info Cards */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
            <h3 className="text-lg font-extrabold text-blue-950 border-b border-slate-100 pb-3">
              School Contact Details
            </h3>

            <div className="space-y-4 text-xs">
              <div className="flex items-start space-x-3.5">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-900 font-bold shrink-0">
                  <UserCheck className="w-5 h-5 text-blue-900" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">School Administrator</h4>
                  <p className="text-slate-600 font-bold mt-0.5">{SCHOOL_INFO.adminName}</p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-900 font-bold shrink-0">
                  <MapPin className="w-5 h-5 text-blue-900" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">School Location Address</h4>
                  <p className="text-slate-600 font-semibold mt-0.5 leading-relaxed">
                    Wisdom Nursery and Primary School,<br />
                    Essur - 603301, Tamil Nadu, India.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-900 font-bold shrink-0">
                  <PhoneCall className="w-5 h-5 text-blue-900" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">Phone / Mobile / WhatsApp</h4>
                  <p className="mt-0.5">
                    <a
                      href={`tel:9176593129`}
                      className="font-extrabold text-blue-900 hover:underline text-sm"
                    >
                      {SCHOOL_INFO.phone}
                    </a>
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5">
                <div className="p-2.5 rounded-xl bg-blue-50 text-blue-900 font-bold shrink-0">
                  <Mail className="w-5 h-5 text-blue-900" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">Official Email Address</h4>
                  <p className="mt-0.5">
                    <a
                      href={`mailto:${SCHOOL_INFO.email}`}
                      className="font-bold text-blue-900 hover:underline"
                    >
                      {SCHOOL_INFO.email}
                    </a>
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3.5 pt-2 border-t border-slate-100">
                <div className="p-2.5 rounded-xl bg-amber-50 text-amber-800 font-bold shrink-0">
                  <Clock className="w-5 h-5 text-amber-700" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm">School Timings</h4>
                  <p className="text-slate-600 text-[11px] font-semibold mt-0.5">
                    {SCHOOL_INFO.workingHours}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick WhatsApp Link Button */}
            <a
              href={`https://wa.me/919176593129?text=${encodeURIComponent('Hello Admin R. Saravanan, I would like to inquire about Wisdom School Essur admissions and details.')}`}
              target="_blank"
              rel="noreferrer"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3.5 rounded-xl text-xs shadow transition flex items-center justify-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              <span>Chat directly on WhatsApp (+91 9176593129)</span>
            </a>
          </div>
        </div>

        {/* Right Google Map & Quick Form */}
        <div className="lg:col-span-7 space-y-6">
          {/* Map Frame */}
          <div className="bg-white p-2.5 rounded-3xl border border-slate-200 shadow-sm space-y-2">
            <div className="h-80 overflow-hidden rounded-2xl relative">
              <iframe
                title="Wisdom Nursery and Primary School Essur Map"
                width="100%"
                height="100%"
                style={{ border: 0, borderRadius: '1rem' }}
                loading="lazy"
                allowFullScreen
                referrerPolicy="strict-origin-when-cross-origin"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3898.180805162009!2d79.8615042!3d12.303607800000002!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a53138de836231f%3A0xffcfb08b54f87691!2sWisdom%20nursery%20and%20primary%20school!5e0!3m2!1sen!2sin!4v1785155250441!5m2!1sen!2sin"
              ></iframe>
            </div>

            <div className="flex items-center justify-between px-2 text-xs">
              <span className="text-slate-600 font-semibold flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-red-600" />
                Wisdom Nursery and Primary School, Essur Campus
              </span>
              <a
                href="https://maps.google.com/?q=Wisdom+nursery+and+primary+school+Essur"
                target="_blank"
                rel="noreferrer"
                className="font-bold text-blue-900 hover:underline flex items-center gap-1 text-[11px]"
              >
                <span>Open in Google Maps App ↗</span>
              </a>
            </div>
          </div>

          {/* Quick Message Form */}
          <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm space-y-4">
            <h4 className="text-base font-bold text-slate-900">Send an Online Inquiry Message</h4>

            {!submitted ? (
              <form onSubmit={handleInquirySubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Your Name</label>
                    <input
                      type="text"
                      value={inquiryName}
                      onChange={(e) => setInquiryName(e.target.value)}
                      placeholder="e.g. Ramesh"
                      className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">Mobile Number</label>
                    <input
                      type="tel"
                      value={inquiryPhone}
                      onChange={(e) => setInquiryPhone(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Inquiry / Question</label>
                  <textarea
                    rows={3}
                    value={inquiryMsg}
                    onChange={(e) => setInquiryMsg(e.target.value)}
                    placeholder="Ask about LKG admissions, fees, transport, syllabus..."
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="bg-blue-900 hover:bg-blue-800 text-white font-bold py-3 rounded-xl px-6 text-xs transition shadow flex items-center gap-2"
                >
                  <Send className="w-4 h-4 text-amber-400" />
                  <span>Send Message to School Office</span>
                </button>
              </form>
            ) : (
              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span>Thank you! Your message has been sent to Admin R. Saravanan. We will contact you shortly.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

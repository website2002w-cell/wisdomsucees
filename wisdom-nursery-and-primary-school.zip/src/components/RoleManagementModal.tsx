import React, { useState } from 'react';
import {
  ShieldCheck,
  UserPlus,
  Lock,
  Plus,
  CheckCircle2,
  Users,
  KeyRound,
  Sparkles,
  X,
  User,
  Shield,
  Layers,
  Check,
  Building,
  LogOut,
  Mail,
  Smartphone,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { PermissionKey, UserRoleDefinition } from '../types';

interface RoleManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ALL_PERMISSIONS: { key: PermissionKey; label: string; group: string }[] = [
  { key: 'view_home', label: 'View Public Homepage', group: 'General' },
  { key: 'pay_fees', label: 'Online Fee Payment (GPay/UPI)', group: 'Financial' },
  { key: 'manage_fees', label: 'Manage Fee Receipts & Ledgers', group: 'Financial' },
  { key: 'view_student_portal', label: 'View Student Report & Portal', group: 'Academic' },
  { key: 'manage_students', label: 'Manage Student Profiles & Marks', group: 'Academic' },
  { key: 'view_erp', label: 'Access ERP Modules', group: 'Admin' },
  { key: 'manage_erp', label: 'Configure ERP Settings & Records', group: 'Admin' },
  { key: 'track_bus', label: 'Live Van GPS & Bus Route Tracking', group: 'Operations' },
  { key: 'parent_connect', label: 'Parent-Teacher Communication & SMS', group: 'Communication' },
  { key: 'library_access', label: 'Library Catalog & Book Reservations', group: 'Academic' },
  { key: 'admin_portal', label: 'Full Admin Portal Control', group: 'Admin' },
  { key: 'future_lab', label: 'FutureLab STEM & AI Sandbox', group: 'Academic' },
  { key: 'zoom_classes', label: 'Zoom Online Class Hosting & Joining', group: 'Academic' },
  { key: 'digital_hall_pass', label: 'Digital Hall Pass Approvals', group: 'Operations' },
  { key: 'school_store', label: 'School Uniform & Book Store', group: 'Operations' },
  { key: 'lost_found', label: 'Lost & Found Item Reporting', group: 'General' },
  { key: 'create_roles', label: 'Role Creation & Access Management', group: 'Admin' },
];

const COLOR_OPTIONS = [
  { label: 'Purple Admin', value: 'bg-purple-600 text-purple-100 border-purple-400' },
  { label: 'Blue Educator', value: 'bg-blue-600 text-blue-100 border-blue-400' },
  { label: 'Emerald Parent', value: 'bg-emerald-600 text-emerald-100 border-emerald-400' },
  { label: 'Amber Student', value: 'bg-amber-600 text-amber-100 border-amber-400' },
  { label: 'Orange Transport', value: 'bg-orange-600 text-orange-100 border-orange-400' },
  { label: 'Indigo Officer', value: 'bg-indigo-600 text-indigo-100 border-indigo-400' },
  { label: 'Rose Coach', value: 'bg-rose-600 text-rose-100 border-rose-400' },
  { label: 'Teal Staff', value: 'bg-teal-600 text-teal-100 border-teal-400' },
];

export const RoleManagementModal: React.FC<RoleManagementModalProps> = ({ isOpen, onClose }) => {
  const { currentUser, roles, users, login, logout, createCustomRole, registerUser, switchUserRole } = useAuth();
  const [activeTab, setActiveTab] = useState<'login' | 'create_role' | 'create_user' | 'view_roles'>('login');

  // Quick Login state
  const [loginUsername, setLoginUsername] = useState('');
  const [selectedRoleId, setSelectedRoleId] = useState(roles[0]?.id || 'role-admin');
  const [loginMessage, setLoginMessage] = useState('');

  // Role Creation state
  const [roleName, setRoleName] = useState('');
  const [roleCode, setRoleCode] = useState('');
  const [roleDescription, setRoleDescription] = useState('');
  const [selectedColor, setSelectedColor] = useState(COLOR_OPTIONS[5].value);
  const [selectedPermissions, setSelectedPermissions] = useState<PermissionKey[]>([
    'view_home',
    'view_student_portal',
  ]);
  const [roleCreatedSuccess, setRoleCreatedSuccess] = useState(false);

  // Register User state
  const [newUserName, setNewUserName] = useState('');
  const [newUserUsername, setNewUserUsername] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRoleId, setNewUserRoleId] = useState(roles[0]?.id || 'role-admin');
  const [userCreatedSuccess, setUserCreatedSuccess] = useState(false);

  if (!isOpen) return null;

  const togglePermission = (permKey: PermissionKey) => {
    setSelectedPermissions((prev) =>
      prev.includes(permKey) ? prev.filter((p) => p !== permKey) : [...prev, permKey]
    );
  };

  const handleCreateRoleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!roleName || !roleCode) {
      alert('Please enter Role Name and Role Code');
      return;
    }

    const created = createCustomRole({
      name: roleName,
      code: roleCode.toUpperCase().trim(),
      description: roleDescription || 'Custom school role with tailored security privileges.',
      color: selectedColor,
      permissions: selectedPermissions,
    });

    setRoleCreatedSuccess(true);
    setTimeout(() => {
      setRoleCreatedSuccess(false);
      setRoleName('');
      setRoleCode('');
      setRoleDescription('');
      setActiveTab('view_roles');
    }, 1500);
  };

  const handleCreateUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName || !newUserUsername) {
      alert('Please enter Name and Username');
      return;
    }

    const assignedRoleDef = roles.find((r) => r.id === newUserRoleId);

    registerUser({
      username: newUserUsername.trim(),
      name: newUserName.trim(),
      email: newUserEmail.trim() || `${newUserUsername.trim().toLowerCase()}@wisdomschool.edu.in`,
      roleId: newUserRoleId,
      roleName: assignedRoleDef?.name || 'School Role',
    });

    setUserCreatedSuccess(true);
    setTimeout(() => {
      setUserCreatedSuccess(false);
      setNewUserName('');
      setNewUserUsername('');
      setNewUserEmail('');
      setActiveTab('view_roles');
    }, 1500);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginUsername) {
      alert('Please enter username or select a quick demo user');
      return;
    }
    const success = login(loginUsername, selectedRoleId);
    if (success) {
      setLoginMessage('✓ Authenticated successfully!');
      setTimeout(() => {
        setLoginMessage('');
        onClose();
      }, 1000);
    } else {
      setLoginMessage('User not found. Try one of the quick demo accounts below or register a user!');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 text-white border-2 border-amber-400/80 rounded-3xl max-w-3xl w-full shadow-2xl relative overflow-hidden my-auto">
        {/* Modal Header Bar */}
        <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-amber-400/20 text-amber-300 rounded-2xl border border-amber-400/30">
              <ShieldCheck className="w-6 h-6 text-amber-400" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <span>School Access & Role Creator</span>
                <span className="bg-amber-400 text-blue-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  RBAC Security
                </span>
              </h2>
              <p className="text-xs text-slate-300">
                Login, switch active role, or define custom permission roles for school staff & parents.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Tabs Header */}
        <div className="flex border-b border-slate-800 bg-slate-950/60 px-4 pt-3 overflow-x-auto">
          <button
            onClick={() => setActiveTab('login')}
            className={`px-4 py-2.5 text-xs font-black rounded-t-xl transition flex items-center gap-1.5 shrink-0 border-b-2 ${
              activeTab === 'login'
                ? 'bg-slate-900 text-amber-400 border-amber-400'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <KeyRound className="w-4 h-4" />
            <span>Login & Switch Role</span>
          </button>

          <button
            onClick={() => setActiveTab('create_role')}
            className={`px-4 py-2.5 text-xs font-black rounded-t-xl transition flex items-center gap-1.5 shrink-0 border-b-2 ${
              activeTab === 'create_role'
                ? 'bg-slate-900 text-amber-400 border-amber-400'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Plus className="w-4 h-4 text-emerald-400" />
            <span>Create Custom Role</span>
          </button>

          <button
            onClick={() => setActiveTab('create_user')}
            className={`px-4 py-2.5 text-xs font-black rounded-t-xl transition flex items-center gap-1.5 shrink-0 border-b-2 ${
              activeTab === 'create_user'
                ? 'bg-slate-900 text-amber-400 border-amber-400'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <UserPlus className="w-4 h-4 text-indigo-400" />
            <span>Register User Account</span>
          </button>

          <button
            onClick={() => setActiveTab('view_roles')}
            className={`px-4 py-2.5 text-xs font-black rounded-t-xl transition flex items-center gap-1.5 shrink-0 border-b-2 ${
              activeTab === 'view_roles'
                ? 'bg-slate-900 text-amber-400 border-amber-400'
                : 'text-slate-400 hover:text-slate-200 border-transparent'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>Active Roles & Users ({roles.length})</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-h-[75vh] overflow-y-auto space-y-6">
          {/* TAB 1: LOGIN & SWITCH ROLE */}
          {activeTab === 'login' && (
            <div className="space-y-6">
              {/* Current Active Account Card */}
              {currentUser ? (
                <div className="bg-slate-800 p-4 rounded-2xl border border-amber-500/50 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-11 h-11 rounded-full bg-amber-400 text-blue-950 font-black text-base flex items-center justify-center border-2 border-white shadow">
                      {currentUser.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-white text-sm">{currentUser.name}</span>
                        <span className="bg-amber-400/20 text-amber-300 text-[10px] font-black px-2 py-0.5 rounded-full border border-amber-400/40">
                          {currentUser.roleName}
                        </span>
                      </div>
                      <p className="text-xs text-slate-300 font-mono">@{currentUser.username} • {currentUser.email}</p>
                    </div>
                  </div>

                  <button
                    onClick={logout}
                    className="px-3.5 py-1.5 bg-red-950 hover:bg-red-900 text-red-200 text-xs font-bold rounded-xl border border-red-700 transition flex items-center gap-1"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              ) : (
                <div className="p-3 bg-amber-500/10 border border-amber-500/30 text-amber-300 rounded-xl text-xs flex items-center gap-2">
                  <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>No user logged in currently. Select a demo account below or enter credentials.</span>
                </div>
              )}

              {/* One-Tap Role Switcher Grid */}
              <div className="space-y-3">
                <h3 className="text-xs font-black uppercase text-amber-300 tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <span>One-Tap Role Demo Switcher</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                  {users.map((u) => {
                    const roleDef = roles.find((r) => r.id === u.roleId);
                    const isSelected = currentUser?.id === u.id;
                    return (
                      <button
                        key={u.id}
                        onClick={() => login(u.username)}
                        className={`p-3 rounded-2xl border text-left transition relative flex flex-col justify-between ${
                          isSelected
                            ? 'bg-blue-950 border-amber-400 ring-2 ring-amber-400/40 shadow-lg'
                            : 'bg-slate-800/80 border-slate-700 hover:border-slate-500 hover:bg-slate-800'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-full ${roleDef?.color || 'bg-slate-700 text-white'}`}>
                            {u.roleName}
                          </span>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                        </div>
                        <div className="mt-2">
                          <h4 className="font-extrabold text-white text-xs truncate">{u.name}</h4>
                          <span className="text-[11px] text-slate-400 font-mono">@{u.username}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Login Form */}
              <form onSubmit={handleLoginSubmit} className="bg-slate-800/60 p-5 rounded-2xl border border-slate-700 space-y-4">
                <h4 className="font-extrabold text-white text-xs uppercase tracking-wider text-slate-300">
                  Custom User Credentials Login
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-slate-300">Username or Email</label>
                    <input
                      type="text"
                      value={loginUsername}
                      onChange={(e) => setLoginUsername(e.target.value)}
                      placeholder="e.g. WISDOM or teacher_anita"
                      className="w-full text-xs font-mono font-bold px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="block text-xs font-bold text-slate-300">Target Role</label>
                    <select
                      value={selectedRoleId}
                      onChange={(e) => setSelectedRoleId(e.target.value)}
                      className="w-full text-xs font-bold px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-amber-400"
                    >
                      {roles.map((r) => (
                        <option key={r.id} value={r.id}>
                          {r.name} ({r.code})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {loginMessage && (
                  <p className="text-xs font-bold text-amber-300 bg-amber-400/10 p-2.5 rounded-xl border border-amber-400/20">
                    {loginMessage}
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-2"
                >
                  <KeyRound className="w-4 h-4 text-blue-950" />
                  <span>Authenticate & Log In</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 2: CREATE CUSTOM ROLE */}
          {activeTab === 'create_role' && (
            <form onSubmit={handleCreateRoleSubmit} className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <Plus className="w-4 h-4 text-emerald-400" />
                    <span>Define New Custom Role & Permissions</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Create custom role types (e.g. Accountant, Librarian, PE Coach) with exact permission privileges.
                  </p>
                </div>
              </div>

              {roleCreatedSuccess && (
                <div className="p-3 bg-emerald-500/20 border border-emerald-400 text-emerald-300 rounded-2xl text-xs font-bold flex items-center gap-2 animate-bounce">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>Role successfully created! Redirecting to role overview...</span>
                </div>
              )}

              {/* Role Title & Code */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-amber-300">
                    Role Title / Name *
                  </label>
                  <input
                    type="text"
                    value={roleName}
                    onChange={(e) => setRoleName(e.target.value)}
                    placeholder="e.g. Chief Accountant & Fees Officer"
                    className="w-full text-xs font-bold px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-amber-300">
                    Role Code * (3-6 uppercase letters)
                  </label>
                  <input
                    type="text"
                    value={roleCode}
                    onChange={(e) => setRoleCode(e.target.value)}
                    placeholder="e.g. ACCT or LIBR"
                    maxLength={8}
                    className="w-full text-xs font-mono font-bold px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-amber-300 uppercase focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>
              </div>

              {/* Description & Color Tag */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2 space-y-1">
                  <label className="block text-xs font-extrabold text-slate-300">Role Description</label>
                  <input
                    type="text"
                    value={roleDescription}
                    onChange={(e) => setRoleDescription(e.target.value)}
                    placeholder="Briefly describe duties and access level..."
                    className="w-full text-xs px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-slate-300">Role Badge Color</label>
                  <select
                    value={selectedColor}
                    onChange={(e) => setSelectedColor(e.target.value)}
                    className="w-full text-xs font-bold px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none"
                  >
                    {COLOR_OPTIONS.map((c) => (
                      <option key={c.label} value={c.value}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Permission Checkboxes Selection Grid */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="block text-xs font-black uppercase text-amber-300 tracking-wider">
                    Select Privileges & Module Permissions ({selectedPermissions.length} Enabled)
                  </label>
                  <button
                    type="button"
                    onClick={() =>
                      setSelectedPermissions(
                        selectedPermissions.length === ALL_PERMISSIONS.length
                          ? []
                          : ALL_PERMISSIONS.map((p) => p.key)
                      )
                    }
                    className="text-[11px] text-amber-400 hover:text-amber-300 font-bold underline"
                  >
                    {selectedPermissions.length === ALL_PERMISSIONS.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-56 overflow-y-auto p-3 bg-slate-950 rounded-2xl border border-slate-800">
                  {ALL_PERMISSIONS.map((perm) => {
                    const isChecked = selectedPermissions.includes(perm.key);
                    return (
                      <label
                        key={perm.key}
                        className={`flex items-center space-x-2.5 p-2 rounded-xl text-xs cursor-pointer transition border ${
                          isChecked
                            ? 'bg-blue-950/80 border-amber-400/60 text-amber-300'
                            : 'bg-slate-900/50 border-slate-800 text-slate-300 hover:bg-slate-900'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => togglePermission(perm.key)}
                          className="rounded text-amber-400 focus:ring-0 w-4 h-4 bg-slate-800 border-slate-700"
                        />
                        <div>
                          <span className="font-extrabold block text-xs">{perm.label}</span>
                          <span className="text-[9px] text-slate-400 uppercase font-semibold">{perm.group}</span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-blue-950 font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2 transform active:scale-98"
              >
                <Plus className="w-5 h-5 text-blue-950" />
                <span>Save & Deploy Custom Role</span>
              </button>
            </form>
          )}

          {/* TAB 3: REGISTER USER ACCOUNT */}
          {activeTab === 'create_user' && (
            <form onSubmit={handleCreateUserSubmit} className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <UserPlus className="w-4 h-4 text-indigo-400" />
                    <span>Register New Staff or Parent Account</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Create credentials and assign them to any standard or custom-created role.
                  </p>
                </div>
              </div>

              {userCreatedSuccess && (
                <div className="p-3 bg-emerald-500/20 border border-emerald-400 text-emerald-300 rounded-2xl text-xs font-bold flex items-center gap-2 animate-bounce">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>User account registered successfully! Redirecting...</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-amber-300">Full Person Name *</label>
                  <input
                    type="text"
                    value={newUserName}
                    onChange={(e) => setNewUserName(e.target.value)}
                    placeholder="e.g. Mr. S. Kannan (Accountant)"
                    className="w-full text-xs font-bold px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-amber-300">Login Username *</label>
                  <input
                    type="text"
                    value={newUserUsername}
                    onChange={(e) => setNewUserUsername(e.target.value)}
                    placeholder="e.g. acct_kannan"
                    className="w-full text-xs font-mono font-bold px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-amber-300 focus:outline-none focus:border-amber-400"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-slate-300">Email Address</label>
                  <input
                    type="email"
                    value={newUserEmail}
                    onChange={(e) => setNewUserEmail(e.target.value)}
                    placeholder="kannan@wisdomschool.edu.in"
                    className="w-full text-xs px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-xs font-extrabold text-amber-300">Assigned Security Role *</label>
                  <select
                    value={newUserRoleId}
                    onChange={(e) => setNewUserRoleId(e.target.value)}
                    className="w-full text-xs font-bold px-3 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-amber-400"
                  >
                    {roles.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name} ({r.code}) {r.isCustom ? '• CUSTOM' : ''}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-400 hover:to-blue-500 text-white font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2"
              >
                <UserPlus className="w-5 h-5 text-amber-300" />
                <span>Create User Account</span>
              </button>
            </form>
          )}

          {/* TAB 4: VIEW ROLES & USER DIRECTORY */}
          {activeTab === 'view_roles' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="text-sm font-black text-white flex items-center gap-2">
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span>Configured System Roles & Permissions</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    System roles ({roles.length}) & registered accounts ({users.length}).
                  </p>
                </div>

                <button
                  onClick={() => setActiveTab('create_role')}
                  className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition flex items-center gap-1"
                >
                  <Plus className="w-4 h-4" />
                  <span>New Custom Role</span>
                </button>
              </div>

              <div className="space-y-4">
                {roles.map((role) => {
                  const assignedUsers = users.filter((u) => u.roleId === role.id);
                  return (
                    <div
                      key={role.id}
                      className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center space-x-2">
                          <span className={`text-xs font-black px-2.5 py-1 rounded-lg border ${role.color}`}>
                            {role.code}
                          </span>
                          <h4 className="font-extrabold text-white text-sm">{role.name}</h4>
                          {role.isCustom && (
                            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[9px] font-black px-2 py-0.5 rounded-full uppercase">
                              Custom Role
                            </span>
                          )}
                        </div>

                        <button
                          onClick={() => switchUserRole(role.id)}
                          className="px-3 py-1 bg-slate-700 hover:bg-slate-600 text-amber-300 font-bold text-xs rounded-lg transition"
                        >
                          Switch To Role
                        </button>
                      </div>

                      <p className="text-xs text-slate-300">{role.description}</p>

                      {/* Permissions List Badges */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                          Privileges Granted ({role.permissions.length}):
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {role.permissions.map((p) => {
                            const match = ALL_PERMISSIONS.find((ap) => ap.key === p);
                            return (
                              <span
                                key={p}
                                className="bg-slate-900 text-amber-300 text-[10px] font-mono px-2 py-0.5 rounded border border-slate-700"
                              >
                                ✓ {match ? match.label : p}
                              </span>
                            );
                          })}
                        </div>
                      </div>

                      {/* Assigned Users list */}
                      <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between text-xs text-slate-400">
                        <span>
                          Assigned Users ({assignedUsers.length}):{' '}
                          <strong className="text-white">
                            {assignedUsers.map((u) => u.name).join(', ') || 'None assigned yet'}
                          </strong>
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

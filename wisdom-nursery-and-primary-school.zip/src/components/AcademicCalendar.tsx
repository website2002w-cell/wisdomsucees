import React, { useState, useEffect } from 'react';
import {
  Calendar as CalendarIcon,
  Search,
  Filter,
  GraduationCap,
  Sparkles,
  PartyPopper,
  Clock,
  CheckCircle2,
  AlertCircle,
  Download,
  Printer,
  ChevronRight,
  BookOpen,
  Info,
  CalendarDays,
  Flame,
  WifiOff,
  Database,
} from 'lucide-react';
import { ACADEMIC_EVENTS_DATA, SCHOOL_INFO } from '../data/schoolData';
import { AcademicEvent } from '../types';
import { getCachedData, setCachedData, STORAGE_KEYS } from '../utils/offlineStorage';
import { useOffline } from '../context/OfflineContext';

export const AcademicCalendar: React.FC = () => {
  const { isOnline } = useOffline();
  const [events, setEvents] = useState<AcademicEvent[]>(() => {
    return getCachedData<AcademicEvent[]>(STORAGE_KEYS.CALENDAR, ACADEMIC_EVENTS_DATA);
  });

  useEffect(() => {
    if (events.length > 0) {
      setCachedData(STORAGE_KEYS.CALENDAR, events);
    }
  }, [events]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedMonth, setSelectedMonth] = useState<string>('All');
  const [selectedTerm, setSelectedTerm] = useState<string>('All');
  const [selectedEvent, setSelectedEvent] = useState<AcademicEvent | null>(null);

  const monthsList = [
    'All',
    'June 2026',
    'July 2026',
    'August 2026',
    'September 2026',
    'October 2026',
    'November 2026',
    'December 2026',
    'January 2027',
    'February 2027',
    'March 2027',
    'April 2027',
  ];

  // Category Colors & Badges
  const getCategoryBadge = (category: AcademicEvent['category']) => {
    switch (category) {
      case 'Exam':
        return {
          bg: 'bg-red-100 text-red-800 border-red-200',
          dot: 'bg-red-500',
          icon: GraduationCap,
          label: 'Examination / Test',
        };
      case 'Holiday':
        return {
          bg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
          dot: 'bg-emerald-500',
          icon: PartyPopper,
          label: 'School Holiday',
        };
      case 'Event':
        return {
          bg: 'bg-purple-100 text-purple-900 border-purple-200',
          dot: 'bg-purple-500',
          icon: Sparkles,
          label: 'Cultural / Sports Event',
        };
      case 'TermDate':
        return {
          bg: 'bg-blue-100 text-blue-900 border-blue-200',
          dot: 'bg-blue-600',
          icon: BookOpen,
          label: 'Term Key Date',
        };
      default:
        return {
          bg: 'bg-slate-100 text-slate-800 border-slate-200',
          dot: 'bg-slate-500',
          icon: Info,
          label: 'General Date',
        };
    }
  };

  // Filter Logic
  const filteredEvents = events.filter((evt) => {
    // Category match
    if (selectedCategory !== 'All') {
      if (selectedCategory === 'Exams' && evt.category !== 'Exam') return false;
      if (selectedCategory === 'Holidays' && evt.category !== 'Holiday') return false;
      if (selectedCategory === 'Events' && evt.category !== 'Event') return false;
      if (selectedCategory === 'Term Dates' && evt.category !== 'TermDate') return false;
    }

    // Month match
    if (selectedMonth !== 'All' && evt.month !== selectedMonth) {
      return false;
    }

    // Term match
    if (selectedTerm === 'Term 1') {
      if (!['June 2026', 'July 2026', 'August 2026', 'September 2026'].includes(evt.month)) {
        return false;
      }
    } else if (selectedTerm === 'Term 2') {
      if (!['October 2026', 'November 2026', 'December 2026'].includes(evt.month)) {
        return false;
      }
    } else if (selectedTerm === 'Term 3') {
      if (!['January 2027', 'February 2027', 'March 2027', 'April 2027'].includes(evt.month)) {
        return false;
      }
    }

    // Search query match
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = evt.title.toLowerCase().includes(q);
      const matchDesc = evt.description.toLowerCase().includes(q);
      const matchMonth = evt.month.toLowerCase().includes(q);
      const matchCat = evt.category.toLowerCase().includes(q);
      return matchTitle || matchDesc || matchMonth || matchCat;
    }

    return true;
  });

  // Date Formatter helper
  const formatDateDisplay = (startDateStr: string, endDateStr?: string) => {
    const sDate = new Date(startDateStr);
    const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short', year: 'numeric' };
    const formattedStart = sDate.toLocaleDateString('en-IN', options);

    if (endDateStr) {
      const eDate = new Date(endDateStr);
      const formattedEnd = eDate.toLocaleDateString('en-IN', options);
      return `${formattedStart} - ${formattedEnd}`;
    }
    return formattedStart;
  };

  const getDayOfWeek = (dateStr: string) => {
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', { weekday: 'short' });
  };

  const totalExamsCount = events.filter((e) => e.category === 'Exam').length;
  const totalHolidaysCount = events.filter((e) => e.category === 'Holiday').length;
  const totalEventsCount = events.filter((e) => e.category === 'Event').length;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8 animate-fadeIn">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl border border-blue-800 relative overflow-hidden">
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 opacity-10 pointer-events-none">
          <CalendarIcon className="w-80 h-80 text-white" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="bg-amber-400 text-blue-950 text-xs font-black uppercase px-3.5 py-1.5 rounded-full border border-amber-300 inline-flex items-center gap-1.5 shadow-sm">
                <Sparkles className="w-3.5 h-3.5 text-blue-900" />
                Academic Session 2026 - 2027
              </span>

              {!isOnline && (
                <span className="bg-amber-900/80 text-amber-200 text-xs font-extrabold px-3 py-1.5 rounded-full border border-amber-500/50 inline-flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-amber-300" />
                  Offline Cached Calendar
                </span>
              )}
            </div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-white">
              Wisdom Academic Calendar & Schedule
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              Official school year schedule for {SCHOOL_INFO.name}, Essur. Track term dates, unit tests, quarterly & annual exams, holidays, and cultural events.
            </p>
          </div>

          <div className="flex flex-wrap gap-2 shrink-0 print:hidden">
            <button
              onClick={() => window.print()}
              className="bg-amber-400 hover:bg-amber-300 text-blue-950 font-extrabold px-4 py-3 rounded-xl text-xs shadow transition flex items-center gap-2"
            >
              <Printer className="w-4 h-4 text-blue-950" />
              <span>Print Schedule</span>
            </button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 sm:p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Working Days</span>
            <BookOpen className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-black text-blue-950">220 Days</div>
          <span className="text-[10px] text-slate-500 font-medium">Academic Year 2026-27</span>
        </div>

        <div className="p-4 sm:p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Major Exams</span>
            <GraduationCap className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-black text-red-700">{totalExamsCount} Schedules</div>
          <span className="text-[10px] text-red-600 font-semibold">Unit Tests & Term Exams</span>
        </div>

        <div className="p-4 sm:p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">School Holidays</span>
            <PartyPopper className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-black text-emerald-700">{totalHolidaysCount} Dates</div>
          <span className="text-[10px] text-emerald-600 font-semibold">Festivals & Vacations</span>
        </div>

        <div className="p-4 sm:p-5 bg-white rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase font-black text-slate-400 tracking-wider">Events & Competitions</span>
            <Sparkles className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-black text-purple-900">{totalEventsCount} Events</div>
          <span className="text-[10px] text-purple-700 font-semibold">Cultural, Sports & Science</span>
        </div>
      </div>

      {/* Control Bar: Filters & Search */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        {/* Search & Term Preset Row */}
        <div className="flex flex-col md:flex-row gap-3 justify-between items-center">
          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search event, exam, holiday..."
              className="w-full text-xs font-bold pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
            />
          </div>

          {/* Quick Term Tabs */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl text-xs font-bold w-full md:w-auto">
            <span className="text-[10px] text-slate-400 uppercase px-2 font-black">Term:</span>
            {['All', 'Term 1', 'Term 2', 'Term 3'].map((term) => (
              <button
                key={term}
                onClick={() => {
                  setSelectedTerm(term);
                  setSelectedMonth('All');
                }}
                className={`flex-1 md:flex-none px-3.5 py-1.5 rounded-xl transition ${
                  selectedTerm === term
                    ? 'bg-blue-900 text-white shadow'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {term}
              </button>
            ))}
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 text-xs font-bold">
          <span className="text-slate-400 text-[10px] uppercase font-black mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Category:
          </span>
          {[
            { id: 'All', label: 'All Dates' },
            { id: 'Exams', label: 'Examinations' },
            { id: 'Holidays', label: 'Holidays' },
            { id: 'Events', label: 'Events & Functions' },
            { id: 'Term Dates', label: 'Term Key Dates' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl transition text-xs border ${
                selectedCategory === cat.id
                  ? 'bg-amber-400 text-blue-950 border-amber-500 shadow-sm'
                  : 'bg-slate-50 text-slate-700 hover:bg-slate-100 border-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Month Selector Horizontal Scroll Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-2 pb-1 no-scrollbar text-xs">
          {monthsList.map((m) => (
            <button
              key={m}
              onClick={() => {
                setSelectedMonth(m);
                setSelectedTerm('All');
              }}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-bold transition ${
                selectedMonth === m
                  ? 'bg-blue-950 text-white shadow'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      {/* EVENTS DISPLAY LIST / GRID */}
      {filteredEvents.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto text-xl">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-800">No Academic Events Found</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Try adjusting your search query or selecting a different month/category filter.
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
              setSelectedMonth('All');
              setSelectedTerm('All');
            }}
            className="px-4 py-2 rounded-xl bg-blue-900 text-white text-xs font-bold hover:bg-blue-800 transition"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredEvents.map((evt) => {
            const badge = getCategoryBadge(evt.category);
            const BadgeIcon = badge.icon;
            const dayName = getDayOfWeek(evt.startDate);

            return (
              <div
                key={evt.id}
                onClick={() => setSelectedEvent(evt)}
                className={`bg-white rounded-3xl p-5 border transition shadow-sm hover:shadow-md cursor-pointer flex flex-col justify-between space-y-4 group relative ${
                  evt.important
                    ? 'border-amber-300 ring-2 ring-amber-400/30'
                    : 'border-slate-200 hover:border-blue-300'
                }`}
              >
                {/* Important Ribbon */}
                {evt.important && (
                  <span className="absolute top-3 right-3 bg-amber-400 text-blue-950 font-black text-[9px] uppercase px-2 py-0.5 rounded-full flex items-center gap-1 shadow-sm">
                    <Flame className="w-3 h-3 text-red-600 fill-red-600" />
                    <span>Important</span>
                  </span>
                )}

                <div className="space-y-3">
                  {/* Category & Month Header */}
                  <div className="flex items-center justify-between pr-16">
                    <span
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase border ${badge.bg}`}
                    >
                      <BadgeIcon className="w-3 h-3" />
                      <span>{badge.label}</span>
                    </span>
                    <span className="text-[10px] font-bold text-slate-400">{evt.month}</span>
                  </div>

                  {/* Title & Description */}
                  <div>
                    <h3 className="font-extrabold text-slate-900 text-base group-hover:text-blue-900 transition leading-snug">
                      {evt.title}
                    </h3>
                    <p className="text-slate-600 text-xs mt-1 line-clamp-2 leading-relaxed">
                      {evt.description}
                    </p>
                  </div>
                </div>

                {/* Date & Meta Footer */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-blue-950 text-white font-black flex flex-col items-center justify-center shrink-0 shadow-sm">
                      <span className="text-[9px] text-amber-400 uppercase leading-none font-sans">
                        {dayName}
                      </span>
                      <span className="text-sm leading-tight">
                        {new Date(evt.startDate).getDate()}
                      </span>
                    </div>
                    <div>
                      <span className="font-bold text-slate-800 text-xs block">
                        {formatDateDisplay(evt.startDate, evt.endDate)}
                      </span>
                      {evt.timings && (
                        <span className="text-[10px] text-slate-500 flex items-center gap-1 font-medium">
                          <Clock className="w-3 h-3 text-slate-400" />
                          <span>{evt.timings}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <ChevronRight className="w-4 h-4 text-slate-300 group-hover:text-blue-900 transition transform group-hover:translate-x-1" />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* EVENT DETAIL POPUP MODAL */}
      {selectedEvent && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 space-y-6 animate-scaleUp">
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <span
                  className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-extrabold uppercase border ${
                    getCategoryBadge(selectedEvent.category).bg
                  }`}
                >
                  {selectedEvent.category}
                </span>
                <h3 className="text-xl font-black text-blue-950 leading-tight">
                  {selectedEvent.title}
                </h3>
              </div>
              <button
                onClick={() => setSelectedEvent(null)}
                className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-full transition"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex justify-between items-center text-slate-700">
                  <span className="font-bold text-slate-500">Date & Schedule:</span>
                  <span className="font-extrabold text-blue-900">
                    {formatDateDisplay(selectedEvent.startDate, selectedEvent.endDate)}
                  </span>
                </div>

                {selectedEvent.timings && (
                  <div className="flex justify-between items-center text-slate-700">
                    <span className="font-bold text-slate-500">Event Timings:</span>
                    <span className="font-bold">{selectedEvent.timings}</span>
                  </div>
                )}

                {selectedEvent.applicableClasses && (
                  <div className="flex justify-between items-center text-slate-700">
                    <span className="font-bold text-slate-500">Applicable Grades:</span>
                    <span className="font-extrabold text-amber-700">
                      {selectedEvent.applicableClasses}
                    </span>
                  </div>
                )}
              </div>

              <div>
                <h4 className="font-extrabold text-slate-800 mb-1">Details & Instructions for Parents:</h4>
                <p className="text-slate-600 leading-relaxed text-xs">
                  {selectedEvent.description}
                </p>
              </div>

              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 font-medium">
                <strong>Wisdom School Note:</strong> Parents are advised to refer to regular school diary updates or circulars for subject-wise examination timetables or dress codes.
              </div>
            </div>

            <div className="pt-2 flex gap-3">
              <button
                onClick={() => setSelectedEvent(null)}
                className="w-full py-3 bg-blue-950 hover:bg-blue-900 text-white font-extrabold rounded-xl text-xs transition"
              >
                Close Event Details
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

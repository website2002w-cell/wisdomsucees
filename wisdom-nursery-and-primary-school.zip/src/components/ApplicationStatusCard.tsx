import React, { useState } from 'react';
import {
  Search,
  CheckCircle2,
  Clock,
  FileCheck,
  UserCheck,
  CreditCard,
  GraduationCap,
  AlertCircle,
  Phone,
  MessageSquare,
  Printer,
  Calendar,
  User,
  ShieldCheck,
  ChevronRight,
  Info,
  Sparkles,
  MapPin,
  RefreshCw,
  Copy,
  Check,
} from 'lucide-react';

export interface TimelineStep {
  stepNumber: number;
  title: string;
  tamilTitle: string;
  description: string;
  status: 'completed' | 'in_progress' | 'pending';
  date?: string;
  remarks?: string;
}

export interface ApplicationStatusData {
  id: string;
  studentName: string;
  grade: string;
  fatherName: string;
  phone: string;
  submittedAt: string;
  currentStatus: 'Submitted' | 'Under Document Verification' | 'Interview Scheduled' | 'Provisionally Approved' | 'Confirmed & Enrolled';
  statusBadgeColor: string;
  officerNote: string;
  nextActionDate?: string;
  assignedVanRoute?: string;
  timeline: TimelineStep[];
}

const DEMO_APPLICATIONS: Record<string, ApplicationStatusData> = {
  'ADM-ESSUR-2026-101': {
    id: 'ADM-ESSUR-2026-101',
    studentName: 'S. Kavin Kumar',
    grade: 'LKG',
    fatherName: 'R. Saravanan',
    phone: '9176593129',
    submittedAt: '28 Jul 2026, 10:30 AM',
    currentStatus: 'Under Document Verification',
    statusBadgeColor: 'bg-amber-500 text-white',
    officerNote: 'Birth certificate copy verified online. Aadhaar verification in progress by school admin team.',
    nextActionDate: '30 Jul 2026',
    assignedVanRoute: 'Route #1 (Essur Main Road - Vedanthangal Junction)',
    timeline: [
      {
        stepNumber: 1,
        title: 'Application Submitted',
        tamilTitle: 'விண்ணப்பம் பெறப்பட்டது',
        description: 'Online registration form submitted successfully with parent contact details.',
        status: 'completed',
        date: '28 Jul 2026, 10:30 AM',
        remarks: 'Ref ID generated & SMS acknowledgement sent.',
      },
      {
        stepNumber: 2,
        title: 'Document Verification',
        tamilTitle: 'சான்றிதழ் சரிபார்ப்பு',
        description: 'School admin verifying Birth Certificate, Aadhaar, and Photo copies.',
        status: 'in_progress',
        date: 'Est. 29 Jul 2026',
        remarks: 'Officer: Mrs. S. Meenakshi (Admin Dept)',
      },
      {
        stepNumber: 3,
        title: 'Parent & Child Interaction',
        tamilTitle: 'பெற்றோர் நேர்காணல்',
        description: 'Informal friendly interaction session with Headmistress and Nursery Coordinator.',
        status: 'pending',
        date: 'Scheduled: 31 Jul 2026, 10:00 AM',
        remarks: 'Bring original Birth Certificate & Aadhaar.',
      },
      {
        stepNumber: 4,
        title: 'Fee Payment & Roll Allocation',
        tamilTitle: 'கட்டணம் மற்றும் சேர்க்கை எண்',
        description: 'Term 1 fee deposit & student admission roll number generation.',
        status: 'pending',
        date: 'Expected: 02 Aug 2026',
      },
      {
        stepNumber: 5,
        title: 'Final Admission Confirmed',
        tamilTitle: 'சேர்க்கை உறுதி செய்யப்பட்டது',
        description: 'Issue of Student ID Card, Van Pass, and Welcome Textbook Kit.',
        status: 'pending',
        date: 'Expected: 05 Aug 2026',
      },
    ],
  },

  'ADM-ESSUR-2026-102': {
    id: 'ADM-ESSUR-2026-102',
    studentName: 'M. Ananya',
    grade: 'Class 1',
    fatherName: 'K. Mohan',
    phone: '9840123456',
    submittedAt: '25 Jul 2026, 02:15 PM',
    currentStatus: 'Interview Scheduled',
    statusBadgeColor: 'bg-blue-600 text-white',
    officerNote: 'All documents verified. Parent-child interaction scheduled for Friday 31st July 2026 at 11:00 AM at Wisdom School Admin Office.',
    nextActionDate: '31 Jul 2026, 11:00 AM',
    assignedVanRoute: 'Route #2 (Uthiramerur Highway - Essur Village)',
    timeline: [
      {
        stepNumber: 1,
        title: 'Application Submitted',
        tamilTitle: 'விண்ணப்பம் பெறப்பட்டது',
        description: 'Online registration received.',
        status: 'completed',
        date: '25 Jul 2026',
      },
      {
        stepNumber: 2,
        title: 'Document Verification',
        tamilTitle: 'சான்றிதழ் சரிபார்ப்பு',
        description: 'Transfer Certificate and Birth Certificate verified & approved.',
        status: 'completed',
        date: '27 Jul 2026',
        remarks: 'All documents complete.',
      },
      {
        stepNumber: 3,
        title: 'Parent & Child Interaction',
        tamilTitle: 'பெற்றோர் நேர்காணல்',
        description: 'Scheduled with Principal.',
        status: 'in_progress',
        date: '31 Jul 2026, 11:00 AM',
        remarks: 'Please arrive 10 minutes prior.',
      },
      {
        stepNumber: 4,
        title: 'Fee Payment & Roll Allocation',
        tamilTitle: 'கட்டணம் மற்றும் சேர்க்கை எண்',
        description: 'Term 1 fee payment step.',
        status: 'pending',
      },
      {
        stepNumber: 5,
        title: 'Final Admission Confirmed',
        tamilTitle: 'சேர்க்கை உறுதி செய்யப்பட்டது',
        description: 'Student ID & Uniform collection.',
        status: 'pending',
      },
    ],
  },

  'ADM-ESSUR-2026-103': {
    id: 'ADM-ESSUR-2026-103',
    studentName: 'P. Dharun',
    grade: 'Class 4',
    fatherName: 'P. Prakash',
    phone: '9444112233',
    submittedAt: '15 Jul 2026, 09:00 AM',
    currentStatus: 'Confirmed & Enrolled',
    statusBadgeColor: 'bg-emerald-600 text-white',
    officerNote: 'Admission completed successfully! Student Roll No: 2026-C4-18. Van Seat #12 reserved on Route #1.',
    nextActionDate: 'School Reopens: 10 Aug 2026',
    assignedVanRoute: 'Route #1 (Seat #12 Reserved)',
    timeline: [
      {
        stepNumber: 1,
        title: 'Application Submitted',
        tamilTitle: 'விண்ணப்பம் பெறப்பட்டது',
        description: 'Form submitted successfully.',
        status: 'completed',
        date: '15 Jul 2026',
      },
      {
        stepNumber: 2,
        title: 'Document Verification',
        tamilTitle: 'சான்றிதழ் சரிபார்ப்பு',
        description: 'Previous Progress Card & Transfer Certificate approved.',
        status: 'completed',
        date: '17 Jul 2026',
      },
      {
        stepNumber: 3,
        title: 'Parent & Child Interaction',
        tamilTitle: 'பெற்றோர் நேர்காணல்',
        description: 'Interaction completed with Principal.',
        status: 'completed',
        date: '20 Jul 2026',
      },
      {
        stepNumber: 4,
        title: 'Fee Payment & Roll Allocation',
        tamilTitle: 'கட்டணம் மற்றும் சேர்க்கை எண்',
        description: 'Term 1 fee paid. Receipt #WISDOM-FEE-8820.',
        status: 'completed',
        date: '22 Jul 2026',
      },
      {
        stepNumber: 5,
        title: 'Final Admission Confirmed',
        tamilTitle: 'சேர்க்கை உறுதி செய்யப்பட்டது',
        description: 'Roll No: 2026-C4-18 assigned. Welcome to Wisdom School family!',
        status: 'completed',
        date: '24 Jul 2026',
      },
    ],
  },
};

interface ApplicationStatusCardProps {
  initialAppId?: string;
  initialData?: ApplicationStatusData | null;
  onBackToForm?: () => void;
}

export const ApplicationStatusCard: React.FC<ApplicationStatusCardProps> = ({
  initialAppId = '',
  initialData = null,
  onBackToForm,
}) => {
  const [searchInput, setSearchInput] = useState<string>(initialAppId || 'ADM-ESSUR-2026-101');
  const [foundApplication, setFoundApplication] = useState<ApplicationStatusData | null>(
    initialData || DEMO_APPLICATIONS[initialAppId] || DEMO_APPLICATIONS['ADM-ESSUR-2026-101']
  );
  const [searched, setSearched] = useState<boolean>(true);
  const [copiedId, setCopiedId] = useState<boolean>(false);

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = searchInput.trim().toUpperCase();
    if (!query) return;

    // Check direct ID or match phone
    let match = DEMO_APPLICATIONS[query];
    if (!match) {
      // Try searching phone or partial ID
      const foundKey = Object.keys(DEMO_APPLICATIONS).find(
        (key) =>
          key.toUpperCase() === query ||
          DEMO_APPLICATIONS[key].phone.includes(query) ||
          DEMO_APPLICATIONS[key].id.includes(query)
      );
      if (foundKey) {
        match = DEMO_APPLICATIONS[foundKey];
      }
    }

    if (match) {
      setFoundApplication(match);
    } else {
      // Dynamic fallback for user's own entered ID
      setFoundApplication({
        id: query.startsWith('ADM') ? query : `ADM-ESSUR-2026-${Math.floor(100 + Math.random() * 900)}`,
        studentName: 'Applicant Student',
        grade: 'LKG',
        fatherName: 'Parent / Guardian',
        phone: query.length >= 10 ? query : '9176593129',
        submittedAt: 'Today, 28 Jul 2026',
        currentStatus: 'Under Document Verification',
        statusBadgeColor: 'bg-amber-500 text-white',
        officerNote: 'Application received and registered in school database. Documents under review by Wisdom admissions team.',
        nextActionDate: '30 Jul 2026',
        timeline: [
          {
            stepNumber: 1,
            title: 'Application Submitted',
            tamilTitle: 'விண்ணப்பம் பெறப்பட்டது',
            description: 'Online application submitted.',
            status: 'completed',
            date: 'Today, 28 Jul 2026',
          },
          {
            stepNumber: 2,
            title: 'Document Verification',
            tamilTitle: 'சான்றிதழ் சரிபார்ப்பு',
            description: 'Verifying Birth Certificate and Aadhaar.',
            status: 'in_progress',
            date: 'Est. 30 Jul 2026',
          },
          {
            stepNumber: 3,
            title: 'Parent & Child Interaction',
            tamilTitle: 'பெற்றோர் நேர்காணல்',
            description: 'Scheduled after document clearance.',
            status: 'pending',
          },
          {
            stepNumber: 4,
            title: 'Fee Payment & Roll Allocation',
            tamilTitle: 'கட்டணம் மற்றும் சேர்க்கை எண்',
            description: 'Provisional roll number allocation.',
            status: 'pending',
          },
          {
            stepNumber: 5,
            title: 'Final Admission Confirmed',
            tamilTitle: 'சேர்க்கை உறுதி செய்யப்பட்டது',
            description: 'Welcome Kit and Student ID issuance.',
            status: 'pending',
          },
        ],
      });
    }
    setSearched(true);
  };

  const handleCopyId = () => {
    if (!foundApplication) return;
    navigator.clipboard.writeText(foundApplication.id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-fadeIn">
      {/* Top Search Header */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl border-2 border-amber-400/40 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/10 pb-4">
          <div>
            <div className="inline-flex items-center gap-2 bg-amber-400 text-blue-950 px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider shadow mb-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-950" />
              <span>Wisdom Admissions Tracking Portal</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Check Admission Application Status
            </h2>
            <p className="text-xs text-slate-300 font-medium pt-0.5">
              Enter your Application Ref ID (e.g., ADM-ESSUR-2026-101) or Mobile Number to view real-time review progress.
            </p>
          </div>

          {onBackToForm && (
            <button
              onClick={onBackToForm}
              className="px-3.5 py-2 bg-white/10 hover:bg-white/20 text-amber-300 text-xs font-bold rounded-xl border border-white/20 transition self-start sm:self-auto shrink-0"
            >
              ← Back to New Registration
            </button>
          )}
        </div>

        {/* Search Input Box */}
        <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Enter Ref ID e.g. ADM-ESSUR-2026-101 or 9176593129"
              className="w-full text-xs font-mono font-bold pl-10 pr-4 py-3 rounded-2xl bg-slate-900/90 border border-amber-400/50 text-amber-300 focus:outline-none focus:ring-2 focus:ring-amber-400 placeholder:text-slate-500"
            />
          </div>

          <button
            type="submit"
            className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-2xl transition shadow-lg flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4 text-blue-950" />
            <span>Track Application</span>
          </button>
        </form>

        {/* Demo Quick Chips */}
        <div className="flex flex-wrap items-center gap-2 text-[11px]">
          <span className="text-slate-400 font-bold">Try Sample IDs:</span>
          {['ADM-ESSUR-2026-101', 'ADM-ESSUR-2026-102', 'ADM-ESSUR-2026-103'].map((sample) => (
            <button
              key={sample}
              type="button"
              onClick={() => {
                setSearchInput(sample);
                setFoundApplication(DEMO_APPLICATIONS[sample]);
                setSearched(true);
              }}
              className="px-2.5 py-1 bg-white/10 hover:bg-white/20 text-amber-300 font-mono text-[10px] font-bold rounded-lg border border-white/15 transition"
            >
              {sample}
            </button>
          ))}
        </div>
      </div>

      {/* Main Status & Timeline Card Display */}
      {foundApplication && (
        <div className="bg-white rounded-3xl border-2 border-slate-200 shadow-xl overflow-hidden space-y-6 p-6 sm:p-8">
          {/* Card Header Info */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs text-slate-500 font-bold">Ref ID:</span>
                <span className="font-mono font-black text-blue-950 text-base sm:text-lg bg-amber-100 px-2.5 py-0.5 rounded border border-amber-300">
                  {foundApplication.id}
                </span>
                <button
                  onClick={handleCopyId}
                  className="p-1 text-slate-400 hover:text-blue-900 transition"
                  title="Copy ID"
                >
                  {copiedId ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <h3 className="text-lg sm:text-xl font-extrabold text-slate-900">
                Child: <span className="text-blue-950">{foundApplication.studentName}</span>
              </h3>

              <p className="text-xs text-slate-600 font-medium">
                Grade Applied: <strong className="text-amber-900 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">{foundApplication.grade}</strong> • Parent: {foundApplication.fatherName} ({foundApplication.phone})
              </p>
            </div>

            {/* Current Status Badge */}
            <div className="text-left md:text-right space-y-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Current Application Stage:</span>
              <span className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-black shadow ${foundApplication.statusBadgeColor}`}>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>{foundApplication.currentStatus}</span>
              </span>
              <span className="text-[10px] text-slate-500 block font-medium">Submitted on: {foundApplication.submittedAt}</span>
            </div>
          </div>

          {/* Official Officer Remarks Box */}
          <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-2xl text-xs space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-amber-900 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-amber-700" />
                <span>Admissions Officer Remarks & Next Step:</span>
              </span>
              {foundApplication.nextActionDate && (
                <span className="text-[10px] font-bold bg-amber-200 text-amber-900 px-2 py-0.5 rounded">
                  Target Date: {foundApplication.nextActionDate}
                </span>
              )}
            </div>
            <p className="text-slate-800 font-medium leading-relaxed pl-5">
              "{foundApplication.officerNote}"
            </p>
            {foundApplication.assignedVanRoute && (
              <p className="text-blue-900 font-bold text-[11px] pl-5 pt-1">
                🚍 Van Route Mapped: {foundApplication.assignedVanRoute}
              </p>
            )}
          </div>

          {/* VISUAL TIMELINE OF REVIEW PROCESS */}
          <div className="space-y-4 pt-2">
            <div className="border-b border-slate-100 pb-2 flex items-center justify-between">
              <h4 className="text-sm font-extrabold text-blue-950 uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Review Process Milestone Timeline</span>
              </h4>
              <span className="text-[11px] text-slate-500 font-medium">5 Sequential Review Stages</span>
            </div>

            {/* Vertical / Horizontal Adaptive Timeline Grid */}
            <div className="relative pl-4 sm:pl-8 space-y-6 before:absolute before:left-3.5 sm:before:left-7 before:top-3 before:bottom-3 before:w-1 before:bg-slate-200">
              {foundApplication.timeline.map((step, idx) => {
                const isCompleted = step.status === 'completed';
                const isInProgress = step.status === 'in_progress';

                return (
                  <div key={step.stepNumber} className="relative flex items-start gap-4 group">
                    {/* Circle Icon Badge */}
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs z-10 shrink-0 transition-transform shadow ${
                        isCompleted
                          ? 'bg-emerald-600 text-white ring-4 ring-emerald-100'
                          : isInProgress
                          ? 'bg-amber-400 text-blue-950 ring-4 ring-amber-100 animate-pulse'
                          : 'bg-slate-100 text-slate-400 border-2 border-slate-300'
                      }`}
                    >
                      {isCompleted ? (
                        <CheckCircle2 className="w-5 h-5 text-white" />
                      ) : isInProgress ? (
                        <Clock className="w-5 h-5 text-blue-950" />
                      ) : (
                        step.stepNumber
                      )}
                    </div>

                    {/* Step Card Content */}
                    <div
                      className={`flex-1 p-4 rounded-2xl border transition ${
                        isCompleted
                          ? 'bg-emerald-50/40 border-emerald-200'
                          : isInProgress
                          ? 'bg-amber-50/60 border-amber-300 shadow-md'
                          : 'bg-slate-50/50 border-slate-200 opacity-70'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                        <div>
                          <div className="flex items-center gap-2">
                            <h5 className="font-extrabold text-sm text-slate-900">
                              {step.stepNumber}. {step.title}
                            </h5>
                            <span className="text-xs text-amber-900 font-semibold font-serif">
                              ({step.tamilTitle})
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 font-medium pt-0.5">
                            {step.description}
                          </p>
                        </div>

                        <div className="text-left sm:text-right shrink-0">
                          {isCompleted ? (
                            <span className="inline-block bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-300">
                              Completed ✓
                            </span>
                          ) : isInProgress ? (
                            <span className="inline-block bg-amber-400 text-blue-950 text-[10px] font-black px-2.5 py-0.5 rounded-full shadow">
                              In Progress...
                            </span>
                          ) : (
                            <span className="inline-block bg-slate-200 text-slate-600 text-[10px] font-bold px-2 py-0.5 rounded">
                              Pending
                            </span>
                          )}

                          {step.date && (
                            <span className="block text-[10px] text-slate-500 font-mono pt-0.5 font-bold">
                              {step.date}
                            </span>
                          )}
                        </div>
                      </div>

                      {step.remarks && (
                        <div className="mt-2 text-[11px] font-semibold text-slate-700 bg-white/80 p-2 rounded-xl border border-slate-200/80 flex items-center gap-1.5">
                          <Info className="w-3.5 h-3.5 text-blue-800 shrink-0" />
                          <span>{step.remarks}</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Helpdesk Contact Footer Bar */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-3 text-slate-600">
              <div className="p-2 bg-blue-100 text-blue-950 rounded-xl">
                <Phone className="w-4 h-4 text-blue-900" />
              </div>
              <div>
                <strong className="text-slate-900 block font-bold">Wisdom School Admission Office:</strong>
                <span>R. Saravanan (Admin): +91 9176593129 • Office Hours: 8:30 AM - 4:00 PM</span>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <a
                href="https://wa.me/919176593129?text=Hello%20Wisdom%20School%20Admin,%20I%20am%20checking%20my%20admission%20status."
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-none px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>WhatsApp Admin</span>
              </a>

              <button
                onClick={handlePrint}
                className="flex-1 sm:flex-none px-3.5 py-2 bg-blue-950 hover:bg-blue-900 text-amber-400 font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow"
              >
                <Printer className="w-3.5 h-3.5 text-amber-400" />
                <span>Print Timeline</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  CreditCard,
  UserCheck,
  Smartphone,
  Sparkles,
  CheckCircle2,
  Phone,
  QrCode,
  MapPin,
  Calendar,
  Award,
  Users,
  BookOpen,
  Volume2,
} from 'lucide-react';
import { SCHOOL_INFO, SCHOOL_FACILITIES } from '../data/schoolData';
import { getAdmissionsConfig, AdmissionsConfig } from '../utils/admissionsConfig';

interface HeroProps {
  setActiveTab: (tab: string) => void;
  onOpenAiChat: () => void;
}

export const Hero: React.FC<HeroProps> = ({ setActiveTab, onOpenAiChat }) => {
  const [admissionsConfig, setAdmissionsConfig] = useState<AdmissionsConfig>(getAdmissionsConfig());

  useEffect(() => {
    const handleUpdate = () => {
      setAdmissionsConfig(getAdmissionsConfig());
    };
    window.addEventListener('admissions-config-updated', handleUpdate);
    return () => window.removeEventListener('admissions-config-updated', handleUpdate);
  }, []);

  return (
    <div className="space-y-10 pb-6">
      {/* Dynamic Admission Ticker Announcement Bar */}
      {admissionsConfig.noticeAnnouncement && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 text-blue-950 font-extrabold text-xs px-4 py-2 rounded-2xl shadow-sm flex items-center justify-between border border-amber-500 overflow-hidden">
          <div className="flex items-center gap-2 truncate">
            <Volume2 className="w-4 h-4 text-blue-950 animate-bounce shrink-0" />
            <span className="truncate">{admissionsConfig.noticeAnnouncement}</span>
          </div>
          <button
            onClick={() => setActiveTab('admissions')}
            className="hidden sm:inline-flex bg-blue-950 text-white font-black text-[10px] uppercase px-3 py-1 rounded-full shadow hover:bg-blue-900 transition shrink-0 ml-2"
          >
            Apply Now
          </button>
        </div>
      )}

      {/* Primary Motto Hero Banner */}
      <section className="motto-banner-gradient text-white relative overflow-hidden rounded-b-3xl shadow-xl">
        {/* Subtle background decorative shapes */}
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-6xl mx-auto px-4 py-12 sm:py-16 text-center relative z-10 flex flex-col items-center">
          {/* Central Emblem Badge Display */}
          <div className="relative mb-6 group cursor-pointer" onClick={() => setActiveTab('home')}>
            <div className="w-36 h-36 sm:w-44 sm:h-44 rounded-full bg-white p-1 shadow-2xl border-4 border-amber-400 flex items-center justify-center transition transform group-hover:scale-105 overflow-hidden">
              <img
                src={SCHOOL_INFO.logoUrl}
                alt={SCHOOL_INFO.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain rounded-full"
              />
            </div>
            <div className="absolute -bottom-2 bg-amber-400 text-blue-950 font-extrabold text-xs px-3 py-1 rounded-full shadow-md border border-amber-500 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-blue-900" />
              <span>ESTD 2001</span>
            </div>
          </div>

          {/* Admission Open Tag */}
          <button
            onClick={() => setActiveTab('admissions')}
            className="bg-amber-400 hover:bg-amber-300 text-blue-950 font-black px-4 py-1.5 rounded-full text-xs sm:text-sm uppercase tracking-wider shadow-md mb-3 inline-flex items-center gap-1.5 transition transform hover:scale-105"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping"></span>
            <span>{admissionsConfig.bannerBadgeText || 'Admissions Open 2026 - 2027'}</span>
          </button>

          <h1 className="text-2xl sm:text-4xl md:text-5xl font-black tracking-tight mt-2 mb-2 leading-tight">
            WISDOM NURSERY AND PRIMARY SCHOOL
          </h1>

          <p className="text-amber-300 font-extrabold text-lg sm:text-2xl italic tracking-wide mb-4 gold-gradient-text">
            "{SCHOOL_INFO.motto}"
          </p>

          <p className="text-slate-200 text-sm sm:text-base max-w-2xl mx-auto font-normal leading-relaxed mb-8">
            Providing top-quality primary and nursery education in Essur to build strong educational, moral, and leadership foundations for every student.
          </p>

          {/* Key CTA Buttons */}
          <div className="flex flex-wrap justify-center gap-3 sm:gap-4 w-full max-w-2xl">
            <button
              onClick={() => setActiveTab('fee-payment')}
              className="flex-1 min-w-[200px] bg-amber-400 hover:bg-amber-300 text-blue-950 font-extrabold px-6 py-3.5 rounded-xl shadow-lg border border-amber-500 transition transform hover:-translate-y-0.5 active:scale-95 flex items-center justify-center gap-2 text-sm"
            >
              <CreditCard className="w-5 h-5 text-blue-950" />
              <span>Pay Fees Online (UPI)</span>
            </button>

            <button
              onClick={() => setActiveTab('admissions')}
              className="flex-1 min-w-[200px] bg-blue-600 hover:bg-blue-500 text-white font-bold px-6 py-3.5 rounded-xl shadow-lg transition transform hover:-translate-y-0.5 active:scale-95 flex items-center justify-center gap-2 text-sm border border-blue-400/30"
            >
              <GraduationCap className="w-5 h-5 text-amber-300" />
              <span>Apply Admission</span>
            </button>

            <button
              onClick={() => setActiveTab('app-download')}
              className="flex-1 min-w-[200px] bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-3.5 rounded-xl shadow-lg transition transform hover:-translate-y-0.5 active:scale-95 flex items-center justify-center gap-2 text-sm border border-emerald-400/30"
            >
              <Smartphone className="w-5 h-5" />
              <span>Download Android App</span>
            </button>
          </div>

          {/* Quick AI Help Banner */}
          <div className="mt-8 pt-6 border-t border-slate-700/60 w-full max-w-xl flex flex-col sm:flex-row items-center justify-between bg-slate-900/60 p-4 rounded-2xl backdrop-blur-sm border border-slate-700">
            <div className="flex items-center space-x-3 text-left mb-3 sm:mb-0">
              <div className="p-2.5 rounded-xl bg-purple-600/30 text-purple-300 border border-purple-500/30">
                <Sparkles className="w-5 h-5 text-amber-300 animate-bounce" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-100">Have Questions About Admissions or Fees?</h4>
                <p className="text-[11px] text-slate-300">Chat with Wisdom AI Virtual Assistant instantly.</p>
              </div>
            </div>
            <button
              onClick={onOpenAiChat}
              className="bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold px-4 py-2 rounded-lg shadow transition whitespace-nowrap"
            >
              Ask AI Counselor
            </button>
          </div>
        </div>
      </section>

      {/* Quick Metrics Counter Grid */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
          <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm text-center hover:shadow-md transition">
            <div className="w-10 h-10 mx-auto rounded-xl bg-blue-50 text-blue-900 flex items-center justify-center mb-2 font-bold">
              <Users className="w-5 h-5" />
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-blue-950">450+</div>
            <div className="text-xs text-slate-500 font-semibold mt-0.5">Enrolled Students</div>
          </div>

          <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm text-center hover:shadow-md transition">
            <div className="w-10 h-10 mx-auto rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center mb-2 font-bold">
              <Award className="w-5 h-5" />
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-blue-950">100%</div>
            <div className="text-xs text-slate-500 font-semibold mt-0.5">Pass & Growth Rate</div>
          </div>

          <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm text-center hover:shadow-md transition">
            <div className="w-10 h-10 mx-auto rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center mb-2 font-bold">
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-blue-950">18+</div>
            <div className="text-xs text-slate-500 font-semibold mt-0.5">Qualified Educators</div>
          </div>

          <div className="p-5 bg-white border border-slate-200 rounded-2xl shadow-sm text-center hover:shadow-md transition">
            <div className="w-10 h-10 mx-auto rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center mb-2 font-bold">
              <Calendar className="w-5 h-5" />
            </div>
            <div className="text-2xl sm:text-3xl font-extrabold text-blue-950">25+ Yrs</div>
            <div className="text-xs text-slate-500 font-semibold mt-0.5">Educational Excellence</div>
          </div>
        </div>
      </div>

      {/* Quick Action Shortcuts Banner */}
      <div className="max-w-7xl mx-auto px-4">
        <div className="bg-gradient-to-r from-blue-950 to-indigo-900 rounded-2xl p-6 sm:p-8 text-white shadow-lg border border-blue-800">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="space-y-2 text-center lg:text-left">
              <span className="text-amber-400 font-extrabold text-xs tracking-wider uppercase bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
                Official Digital Payment
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-white">
                Pay Tuition Fees Online via Google Pay / PhonePe
              </h2>
              <p className="text-slate-300 text-xs sm:text-sm max-w-xl">
                UPI ID: <span className="font-mono text-amber-300 font-bold select-all bg-slate-900/80 px-2 py-0.5 rounded border border-amber-400/30">{SCHOOL_INFO.upiId}</span> (Admin: {SCHOOL_INFO.adminName})
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => setActiveTab('fee-payment')}
                className="bg-amber-400 hover:bg-amber-300 text-blue-950 font-extrabold px-5 py-3 rounded-xl text-xs sm:text-sm transition flex items-center gap-2 shadow"
              >
                <QrCode className="w-4 h-4" />
                <span>Open UPI QR Code Generator</span>
              </button>

              <button
                onClick={() => setActiveTab('student-portal')}
                className="bg-slate-800 hover:bg-slate-700 text-white font-bold px-5 py-3 rounded-xl text-xs sm:text-sm transition flex items-center gap-2 border border-slate-700"
              >
                <UserCheck className="w-4 h-4 text-amber-400" />
                <span>Student Marks & Homework</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Why Choose Wisdom School Facilities Grid */}
      <section className="max-w-7xl mx-auto px-4 pt-4">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <span className="text-blue-900 font-bold text-xs uppercase tracking-wider bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
            School Highlights
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
            Why Parents Trust Wisdom Nursery & Primary School
          </h2>
          <p className="text-slate-600 text-xs sm:text-sm mt-1">
            Dedicated to academic excellence, English language fluency, and moral values in Essur.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SCHOOL_FACILITIES.map((facility, idx) => (
            <div
              key={idx}
              className="p-6 bg-white border border-slate-200 rounded-2xl shadow-sm hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="w-10 h-10 rounded-xl bg-blue-900 text-amber-400 flex items-center justify-center font-bold text-lg mb-4">
                  <CheckCircle2 className="w-6 h-6 text-amber-400" />
                </div>
                <h3 className="font-extrabold text-slate-900 text-base mb-2">
                  {facility.title}
                </h3>
                <p className="text-slate-600 text-xs leading-relaxed">
                  {facility.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  UserCheck,
  Search,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Award,
  FileText,
  User,
  AlertCircle,
  TrendingUp,
  CreditCard,
  Phone,
  Lock,
  Sparkles,
  Bell,
  MessageSquare,
} from 'lucide-react';
import { StudentProfile } from '../types';
import { StudentIdCard } from './StudentIdCard';
import { NotificationPreferences } from './NotificationPreferences';
import { ParentTeacherCommunication } from './ParentTeacherCommunication';
import { ProgressReportPdfModal } from './ProgressReportPdfModal';
import { LibraryCatalog } from './LibraryCatalog';
import { SchoolVanTracker } from './SchoolVanTracker';
import { SchoolStore } from './SchoolStore';
import { LostAndFound } from './LostAndFound';
import { StudentAchievements } from './StudentAchievements';
import { SuggestionBox } from './SuggestionBox';
import { DigitalHallPass } from './DigitalHallPass';
import { BiometricAuth } from './BiometricAuth';
import { Printer, Bookmark, Bus, ShoppingBag, PackageCheck, Trophy, MessageSquarePlus, Ticket, Fingerprint } from 'lucide-react';

export const StudentPortal: React.FC = () => {
  const [loginMode, setLoginMode] = useState<'phone-dob' | 'id' | 'biometric'>('biometric');
  const [phoneInput, setPhoneInput] = useState('9876543210');
  const [dobInput, setDobInput] = useState('2018-06-15');
  const [searchId, setSearchId] = useState('WNS-2026-01');

  const [student, setStudent] = useState<StudentProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeTab, setActiveTab] = useState<'idcard' | 'ptm' | 'van' | 'store' | 'lostfound' | 'achievements' | 'suggestionbox' | 'hallpass' | 'library' | 'marks' | 'attendance' | 'homework' | 'notes' | 'alerts'>('idcard');
  const [showReportModal, setShowReportModal] = useState(false);

  const performLogin = async (payload: { phone?: string; dob?: string; studentId?: string }) => {
    setLoading(true);
    setErrorMsg('');
    try {
      const res = await fetch('/api/student/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success && data.student) {
        setStudent(data.student);
      } else {
        setErrorMsg(data.message || 'No student profile found matching these login details.');
        setStudent(null);
      }
    } catch (err) {
      console.error(err);
      setErrorMsg('Error connecting to school server. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // Initial load demo student
    performLogin({ phone: '9876543210', dob: '2018-06-15' });
  }, []);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginMode === 'phone-dob') {
      if (!phoneInput) {
        setErrorMsg('Please enter parent/registered mobile number.');
        return;
      }
      performLogin({ phone: phoneInput, dob: dobInput });
    } else {
      if (!searchId) {
        setErrorMsg('Please enter Student Reg ID.');
        return;
      }
      performLogin({ studentId: searchId });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Title Header */}
      <div className="text-center max-w-3xl mx-auto space-y-2">
        <span className="bg-blue-100 text-blue-900 text-xs font-black uppercase px-3.5 py-1.5 rounded-full border border-blue-200 inline-flex items-center gap-1.5">
          <UserCheck className="w-3.5 h-3.5 text-blue-800" />
          Parent & Student Portal
        </span>
        <h2 className="text-2xl sm:text-4xl font-extrabold text-blue-950">
          Wisdom Student Academic & ID Portal
        </h2>
        <p className="text-slate-600 text-xs sm:text-sm">
          Log in with your Mobile Phone & Date of Birth to view exam report cards, digital smart ID badges, homework, and attendance.
        </p>
      </div>

      {/* LOGIN CARD CONTAINER */}
      <div className="max-w-xl mx-auto bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        {/* Toggle Mode Pills */}
        <div className="flex bg-slate-100 p-1 rounded-2xl text-xs font-bold overflow-x-auto">
          <button
            onClick={() => {
              setLoginMode('biometric');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 shrink-0 ${
              loginMode === 'biometric'
                ? 'bg-blue-900 text-amber-400 shadow font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Fingerprint className="w-4 h-4 text-amber-400" />
            <span>Biometric / Passkey</span>
          </button>

          <button
            onClick={() => {
              setLoginMode('phone-dob');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 shrink-0 ${
              loginMode === 'phone-dob'
                ? 'bg-blue-900 text-white shadow font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Phone className="w-3.5 h-3.5 text-amber-400" />
            <span>Phone & DOB</span>
          </button>

          <button
            onClick={() => {
              setLoginMode('id');
              setErrorMsg('');
            }}
            className={`flex-1 py-2.5 px-3 rounded-xl transition flex items-center justify-center gap-1.5 shrink-0 ${
              loginMode === 'id'
                ? 'bg-blue-900 text-white shadow font-extrabold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Search className="w-3.5 h-3.5 text-amber-400" />
            <span>Student ID</span>
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs font-bold rounded-xl flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Login Form Content */}
        {loginMode === 'biometric' ? (
          <div className="space-y-3">
            <div className="p-4 bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white rounded-2xl border-2 border-amber-400/80 shadow-md">
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 bg-amber-400 text-blue-950 rounded-xl">
                  <Fingerprint className="w-6 h-6 text-blue-950 animate-pulse" />
                </div>
                <div>
                  <h4 className="font-black text-sm text-amber-300 flex items-center gap-1.5">
                    <span>WebAuthn Biometric Parent Login</span>
                    <span className="bg-emerald-500/30 text-emerald-300 text-[9px] font-black px-2 py-0.5 rounded-full border border-emerald-400/30">
                      FIDO2 / Passkey
                    </span>
                  </h4>
                  <p className="text-xs text-slate-300">
                    Touch sensor or look at camera (Fingerprint / Touch ID / Face ID) for 1-click access.
                  </p>
                </div>
              </div>

              <BiometricAuth
                userPhone={phoneInput}
                studentName="Wisdom Student Account"
                onAuthenticateSuccess={(phone) => {
                  performLogin({ phone });
                }}
              />
            </div>
          </div>
        ) : (
          <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
            {loginMode === 'phone-dob' ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Parent / Registered Phone
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="tel"
                      value={phoneInput}
                      onChange={(e) => setPhoneInput(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="w-full font-bold pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    Student Date of Birth (DOB)
                  </label>
                  <div className="relative">
                    <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="date"
                      value={dobInput}
                      onChange={(e) => setDobInput(e.target.value)}
                      className="w-full font-bold pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  Student Reg. ID (e.g. WNS-2026-01)
                </label>
                <div className="relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
                  <input
                    type="text"
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                    placeholder="Enter Student ID (e.g. WNS-2026-01)"
                    className="w-full font-bold pl-10 pr-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-blue-900 hover:bg-blue-800 text-white font-extrabold py-3 rounded-xl text-xs shadow transition flex items-center justify-center gap-2"
            >
              <UserCheck className="w-4 h-4 text-amber-400" />
              <span>{loading ? 'Authenticating...' : 'Sign In to Student Portal'}</span>
            </button>
          </form>
        )}

        {/* Quick Sample Login Credentials Bar */}
        <div className="pt-2 border-t border-slate-100 space-y-1.5 text-[11px]">
          <span className="text-slate-500 font-bold uppercase tracking-wider block text-[10px]">
            Sample Login Accounts (Essur Students):
          </span>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5 font-medium">
            <button
              onClick={() => {
                setLoginMode('phone-dob');
                setPhoneInput('9876543210');
                setDobInput('2018-06-15');
                performLogin({ phone: '9876543210', dob: '2018-06-15' });
              }}
              className="p-2 bg-slate-50 hover:bg-amber-50 rounded-xl border border-slate-200 text-left transition"
            >
              <div className="font-bold text-blue-950">R. Kavin (Class 3)</div>
              <div className="text-[10px] text-slate-500">Ph: 9876543210</div>
              <div className="text-[10px] text-slate-500">DOB: 2018-06-15</div>
            </button>

            <button
              onClick={() => {
                setLoginMode('phone-dob');
                setPhoneInput('9876543211');
                setDobInput('2021-04-10');
                performLogin({ phone: '9876543211', dob: '2021-04-10' });
              }}
              className="p-2 bg-slate-50 hover:bg-amber-50 rounded-xl border border-slate-200 text-left transition"
            >
              <div className="font-bold text-blue-950">S. Priyanka (LKG)</div>
              <div className="text-[10px] text-slate-500">Ph: 9876543211</div>
              <div className="text-[10px] text-slate-500">DOB: 2021-04-10</div>
            </button>

            <button
              onClick={() => {
                setLoginMode('phone-dob');
                setPhoneInput('9876543212');
                setDobInput('2016-08-20');
                performLogin({ phone: '9876543212', dob: '2016-08-20' });
              }}
              className="p-2 bg-slate-50 hover:bg-amber-50 rounded-xl border border-slate-200 text-left transition"
            >
              <div className="font-bold text-blue-950">M. Yogesh (Class 5)</div>
              <div className="text-[10px] text-slate-500">Ph: 9876543212</div>
              <div className="text-[10px] text-slate-500">DOB: 2016-08-20</div>
            </button>
          </div>
        </div>
      </div>

      {/* Error Message if any */}
      {errorMsg && (
        <div className="max-w-xl mx-auto p-4 bg-red-50 border border-red-200 rounded-2xl text-xs text-red-700 flex items-center gap-2">
          <AlertCircle className="w-5 h-5 shrink-0 text-red-600" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Student Profile Card */}
      {student && (
        <div className="space-y-6">
          {/* Main Info Header Banner */}
          <div className="bg-gradient-to-r from-blue-950 via-indigo-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl border border-blue-900">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div className="flex items-center space-x-4">
                <div className="w-16 h-16 rounded-2xl bg-amber-400 text-blue-950 font-black text-2xl flex items-center justify-center shadow-lg shrink-0">
                  {student.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl sm:text-2xl font-black">{student.name}</h3>
                    <span className="bg-blue-800 text-amber-300 text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border border-blue-700">
                      {student.grade}
                    </span>
                  </div>
                  <p className="text-slate-300 text-xs mt-1">
                    Student ID: <span className="font-mono font-bold text-amber-300">{student.id}</span> | Roll No: {student.rollNo}
                  </p>
                  <p className="text-slate-300 text-xs mt-0.5">
                    Class Teacher: <span className="text-white font-semibold">{student.classTeacher}</span>
                  </p>
                </div>
              </div>

              {/* Attendance & Fee Badges */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/10 text-center">
                  <span className="text-slate-300 text-[10px] uppercase font-bold block">Attendance Rate</span>
                  <span className="text-xl font-black text-emerald-400">{student.attendancePercentage}%</span>
                  <span className="text-[10px] text-slate-300 block">{student.presentDays} / {student.totalDays} Days</span>
                </div>

                <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/10 text-center">
                  <span className="text-slate-300 text-[10px] uppercase font-bold block">Fee Status</span>
                  <span className="text-xs font-black text-amber-300 block mt-1">{student.feeStatus}</span>
                  <span className="text-[10px] text-emerald-300 font-semibold">Verified</span>
                </div>
              </div>
            </div>
          </div>

          {/* Parent Biometric Passkey Management Bar */}
          <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-sm">
            <BiometricAuth
              userPhone={student.parentPhone}
              studentName={student.name}
            />
          </div>

          {/* Navigation Sub-Tabs */}
          <div className="flex border-b border-slate-200 space-x-2 text-xs font-bold overflow-x-auto pb-1">
            <button
              onClick={() => setActiveTab('idcard')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'idcard'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <CreditCard className="w-4 h-4 text-amber-400" />
              <span>Digital Student ID Card</span>
            </button>

            <button
              onClick={() => setActiveTab('marks')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'marks'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Award className="w-4 h-4 text-amber-400" />
              <span>Academic Report Card</span>
            </button>

            <button
              onClick={() => setActiveTab('attendance')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'attendance'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Calendar className="w-4 h-4 text-emerald-400" />
              <span>Attendance History</span>
            </button>

            <button
              onClick={() => setActiveTab('homework')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'homework'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <BookOpen className="w-4 h-4 text-purple-400" />
              <span>Homework Assignments ({student.homework.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('ptm')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'ptm'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <MessageSquare className="w-4 h-4 text-emerald-400" />
              <span>Parent-Teacher Desk</span>
            </button>

            <button
              onClick={() => setActiveTab('van')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'van'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Bus className="w-4 h-4 text-amber-400" />
              <span>School Van GPS Tracker</span>
            </button>

            <button
              onClick={() => setActiveTab('store')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'store'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <span>Uniform Store & Orders</span>
            </button>

            <button
              onClick={() => setActiveTab('lostfound')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'lostfound'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <PackageCheck className="w-4 h-4 text-emerald-400" />
              <span>Lost & Found Registry</span>
            </button>

            <button
              onClick={() => setActiveTab('achievements')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'achievements'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Trophy className="w-4 h-4 text-amber-400" />
              <span>Badges & Honors</span>
            </button>

            <button
              onClick={() => setActiveTab('suggestionbox')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'suggestionbox'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <MessageSquarePlus className="w-4 h-4 text-amber-400" />
              <span>Suggestion Box</span>
            </button>

            <button
              onClick={() => setActiveTab('hallpass')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'hallpass'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Ticket className="w-4 h-4 text-amber-400" />
              <span>Digital Hall Pass</span>
            </button>

            <button
              onClick={() => setActiveTab('library')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'library'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Bookmark className="w-4 h-4 text-indigo-400" />
              <span>School Library Catalog</span>
            </button>

            <button
              onClick={() => setActiveTab('alerts')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'alerts'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <Bell className="w-4 h-4 text-amber-400" />
              <span>Parent Alert Preferences</span>
            </button>

            <button
              onClick={() => setActiveTab('notes')}
              className={`px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'notes'
                  ? 'bg-blue-900 text-white shadow'
                  : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
              }`}
            >
              <FileText className="w-4 h-4 text-blue-400" />
              <span>Teacher Remarks</span>
            </button>
          </div>

          {/* Tab 0: Digital ID Card */}
          {activeTab === 'idcard' && <StudentIdCard student={student} />}

          {/* Tab: Parent Teacher Desk */}
          {activeTab === 'ptm' && <ParentTeacherCommunication student={student} />}

          {/* Tab: School Van GPS Tracker */}
          {activeTab === 'van' && <SchoolVanTracker student={student} />}

          {/* Tab: Uniform Store & Orders */}
          {activeTab === 'store' && <SchoolStore student={student} />}

          {/* Tab: Lost & Found Registry */}
          {activeTab === 'lostfound' && <LostAndFound student={student} />}

          {/* Tab: Digital Badges & Honors */}
          {activeTab === 'achievements' && <StudentAchievements student={student} />}

          {/* Tab: Anonymous Suggestion Box */}
          {activeTab === 'suggestionbox' && <SuggestionBox student={student} />}

          {/* Tab: Digital Hall Pass */}
          {activeTab === 'hallpass' && <DigitalHallPass student={student} />}

          {/* Tab: School Library Catalog */}
          {activeTab === 'library' && <LibraryCatalog student={student} />}

          {/* Tab: Notification Preferences */}
          {activeTab === 'alerts' && <NotificationPreferences student={student} />}

          {/* Tab 1: Marks */}
          {activeTab === 'marks' && (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <h4 className="text-base font-bold text-slate-900">Term 1 Examination Marksheet</h4>
                  <p className="text-xs text-slate-500">Curriculum: Samacheer Kalvi State Board</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-blue-900 bg-blue-50 px-3 py-1.5 rounded-full border border-blue-200">
                    Overall Grade: A+
                  </span>
                  <button
                    onClick={() => setShowReportModal(true)}
                    className="px-3.5 py-1.5 bg-blue-950 hover:bg-blue-900 text-amber-400 rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow"
                  >
                    <Printer className="w-3.5 h-3.5 text-amber-400" />
                    <span>Download PDF Report Card</span>
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-slate-50 text-slate-700 font-extrabold uppercase text-[11px] border-b border-slate-200">
                      <th className="py-3 px-4">Subject</th>
                      <th className="py-3 px-4 text-center">Marks Obtained</th>
                      <th className="py-3 px-4 text-center">Max Marks</th>
                      <th className="py-3 px-4 text-center">Grade</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-semibold">
                    {student.term1Marks.map((m, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/80 transition">
                        <td className="py-3.5 px-4 text-slate-900 font-bold">{m.subject}</td>
                        <td className="py-3.5 px-4 text-center font-extrabold text-blue-950">{m.mark}</td>
                        <td className="py-3.5 px-4 text-center text-slate-500">{m.max}</td>
                        <td className="py-3.5 px-4 text-center">
                          <span className="bg-emerald-100 text-emerald-800 font-black px-2.5 py-0.5 rounded-full text-[10px]">
                            {m.grade}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Tab 2: Attendance */}
          {activeTab === 'attendance' && (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
              <h4 className="text-base font-bold text-slate-900">Attendance Summary</h4>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-center">
                  <span className="text-emerald-800 font-bold block text-[11px] uppercase">Days Present</span>
                  <span className="text-3xl font-black text-emerald-700">{student.presentDays} Days</span>
                </div>

                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-center">
                  <span className="text-amber-800 font-bold block text-[11px] uppercase">Total Working Days</span>
                  <span className="text-3xl font-black text-amber-700">{student.totalDays} Days</span>
                </div>

                <div className="p-4 bg-blue-50 border border-blue-200 rounded-2xl text-center">
                  <span className="text-blue-800 font-bold block text-[11px] uppercase">Attendance Percentage</span>
                  <span className="text-3xl font-black text-blue-900">{student.attendancePercentage}%</span>
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Homework */}
          {activeTab === 'homework' && (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
              <h4 className="text-base font-bold text-slate-900">Assigned Homework & Practice</h4>

              <div className="space-y-3">
                {student.homework.map((hw) => (
                  <div
                    key={hw.id}
                    className="p-4 border border-slate-200 rounded-2xl bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <span className="bg-blue-100 text-blue-900 text-[10px] font-black uppercase px-2 py-0.5 rounded">
                        {hw.subject}
                      </span>
                      <h5 className="font-bold text-slate-900 text-sm mt-1">{hw.title}</h5>
                      <span className="text-[11px] text-slate-500 mt-0.5 block">Due Date: {hw.dueDate}</span>
                    </div>

                    <div>
                      {hw.status === 'Submitted' ? (
                        <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Submitted</span>
                        </span>
                      ) : (
                        <span className="bg-amber-100 text-amber-800 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Pending</span>
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 4: Teacher Notes */}
          {activeTab === 'notes' && (
            <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
              <h4 className="text-base font-bold text-slate-900">Class Teacher Remarks</h4>
              <div className="p-5 bg-amber-50/60 border border-amber-200 rounded-2xl text-xs text-amber-950 space-y-2">
                <p className="italic font-medium leading-relaxed">"{student.teacherNotes}"</p>
                <p className="text-right font-extrabold text-amber-900">— {student.classTeacher}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Progress Report PDF Preview Modal */}
      {showReportModal && student && (
        <ProgressReportPdfModal
          student={student}
          onClose={() => setShowReportModal(false)}
        />
      )}
    </div>
  );
};

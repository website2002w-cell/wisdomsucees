import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  X,
  BellRing,
  PhoneCall,
  ChevronRight,
  Info,
  ShieldAlert,
  CalendarX,
  CloudRain,
  CheckCircle2,
  RotateCcw,
} from 'lucide-react';
import { SCHOOL_INFO } from '../data/schoolData';

export interface EmergencyNotice {
  id: string;
  type: 'closure' | 'weather' | 'urgent' | 'advisory';
  title: string;
  message: string;
  affectedGrades: string;
  issuedAt: string;
  issuedBy: string;
  actionRequired?: string;
  emergencyContact: string;
  isHighPriority: boolean;
}

const DEFAULT_EMERGENCY_ALERT: EmergencyNotice = {
  id: 'ALERT-2026-0728',
  type: 'closure',
  title: 'HIGH PRIORITY: Emergency School Closure Notice',
  message: 'As per District Collector guidelines due to heavy monsoon rainfall forecast in Chengalpattu Dist, Wisdom Nursery & Primary School will remain CLOSED on Tuesday, 28-July-2026.',
  affectedGrades: 'All Grades (Nursery to Class 5)',
  issuedAt: '27-Jul-2026, 08:30 PM',
  issuedBy: 'Correspondent R. Saravanan',
  actionRequired: 'All scheduled term tests postponed. Online revision worksheets uploaded to Student Portal.',
  emergencyContact: SCHOOL_INFO.phone,
  isHighPriority: true,
};

interface EmergencyAlertBannerProps {
  setActiveTab?: (tab: string) => void;
}

export const EmergencyAlertBanner: React.FC<EmergencyAlertBannerProps> = ({ setActiveTab }) => {
  const [activeAlert, setActiveAlert] = useState<EmergencyNotice | null>(DEFAULT_EMERGENCY_ALERT);
  const [dismissed, setDismissed] = useState<boolean>(false);
  const [showDetailModal, setShowDetailModal] = useState<boolean>(false);

  // Check localStorage for dismissal
  useEffect(() => {
    const isDismissed = localStorage.getItem('wns_emergency_alert_dismissed');
    if (isDismissed === DEFAULT_EMERGENCY_ALERT.id) {
      setDismissed(true);
    }
  }, []);

  const handleDismiss = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDismissed(true);
    localStorage.setItem('wns_emergency_alert_dismissed', DEFAULT_EMERGENCY_ALERT.id);
  };

  const handleRestoreAlert = () => {
    setDismissed(false);
    localStorage.removeItem('wns_emergency_alert_dismissed');
  };

  if (!activeAlert) return null;

  // Render dismissed pill if parent dismissed it but wants a quick recall option
  if (dismissed) {
    return (
      <div className="bg-red-950 text-white text-xs py-1 px-4 border-b border-red-800 flex items-center justify-between animate-fadeIn">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
          <span className="font-extrabold text-amber-300">Emergency Alert Active:</span>
          <span className="text-slate-200 truncate max-w-xs sm:max-w-md">
            {activeAlert.title}
          </span>
        </div>
        <button
          onClick={handleRestoreAlert}
          className="text-amber-400 hover:text-amber-300 font-bold underline flex items-center gap-1 text-[11px] shrink-0 ml-2"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>View Alert Banner</span>
        </button>
      </div>
    );
  }

  return (
    <>
      {/* High-Priority Dismissible Banner */}
      <div className="bg-gradient-to-r from-red-900 via-rose-950 to-red-900 text-white border-b-2 border-amber-400 shadow-xl relative z-50 animate-fadeIn">
        <div className="max-w-7xl mx-auto px-4 py-2.5 sm:py-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          
          {/* Alert Content & Icon */}
          <div className="flex items-start sm:items-center gap-3 flex-1">
            <div className="p-2 bg-red-600 text-white rounded-xl shadow-lg shrink-0 border border-amber-300/40 animate-bounce">
              {activeAlert.type === 'closure' ? (
                <CalendarX className="w-5 h-5 text-amber-300" />
              ) : activeAlert.type === 'weather' ? (
                <CloudRain className="w-5 h-5 text-amber-300" />
              ) : (
                <ShieldAlert className="w-5 h-5 text-amber-300" />
              )}
            </div>

            <div className="space-y-0.5">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full shadow-sm">
                  Urgent Notice
                </span>
                <span className="text-amber-300 font-black text-xs sm:text-sm tracking-tight">
                  {activeAlert.title}
                </span>
                <span className="text-[10px] text-slate-300 hidden md:inline">
                  • Issued: {activeAlert.issuedAt}
                </span>
              </div>
              <p className="text-xs text-slate-100 font-medium line-clamp-2 sm:line-clamp-1">
                {activeAlert.message}
              </p>
            </div>
          </div>

          {/* Action & Dismiss Buttons */}
          <div className="flex items-center gap-2 self-end sm:self-center shrink-0 w-full sm:w-auto justify-between sm:justify-end border-t sm:border-t-0 border-red-800/80 pt-2 sm:pt-0">
            <button
              onClick={() => setShowDetailModal(true)}
              className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black rounded-xl transition shadow flex items-center gap-1.5 shrink-0"
            >
              <Info className="w-3.5 h-3.5 text-slate-950" />
              <span>Full Notice Details</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={handleDismiss}
              className="p-1.5 bg-red-950/80 hover:bg-red-800 text-slate-300 hover:text-white rounded-xl border border-red-700/60 transition flex items-center gap-1 text-xs px-2.5"
              title="Dismiss banner"
            >
              <X className="w-4 h-4 text-slate-200" />
              <span className="hidden lg:inline text-[11px] font-bold">Dismiss</span>
            </button>
          </div>

        </div>
      </div>

      {/* Emergency Notice Detail Modal */}
      {showDetailModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white text-slate-900 rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl border-4 border-red-600 relative overflow-hidden">
            {/* Top Decorative Alert Bar */}
            <div className="absolute top-0 left-0 right-0 h-3 bg-gradient-to-r from-red-600 via-amber-400 to-red-600" />

            <button
              onClick={() => setShowDetailModal(false)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="flex items-center gap-3">
              <div className="p-3 bg-red-100 text-red-700 rounded-2xl border border-red-200">
                <AlertTriangle className="w-7 h-7 text-red-600" />
              </div>
              <div>
                <span className="bg-red-100 text-red-800 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border border-red-300">
                  Official Emergency Bulletin
                </span>
                <h3 className="text-xl font-extrabold text-slate-950 leading-tight mt-0.5">
                  {activeAlert.title}
                </h3>
              </div>
            </div>

            {/* Content Details Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-xs sm:text-sm">
              <div className="space-y-1">
                <span className="font-bold text-slate-500 uppercase text-[10px] tracking-wider block">
                  Alert Message:
                </span>
                <p className="text-slate-800 font-medium leading-relaxed">
                  {activeAlert.message}
                </p>
              </div>

              {activeAlert.actionRequired && (
                <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl space-y-1 text-amber-950">
                  <span className="font-black text-amber-900 text-xs flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-amber-700" />
                    Instructions for Parents & Students:
                  </span>
                  <p className="text-xs text-amber-900 font-medium">
                    {activeAlert.actionRequired}
                  </p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2 text-xs border-t border-slate-200 pt-3 text-slate-600">
                <div>
                  <span className="font-bold block text-slate-800">Affected Classes:</span>
                  <span>{activeAlert.affectedGrades}</span>
                </div>
                <div>
                  <span className="font-bold block text-slate-800">Issued By:</span>
                  <span>{activeAlert.issuedBy}</span>
                </div>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-2 pt-1">
              <a
                href={`tel:${activeAlert.emergencyContact}`}
                className="w-full sm:w-auto flex-1 py-2.5 px-4 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition flex items-center justify-center gap-2 shadow"
              >
                <PhoneCall className="w-4 h-4 text-amber-300" />
                <span>Call Emergency Line (+91 {activeAlert.emergencyContact})</span>
              </a>

              {setActiveTab && (
                <button
                  onClick={() => {
                    setShowDetailModal(false);
                    setActiveTab('notices');
                  }}
                  className="w-full sm:w-auto py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs rounded-xl transition flex items-center justify-center gap-1.5"
                >
                  <BellRing className="w-4 h-4" />
                  <span>View Noticeboard</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

import React, { useState } from 'react';
import {
  CreditCard,
  Printer,
  RotateCw,
  ShieldCheck,
  Upload,
  QrCode,
  CheckCircle2,
  Scan,
  Maximize2,
  X,
  Sparkles,
  Bus,
  Clock,
  Building2,
  Send,
  Radio,
} from 'lucide-react';
import { StudentProfile } from '../types';
import { SCHOOL_INFO, DEFAULT_STUDENT_PROFILE } from '../data/schoolData';

interface StudentIdCardProps {
  student?: StudentProfile | null;
}

interface ScanLog {
  id: string;
  time: string;
  location: string;
  type: 'Gate Entry' | 'School Bus' | 'Library' | 'Gate Exit';
  status: 'Verified';
}

export const StudentIdCard: React.FC<StudentIdCardProps> = ({ student: inputStudent }) => {
  const student = inputStudent || DEFAULT_STUDENT_PROFILE;
  const [isFlipped, setIsFlipped] = useState(false);
  const [customPhotoUrl, setCustomPhotoUrl] = useState<string | null>(null);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [fullScreenQr, setFullScreenQr] = useState(false);

  // Scan simulation state
  const [scanning, setScanning] = useState(false);
  const [lastScanResult, setLastScanResult] = useState<ScanLog | null>(null);
  const [scanHistory, setScanHistory] = useState<ScanLog[]>([
    {
      id: 'scan-1',
      time: 'Today, 08:32 AM',
      location: 'Gate 1 (Main Campus)',
      type: 'Gate Entry',
      status: 'Verified',
    },
    {
      id: 'scan-2',
      time: 'Yesterday, 03:45 PM',
      location: 'School Van #TN21-A-402',
      type: 'School Bus',
      status: 'Verified',
    },
    {
      id: 'scan-3',
      time: '24 Jul 2026, 11:15 AM',
      location: 'Junior Library Hall',
      type: 'Library',
      status: 'Verified',
    },
  ]);

  const defaultPhoto = `https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=300&q=80`;

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCustomPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleDownloadCard = () => {
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 4000);
    window.print();
  };

  const handleSimulateScan = () => {
    setScanning(true);
    setTimeout(() => {
      const now = new Date();
      const timeStr = `Today, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}`;
      const newScan: ScanLog = {
        id: `scan-${Date.now()}`,
        time: timeStr,
        location: 'Gate 1 (Main Entrance - Essur)',
        type: 'Gate Entry',
        status: 'Verified',
      };
      setLastScanResult(newScan);
      setScanHistory((prev) => [newScan, ...prev]);
      setScanning(false);
    }, 1200);
  };

  const activePhoto = customPhotoUrl || defaultPhoto;
  const qrDataUrl = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=WNS:STUDENT:${student.id}:NAME=${encodeURIComponent(student.name)}:GRADE=${encodeURIComponent(student.grade)}`;

  return (
    <div className="space-y-6">
      {/* Top Banner & Control Bar */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="bg-purple-100 text-purple-900 text-[10px] font-black uppercase px-2.5 py-1 rounded-full border border-purple-200 inline-flex items-center gap-1 mb-1">
            <CreditCard className="w-3 h-3 text-purple-800" />
            Verified Digital Student Badge
          </span>
          <h3 className="text-lg font-extrabold text-blue-950">
            Digital School ID Card & QR Check-In
          </h3>
          <p className="text-xs text-slate-500">
            Official digital identity badge for academic year 2026-2027 with instant QR barcode for campus check-ins.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-bold shrink-0">
          <button
            onClick={() => setIsFlipped(!isFlipped)}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 transition flex items-center gap-1.5"
          >
            <RotateCw className="w-3.5 h-3.5 text-blue-900" />
            <span>{isFlipped ? 'Show Front' : 'Flip to Back'}</span>
          </button>

          <button
            onClick={() => setFullScreenQr(true)}
            className="px-3.5 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 transition flex items-center gap-1.5"
          >
            <Maximize2 className="w-3.5 h-3.5 text-emerald-700" />
            <span>Campus QR Scanner Mode</span>
          </button>

          <label className="px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-blue-950 transition flex items-center gap-1.5 cursor-pointer shadow-sm">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Photo</span>
            <input
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />
          </label>

          <button
            onClick={handleDownloadCard}
            className="px-4 py-2 rounded-xl bg-blue-900 hover:bg-blue-800 text-white transition flex items-center gap-1.5 shadow"
          >
            <Printer className="w-3.5 h-3.5 text-amber-300" />
            <span>Print / Save Badge</span>
          </button>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-800 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Print dialog opened! You can select "Save as PDF" to download the digital ID card.</span>
        </div>
      )}

      {/* TWO COLUMN DISPLAY: 3D ID CARD & QR CHECK-IN PANEL */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: 3D FLIPPABLE DIGITAL ID BADGE */}
        <div className="lg:col-span-6 flex flex-col items-center">
          <div className="w-full max-w-md perspective">
            <div
              className={`transition-all duration-500 transform-style-3d ${
                isFlipped ? 'rotate-y-180' : ''
              }`}
            >
              {!isFlipped ? (
                /* FRONT OF ID CARD */
                <div className="w-full bg-gradient-to-b from-blue-950 via-slate-900 to-indigo-950 rounded-3xl p-6 text-white shadow-2xl border-2 border-amber-400 relative overflow-hidden space-y-5">
                  {/* Holographic Watermark Background */}
                  <div className="absolute -top-12 -right-12 w-40 h-40 bg-amber-400/10 rounded-full blur-2xl pointer-events-none"></div>
                  <div className="absolute -bottom-12 -left-12 w-40 h-40 bg-purple-500/10 rounded-full blur-2xl pointer-events-none"></div>

                  {/* School Header */}
                  <div className="text-center border-b border-amber-400/30 pb-3 space-y-1">
                    <div className="flex items-center justify-center space-x-2">
                      <img
                        src={SCHOOL_INFO.logoUrl}
                        alt={SCHOOL_INFO.name}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-full border border-amber-400 bg-white p-0.5 shadow shrink-0 object-contain"
                      />
                      <div className="text-left">
                        <span className="font-extrabold text-sm sm:text-base text-amber-300 tracking-wide block leading-tight">
                          WISDOM SCHOOL ESSUR
                        </span>
                        <span className="text-[9px] text-slate-300 font-semibold uppercase tracking-wider block">
                          Nursery & Primary School
                        </span>
                      </div>
                    </div>
                    <p className="text-[9px] text-amber-400/90 italic font-bold pt-0.5">
                      "{SCHOOL_INFO.motto}"
                    </p>
                  </div>

                  {/* Photo & Details Grid */}
                  <div className="grid grid-cols-12 gap-3 items-center">
                    {/* Student Photo Column */}
                    <div className="col-span-5 text-center space-y-2">
                      <div className="relative w-28 h-32 mx-auto rounded-2xl overflow-hidden border-2 border-amber-400 shadow-lg bg-slate-800">
                        <img
                          src={activePhoto}
                          alt={student.name}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-0 inset-x-0 bg-blue-950/85 backdrop-blur-xs py-0.5 text-[9px] font-bold text-amber-300 uppercase">
                          STUDENT
                        </div>
                      </div>
                      <span className="inline-block bg-amber-400 text-blue-950 font-black text-[10px] px-2.5 py-0.5 rounded-full shadow">
                        Academic 2026-27
                      </span>
                    </div>

                    {/* Details Column */}
                    <div className="col-span-7 space-y-1.5 text-xs">
                      <div>
                        <span className="text-[9px] text-slate-400 uppercase font-extrabold block">
                          Student Name
                        </span>
                        <h4 className="font-extrabold text-base text-white tracking-tight">
                          {student.name}
                        </h4>
                      </div>

                      <div className="grid grid-cols-2 gap-1 text-[11px]">
                        <div>
                          <span className="text-[9px] text-slate-400 uppercase font-extrabold block">
                            Grade
                          </span>
                          <span className="font-bold text-amber-300">{student.grade}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 uppercase font-extrabold block">
                            Roll No
                          </span>
                          <span className="font-bold text-white">{student.rollNo}</span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-1 text-[11px]">
                        <div>
                          <span className="text-[9px] text-slate-400 uppercase font-extrabold block">
                            Blood Group
                          </span>
                          <span className="font-extrabold text-red-400">{student.bloodGroup}</span>
                        </div>
                        <div>
                          <span className="text-[9px] text-slate-400 uppercase font-extrabold block">
                            Parent Name
                          </span>
                          <span className="font-medium text-slate-200 truncate block">
                            {student.fatherName}
                          </span>
                        </div>
                      </div>

                      <div>
                        <span className="text-[9px] text-slate-400 uppercase font-extrabold block">
                          Student Reg. ID
                        </span>
                        <span className="font-mono font-bold text-xs text-amber-300 bg-blue-900/60 px-2 py-0.5 rounded border border-blue-700 inline-block">
                          {student.id}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Card Footer: Embedded QR & Principal Stamp */}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
                    <div className="flex items-center space-x-2 bg-white/10 p-1.5 rounded-xl border border-white/10">
                      <img
                        src={qrDataUrl}
                        alt="Student QR Code"
                        className="w-9 h-9 rounded bg-white p-0.5 shrink-0 object-contain"
                      />
                      <div>
                        <span className="text-[8px] text-slate-300 font-bold block uppercase">
                          Campus Gate Scan
                        </span>
                        <span className="font-mono font-bold text-amber-300 text-[9px]">
                          VALID 2026-27
                        </span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="font-serif italic text-[11px] text-amber-300 font-bold">
                        R. Saravanan
                      </div>
                      <span className="text-[8px] uppercase font-extrabold text-slate-400 block border-t border-slate-700 pt-0.5">
                        Admin Signature
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                /* BACK OF ID CARD */
                <div className="w-full bg-slate-900 rounded-3xl p-6 text-white shadow-2xl border-2 border-amber-400 relative overflow-hidden space-y-4">
                  <div className="border-b border-slate-800 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 text-amber-300 text-xs font-bold">
                      <ShieldCheck className="w-4 h-4" />
                      <span>EMERGENCY & SCHOOL INFO</span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-mono">ID: {student.id}</span>
                  </div>

                  <div className="space-y-3 text-xs">
                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-400 block">
                        Class Teacher
                      </span>
                      <p className="font-semibold text-slate-200">{student.classTeacher}</p>
                    </div>

                    <div>
                      <span className="text-[9px] uppercase font-bold text-slate-400 block">
                        Residential Address
                      </span>
                      <p className="font-medium text-slate-300 text-[11px]">
                        Essur Village, Kanchipuram / Chengalpattu District, Tamil Nadu - 603301.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="p-2 bg-slate-800 rounded-xl border border-slate-700">
                        <span className="text-[8px] uppercase font-bold text-amber-300 block">
                          School Helpline
                        </span>
                        <span className="font-bold text-white text-[10px]">{SCHOOL_INFO.phone}</span>
                      </div>

                      <div className="p-2 bg-slate-800 rounded-xl border border-slate-700">
                        <span className="text-[8px] uppercase font-bold text-amber-300 block">
                          Blood Group
                        </span>
                        <span className="font-bold text-red-400 text-[10px]">
                          {student.bloodGroup} (Emergency)
                        </span>
                      </div>
                    </div>

                    <div className="p-2.5 bg-blue-950/60 rounded-xl border border-blue-800 text-[10px] text-slate-300 space-y-1">
                      <p className="font-bold text-amber-300 uppercase text-[9px]">Instructions:</p>
                      <ul className="list-disc list-inside space-y-0.5 text-[9.5px]">
                        <li>This card must be presented at school entrance gate & van pickup.</li>
                        <li>If found, please return to Wisdom School Admin Office, Essur - 603301.</li>
                      </ul>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-800 text-center">
                    <p className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">
                      Wisdom Nursery and Primary School • Essur - 603301
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: DYNAMIC QR CODE & CAMPUS GATE CHECK-IN SIMULATOR */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-blue-100 text-blue-900 rounded-xl">
                  <QrCode className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">Campus Check-In QR Code</h4>
                  <p className="text-xs text-slate-500">Scan at campus entrance gate or school bus van</p>
                </div>
              </div>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full border border-emerald-200 flex items-center gap-1">
                <Radio className="w-3 h-3 text-emerald-600 animate-pulse" />
                <span>Live Token</span>
              </span>
            </div>

            {/* Main QR Code Canvas Box */}
            <div className="flex flex-col sm:flex-row items-center gap-6 bg-slate-50 p-5 rounded-2xl border border-slate-200">
              <div className="relative shrink-0">
                <div className="p-3 bg-white rounded-2xl border-2 border-blue-900 shadow-md">
                  <img
                    src={qrDataUrl}
                    alt="Digital Checkin QR Code"
                    className="w-36 h-36 object-contain"
                  />
                </div>
                <div className="absolute -bottom-2 -right-2 bg-amber-400 text-blue-950 font-black text-[9px] px-2 py-0.5 rounded-full border border-amber-500 shadow">
                  2026-27
                </div>
              </div>

              <div className="space-y-3 text-xs w-full">
                <div>
                  <span className="text-slate-500 text-[10px] uppercase font-bold block">
                    Student Authentication Payload
                  </span>
                  <code className="font-mono text-[10px] bg-slate-900 text-amber-300 px-2.5 py-1.5 rounded-xl block overflow-x-auto break-all border border-slate-800">
                    WNS:CHECKIN:{student.id}:{student.grade}
                  </code>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2 bg-white rounded-xl border border-slate-200">
                    <span className="text-[9px] text-slate-400 font-bold block uppercase">Campus Security</span>
                    <span className="font-extrabold text-blue-950">Gate 1 & Van #1</span>
                  </div>
                  <div className="p-2 bg-white rounded-xl border border-slate-200">
                    <span className="text-[9px] text-slate-400 font-bold block uppercase">Status</span>
                    <span className="font-extrabold text-emerald-600">Active Check-In</span>
                  </div>
                </div>

                {/* Simulate Gate Scanner Button */}
                <button
                  onClick={handleSimulateScan}
                  disabled={scanning}
                  className="w-full bg-blue-950 hover:bg-blue-900 text-white font-extrabold py-2.5 rounded-xl text-xs transition flex items-center justify-center gap-2 shadow"
                >
                  <Scan className="w-4 h-4 text-amber-400" />
                  <span>{scanning ? 'Scanning QR Code at Gate...' : 'Simulate Campus Gate Check-In'}</span>
                </button>
              </div>
            </div>

            {/* Scan Feedback Banner */}
            {lastScanResult && (
              <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-2xl space-y-2 animate-fadeIn">
                <div className="flex items-center justify-between text-xs font-bold text-emerald-900">
                  <span className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Gate Scan Verified! Student Checked-In</span>
                  </span>
                  <span className="text-[10px] text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                    {lastScanResult.time}
                  </span>
                </div>
                <p className="text-xs text-emerald-800">
                  <strong>{student.name} ({student.grade})</strong> successfully scanned at <strong>{lastScanResult.location}</strong>. Automatic parent SMS notification triggered!
                </p>
              </div>
            )}

            {/* Recent Check-In History Log */}
            <div className="space-y-2">
              <h5 className="font-extrabold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-900" />
                <span>Recent Campus Check-In History</span>
              </h5>

              <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-white">
                {scanHistory.map((log) => (
                  <div key={log.id} className="p-3 text-xs flex items-center justify-between hover:bg-slate-50 transition">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 bg-blue-50 text-blue-900 rounded-lg">
                        {log.type === 'School Bus' ? <Bus className="w-3.5 h-3.5" /> : <Building2 className="w-3.5 h-3.5" />}
                      </div>
                      <div>
                        <span className="font-bold text-slate-900 block leading-tight">{log.location}</span>
                        <span className="text-[10px] text-slate-500">{log.time}</span>
                      </div>
                    </div>

                    <span className="bg-emerald-100 text-emerald-800 font-extrabold text-[10px] px-2 py-0.5 rounded-full">
                      {log.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* FULL SCREEN / LARGE QR SCAN MODAL */}
      {fullScreenQr && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-sm w-full text-center space-y-6 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setFullScreenQr(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <span className="bg-blue-100 text-blue-900 text-[10px] font-black uppercase px-2.5 py-1 rounded-full">
                Wisdom School Gate Scanner
              </span>
              <h3 className="text-xl font-extrabold text-blue-950">{student.name}</h3>
              <p className="text-xs text-slate-500">Class: {student.grade} | Reg ID: {student.id}</p>
            </div>

            <div className="p-4 bg-slate-900 rounded-2xl border-4 border-amber-400 inline-block shadow-inner">
              <img
                src={qrDataUrl}
                alt="Full screen QR code"
                className="w-56 h-56 mx-auto object-contain bg-white p-2 rounded-xl"
              />
            </div>

            <p className="text-xs text-slate-600 font-medium">
              Hold this QR code steady in front of the security gate scanner or school bus conductor tablet to register entry.
            </p>

            <button
              onClick={() => setFullScreenQr(false)}
              className="w-full bg-blue-900 text-white font-extrabold py-3 rounded-xl text-xs hover:bg-blue-800 transition"
            >
              Close Scanner Mode
            </button>
          </div>
        </div>
      )}
    </div>
  );
};


import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import {
  FileSpreadsheet,
  Upload,
  Download,
  CheckCircle2,
  AlertTriangle,
  X,
  Users,
  Sparkles,
  FileText,
  Trash2,
  RefreshCw,
  Search,
  Check,
  ShieldAlert,
  ArrowRight,
  Database,
} from 'lucide-react';

export interface ExcelStudentRow {
  id?: string;
  name: string;
  grade: string;
  rollNo?: string;
  phone: string;
  dob: string;
  fatherName?: string;
  motherName?: string;
  classTeacher?: string;
  bloodGroup?: string;
  feeStatus?: string;
  importantTag?: string;
  status?: 'valid' | 'warning' | 'error';
  validationMessage?: string;
}

interface StudentExcelImporterProps {
  isOpen: boolean;
  onClose: () => void;
  onImportSuccess?: (importedStudents: ExcelStudentRow[]) => void;
}

const SAMPLE_TEMPLATE_DATA = [
  {
    'Student Reg ID': 'WNS-2026-05',
    'Student Name': 'A. Dhruv',
    'Class / Grade': 'Class 3 - A',
    'Roll No': '05',
    'Parent Phone': '9876543215',
    'Date of Birth (YYYY-MM-DD)': '2018-04-10',
    'Father Name': 'A. Anand',
    'Mother Name': 'A. Deepa',
    'Class Teacher': 'Mrs. Anita Ramesh',
    'Blood Group': 'O+',
    'Fee Status': 'Paid for Term 1',
    'Important Tag': 'RTE Admission, Bus Route 1',
  },
  {
    'Student Reg ID': 'WNS-2026-06',
    'Student Name': 'M. Kavya',
    'Class / Grade': 'Class 4 - B',
    'Roll No': '12',
    'Parent Phone': '9876543216',
    'Date of Birth (YYYY-MM-DD)': '2017-09-22',
    'Father Name': 'M. Murali',
    'Mother Name': 'M. Vimala',
    'Class Teacher': 'Mr. P. Ramesh',
    'Blood Group': 'A+',
    'Fee Status': 'Pending Term 2',
    'Important Tag': 'Scholarship Holder',
  },
  {
    'Student Reg ID': 'WNS-2026-07',
    'Student Name': 'S. Harish',
    'Class / Grade': 'LKG - Blossom',
    'Roll No': '08',
    'Parent Phone': '9876543217',
    'Date of Birth (YYYY-MM-DD)': '2021-02-18',
    'Father Name': 'S. Siva',
    'Mother Name': 'S. Radha',
    'Class Teacher': 'Mrs. V. Radha',
    'Blood Group': 'B+',
    'Fee Status': 'Paid Full Year',
    'Important Tag': 'Van Drop-Off Essur',
  },
];

export const StudentExcelImporter: React.FC<StudentExcelImporterProps> = ({
  isOpen,
  onClose,
  onImportSuccess,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>('');
  const [parsedRows, setParsedRows] = useState<ExcelStudentRow[]>([]);
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [isDragOver, setIsDragOver] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [importing, setImporting] = useState<boolean>(false);
  const [importSuccessMsg, setImportSuccessMsg] = useState<string>('');
  const [filterMode, setFilterMode] = useState<'all' | 'valid' | 'warning'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  // Generate and download standard Excel Template (.xlsx)
  const handleDownloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet(SAMPLE_TEMPLATE_DATA);

    // Styling column widths roughly
    ws['!cols'] = [
      { wch: 18 },
      { wch: 22 },
      { wch: 18 },
      { wch: 10 },
      { wch: 16 },
      { wch: 24 },
      { wch: 18 },
      { wch: 18 },
      { wch: 20 },
      { wch: 14 },
      { wch: 18 },
      { wch: 25 },
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Student Import Template');

    XLSX.writeFile(wb, 'Wisdom_School_Student_Import_Template.xlsx');
  };

  // Process File buffer
  const processExcelBuffer = (buffer: ArrayBuffer, name: string) => {
    setIsProcessing(true);
    setFileName(name);
    setImportSuccessMsg('');

    try {
      const workbook = XLSX.read(buffer, { type: 'array' });
      const firstSheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[firstSheetName];

      const rawJson = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

      if (rawJson.length === 0) {
        alert('The uploaded Excel sheet contains no data rows.');
        setIsProcessing(false);
        return;
      }

      // Collect headers
      const headers = Object.keys(rawJson[0]);
      setRawHeaders(headers);

      // Map rows into standardized ExcelStudentRow objects
      const formattedRows: ExcelStudentRow[] = rawJson.map((row, idx) => {
        // Flexibly map column keys
        const getVal = (possibleKeys: string[]) => {
          for (const key of Object.keys(row)) {
            if (possibleKeys.some((pk) => key.toLowerCase().includes(pk.toLowerCase()))) {
              return String(row[key]).trim();
            }
          }
          return '';
        };

        const id = getVal(['id', 'reg', 'student reg', 'roll']) || `WNS-2026-${100 + idx}`;
        const nameVal = getVal(['name', 'student name']) || `Student ${idx + 1}`;
        const gradeVal = getVal(['class', 'grade', 'standard']) || 'Class 3';
        const rollNoVal = getVal(['roll']) || String(idx + 1);
        const phoneVal = getVal(['phone', 'mobile', 'contact', 'parent phone']) || '9876543210';
        const dobVal = getVal(['dob', 'birth', 'date of birth']) || '2018-06-15';
        const fatherVal = getVal(['father']) || 'Parent';
        const motherVal = getVal(['mother']) || 'Parent';
        const teacherVal = getVal(['teacher']) || 'Mrs. Anita Ramesh';
        const bloodVal = getVal(['blood']) || 'O+';
        const feeVal = getVal(['fee', 'payment']) || 'Paid';
        const tagVal = getVal(['tag', 'note', 'important', 'remarks']) || 'Excel Batch Uploaded';

        let status: 'valid' | 'warning' | 'error' = 'valid';
        let msg = 'Ready for import';

        if (!nameVal || nameVal.length < 2) {
          status = 'warning';
          msg = 'Student name missing or short';
        } else if (!phoneVal || phoneVal.replace(/\D/g, '').length < 10) {
          status = 'warning';
          msg = 'Mobile phone number less than 10 digits';
        } else if (!dobVal) {
          status = 'warning';
          msg = 'Missing Date of Birth (DOB)';
        }

        return {
          id,
          name: nameVal,
          grade: gradeVal,
          rollNo: rollNoVal,
          phone: phoneVal,
          dob: dobVal,
          fatherName: fatherVal,
          motherName: motherVal,
          classTeacher: teacherVal,
          bloodGroup: bloodVal,
          feeStatus: feeVal,
          importantTag: tagVal,
          status,
          validationMessage: msg,
        };
      });

      setParsedRows(formattedRows);
    } catch (err) {
      console.error('Failed to parse Excel file:', err);
      alert('Error parsing Excel file. Please ensure it is a valid .xlsx, .xls, or .csv file.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      if (evt.target?.result) {
        processExcelBuffer(evt.target.result as ArrayBuffer, file.name);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      if (evt.target?.result) {
        processExcelBuffer(evt.target.result as ArrayBuffer, file.name);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDeleteRow = (index: number) => {
    setParsedRows((prev) => prev.filter((_, i) => i !== index));
  };

  const handleImportToBackend = async () => {
    if (parsedRows.length === 0) {
      alert('No rows available to import.');
      return;
    }

    setImporting(true);
    try {
      const res = await fetch('/api/admin/students/batch-upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ students: parsedRows }),
      });

      const data = await res.json();
      if (data.success) {
        setImportSuccessMsg(
          `✓ Success! ${data.importedCount || parsedRows.length} student records imported to Wisdom Student Directory!`
        );
        if (onImportSuccess) {
          onImportSuccess(parsedRows);
        }
        setTimeout(() => {
          onClose();
        }, 2000);
      } else {
        alert(data.message || 'Failed to batch upload student records.');
      }
    } catch (err) {
      console.error('Batch import failed:', err);
      // Fallback local notification
      setImportSuccessMsg(`✓ Success! ${parsedRows.length} student records batch added locally!`);
      if (onImportSuccess) {
        onImportSuccess(parsedRows);
      }
      setTimeout(() => {
        onClose();
      }, 2000);
    } finally {
      setImporting(false);
    }
  };

  const filteredData = parsedRows.filter((r) => {
    if (filterMode === 'valid' && r.status !== 'valid') return false;
    if (filterMode === 'warning' && r.status !== 'warning') return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        r.name.toLowerCase().includes(q) ||
        r.id?.toLowerCase().includes(q) ||
        r.grade.toLowerCase().includes(q) ||
        r.phone.includes(q)
      );
    }
    return true;
  });

  const validCount = parsedRows.filter((r) => r.status === 'valid').length;
  const warningCount = parsedRows.filter((r) => r.status === 'warning').length;

  return (
    <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-slate-900 text-white border-2 border-amber-400/80 rounded-3xl max-w-4xl w-full shadow-2xl relative overflow-hidden my-auto">
        {/* Header Bar */}
        <div className="bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-emerald-500/20 text-emerald-300 rounded-2xl border border-emerald-400/30">
              <FileSpreadsheet className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                <span>Important Student Records Excel Importer</span>
                <span className="bg-emerald-400 text-blue-950 text-[10px] font-black px-2 py-0.5 rounded-full uppercase">
                  Batch Parser
                </span>
              </h2>
              <p className="text-xs text-slate-300">
                Bulk upload student data, parent contact numbers, roll numbers & fees from .xlsx or .csv
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-full bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {/* Top Actions: File Upload Drop Zone & Template Download */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Download Template Card */}
            <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 flex flex-col justify-between space-y-3">
              <div>
                <div className="flex items-center gap-2 text-amber-300 font-extrabold text-xs">
                  <Download className="w-4 h-4 text-amber-400" />
                  <span>Standard Excel Template</span>
                </div>
                <p className="text-[11px] text-slate-300 mt-1">
                  Download pre-formatted Excel template (.xlsx) with pre-filled sample student records.
                </p>
              </div>

              <button
                onClick={handleDownloadTemplate}
                className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl shadow transition flex items-center justify-center gap-1.5"
              >
                <FileSpreadsheet className="w-4 h-4 text-blue-950" />
                <span>Download .xlsx Template</span>
              </button>
            </div>

            {/* Drag & Drop File Input */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragOver(true);
              }}
              onDragLeave={() => setIsDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`md:col-span-2 border-2 border-dashed rounded-2xl p-6 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-2 ${
                isDragOver
                  ? 'border-amber-400 bg-amber-400/10'
                  : 'border-slate-700 hover:border-slate-500 bg-slate-800/40'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx, .xls, .csv"
                onChange={handleFileUpload}
                className="hidden"
              />

              <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-full border border-emerald-400/30">
                <Upload className="w-6 h-6 animate-pulse" />
              </div>

              <div>
                <span className="font-extrabold text-white text-xs block">
                  Click to select or Drag & Drop Excel File here
                </span>
                <span className="text-[10px] text-slate-400">
                  Supports Microsoft Excel (.xlsx, .xls) and CSV (.csv) files
                </span>
              </div>

              {fileName && (
                <span className="bg-emerald-500/20 text-emerald-300 text-[11px] font-mono font-bold px-3 py-1 rounded-full border border-emerald-400/30">
                  Selected File: {fileName}
                </span>
              )}
            </div>
          </div>

          {importSuccessMsg && (
            <div className="p-4 bg-emerald-500/20 border border-emerald-400 text-emerald-300 rounded-2xl text-xs font-bold flex items-center gap-3 animate-fadeIn">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
              <span>{importSuccessMsg}</span>
            </div>
          )}

          {/* Parsed Preview Section */}
          {parsedRows.length > 0 && (
            <div className="space-y-4">
              {/* Summary Metrics Bar */}
              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-4 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Loaded</span>
                    <strong className="text-white text-base font-black">{parsedRows.length} Students</strong>
                  </div>

                  <div className="h-8 w-px bg-slate-700"></div>

                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Valid Records</span>
                    <strong className="text-emerald-400 text-base font-black">{validCount} Ready</strong>
                  </div>

                  <div className="h-8 w-px bg-slate-700"></div>

                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Warnings / Fixes</span>
                    <strong className="text-amber-400 text-base font-black">{warningCount} Rows</strong>
                  </div>
                </div>

                {/* Filter and Search controls */}
                <div className="flex items-center space-x-2 w-full sm:w-auto">
                  <div className="relative flex-1 sm:w-48">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search preview..."
                      className="w-full text-xs font-bold pl-8 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>

                  <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-700 text-[11px]">
                    <button
                      onClick={() => setFilterMode('all')}
                      className={`px-2.5 py-1 rounded-lg font-extrabold ${
                        filterMode === 'all' ? 'bg-amber-400 text-blue-950' : 'text-slate-300'
                      }`}
                    >
                      All ({parsedRows.length})
                    </button>
                    <button
                      onClick={() => setFilterMode('valid')}
                      className={`px-2.5 py-1 rounded-lg font-extrabold ${
                        filterMode === 'valid' ? 'bg-emerald-400 text-blue-950' : 'text-slate-300'
                      }`}
                    >
                      Valid ({validCount})
                    </button>
                  </div>
                </div>
              </div>

              {/* Data Table Preview */}
              <div className="border border-slate-800 rounded-2xl overflow-hidden bg-slate-950">
                <div className="max-h-64 overflow-y-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900 text-amber-300 font-black uppercase text-[10px] tracking-wider sticky top-0 border-b border-slate-800">
                      <tr>
                        <th className="px-3 py-2.5">Status</th>
                        <th className="px-3 py-2.5">Reg ID</th>
                        <th className="px-3 py-2.5">Student Name</th>
                        <th className="px-3 py-2.5">Class / Grade</th>
                        <th className="px-3 py-2.5">Parent Phone</th>
                        <th className="px-3 py-2.5">DOB</th>
                        <th className="px-3 py-2.5">Important Tag</th>
                        <th className="px-3 py-2.5 text-right">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 font-medium">
                      {filteredData.map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-900/80 transition">
                          <td className="px-3 py-2">
                            {row.status === 'valid' ? (
                              <span className="inline-flex items-center gap-1 bg-emerald-500/20 text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-400/30">
                                <Check className="w-3 h-3 text-emerald-400" /> Valid
                              </span>
                            ) : (
                              <span
                                className="inline-flex items-center gap-1 bg-amber-500/20 text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-400/30"
                                title={row.validationMessage}
                              >
                                <AlertTriangle className="w-3 h-3 text-amber-400" /> {row.validationMessage}
                              </span>
                            )}
                          </td>
                          <td className="px-3 py-2 font-mono text-amber-300 text-[11px]">{row.id}</td>
                          <td className="px-3 py-2 font-extrabold text-white">{row.name}</td>
                          <td className="px-3 py-2 text-slate-300">{row.grade}</td>
                          <td className="px-3 py-2 font-mono text-slate-300">{row.phone}</td>
                          <td className="px-3 py-2 text-slate-300">{row.dob}</td>
                          <td className="px-3 py-2">
                            <span className="bg-blue-950 text-blue-300 text-[10px] px-2 py-0.5 rounded border border-blue-800">
                              {row.importantTag}
                            </span>
                          </td>
                          <td className="px-3 py-2 text-right">
                            <button
                              onClick={() => handleDeleteRow(idx)}
                              className="p-1 text-red-400 hover:text-red-300 rounded hover:bg-red-950/50 transition"
                              title="Remove row"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Confirm Import Footer Bar */}
              <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-xs text-slate-400">
                  Ready to add <strong>{parsedRows.length} student profiles</strong> into Wisdom School database.
                </span>

                <button
                  onClick={handleImportToBackend}
                  disabled={importing}
                  className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-blue-950 font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2 transform active:scale-98"
                >
                  <Database className="w-4 h-4 text-blue-950" />
                  <span>{importing ? 'Importing Batch...' : `Batch Import ${parsedRows.length} Students`}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  FileText,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  AlertCircle,
  Eye,
  Download,
  Info,
  Sparkles,
  Camera,
  ShieldCheck,
  Award,
  Layers,
  HelpCircle,
  ExternalLink,
  Upload,
  Check,
  FileCheck,
  QrCode,
  GraduationCap,
} from 'lucide-react';

export interface DocumentGuideItem {
  id: string;
  title: string;
  tamilTitle: string;
  category: 'Identity' | 'Academic' | 'Medical' | 'Category';
  mandatoryFor: string[]; // e.g. ['LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5']
  optionalFor?: string[];
  maxSize: string;
  formats: string[];
  description: string;
  specimenType: 'birth_cert' | 'aadhaar' | 'photo' | 'tc' | 'community' | 'blood_group' | 'marksheet';
  keyCheckpoints: string[];
  whereToGet: string;
  digiLockerAvailable: boolean;
}

export const DOCUMENT_GUIDE_DATA: DocumentGuideItem[] = [
  {
    id: 'doc-birth-cert',
    title: 'Child Birth Certificate',
    tamilTitle: 'குழந்தையின் பிறப்புச் சான்றிதழ்',
    category: 'Identity',
    mandatoryFor: ['Pre-Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'],
    maxSize: '5 MB',
    formats: ['PDF', 'JPG', 'PNG'],
    description: 'Official birth certificate issued by Municipal Corporation, Town Panchayat, or e-Sevai portal in Tamil Nadu.',
    specimenType: 'birth_cert',
    keyCheckpoints: [
      "Child's full name must be spelled correctly",
      "Date of birth must match admission register entry",
      "Registration Number & Official Registrar Seal must be clearly visible",
      "Parent names must match Aadhaar card records",
    ],
    whereToGet: 'Town Panchayat / Village Office in Essur or Tamil Nadu e-district portal (crstn.org)',
    digiLockerAvailable: true,
  },
  {
    id: 'doc-aadhaar',
    title: "Child / Parent Aadhaar Card Copy",
    tamilTitle: 'குழந்தை / பெற்றோர் ஆதார் அட்டை',
    category: 'Identity',
    mandatoryFor: ['Pre-Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'],
    maxSize: '5 MB',
    formats: ['PDF', 'JPG', 'PNG'],
    description: 'Front and back scan copy of child or parent Aadhaar card for government student identification & EMIS linking.',
    specimenType: 'aadhaar',
    keyCheckpoints: [
      '12-Digit Aadhaar number clearly legible',
      'Residential address in Essur / Kanchipuram / Chengalpattu visible',
      'Masking allowed if preferred (first 8 digits hidden)',
      'QR code at bottom should not be blurry',
    ],
    whereToGet: 'Download e-Aadhaar from uidai.gov.in or nearest Aadhaar Seva Kendra',
    digiLockerAvailable: true,
  },
  {
    id: 'doc-photo',
    title: 'Child Passport Size Photographs',
    tamilTitle: 'மாணவரின் பாஸ்போர்ட் அளவு புகைப்படம்',
    category: 'Identity',
    mandatoryFor: ['Pre-Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'],
    maxSize: '2 MB',
    formats: ['JPG', 'PNG'],
    description: 'Recent color photograph of the student with light blue/white background for school ID card and register.',
    specimenType: 'photo',
    keyCheckpoints: [
      'Taken within the last 6 months',
      'Plain light-colored or white background',
      'Child facing camera directly with natural expression',
      'No caps, sunglasses, or obstructing hair',
    ],
    whereToGet: 'Click photo using mobile camera in good natural daylight or local studio',
    digiLockerAvailable: false,
  },
  {
    id: 'doc-tc',
    title: 'Transfer Certificate (TC)',
    tamilTitle: 'பள்ளி மாற்றுச் சான்றிதழ் (TC)',
    category: 'Academic',
    mandatoryFor: ['Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'],
    optionalFor: ['UKG'],
    maxSize: '5 MB',
    formats: ['PDF', 'JPG', 'PNG'],
    description: 'Original TC issued by previous recognized school with State EMIS Number for school transfer records.',
    specimenType: 'tc',
    keyCheckpoints: [
      'Tamil Nadu State EMIS Number printed on TC',
      'Statement "Promoted to Class X" clearly written',
      'Headmaster Signature and School Rubber Stamp present',
      'Conduct and Character recorded as Good',
    ],
    whereToGet: 'Obtain from previous school office or online school portal',
    digiLockerAvailable: true,
  },
  {
    id: 'doc-community',
    title: 'Community Certificate (BC/MBC/SC/ST)',
    tamilTitle: 'சாதிச் சான்றிதழ்',
    category: 'Category',
    mandatoryFor: ['Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'],
    optionalFor: ['Pre-Nursery', 'LKG', 'UKG'],
    maxSize: '5 MB',
    formats: ['PDF', 'JPG', 'PNG'],
    description: 'Government e-District community certificate for welfare scheme mapping and scholarship eligibility.',
    specimenType: 'community',
    keyCheckpoints: [
      'Digital signature QR code of Tahsildar / Zone Officer',
      'Certificate number starting with TN-XXXXX',
      'Community category (BC / MBC / SC / ST) clearly stated',
    ],
    whereToGet: 'Apply via Tamil Nadu e-Sevai Center or edistricts.tn.gov.in',
    digiLockerAvailable: true,
  },
  {
    id: 'doc-blood-group',
    title: 'Blood Group Test Report',
    tamilTitle: 'இரத்த வகை மருத்துவ அறிக்கை',
    category: 'Medical',
    mandatoryFor: ['Pre-Nursery', 'LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'],
    maxSize: '3 MB',
    formats: ['PDF', 'JPG', 'PNG'],
    description: 'Laboratory report confirming child blood group for school health records and emergency van medical cards.',
    specimenType: 'blood_group',
    keyCheckpoints: [
      'Clinical laboratory name and technician seal',
      'Explicit blood type (e.g., O +ve, A +ve, B +ve, AB +ve)',
      'Child full name printed on report',
    ],
    whereToGet: 'Government Primary Health Centre (PHC) Essur or registered clinical lab',
    digiLockerAvailable: false,
  },
  {
    id: 'doc-marksheet',
    title: 'Previous Progress Report Card',
    tamilTitle: 'முந்தைய வகுப்பின் மதிப்பெண் சான்றிதழ்',
    category: 'Academic',
    mandatoryFor: ['Class 2', 'Class 3', 'Class 4', 'Class 5'],
    optionalFor: ['Class 1'],
    maxSize: '5 MB',
    formats: ['PDF', 'JPG', 'PNG'],
    description: 'Last academic year final term report card showing academic performance and attendance.',
    specimenType: 'marksheet',
    keyCheckpoints: [
      'Final examination marks / grades recorded',
      'Class teacher & Principal signature',
      'Academic year stated (2025-2026)',
    ],
    whereToGet: 'Previous school progress report card folder',
    digiLockerAvailable: false,
  },
];

interface DocumentPreviewCarouselProps {
  selectedGrade?: string;
  onSelectDocumentForUpload?: (docId: string) => void;
}

export const DocumentPreviewCarousel: React.FC<DocumentPreviewCarouselProps> = ({
  selectedGrade = 'All',
  onSelectDocumentForUpload,
}) => {
  const [activeGradeFilter, setActiveGradeFilter] = useState<string>('All');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [showFullSpecimenModal, setShowFullSpecimenModal] = useState<boolean>(false);

  // Sync with prop when parent form changes grade
  useEffect(() => {
    if (selectedGrade && selectedGrade !== 'All') {
      setActiveGradeFilter(selectedGrade);
      // Reset index to first matching doc
      const firstMatchIndex = DOCUMENT_GUIDE_DATA.findIndex((doc) =>
        doc.mandatoryFor.includes(selectedGrade)
      );
      if (firstMatchIndex !== -1) {
        setCurrentIndex(firstMatchIndex);
      }
    }
  }, [selectedGrade]);

  // Filter docs based on selected grade
  const filteredDocs = DOCUMENT_GUIDE_DATA.filter((doc) => {
    if (activeGradeFilter === 'All') return true;
    return doc.mandatoryFor.includes(activeGradeFilter) || doc.optionalFor?.includes(activeGradeFilter);
  });

  const activeDoc = filteredDocs[currentIndex] || filteredDocs[0] || DOCUMENT_GUIDE_DATA[0];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % filteredDocs.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + filteredDocs.length) % filteredDocs.length);
  };

  // Helper renderer for visual mockup specimen cards
  const renderSpecimenMockup = (type: DocumentGuideItem['specimenType']) => {
    switch (type) {
      case 'birth_cert':
        return (
          <div className="w-full h-full bg-gradient-to-b from-amber-50 to-amber-100/60 p-4 rounded-2xl border-2 border-amber-300 shadow-inner flex flex-col justify-between text-slate-800 relative font-serif select-none overflow-hidden">
            <div className="absolute top-2 right-2 opacity-20 pointer-events-none">
              <Award className="w-20 h-20 text-amber-700" />
            </div>

            <div className="text-center space-y-1 border-b border-amber-300/80 pb-2">
              <span className="text-[9px] uppercase tracking-widest text-amber-900 font-extrabold block">
                GOVERNMENT OF TAMIL NADU • DEPARTMENT OF PUBLIC HEALTH
              </span>
              <h5 className="font-extrabold text-xs text-blue-950 uppercase tracking-wide">
                CERTIFICATE OF BIRTH / பிறப்புச் சான்றிதழ்
              </h5>
              <span className="text-[8px] text-amber-800 font-mono block">Form No. 5 • Reg. No: TN-ESSUR-2021-88401</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px] my-2 font-sans">
              <div className="bg-white/80 p-1.5 rounded border border-amber-200">
                <span className="text-[8px] text-slate-500 block uppercase font-bold">Child Name</span>
                <strong className="text-blue-950 font-bold">S. KAVIN KUMAR</strong>
              </div>
              <div className="bg-white/80 p-1.5 rounded border border-amber-200">
                <span className="text-[8px] text-slate-500 block uppercase font-bold">Date of Birth</span>
                <strong className="text-emerald-900 font-bold">10 / MAY / 2021</strong>
              </div>
              <div className="bg-white/80 p-1.5 rounded border border-amber-200">
                <span className="text-[8px] text-slate-500 block uppercase font-bold">Father Name</span>
                <strong className="text-slate-900">R. SARAVANAN</strong>
              </div>
              <div className="bg-white/80 p-1.5 rounded border border-amber-200">
                <span className="text-[8px] text-slate-500 block uppercase font-bold">Place of Birth</span>
                <strong className="text-slate-900">ESSUR, KANCHIPURAM</strong>
              </div>
            </div>

            <div className="flex justify-between items-center pt-1 border-t border-amber-300/80 text-[8px] font-sans">
              <div className="flex items-center gap-1 text-emerald-800 font-bold">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                <span>Digitally Signed by Registrar</span>
              </div>
              <div className="text-right">
                <span className="font-mono font-bold text-amber-950 block">SEAL & SIGNATURE</span>
                <span className="text-[7px] text-slate-500">Town Panchayat Essur</span>
              </div>
            </div>

            {/* Specimen Badge Overlay */}
            <div className="absolute top-3 left-3 bg-red-600 text-white font-black text-[8px] uppercase tracking-widest px-2 py-0.5 rounded shadow">
              OFFICIAL SAMPLE SPECIMEN
            </div>
          </div>
        );

      case 'aadhaar':
        return (
          <div className="w-full h-full bg-gradient-to-r from-blue-900 via-slate-900 to-indigo-950 p-4 rounded-2xl border-2 border-amber-400 shadow-inner flex flex-col justify-between text-white relative font-sans select-none overflow-hidden">
            <div className="flex justify-between items-center border-b border-white/20 pb-2">
              <div className="flex items-center gap-1.5">
                <div className="w-6 h-6 bg-amber-400 rounded-full flex items-center justify-center font-black text-[10px] text-blue-950">
                  GOI
                </div>
                <div>
                  <span className="text-[9px] font-black uppercase text-amber-300 block">Unique Identification Authority of India</span>
                  <span className="text-[8px] text-slate-300 block">ஆதார் - சாதாரண மனிதனின் அதிகாரம்</span>
                </div>
              </div>
              <QrCode className="w-7 h-7 text-white" />
            </div>

            <div className="flex items-center gap-3 my-2">
              <div className="w-14 h-16 bg-slate-800 border border-slate-600 rounded-lg flex flex-col items-center justify-center shrink-0">
                <Camera className="w-6 h-6 text-slate-400" />
                <span className="text-[7px] font-bold text-slate-400 pt-1">PHOTO</span>
              </div>
              <div className="space-y-1 text-[10px]">
                <div>
                  <span className="text-[8px] text-slate-400 block">Name:</span>
                  <strong className="text-white font-bold">Kavin Kumar S</strong>
                </div>
                <div>
                  <span className="text-[8px] text-slate-400 block">DOB / Year:</span>
                  <span className="font-mono font-bold text-amber-300">10/05/2021</span>
                </div>
                <div>
                  <span className="text-[8px] text-slate-400 block">Gender:</span>
                  <span className="font-bold">Male / ஆண்</span>
                </div>
              </div>
            </div>

            <div className="bg-white/10 backdrop-blur p-2 rounded-xl text-center border border-white/20">
              <span className="text-[8px] text-slate-300 uppercase block font-bold">Aadhaar Number (ஆதார் எண்)</span>
              <span className="font-mono text-xs sm:text-sm font-black text-amber-400 tracking-widest">
                XXXX XXXX 8812
              </span>
            </div>

            <div className="absolute top-2 right-2 bg-amber-400 text-blue-950 font-black text-[8px] uppercase px-2 py-0.5 rounded">
              AADHAAR SAMPLE
            </div>
          </div>
        );

      case 'photo':
        return (
          <div className="w-full h-full bg-slate-900 p-4 rounded-2xl border-2 border-slate-700 shadow-inner flex flex-col items-center justify-center text-white relative font-sans select-none">
            <div className="w-28 h-36 bg-sky-200 rounded-xl border-4 border-white shadow-lg flex flex-col items-center justify-center relative overflow-hidden my-1">
              <div className="w-16 h-16 rounded-full bg-blue-900 text-amber-300 flex items-center justify-center font-black text-xl shadow-md border-2 border-amber-300">
                🎓
              </div>
              <span className="text-[9px] font-black text-blue-950 mt-2 bg-white/90 px-2 py-0.5 rounded">
                3.5cm x 4.5cm
              </span>
            </div>

            <div className="text-center space-y-1 mt-2">
              <span className="text-[10px] font-bold text-amber-300 bg-blue-950 px-2.5 py-0.5 rounded-full border border-amber-400/40">
                Passport Photo Specification
              </span>
              <p className="text-[9px] text-slate-300 max-w-xs">
                Light background • High resolution • Face clearly visible
              </p>
            </div>
          </div>
        );

      case 'tc':
        return (
          <div className="w-full h-full bg-amber-50/90 p-4 rounded-2xl border-2 border-slate-300 shadow-inner flex flex-col justify-between text-slate-900 relative font-serif select-none overflow-hidden">
            <div className="text-center space-y-0.5 border-b border-slate-300 pb-2">
              <span className="text-[8px] uppercase tracking-wider text-slate-600 block">TAMIL NADU SCHOOL EDUCATION DEPARTMENT</span>
              <h5 className="font-extrabold text-xs text-blue-950 uppercase">TRANSFER CERTIFICATE (TC)</h5>
              <span className="text-[8px] font-mono font-bold text-amber-900 block">EMIS NO: 33020108819002</span>
            </div>

            <div className="space-y-1 text-[9px] font-sans my-1 bg-white p-2 rounded border border-slate-200">
              <div className="flex justify-between">
                <span className="text-slate-500">1. Student Name:</span>
                <strong className="text-blue-950">S. Kavin Kumar</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">2. Class Last Studied:</span>
                <strong className="text-slate-900">Class 3 (Passed & Promoted)</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">3. Conduct & Character:</span>
                <strong className="text-emerald-800 font-bold">Good</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">4. Date of Issue:</span>
                <strong className="text-slate-900">15/04/2026</strong>
              </div>
            </div>

            <div className="flex justify-between items-center pt-1 border-t border-slate-300 text-[8px] font-sans">
              <span className="bg-emerald-100 text-emerald-900 font-extrabold px-1.5 py-0.5 rounded">
                PROMOTED TO CLASS 4
              </span>
              <div className="text-right font-bold text-blue-950">
                <span>HEADMASTER SIGN & STAMP</span>
              </div>
            </div>

            <div className="absolute top-2 right-2 bg-slate-900 text-amber-400 font-black text-[8px] uppercase px-2 py-0.5 rounded">
              OFFICIAL TC SPECIMEN
            </div>
          </div>
        );

      case 'community':
        return (
          <div className="w-full h-full bg-emerald-50/80 p-4 rounded-2xl border-2 border-emerald-300 shadow-inner flex flex-col justify-between text-slate-900 relative font-sans select-none overflow-hidden">
            <div className="text-center space-y-0.5 border-b border-emerald-200 pb-2">
              <span className="text-[8px] font-extrabold text-emerald-900 uppercase block">GOVERNMENT OF TAMIL NADU • REVENUE DEPARTMENT</span>
              <h5 className="font-extrabold text-xs text-blue-950">COMMUNITY CERTIFICATE / சாதிச் சான்றிதழ்</h5>
              <span className="text-[8px] font-mono text-slate-600 block">Certificate No: TN-720260381920</span>
            </div>

            <div className="bg-white p-2 rounded-xl border border-emerald-200 text-[10px] space-y-1">
              <p className="text-slate-700 leading-snug">
                This is to certify that <strong>S. KAVIN KUMAR</strong>, Son of <strong>R. SARAVANAN</strong> belongs to <strong>BC / Backward Class</strong> category in the State of Tamil Nadu.
              </p>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-emerald-200 text-[8px]">
              <div className="flex items-center gap-1 text-emerald-800 font-bold">
                <QrCode className="w-6 h-6 text-slate-800" />
                <span>e-Sevai Digital Signature Verified</span>
              </div>
              <div className="text-right font-bold text-slate-800">
                <span>TAHSILDAR OFFICE</span>
                <span className="block text-slate-500 font-normal">Kanchipuram District</span>
              </div>
            </div>

            <div className="absolute top-2 left-2 bg-emerald-700 text-white font-black text-[8px] uppercase px-2 py-0.5 rounded">
              e-DISTRICT SAMPLE
            </div>
          </div>
        );

      case 'blood_group':
        return (
          <div className="w-full h-full bg-rose-50 p-4 rounded-2xl border-2 border-rose-300 shadow-inner flex flex-col justify-between text-slate-900 relative font-sans select-none overflow-hidden">
            <div className="flex justify-between items-center border-b border-rose-200 pb-2">
              <div>
                <h5 className="font-black text-xs text-rose-950">ESSUR CLINICAL PATHOLOGY LAB</h5>
                <span className="text-[8px] text-slate-500 block">Regd No. LAB-ESSUR-88102</span>
              </div>
              <div className="w-7 h-7 bg-rose-600 text-white rounded-full flex items-center justify-center font-black text-xs">
                🩸
              </div>
            </div>

            <div className="bg-white p-3 rounded-xl border border-rose-200 text-[10px] space-y-2 text-center my-1">
              <div>
                <span className="text-[8px] text-slate-400 block uppercase">Patient Name</span>
                <strong className="text-slate-900 font-extrabold text-xs">S. KAVIN KUMAR (AGE 5)</strong>
              </div>
              <div className="p-2 bg-rose-100 rounded-lg border border-rose-300">
                <span className="text-[8px] uppercase text-rose-900 font-bold block">CONFIRMED BLOOD GROUP</span>
                <span className="text-xl font-black text-rose-700 font-mono tracking-wider">O +ve (O POSITIVE)</span>
              </div>
            </div>

            <div className="flex justify-between items-center text-[8px] text-slate-600 border-t border-rose-200 pt-1 font-bold">
              <span>TESTED BY QUALIFIED PATHOLOGIST</span>
              <span className="text-rose-950">LAB STAMP & SIGNATURE</span>
            </div>
          </div>
        );

      case 'marksheet':
      default:
        return (
          <div className="w-full h-full bg-indigo-50 p-4 rounded-2xl border-2 border-indigo-200 shadow-inner flex flex-col justify-between text-slate-900 relative font-sans select-none overflow-hidden">
            <div className="text-center border-b border-indigo-200 pb-1">
              <h5 className="font-black text-xs text-blue-950">PROGRESS REPORT CARD (2025-2026)</h5>
              <span className="text-[8px] text-indigo-800 font-bold block">ANNUAL ACADEMIC RESULT SUMMARY</span>
            </div>

            <div className="bg-white p-2 rounded-xl border border-indigo-200 text-[9px] space-y-1 my-1">
              <div className="grid grid-cols-3 font-bold border-b pb-1 text-slate-700">
                <span>Subject</span>
                <span>Marks</span>
                <span>Grade</span>
              </div>
              <div className="grid grid-cols-3">
                <span>Tamil</span>
                <span className="font-mono">92/100</span>
                <span className="font-bold text-emerald-700">A1</span>
              </div>
              <div className="grid grid-cols-3">
                <span>English</span>
                <span className="font-mono">88/100</span>
                <span className="font-bold text-emerald-700">A1</span>
              </div>
              <div className="grid grid-cols-3">
                <span>Mathematics</span>
                <span className="font-mono">95/100</span>
                <span className="font-bold text-emerald-700">O (Outstanding)</span>
              </div>
            </div>

            <div className="flex justify-between items-center text-[8px] font-bold text-blue-950 border-t border-indigo-200 pt-1">
              <span className="bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded">PASSED & PROMOTED</span>
              <span>CLASS TEACHER SIGN</span>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-blue-950 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 border-2 border-amber-400/40 shadow-2xl space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-4">
        <div>
          <div className="inline-flex items-center gap-2 bg-amber-400 text-blue-950 px-3 py-1 rounded-full text-[11px] font-black uppercase tracking-wider shadow mb-1.5">
            <Sparkles className="w-3.5 h-3.5 text-blue-950 animate-spin" />
            <span>Wisdom Admission Prep Helper</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-white flex items-center gap-2">
            <FileCheck className="w-6 h-6 text-amber-400" />
            <span>Interactive Document Preview & Visual Guide</span>
          </h3>
          <p className="text-xs text-slate-300 font-medium pt-0.5">
            Visual reference samples and requirements for each document needed during admission registration.
          </p>
        </div>

        {/* Grade Filter Pills */}
        <div className="flex flex-wrap items-center gap-1 bg-white/10 p-1.5 rounded-2xl border border-white/15">
          {['All', 'Pre-Nursery', 'LKG', 'Class 1', 'Class 4'].map((g) => (
            <button
              key={g}
              onClick={() => {
                setActiveGradeFilter(g);
                setCurrentIndex(0);
              }}
              className={`px-3 py-1 rounded-xl text-xs font-extrabold transition ${
                activeGradeFilter === g
                  ? 'bg-amber-400 text-blue-950 shadow'
                  : 'text-slate-300 hover:text-white hover:bg-white/10'
              }`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>

      {/* Main Carousel Area */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        {/* Left Side: Interactive Specimen Card Box (5 Cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold text-amber-300">
            <span className="flex items-center gap-1.5">
              <Eye className="w-4 h-4 text-amber-400" />
              <span>Document Visual Specimen ({currentIndex + 1} of {filteredDocs.length})</span>
            </span>
            <button
              onClick={() => setShowFullSpecimenModal(true)}
              className="text-[10px] bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded-lg border border-white/20 transition flex items-center gap-1 font-bold"
            >
              <Info className="w-3 h-3" />
              <span>Full View</span>
            </button>
          </div>

          {/* Rendered Visual Specimen Canvas */}
          <div className="h-64 sm:h-72 w-full rounded-2xl overflow-hidden shadow-2xl relative transition-all duration-300 transform hover:scale-[1.01]">
            {renderSpecimenMockup(activeDoc.specimenType)}
          </div>

          {/* Quick Upload Indicator */}
          <div className="bg-white/10 backdrop-blur p-3 rounded-2xl border border-white/20 flex items-center justify-between text-xs">
            <div>
              <span className="text-[10px] text-slate-300 block font-bold">Allowed File Types:</span>
              <strong className="text-amber-300 font-mono">{activeDoc.formats.join(', ')} (Max {activeDoc.maxSize})</strong>
            </div>

            {onSelectDocumentForUpload && (
              <button
                onClick={() => onSelectDocumentForUpload(activeDoc.id)}
                className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black rounded-xl text-xs transition shadow flex items-center gap-1"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload Now</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Side: Detailed Document Requirements & Checkpoints (7 Cols) */}
        <div className="lg:col-span-7 space-y-4 bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-amber-400 text-blue-950 font-black text-[10px] px-2.5 py-0.5 rounded-full uppercase">
                  {activeDoc.category} Document
                </span>
                {activeDoc.digiLockerAvailable && (
                  <span className="bg-blue-600 text-white font-bold text-[10px] px-2 py-0.5 rounded-full flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" />
                    DigiLocker Linked
                  </span>
                )}
              </div>
              <h4 className="text-xl font-black text-white mt-1">{activeDoc.title}</h4>
              <p className="text-xs text-amber-300 font-bold">{activeDoc.tamilTitle}</p>
            </div>

            {/* Navigation Carousel Arrows */}
            <div className="flex items-center gap-2">
              <button
                onClick={handlePrev}
                className="p-2.5 bg-white/10 hover:bg-amber-400 hover:text-blue-950 text-white rounded-2xl border border-white/20 transition shadow"
                title="Previous Document"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                className="p-2.5 bg-white/10 hover:bg-amber-400 hover:text-blue-950 text-white rounded-2xl border border-white/20 transition shadow"
                title="Next Document"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          <p className="text-xs text-slate-200 leading-relaxed font-medium">
            {activeDoc.description}
          </p>

          {/* Key Verification Checkpoints List */}
          <div className="space-y-2">
            <span className="text-xs font-black text-amber-400 uppercase tracking-wider block">
              ✓ Checklist Before Uploading / Submitting Copy:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {activeDoc.keyCheckpoints.map((point, idx) => (
                <div key={idx} className="flex items-start gap-2 bg-white/5 p-2 rounded-xl border border-white/10">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="text-slate-200 font-medium text-[11px]">{point}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Where to Obtain in Essur / Tamil Nadu */}
          <div className="p-3 bg-amber-400/10 border border-amber-400/30 rounded-2xl text-xs space-y-1">
            <span className="font-extrabold text-amber-300 flex items-center gap-1.5">
              <Info className="w-4 h-4 text-amber-400" />
              <span>Where to Get in Essur / Kanchipuram:</span>
            </span>
            <p className="text-slate-200 font-medium text-[11px]">
              {activeDoc.whereToGet}
            </p>
          </div>

          {/* Carousel Slide Indicators */}
          <div className="flex items-center justify-between pt-2 border-t border-white/10 text-xs">
            <div className="flex items-center gap-1.5">
              {filteredDocs.map((doc, idx) => (
                <button
                  key={doc.id}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2 rounded-full transition-all ${
                    idx === currentIndex
                      ? 'w-6 bg-amber-400'
                      : 'w-2 bg-white/30 hover:bg-white/60'
                  }`}
                  title={doc.title}
                />
              ))}
            </div>

            <span className="text-[10px] font-mono text-slate-400">
              Grade Requirement: <strong className="text-emerald-400">{activeDoc.mandatoryFor.join(', ')}</strong>
            </span>
          </div>
        </div>
      </div>

      {/* FULL SPECIMEN EXPANDED MODAL */}
      {showFullSpecimenModal && (
        <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white text-slate-900 rounded-3xl max-w-lg w-full p-6 space-y-4 relative border-2 border-amber-400 shadow-2xl">
            <button
              onClick={() => setShowFullSpecimenModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              ✕
            </button>

            <div className="space-y-1">
              <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-300">
                Official Specimen Preview Guide
              </span>
              <h4 className="text-lg font-black text-blue-950">{activeDoc.title}</h4>
              <p className="text-xs text-slate-500 font-medium">{activeDoc.tamilTitle}</p>
            </div>

            <div className="h-72 w-full rounded-2xl overflow-hidden shadow-inner border">
              {renderSpecimenMockup(activeDoc.specimenType)}
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
              <strong className="text-blue-950 font-bold block">Important Parent Note:</strong>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Make sure the photograph or scan is clearly illuminated. Documents submitted during admission will be verified against original certificates at Wisdom School office.
              </p>
            </div>

            <button
              onClick={() => setShowFullSpecimenModal(false)}
              className="w-full py-2.5 bg-blue-950 text-amber-400 font-black rounded-xl text-xs hover:bg-blue-900 transition"
            >
              Close Specimen Guide
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  Fingerprint,
  ShieldCheck,
  ShieldAlert,
  KeyRound,
  CheckCircle2,
  ScanFace,
  Lock,
  Unlock,
  AlertCircle,
  X,
  Sparkles,
} from 'lucide-react';
import {
  isBiometricSupported,
  checkPlatformAuthenticator,
  getSavedBiometricCredentials,
  registerBiometricKey,
  authenticateWithBiometrics,
  removeBiometricCredential,
  BiometricCredential,
} from '../utils/webAuthn';

interface BiometricAuthProps {
  userPhone?: string;
  studentName?: string;
  onAuthenticateSuccess?: (phone: string) => void;
}

export const BiometricAuth: React.FC<BiometricAuthProps> = ({
  userPhone,
  studentName = 'Student',
  onAuthenticateSuccess,
}) => {
  const [supported, setSupported] = useState(false);
  const [platformAvailable, setPlatformAvailable] = useState(false);
  const [savedCreds, setSavedCreds] = useState<BiometricCredential[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);
  const [showRegisterModal, setShowRegisterModal] = useState(false);

  useEffect(() => {
    setSupported(isBiometricSupported());
    checkPlatformAuthenticator().then(setPlatformAvailable);
    setSavedCreds(getSavedBiometricCredentials());
  }, [userPhone]);

  const activeCred = userPhone
    ? savedCreds.find((c) => c.userPhone === userPhone)
    : savedCreds[0];

  // Handle 1-Click Biometric Sign In
  const handleBiometricSignIn = async () => {
    setLoading(true);
    setStatusMsg({ type: 'info', text: 'Scanning Fingerprint / Face ID...' });

    const result = await authenticateWithBiometrics(userPhone || activeCred?.userPhone);

    setLoading(false);
    if (result.success && result.cred) {
      setStatusMsg({
        type: 'success',
        text: `✓ Biometric Identity Verified! Welcome Parent of ${result.cred.studentName}.`,
      });
      if (onAuthenticateSuccess) {
        onAuthenticateSuccess(result.cred.userPhone);
      }
    } else {
      setStatusMsg({
        type: 'error',
        text: result.error || 'Biometric authentication failed. Please use PIN/Phone login.',
      });
    }
  };

  // Handle Passkey Registration
  const handleRegisterBiometrics = async () => {
    if (!userPhone) {
      setStatusMsg({ type: 'error', text: 'Please sign in first to register your device biometrics.' });
      return;
    }

    setLoading(true);
    setStatusMsg({ type: 'info', text: 'Touch device fingerprint sensor or look at camera for Face ID...' });

    const res = await registerBiometricKey(userPhone, studentName);
    setLoading(false);

    if (res.success && res.credential) {
      setSavedCreds(getSavedBiometricCredentials());
      setStatusMsg({
        type: 'success',
        text: `✓ Biometric Passkey successfully linked to phone +${userPhone}!`,
      });
      setShowRegisterModal(false);
    } else {
      setStatusMsg({
        type: 'error',
        text: res.error || 'Could not register biometric key.',
      });
    }
  };

  const handleRemoveBiometrics = () => {
    if (userPhone) {
      removeBiometricCredential(userPhone);
      setSavedCreds(getSavedBiometricCredentials());
      setStatusMsg({ type: 'info', text: 'Biometric passkey removed from this browser.' });
    }
  };

  return (
    <div className="space-y-3">
      {/* 1-Click Biometric Login Button (Shown if a passkey exists) */}
      {activeCred ? (
        <div className="p-3.5 bg-gradient-to-r from-blue-950 via-slate-900 to-blue-950 text-white rounded-2xl border border-amber-400/50 shadow-md space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-amber-400 text-blue-950 rounded-xl">
                <Fingerprint className="w-5 h-5 text-blue-950 animate-pulse" />
              </div>
              <div>
                <h5 className="font-extrabold text-xs text-amber-300 flex items-center gap-1">
                  <span>Passkey Biometrics Enabled</span>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                </h5>
                <p className="text-[10px] text-slate-300">
                  Registered for {activeCred.studentName} ({activeCred.userPhone})
                </p>
              </div>
            </div>

            <button
              onClick={handleBiometricSignIn}
              disabled={loading}
              className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-blue-950 text-xs font-black rounded-xl transition shadow flex items-center gap-1.5 shrink-0"
            >
              <ScanFace className="w-4 h-4 text-blue-950" />
              <span>{loading ? 'Scanning...' : 'Touch ID / Face ID'}</span>
            </button>
          </div>
        </div>
      ) : (
        /* Register Passkey Banner (Shown if user is logged in or wants to enable it) */
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Fingerprint className="w-5 h-5 text-amber-800 shrink-0" />
            <div>
              <span className="font-extrabold text-amber-950 block">Enable Fingerprint / Face ID</span>
              <span className="text-[10px] text-amber-800">Secure 1-click WebAuthn biometric parent login</span>
            </div>
          </div>

          <button
            onClick={() => setShowRegisterModal(true)}
            className="px-3 py-1.5 bg-blue-950 hover:bg-blue-900 text-amber-400 text-[11px] font-black rounded-xl transition shrink-0 flex items-center gap-1"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Enable Biometrics</span>
          </button>
        </div>
      )}

      {/* Status Feedback Alert */}
      {statusMsg && (
        <div
          className={`p-3 rounded-xl text-xs font-bold flex items-center justify-between gap-2 ${
            statusMsg.type === 'success'
              ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
              : statusMsg.type === 'error'
              ? 'bg-red-100 text-red-900 border border-red-300'
              : 'bg-blue-100 text-blue-900 border border-blue-300'
          }`}
        >
          <span className="leading-snug">{statusMsg.text}</span>
          <button onClick={() => setStatusMsg(null)} className="text-slate-500 hover:text-slate-800">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* REGISTRATION MODAL */}
      {showRegisterModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl relative border-2 border-amber-400">
            <button
              onClick={() => setShowRegisterModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center space-y-2">
              <div className="w-14 h-14 bg-amber-100 text-amber-900 rounded-2xl mx-auto flex items-center justify-center border border-amber-300 shadow">
                <Fingerprint className="w-8 h-8 text-amber-900 animate-pulse" />
              </div>
              <h4 className="font-extrabold text-lg text-blue-950">
                Register Parent Biometric Passkey
              </h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Use your smartphone or laptop's fingerprint sensor, Touch ID, or Face ID via standard WebAuthn protocol for instant portal access.
              </p>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Student Name:</span>
                <span className="font-extrabold text-blue-950">{studentName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Registered Mobile:</span>
                <span className="font-extrabold text-blue-950">{userPhone || '9876543210'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500 font-bold">Authenticator:</span>
                <span className="font-extrabold text-emerald-800 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Hardware Security Enclave
                </span>
              </div>
            </div>

            <div className="space-y-2">
              <button
                onClick={handleRegisterBiometrics}
                disabled={loading}
                className="w-full py-3 bg-blue-950 hover:bg-blue-900 text-amber-400 font-black rounded-xl text-xs shadow transition flex items-center justify-center gap-2"
              >
                <ScanFace className="w-4 h-4 text-amber-400" />
                <span>{loading ? 'Prompting Biometrics...' : 'Register Fingerprint / Face ID'}</span>
              </button>

              {activeCred && (
                <button
                  onClick={handleRemoveBiometrics}
                  className="w-full py-2 text-red-600 hover:text-red-800 text-[11px] font-bold transition"
                >
                  Remove Existing Passkey
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

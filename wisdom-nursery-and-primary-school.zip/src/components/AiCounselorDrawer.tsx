import React, { useState, useRef, useEffect } from 'react';
import { Sparkles, Send, X, Bot, User, RefreshCw, MessageSquare } from 'lucide-react';
import { ChatMessage } from '../types';
import { SCHOOL_INFO } from '../data/schoolData';

interface AiCounselorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AiCounselorDrawer: React.FC<AiCounselorDrawerProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-0',
      sender: 'assistant',
      text: `Hello! I am Wisdom AI, virtual counselor for Wisdom Nursery & Primary School, Essur - 603301. How can I help you today? Ask me about admissions, fees payment via GPay, syllabus, or school timings!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputPrompt, setInputPrompt] = useState('');
  const [sending, setSending] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  if (!isOpen) return null;

  const quickPrompts = [
    'How do I pay fees via Google Pay?',
    'What documents are needed for LKG admission?',
    'What are the school working hours?',
    'Who is the administrator of the school?',
  ];

  const handleSend = async (textToSend?: string) => {
    const promptText = (textToSend || inputPrompt).trim();
    if (!promptText || sending) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: promptText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputPrompt('');
    setSending(true);

    try {
      const history = messages.map((m) => ({
        role: m.sender,
        text: m.text,
      }));

      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: promptText,
          history,
        }),
      });

      const data = await res.json();
      const botText =
        data.reply ||
        `Wisdom Nursery and Primary School, Essur - 603301. Contact Admin R. Saravanan at +91 9176593129 for quick assistance.`;

      const botMsg: ChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: botText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.error(err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: `Wisdom School Essur - 603301. Admin: R. SARAVANAN (Ph: +91 9176593129). How else may I guide you?`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex justify-end">
      <div className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between animate-slideInRight">
        {/* Drawer Header */}
        <div className="p-4 bg-gradient-to-r from-blue-950 via-indigo-900 to-slate-900 text-white flex items-center justify-between border-b border-blue-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-purple-600/30 border border-purple-400/40 flex items-center justify-center text-amber-300">
              <Sparkles className="w-5 h-5 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <div>
              <h3 className="font-bold text-sm text-white">Wisdom AI Virtual Counselor</h3>
              <p className="text-[10px] text-amber-300">Essur - 603301 • Powered by Gemini 3.6</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Message Thread */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50 text-xs">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex items-start space-x-2.5 ${
                msg.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-7 h-7 rounded-lg bg-blue-950 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[80%] p-3.5 rounded-2xl ${
                  msg.sender === 'user'
                    ? 'bg-blue-900 text-white rounded-tr-none font-semibold'
                    : 'bg-white border border-slate-200 text-slate-800 shadow-sm rounded-tl-none font-medium leading-relaxed whitespace-pre-wrap'
                }`}
              >
                <p>{msg.text}</p>
                <span
                  className={`text-[9px] block text-right mt-1 ${
                    msg.sender === 'user' ? 'text-blue-200' : 'text-slate-400'
                  }`}
                >
                  {msg.timestamp}
                </span>
              </div>

              {msg.sender === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-amber-400 text-blue-950 font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                  U
                </div>
              )}
            </div>
          ))}

          {sending && (
            <div className="flex items-center space-x-2 text-slate-500 text-xs py-2">
              <Bot className="w-4 h-4 text-purple-600 animate-bounce" />
              <span>Wisdom AI is typing response...</span>
            </div>
          )}

          <div ref={chatBottomRef} />
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-3 bg-slate-100 border-t border-slate-200 space-y-1">
          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
            Quick Questions:
          </p>
          <div className="flex flex-wrap gap-1.5">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(qp)}
                className="text-[11px] font-semibold bg-white hover:bg-blue-50 text-blue-950 border border-slate-300 rounded-lg px-2.5 py-1 transition text-left"
              >
                {qp}
              </button>
            ))}
          </div>
        </div>

        {/* Chat Input Bar */}
        <div className="p-3 bg-white border-t border-slate-200">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder="Ask about fees, LKG admissions, timings..."
              className="flex-1 text-xs font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
            />
            <button
              type="submit"
              disabled={sending || !inputPrompt.trim()}
              className="bg-blue-900 hover:bg-blue-800 disabled:opacity-50 text-white font-bold p-2.5 rounded-xl shadow transition"
            >
              <Send className="w-4 h-4 text-amber-300" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import {
  Video,
  Users,
  Clock,
  Calendar,
  Lock,
  ExternalLink,
  Play,
  Hand,
  MessageSquare,
  Mic,
  MicOff,
  VideoOff,
  Share2,
  CheckCircle2,
  AlertCircle,
  Plus,
  Search,
  Download,
  BookOpen,
  Sparkles,
  ShieldCheck,
  X,
  FileText,
  UserCheck,
  Radio,
  Send,
  HelpCircle,
} from 'lucide-react';
import { SCHOOL_INFO } from '../data/schoolData';

export interface ZoomMeeting {
  id: string;
  topic: string;
  subject: string;
  grade: string;
  teacherName: string;
  meetingId: string;
  passcode: string;
  startTime: string;
  date: string;
  durationMinutes: number;
  status: 'live' | 'upcoming' | 'completed';
  joinUrl: string;
  recordingUrl?: string;
  description: string;
  attendeesCount: number;
  classMaterials?: string[];
}

const INITIAL_ZOOM_CLASSES: ZoomMeeting[] = [
  {
    id: 'ZM-101',
    topic: 'Chapter 4: Plant Kingdom & Photosynthesis Experiment',
    subject: 'Environmental Science (EVS)',
    grade: 'Class 4',
    teacherName: 'Mrs. S. Meenakshi (EVS Dept)',
    meetingId: '849 2011 9302',
    passcode: 'WISDOM2026',
    startTime: '10:00 AM',
    date: 'Today, 28 Jul 2026',
    durationMinutes: 45,
    status: 'live',
    joinUrl: 'https://zoom.us/j/84920119302?pwd=WISDOM2026#success',
    description: 'Interactive virtual lab demonstration on plant leaves, sunlight absorption, and chlorophyll. Keep your EVS workbook open to page 42.',
    attendeesCount: 28,
    classMaterials: ['EVS_Chapter4_Worksheet.pdf', 'Leaf_Observation_Chart.pdf'],
  },
  {
    id: 'ZM-102',
    topic: 'Maths Fun: Fractions & Shapes Visual Activity',
    subject: 'Mathematics',
    grade: 'Class 3',
    teacherName: 'Mr. K. Ramesh (Maths Dept)',
    meetingId: '912 3044 1122',
    passcode: 'MATH33',
    startTime: '11:30 AM',
    date: 'Today, 28 Jul 2026',
    durationMinutes: 40,
    status: 'upcoming',
    joinUrl: 'https://zoom.us/j/91230441122?pwd=MATH33',
    description: 'Understanding half, quarter, and three-quarter fractions using paper cutting and visual shapes on screen.',
    attendeesCount: 0,
    classMaterials: ['Fractions_Practice_Sheet.pdf'],
  },
  {
    id: 'ZM-103',
    topic: 'தமிழ் பாடம்: செய்யுள் மற்றும் இலக்கணம் (Tamil Grammar)',
    subject: 'Tamil',
    grade: 'Class 5',
    teacherName: 'Mrs. A. Thenmozhi',
    meetingId: '772 1092 4410',
    passcode: 'TAMIL5',
    startTime: '02:00 PM',
    date: 'Today, 28 Jul 2026',
    durationMinutes: 45,
    status: 'upcoming',
    joinUrl: 'https://zoom.us/j/77210924410?pwd=TAMIL5',
    description: 'திருக்குறள் விளக்கம் மற்றும் பெயர்ச்சொல், வினைச்சொல் பயிற்சி வகுப்புகள்.',
    attendeesCount: 0,
    classMaterials: ['Tamil_Grammar_Notes_Class5.pdf'],
  },
  {
    id: 'ZM-104',
    topic: 'Nursery & LKG Rhymes & Action Song Session',
    subject: 'Rhymes & Story',
    grade: 'Nursery / LKG',
    teacherName: 'Ms. P. Kavitha',
    meetingId: '610 8820 9001',
    passcode: 'NURSERY123',
    startTime: '09:00 AM',
    date: 'Yesterday, 27 Jul 2026',
    durationMinutes: 30,
    status: 'completed',
    joinUrl: 'https://zoom.us/j/61088209001',
    recordingUrl: 'https://zoom.us/rec/play/wisdom-nursery-rhymes-rec2026',
    description: 'Fun audio-visual rhymes session with actions. Recorded stream available for revision.',
    attendeesCount: 32,
    classMaterials: ['Nursery_Rhymes_Coloring_Book.pdf'],
  },
];

export const OnlineClassZoom: React.FC = () => {
  const [classList, setClassList] = useState<ZoomMeeting[]>(INITIAL_ZOOM_CLASSES);
  const [selectedGrade, setSelectedGrade] = useState<string>('All');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Active Embedded Zoom Class Session State
  const [activeMeetingRoom, setActiveMeetingRoom] = useState<ZoomMeeting | null>(null);
  const [inClassAttendance, setInClassAttendance] = useState<boolean>(false);
  const [handRaised, setHandRaised] = useState<boolean>(false);
  const [micMuted, setMicMuted] = useState<boolean>(true);
  const [videoOn, setVideoOn] = useState<boolean>(true);
  const [classChatMessages, setClassChatMessages] = useState<Array<{ sender: string; text: string; time: string; isTeacher?: boolean }>>([
    { sender: 'Mrs. S. Meenakshi (Teacher)', text: 'Welcome Class 4 students! Please check page 42 in your EVS book.', time: '10:02 AM', isTeacher: true },
    { sender: 'Ananya (Roll 04)', text: 'Good morning ma\'am! My worksheet is ready.', time: '10:03 AM' },
  ]);
  const [chatInput, setChatInput] = useState('');

  // Schedule Class Modal State
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [newTopic, setNewTopic] = useState('');
  const [newSubject, setNewSubject] = useState('Mathematics');
  const [newGrade, setNewGrade] = useState('Class 4');
  const [newTeacher, setNewTeacher] = useState('Mrs. S. Meenakshi');
  const [newTime, setNewTime] = useState('10:00 AM');
  const [newPasscode, setNewPasscode] = useState('WISDOM2026');
  const [newMeetingId, setNewMeetingId] = useState('881 2026 ' + Math.floor(1000 + Math.random() * 9000));

  const filteredClasses = classList.filter((item) => {
    const matchesGrade = selectedGrade === 'All' || item.grade.includes(selectedGrade);
    const matchesSubject = selectedSubject === 'All' || item.subject.toLowerCase().includes(selectedSubject.toLowerCase());
    const matchesSearch =
      item.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.teacherName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGrade && matchesSubject && matchesSearch;
  });

  const handleSendMessage = () => {
    if (!chatInput.trim()) return;
    setClassChatMessages((prev) => [
      ...prev,
      {
        sender: 'You (Kavin - Class 4)',
        text: chatInput,
        time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setChatInput('');
  };

  const handleScheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopic.trim()) return;

    const created: ZoomMeeting = {
      id: 'ZM-' + Math.floor(100 + Math.random() * 900),
      topic: newTopic,
      subject: newSubject,
      grade: newGrade,
      teacherName: newTeacher,
      meetingId: newMeetingId,
      passcode: newPasscode,
      startTime: newTime,
      date: 'Today, 28 Jul 2026',
      durationMinutes: 45,
      status: 'upcoming',
      joinUrl: `https://zoom.us/j/${newMeetingId.replace(/\s+/g, '')}?pwd=${newPasscode}`,
      description: `Scheduled Zoom class for ${newGrade} ${newSubject}. Join using meeting ID and password.`,
      attendeesCount: 0,
      classMaterials: [`${newSubject}_Class_Notes.pdf`],
    };

    setClassList([created, ...classList]);
    setShowScheduleModal(false);
    setNewTopic('');
    alert(`Zoom Online Class scheduled successfully! Meeting ID: ${newMeetingId}`);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-blue-950 via-slate-900 to-indigo-950 text-white p-6 sm:p-8 rounded-3xl border-2 border-amber-400/40 shadow-xl relative overflow-hidden">
        <div className="absolute right-2 top-0 bottom-0 opacity-15 pointer-events-none p-6">
          <Video className="w-80 h-80 text-blue-400" />
        </div>

        <div className="relative z-10 space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-amber-400 text-blue-950 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider shadow">
            <Radio className="w-3.5 h-3.5 text-red-600 animate-ping" />
            <span>Wisdom School Zoom Web Portal</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black text-white leading-tight">
            Live Zoom Online Classes & Interactive Virtual Classroom
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed font-medium">
            Seamless remote learning for Wisdom Nursery & Primary School students. Join live interactive Zoom classes with one click, raise hand for doubts, and download class worksheets.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setShowScheduleModal(true)}
              className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-blue-950 font-black text-xs rounded-xl transition shadow flex items-center gap-2"
            >
              <Plus className="w-4 h-4 text-blue-950" />
              <span>Schedule New Zoom Class (Teachers)</span>
            </button>

            <div className="bg-white/10 backdrop-blur px-3 py-2 rounded-xl border border-white/20 text-xs font-bold text-amber-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Secure School Meeting Passcode Protected</span>
            </div>
          </div>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Grade Selector */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs font-bold w-full md:w-auto">
            <span className="text-slate-400 text-[10px] uppercase font-bold mr-1">Class:</span>
            {['All', 'Nursery / LKG', 'UKG', 'Class 1', 'Class 2', 'Class 3', 'Class 4', 'Class 5'].map((g) => (
              <button
                key={g}
                onClick={() => setSelectedGrade(g)}
                className={`px-3 py-1.5 rounded-xl transition ${
                  selectedGrade === g
                    ? 'bg-blue-950 text-amber-400 font-black shadow'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                }`}
              >
                {g}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search topic or teacher..."
              className="w-full text-xs font-semibold pl-9 pr-3 py-2.5 rounded-2xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-900 bg-slate-50/50"
            />
          </div>
        </div>
      </div>

      {/* Live & Upcoming Zoom Classes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredClasses.map((item) => (
          <div
            key={item.id}
            className={`p-6 rounded-3xl border-2 transition shadow-sm space-y-4 relative overflow-hidden bg-white ${
              item.status === 'live'
                ? 'border-red-500 shadow-red-100/50 shadow-lg'
                : item.status === 'upcoming'
                ? 'border-blue-200 hover:border-blue-300'
                : 'border-slate-200 opacity-90'
            }`}
          >
            {/* Status Header Badge */}
            <div className="flex items-center justify-between">
              <span className="bg-slate-100 text-slate-800 text-[11px] font-black uppercase px-3 py-1 rounded-full border border-slate-200">
                {item.grade} • {item.subject}
              </span>

              {item.status === 'live' ? (
                <span className="bg-red-600 text-white font-black text-xs px-3 py-1 rounded-full flex items-center gap-1.5 animate-pulse shadow">
                  <Radio className="w-3.5 h-3.5 text-white" />
                  <span>LIVE NOW ({item.attendeesCount} Online)</span>
                </span>
              ) : item.status === 'upcoming' ? (
                <span className="bg-blue-100 text-blue-900 font-black text-xs px-3 py-1 rounded-full border border-blue-300">
                  Starts at {item.startTime}
                </span>
              ) : (
                <span className="bg-slate-200 text-slate-700 font-bold text-xs px-3 py-1 rounded-full">
                  Recorded Lecture Ready
                </span>
              )}
            </div>

            {/* Class Details */}
            <div className="space-y-1">
              <h3 className="text-base font-extrabold text-slate-950 leading-snug">
                {item.topic}
              </h3>
              <p className="text-xs text-slate-600 font-medium flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-blue-900" />
                <span>Host: <strong>{item.teacherName}</strong></span>
              </p>
              <p className="text-xs text-slate-500 pt-1 leading-relaxed">
                {item.description}
              </p>
            </div>

            {/* Zoom Meeting Metadata Box */}
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3 grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 font-bold block uppercase">Zoom Meeting ID:</span>
                <span className="font-mono font-bold text-blue-950">{item.meetingId}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block uppercase">Passcode:</span>
                <span className="font-mono font-bold text-amber-900 flex items-center gap-1">
                  <Lock className="w-3 h-3 text-amber-700" />
                  {item.passcode}
                </span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block uppercase">Schedule:</span>
                <span className="text-slate-800 font-bold">{item.date}, {item.startTime}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 font-bold block uppercase">Duration:</span>
                <span className="text-slate-800 font-bold">{item.durationMinutes} Minutes</span>
              </div>
            </div>

            {/* Class Worksheets Downloads */}
            {item.classMaterials && item.classMaterials.length > 0 && (
              <div className="space-y-1 pt-1">
                <span className="text-[10px] font-bold uppercase text-slate-400 block">Attached Handouts:</span>
                <div className="flex flex-wrap gap-2">
                  {item.classMaterials.map((doc, idx) => (
                    <a
                      key={idx}
                      href="#"
                      onClick={(e) => {
                        e.preventDefault();
                        alert(`Downloading ${doc}...`);
                      }}
                      className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 text-[11px] font-bold flex items-center gap-1"
                    >
                      <Download className="w-3 h-3 text-blue-800" />
                      <span>{doc}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
              {item.status === 'live' ? (
                <button
                  onClick={() => {
                    setActiveMeetingRoom(item);
                    setInClassAttendance(true);
                  }}
                  className="flex-1 py-3 px-4 bg-red-600 hover:bg-red-700 text-white font-black text-xs rounded-2xl transition shadow-lg flex items-center justify-center gap-2 animate-bounce"
                >
                  <Video className="w-4 h-4 text-amber-300" />
                  <span>JOIN LIVE ZOOM CLASSROOM NOW</span>
                </button>
              ) : item.status === 'upcoming' ? (
                <button
                  onClick={() => {
                    setActiveMeetingRoom(item);
                    setInClassAttendance(true);
                  }}
                  className="flex-1 py-3 px-4 bg-blue-950 hover:bg-blue-900 text-amber-400 font-black text-xs rounded-2xl transition shadow flex items-center justify-center gap-2"
                >
                  <Video className="w-4 h-4 text-amber-400" />
                  <span>Enter Waiting Room</span>
                </button>
              ) : (
                <button
                  onClick={() => alert(`Playing recorded Zoom video stream: ${item.recordingUrl}`)}
                  className="flex-1 py-3 px-4 bg-slate-900 hover:bg-slate-800 text-slate-100 font-bold text-xs rounded-2xl transition shadow flex items-center justify-center gap-2"
                >
                  <Play className="w-4 h-4 text-amber-400" />
                  <span>Watch Recorded Zoom Session</span>
                </button>
              )}

              <a
                href={item.joinUrl}
                target="_blank"
                rel="noreferrer"
                className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-2xl border border-slate-200 transition"
                title="Launch in Zoom Native App"
              >
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* EMBEDDED ZOOM LIVE CLASSROOM MODAL */}
      {activeMeetingRoom && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-50 flex items-center justify-center p-2 sm:p-4 animate-fadeIn">
          <div className="bg-slate-900 text-white rounded-3xl w-full max-w-5xl h-[92vh] flex flex-col border-2 border-amber-400/50 shadow-2xl overflow-hidden relative">
            
            {/* Zoom Classroom Header Bar */}
            <div className="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-600 rounded-xl text-white">
                  <Video className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-extrabold text-sm text-white">{activeMeetingRoom.topic}</h3>
                    <span className="bg-red-600 text-white text-[9px] font-black uppercase px-2 py-0.5 rounded-full animate-pulse">
                      LIVE STREAM
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Meeting ID: <span className="font-mono text-amber-300 font-bold">{activeMeetingRoom.meetingId}</span> • Host: {activeMeetingRoom.teacherName}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {inClassAttendance && (
                  <span className="bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold px-2.5 py-1 rounded-xl flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Attendance Checked In</span>
                  </span>
                )}

                <button
                  onClick={() => setActiveMeetingRoom(null)}
                  className="px-3 py-1.5 bg-red-950 hover:bg-red-800 text-red-200 rounded-xl font-bold text-xs border border-red-700/60 transition"
                >
                  Leave Class
                </button>
              </div>
            </div>

            {/* Classroom Body Grid (Video Stage + Interactive Chat) */}
            <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
              {/* Left Main Video Stage */}
              <div className="lg:col-span-8 bg-slate-950 p-4 flex flex-col justify-between relative overflow-hidden">
                {/* Embedded Video Screen Simulation */}
                <div className="flex-1 bg-slate-900 rounded-2xl border border-slate-800 flex flex-col items-center justify-center relative overflow-hidden shadow-inner">
                  {/* Fake Presentation Canvas */}
                  <div className="text-center space-y-3 p-6 max-w-md">
                    <div className="w-20 h-20 bg-blue-900/60 text-amber-300 rounded-full mx-auto flex items-center justify-center border-2 border-amber-400/40 shadow-xl">
                      <Video className="w-10 h-10 animate-pulse" />
                    </div>
                    <h4 className="font-black text-lg text-white">{activeMeetingRoom.subject} Live Class</h4>
                    <p className="text-xs text-slate-300 font-medium">
                      {activeMeetingRoom.teacherName} is sharing presentation screen on Page 42.
                    </p>
                    <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 text-[11px] text-amber-200 font-mono">
                      "Chlorophyll traps sunlight energy during photosynthesis to produce plant food."
                    </div>
                  </div>

                  {/* Self Video Thumbnail Overlay */}
                  <div className="absolute bottom-3 right-3 w-32 h-24 bg-slate-950 rounded-xl border-2 border-slate-700 overflow-hidden shadow-2xl flex items-center justify-center text-center">
                    {videoOn ? (
                      <div className="text-[10px] font-bold text-emerald-400 space-y-1">
                        <div className="w-8 h-8 rounded-full bg-blue-900 text-white font-black mx-auto flex items-center justify-center">
                          K
                        </div>
                        <span>Kavin (Class 4)</span>
                      </div>
                    ) : (
                      <div className="text-[10px] font-bold text-slate-500">
                        Camera Off
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Control Bar */}
                <div className="pt-3 flex items-center justify-between gap-2 flex-wrap text-xs">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setMicMuted(!micMuted)}
                      className={`p-2.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
                        micMuted ? 'bg-red-900/80 text-white' : 'bg-slate-800 text-slate-200'
                      }`}
                    >
                      {micMuted ? <MicOff className="w-4 h-4 text-red-400" /> : <Mic className="w-4 h-4 text-emerald-400" />}
                      <span>{micMuted ? 'Muted' : 'Unmute'}</span>
                    </button>

                    <button
                      onClick={() => setVideoOn(!videoOn)}
                      className={`p-2.5 rounded-xl font-bold flex items-center gap-1.5 transition ${
                        !videoOn ? 'bg-red-900/80 text-white' : 'bg-slate-800 text-slate-200'
                      }`}
                    >
                      {!videoOn ? <VideoOff className="w-4 h-4 text-red-400" /> : <Video className="w-4 h-4 text-emerald-400" />}
                      <span>{videoOn ? 'Cam On' : 'Cam Off'}</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setHandRaised(!handRaised);
                        alert(handRaised ? 'Hand lowered' : 'Hand raised! Teacher notified of your doubt.');
                      }}
                      className={`px-3 py-2 rounded-xl font-bold flex items-center gap-1.5 transition ${
                        handRaised
                          ? 'bg-amber-400 text-blue-950 font-black'
                          : 'bg-slate-800 text-slate-200 hover:bg-slate-700'
                      }`}
                    >
                      <Hand className="w-4 h-4" />
                      <span>{handRaised ? 'Hand Raised ✋' : 'Raise Hand'}</span>
                    </button>

                    <a
                      href={activeMeetingRoom.joinUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl transition flex items-center gap-1 text-xs"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Zoom App</span>
                    </a>
                  </div>
                </div>
              </div>

              {/* Right Live Class Chat & Doubts Panel */}
              <div className="lg:col-span-4 bg-slate-900 border-t lg:border-t-0 lg:border-l border-slate-800 p-4 flex flex-col justify-between">
                <div className="border-b border-slate-800 pb-2 mb-2 flex items-center justify-between">
                  <span className="font-extrabold text-xs text-amber-300 flex items-center gap-1">
                    <MessageSquare className="w-4 h-4 text-amber-400" />
                    In-Class Live Doubts & Chat
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">28 Students</span>
                </div>

                {/* Messages Box */}
                <div className="flex-1 overflow-y-auto space-y-2 pr-1 text-xs my-2">
                  {classChatMessages.map((msg, idx) => (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-xl space-y-1 ${
                        msg.isTeacher ? 'bg-amber-950/60 border border-amber-500/40 text-amber-100' : 'bg-slate-800 text-slate-200'
                      }`}
                    >
                      <div className="flex items-center justify-between text-[10px] font-bold opacity-80">
                        <span>{msg.sender}</span>
                        <span>{msg.time}</span>
                      </div>
                      <p className="font-medium text-xs">{msg.text}</p>
                    </div>
                  ))}
                </div>

                {/* Chat Input */}
                <div className="pt-2 border-t border-slate-800 flex gap-1.5">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Ask teacher a question..."
                    className="flex-1 bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-medium text-white focus:outline-none focus:ring-1 focus:ring-amber-400"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="p-2 bg-amber-400 text-blue-950 rounded-xl font-bold hover:bg-amber-300 transition"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* SCHEDULE NEW CLASS MODAL (TEACHERS) */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-lg w-full space-y-4 shadow-2xl relative border-2 border-amber-400 text-slate-900 max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowScheduleModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-amber-400 text-blue-950 rounded-2xl shadow">
                <Video className="w-6 h-6 text-blue-950" />
              </div>
              <div>
                <h3 className="font-extrabold text-lg text-blue-950">Schedule Zoom Online Class</h3>
                <p className="text-xs text-slate-500">Teacher Portal • Publish Zoom meeting for students</p>
              </div>
            </div>

            <form onSubmit={handleScheduleSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Class Topic / Chapter Title:</label>
                <input
                  type="text"
                  required
                  value={newTopic}
                  onChange={(e) => setNewTopic(e.target.value)}
                  placeholder="e.g. Chapter 5: Geometry Angles & Triangles"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-semibold focus:outline-none focus:ring-2 focus:ring-blue-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Subject:</label>
                  <select
                    value={newSubject}
                    onChange={(e) => setNewSubject(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800"
                  >
                    <option value="Mathematics">Mathematics</option>
                    <option value="Environmental Science (EVS)">EVS</option>
                    <option value="Tamil">Tamil</option>
                    <option value="English">English</option>
                    <option value="Computer Science">Computer Science</option>
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Target Class / Grade:</label>
                  <select
                    value={newGrade}
                    onChange={(e) => setNewGrade(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-slate-800"
                  >
                    <option value="Nursery / LKG">Nursery / LKG</option>
                    <option value="UKG">UKG</option>
                    <option value="Class 1">Class 1</option>
                    <option value="Class 2">Class 2</option>
                    <option value="Class 3">Class 3</option>
                    <option value="Class 4">Class 4</option>
                    <option value="Class 5">Class 5</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Host Teacher:</label>
                  <input
                    type="text"
                    required
                    value={newTeacher}
                    onChange={(e) => setNewTeacher(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">Start Time:</label>
                  <input
                    type="text"
                    required
                    value={newTime}
                    onChange={(e) => setNewTime(e.target.value)}
                    placeholder="e.g. 10:30 AM"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                <div>
                  <label className="font-bold text-slate-700 block mb-0.5">Zoom Meeting ID:</label>
                  <input
                    type="text"
                    required
                    value={newMeetingId}
                    onChange={(e) => setNewMeetingId(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-mono font-bold text-xs"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-0.5">Passcode:</label>
                  <input
                    type="text"
                    required
                    value={newPasscode}
                    onChange={(e) => setNewPasscode(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-300 font-mono font-bold text-xs text-amber-900"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-950 hover:bg-blue-900 text-amber-400 font-black text-xs rounded-xl transition shadow flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                <span>Publish Zoom Meeting to Student Portals</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

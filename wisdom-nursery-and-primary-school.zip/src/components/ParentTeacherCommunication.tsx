import React, { useState } from 'react';
import {
  MessageSquare,
  Send,
  UserCheck,
  CheckCircle2,
  Clock,
  Plus,
  Filter,
  Paperclip,
  Calendar,
  Sparkles,
  PhoneCall,
  ChevronRight,
  ShieldAlert,
  Search,
  Check,
  X,
  FileText,
  BadgeCheck,
} from 'lucide-react';
import { StudentProfile } from '../types';

interface ParentTeacherCommunicationProps {
  student?: StudentProfile | null;
}

interface MessageReply {
  id: string;
  sender: 'parent' | 'teacher';
  senderName: string;
  senderRole: string;
  content: string;
  timestamp: string;
}

interface QueryThread {
  id: string;
  category: string;
  recipientName: string;
  recipientRole: string;
  subject: string;
  priority: 'Normal' | 'Urgent' | 'Important';
  status: 'Open' | 'Replied' | 'Resolved';
  createdAt: string;
  updatedAt: string;
  messages: MessageReply[];
}

export const ParentTeacherCommunication: React.FC<ParentTeacherCommunicationProps> = ({ student: inputStudent }) => {
  const student = inputStudent || {
    id: 'WNS-2026-0304',
    name: 'S. Kavin Vijay',
    fatherName: 'Mr. S. Vijayakumar',
    motherName: 'Mrs. V. Revathi',
    grade: 'Class 3-A',
    rollNo: '24',
    section: 'A',
    dob: '12/05/2018',
    parentPhone: '9840123456',
    address: 'No. 14, Main Road, Essur Village, Cheyyur Taluk - 603301',
    vanRoute: 'Route 2 - Cheyyur / Essur Van',
  };
  // Sample initial threads
  const [threads, setThreads] = useState<QueryThread[]>([
    {
      id: 'THREAD-101',
      category: 'Academic Progress / Math Doubts',
      recipientName: 'Mrs. V. Srimathi',
      recipientRole: 'Class Teacher & Math Teacher',
      subject: 'Clarification regarding Multiplication Tables homework in Class 3',
      priority: 'Important',
      status: 'Replied',
      createdAt: '25 Jul 2026, 06:30 PM',
      updatedAt: '26 Jul 2026, 09:15 AM',
      messages: [
        {
          id: 'm-1',
          sender: 'parent',
          senderName: `${student.fatherName} (Parent)`,
          senderRole: 'Parent',
          content: `Respected Madam, ${student.name} was facing a small difficulty with 7 and 8 multiplication tables given on Page 42. Could you kindly review his worksheet tomorrow in class? Thank you.`,
          timestamp: '25 Jul 2026, 06:30 PM',
        },
        {
          id: 'm-2',
          sender: 'teacher',
          senderName: 'Mrs. V. Srimathi',
          senderRole: 'Class Teacher',
          content: `Dear Parent, Vanakkam! Sure, I will personally guide ${student.name} during the morning practice session tomorrow and provide extra practice flashcards. His overall progress is very promising!`,
          timestamp: '26 Jul 2026, 09:15 AM',
        },
      ],
    },
    {
      id: 'THREAD-102',
      category: 'Attendance & Sick Leave',
      recipientName: 'Mr. R. Saravanan',
      recipientRole: 'Headmaster / Admin Office',
      subject: 'Leave intimation for 2 days due to mild fever',
      priority: 'Urgent',
      status: 'Resolved',
      createdAt: '18 Jul 2026, 07:45 AM',
      updatedAt: '18 Jul 2026, 08:30 AM',
      messages: [
        {
          id: 'm-3',
          sender: 'parent',
          senderName: `${student.fatherName} (Parent)`,
          senderRole: 'Parent',
          content: `Respected Sir, ${student.name} is down with mild fever since last night. Doctor advised 2 days rest. Kindly grant medical leave for today and tomorrow. Medical certificate attached.`,
          timestamp: '18 Jul 2026, 07:45 AM',
        },
        {
          id: 'm-4',
          sender: 'teacher',
          senderName: 'Mr. R. Saravanan',
          senderRole: 'Headmaster',
          content: `Leave granted and attendance register updated as Medical Leave. Wish ${student.name} a speedy recovery. Homework will be sent via student portal.`,
          timestamp: '18 Jul 2026, 08:30 AM',
        },
      ],
    },
    {
      id: 'THREAD-103',
      category: 'School Bus / Transport Route',
      recipientName: 'Mr. K. Ganesan',
      recipientRole: 'School Transport Coordinator',
      subject: 'Temporary change in van drop location for Friday',
      priority: 'Normal',
      status: 'Open',
      createdAt: 'Today, 07:10 AM',
      updatedAt: 'Today, 07:10 AM',
      messages: [
        {
          id: 'm-5',
          sender: 'parent',
          senderName: `${student.fatherName} (Parent)`,
          senderRole: 'Parent',
          content: `Sir, on Friday evening, please drop ${student.name} near Essur Main Temple Stop instead of Northern Colony stop, as grandmother will be waiting there. Phone: 9176593129.`,
          timestamp: 'Today, 07:10 AM',
        },
      ],
    },
  ]);

  const [selectedThreadId, setSelectedThreadId] = useState<string>('THREAD-101');
  const [filterStatus, setFilterStatus] = useState<'All' | 'Open' | 'Replied' | 'Resolved'>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // New Message Modal State
  const [isNewModalOpen, setIsNewModalOpen] = useState(false);
  const [newCategory, setNewCategory] = useState('Academic Progress / Subject Doubts');
  const [newRecipient, setNewRecipient] = useState('Mrs. V. Srimathi (Class Teacher)');
  const [newSubject, setNewSubject] = useState('');
  const [newMessageText, setNewMessageText] = useState('');
  const [newPriority, setNewPriority] = useState<'Normal' | 'Urgent' | 'Important'>('Normal');
  const [attachment, setAttachment] = useState<File | null>(null);

  // Reply state
  const [replyText, setReplyText] = useState('');

  // PTM Appointment Meeting Modal
  const [isPtmModalOpen, setIsPtmModalOpen] = useState(false);
  const [ptmDate, setPtmDate] = useState('2026-08-01');
  const [ptmSlot, setPtmSlot] = useState('04:00 PM - 04:30 PM (After School Hours)');
  const [ptmTopic, setPtmTopic] = useState('First Term Performance Review & Tamil Reading Progress');
  const [ptmSuccess, setPtmSuccess] = useState(false);

  const selectedThread = threads.find((t) => t.id === selectedThreadId) || threads[0];

  const handleCreateThread = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.trim() || !newMessageText.trim()) {
      alert('Please fill in both Subject and Message details.');
      return;
    }

    const now = new Date();
    const timeStr = `Today, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const newThread: QueryThread = {
      id: `THREAD-${Math.floor(100 + Math.random() * 900)}`,
      category: newCategory,
      recipientName: newRecipient.split(' (')[0],
      recipientRole: newRecipient.includes('(') ? newRecipient.split('(')[1].replace(')', '') : 'Teacher',
      subject: newSubject,
      priority: newPriority,
      status: 'Open',
      createdAt: timeStr,
      updatedAt: timeStr,
      messages: [
        {
          id: `msg-${Date.now()}`,
          sender: 'parent',
          senderName: `${student.fatherName} (Parent)`,
          senderRole: 'Parent',
          content: newMessageText,
          timestamp: timeStr,
        },
      ],
    };

    setThreads([newThread, ...threads]);
    setSelectedThreadId(newThread.id);
    setIsNewModalOpen(false);
    setNewSubject('');
    setNewMessageText('');
    setAttachment(null);
  };

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !selectedThread) return;

    const now = new Date();
    const timeStr = `Today, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const updatedThreads = threads.map((t) => {
      if (t.id === selectedThread.id) {
        return {
          ...t,
          status: 'Open' as const,
          updatedAt: timeStr,
          messages: [
            ...t.messages,
            {
              id: `msg-${Date.now()}`,
              sender: 'parent' as const,
              senderName: `${student.fatherName} (Parent)`,
              senderRole: 'Parent',
              content: replyText,
              timestamp: timeStr,
            },
          ],
        };
      }
      return t;
    });

    setThreads(updatedThreads);
    setReplyText('');
  };

  const handleSchedulePtm = (e: React.FormEvent) => {
    e.preventDefault();
    setPtmSuccess(true);
    setTimeout(() => {
      setPtmSuccess(false);
      setIsPtmModalOpen(false);
    }, 3000);
  };

  const filteredThreads = threads.filter((t) => {
    const matchesFilter = filterStatus === 'All' || t.status === filterStatus;
    const matchesSearch =
      t.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.recipientName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-100 text-blue-900 rounded-2xl shrink-0">
              <MessageSquare className="w-6 h-6 text-blue-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-extrabold text-blue-950">
                  Parent-Teacher Direct Desk
                </h3>
                <span className="bg-amber-100 text-amber-900 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-amber-300">
                  Class {student.grade} Desk
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Send structured queries to Class Teacher ({student.classTeacher}) or Admin. Track official teacher responses.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setIsPtmModalOpen(true)}
              className="px-3.5 py-2.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-900 font-extrabold text-xs transition border border-purple-200 flex items-center gap-1.5"
            >
              <Calendar className="w-4 h-4 text-purple-700" />
              <span>Book 1-on-1 PTM Meet</span>
            </button>

            <button
              onClick={() => setIsNewModalOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black text-xs transition flex items-center gap-1.5 shadow"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>New Teacher Query</span>
            </button>
          </div>
        </div>

        {/* Filters and Search Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search query subject or teacher..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-800"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider shrink-0 flex items-center gap-1">
              <Filter className="w-3 h-3" /> Status:
            </span>
            {(['All', 'Open', 'Replied', 'Resolved'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1 rounded-full font-bold text-[11px] transition shrink-0 ${
                  filterStatus === st
                    ? 'bg-blue-950 text-amber-400'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* TWO COLUMN INTERFACE: QUERY LIST & CONVERSATION DETAIL */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* LEFT COLUMN: THREAD LIST */}
        <div className="lg:col-span-5 bg-white border border-slate-200 rounded-3xl p-4 shadow-sm space-y-3">
          <div className="flex items-center justify-between border-b border-slate-100 pb-2">
            <h4 className="font-extrabold text-xs text-slate-800 uppercase tracking-wider">
              Submitted Queries ({filteredThreads.length})
            </h4>
            <span className="text-[10px] text-slate-400 font-bold">Class Teacher: {student.classTeacher}</span>
          </div>

          <div className="space-y-2.5 max-h-[550px] overflow-y-auto pr-1">
            {filteredThreads.length > 0 ? (
              filteredThreads.map((thread) => {
                const isSelected = thread.id === selectedThreadId;
                return (
                  <div
                    key={thread.id}
                    onClick={() => setSelectedThreadId(thread.id)}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer space-y-2 relative ${
                      isSelected
                        ? 'bg-blue-950 text-white border-blue-900 shadow-md ring-2 ring-amber-400'
                        : 'bg-slate-50 hover:bg-slate-100/80 border-slate-200 text-slate-800'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                        isSelected ? 'bg-amber-400 text-blue-950' : 'bg-slate-200 text-slate-700'
                      }`}>
                        {thread.category.split(' / ')[0]}
                      </span>

                      <span
                        className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full ${
                          thread.status === 'Replied'
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                            : thread.status === 'Resolved'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-amber-100 text-amber-900'
                        }`}
                      >
                        {thread.status === 'Replied' ? 'Teacher Replied' : thread.status}
                      </span>
                    </div>

                    <div>
                      <h5 className={`font-bold text-xs line-clamp-1 ${isSelected ? 'text-white' : 'text-slate-900'}`}>
                        {thread.subject}
                      </h5>
                      <p className={`text-[10px] line-clamp-1 mt-0.5 ${isSelected ? 'text-slate-300' : 'text-slate-500'}`}>
                        To: {thread.recipientName} ({thread.recipientRole})
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-[9px] pt-1 border-t border-slate-200/20">
                      <span className={isSelected ? 'text-amber-300 font-bold' : 'text-slate-400 font-medium'}>
                        {thread.updatedAt}
                      </span>
                      <span className={`font-bold flex items-center gap-1 ${isSelected ? 'text-amber-200' : 'text-blue-900'}`}>
                        <span>{thread.messages.length} msg</span>
                        <ChevronRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="p-8 text-center text-slate-400 text-xs space-y-2">
                <MessageSquare className="w-8 h-8 mx-auto text-slate-300" />
                <p>No query threads found matching criteria.</p>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIVE CONVERSATION MESSAGES */}
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-5">
          {selectedThread ? (
            <div className="space-y-5">
              {/* Thread Title & Teacher Recipient Info */}
              <div className="border-b border-slate-100 pb-4 space-y-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="bg-blue-100 text-blue-950 text-[10px] font-black uppercase px-2.5 py-0.5 rounded-full border border-blue-200">
                    {selectedThread.category}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    Ref ID: {selectedThread.id}
                  </span>
                </div>

                <h3 className="text-base font-extrabold text-blue-950 leading-snug">
                  {selectedThread.subject}
                </h3>

                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-blue-950 text-amber-400 font-black flex items-center justify-center text-xs shrink-0">
                      {selectedThread.recipientName.charAt(0)}
                    </div>
                    <div>
                      <span className="font-bold text-slate-900 block leading-tight">
                        {selectedThread.recipientName}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {selectedThread.recipientRole}
                      </span>
                    </div>
                  </div>

                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black ${
                    selectedThread.status === 'Replied'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-amber-100 text-amber-900'
                  }`}>
                    Status: {selectedThread.status}
                  </span>
                </div>
              </div>

              {/* Message Bubble List */}
              <div className="space-y-4 max-h-[400px] overflow-y-auto pr-1">
                {selectedThread.messages.map((msg) => {
                  const isParent = msg.sender === 'parent';
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isParent ? 'items-end' : 'items-start'} space-y-1`}
                    >
                      <div className="flex items-center gap-2 text-[10px] text-slate-400 font-bold px-1">
                        <span>{msg.senderName} ({msg.senderRole})</span>
                        <span>•</span>
                        <span>{msg.timestamp}</span>
                      </div>

                      <div
                        className={`p-4 rounded-2xl text-xs max-w-[85%] leading-relaxed shadow-xs ${
                          isParent
                            ? 'bg-blue-950 text-slate-100 rounded-tr-none border border-blue-900'
                            : 'bg-emerald-50 text-emerald-950 rounded-tl-none border border-emerald-200'
                        }`}
                      >
                        <p className="whitespace-pre-line">{msg.content}</p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Follow-up Reply Input */}
              <form onSubmit={handleSendReply} className="pt-3 border-t border-slate-100 space-y-3">
                <label className="block text-xs font-bold text-slate-700">
                  Post Follow-up Reply to {selectedThread.recipientName}:
                </label>
                <div className="flex gap-2">
                  <textarea
                    rows={2}
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your reply or additional details here..."
                    className="w-full text-xs font-medium px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-800 bg-slate-50/50"
                  ></textarea>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-slate-400 font-medium">
                    Replies trigger instant teacher dashboard notification.
                  </span>
                  <button
                    type="submit"
                    disabled={!replyText.trim()}
                    className="bg-blue-950 hover:bg-blue-900 disabled:opacity-50 text-amber-400 font-extrabold px-5 py-2 rounded-xl text-xs shadow transition flex items-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5 text-amber-400" />
                    <span>Send Message</span>
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="p-12 text-center text-slate-400 text-xs space-y-3">
              <MessageSquare className="w-10 h-10 mx-auto text-slate-300" />
              <p>Select a submitted query on the left to view response thread.</p>
            </div>
          )}
        </div>
      </div>

      {/* NEW QUERY MODAL */}
      {isNewModalOpen && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setIsNewModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
              <div className="p-2.5 bg-blue-100 text-blue-950 rounded-2xl">
                <Plus className="w-5 h-5 text-blue-950" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Send Query to Class Teacher</h4>
                <p className="text-xs text-slate-500">Student: {student.name} ({student.grade})</p>
              </div>
            </div>

            <form onSubmit={handleCreateThread} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Query Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:ring-2 focus:ring-blue-800"
                >
                  <option value="Academic Progress / Subject Doubts">Academic Progress / Subject Doubts</option>
                  <option value="Attendance & Sick Leave">Attendance & Sick Leave</option>
                  <option value="School Bus / Transport Route">School Bus / Transport Route</option>
                  <option value="School Events & Sports Day">School Events & Sports Day</option>
                  <option value="Fee Receipt / Certificate Request">Fee Receipt / Certificate Request</option>
                  <option value="General Inquiry / Other">General Inquiry / Other</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Select Recipient Staff / Teacher</label>
                <select
                  value={newRecipient}
                  onChange={(e) => setNewRecipient(e.target.value)}
                  className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:ring-2 focus:ring-blue-800"
                >
                  <option value="Mrs. V. Srimathi (Class Teacher)">Mrs. V. Srimathi (Class Teacher - Grade {student.grade})</option>
                  <option value="Mr. R. Saravanan (Headmaster / Admin)">Mr. R. Saravanan (Headmaster / Admin)</option>
                  <option value="Mrs. K. Dhanalakshmi (Tamil Teacher)">Mrs. K. Dhanalakshmi (Tamil Teacher)</option>
                  <option value="Mr. P. Ramesh (English & PE Teacher)">Mr. P. Ramesh (English & PE Teacher)</option>
                  <option value="Mr. K. Ganesan (Transport Coordinator)">Mr. K. Ganesan (School Van Coordinator)</option>
                </select>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Subject Heading</label>
                <input
                  type="text"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  placeholder="e.g. Tamil reading revision assistance"
                  required
                  className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Detailed Message for Teacher</label>
                <textarea
                  rows={4}
                  value={newMessageText}
                  onChange={(e) => setNewMessageText(e.target.value)}
                  placeholder="Write message in detail..."
                  required
                  className="w-full font-medium px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900 focus:ring-2 focus:ring-blue-800"
                ></textarea>
              </div>

              <div className="flex justify-between items-center pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-blue-950 text-amber-400 font-black hover:bg-blue-900 transition shadow flex items-center gap-1.5"
                >
                  <Send className="w-4 h-4 text-amber-400" />
                  <span>Submit Query to Teacher</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 1-ON-1 PTM APPOINTMENT BOOKING MODAL */}
      {isPtmModalOpen && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setIsPtmModalOpen(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 border-b border-slate-100 pb-3">
              <div className="p-2.5 bg-purple-100 text-purple-900 rounded-2xl">
                <Calendar className="w-5 h-5 text-purple-800" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Book 1-on-1 Parent-Teacher Meet</h4>
                <p className="text-xs text-slate-500">Meeting with Class Teacher ({student.classTeacher})</p>
              </div>
            </div>

            {ptmSuccess ? (
              <div className="p-4 bg-emerald-50 border-2 border-emerald-300 rounded-2xl text-xs text-emerald-900 space-y-2">
                <div className="flex items-center gap-2 font-black text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>Meeting Slot Confirmed!</span>
                </div>
                <p>
                  Appointment pass issued for <strong>{ptmDate}</strong> at <strong>{ptmSlot}</strong> in School Admin Office.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSchedulePtm} className="space-y-4 text-xs">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Preferred Meeting Date</label>
                  <input
                    type="date"
                    value={ptmDate}
                    onChange={(e) => setPtmDate(e.target.value)}
                    required
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Available Time Slot</label>
                  <select
                    value={ptmSlot}
                    onChange={(e) => setPtmSlot(e.target.value)}
                    className="w-full font-bold px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900"
                  >
                    <option value="04:00 PM - 04:30 PM (After School Hours)">04:00 PM - 04:30 PM (After School Hours)</option>
                    <option value="04:30 PM - 05:00 PM (After School Hours)">04:30 PM - 05:00 PM (After School Hours)</option>
                    <option value="12:30 PM - 01:00 PM (Lunch Break)">12:30 PM - 01:00 PM (Lunch Break)</option>
                    <option value="Saturday 10:00 AM - 11:00 AM (PTM Day)">Saturday 10:00 AM - 11:00 AM (PTM Day)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Main Topic for Discussion</label>
                  <input
                    type="text"
                    value={ptmTopic}
                    onChange={(e) => setPtmTopic(e.target.value)}
                    required
                    className="w-full font-semibold px-3.5 py-2.5 rounded-xl border border-slate-300 bg-slate-50 text-slate-900"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsPtmModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-purple-900 hover:bg-purple-800 text-white font-extrabold transition shadow flex items-center gap-1.5"
                  >
                    <Check className="w-4 h-4 text-amber-300" />
                    <span>Confirm Meeting Slot</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

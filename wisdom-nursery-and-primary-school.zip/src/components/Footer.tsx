import React from 'react';
import { GraduationCap, Heart, Phone, Mail, MapPin } from 'lucide-react';
import { SCHOOL_INFO } from '../data/schoolData';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveTab }) => {
  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 py-12 grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Brand Col */}
        <div className="space-y-3 md:col-span-1">
          <div className="flex items-center space-x-2.5">
            <img
              src={SCHOOL_INFO.logoUrl}
              alt={SCHOOL_INFO.name}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full border border-amber-400 bg-white p-0.5 object-contain"
            />
            <span className="font-extrabold text-white text-sm">WISDOM SCHOOL</span>
          </div>
          <p className="text-slate-400 text-xs leading-relaxed">
            Wisdom Nursery and Primary School, Essur - 603301. Dedicated to academic excellence, leadership skills, and character building.
          </p>
          <p className="text-amber-400 font-bold italic text-xs">"{SCHOOL_INFO.motto}"</p>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">Quick Navigation</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => setActiveTab('home')} className="hover:text-amber-400 transition">
                Home Overview
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('fee-payment')} className="hover:text-amber-400 transition text-amber-300 font-bold">
                Online Fee Payment (UPI)
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('student-portal')} className="hover:text-amber-400 transition">
                Student & Parent Portal
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('admissions')} className="hover:text-amber-400 transition">
                Online Admissions 2026
              </button>
            </li>
          </ul>
        </div>

        {/* Portals */}
        <div>
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">Resources</h4>
          <ul className="space-y-2 text-xs">
            <li>
              <button onClick={() => setActiveTab('notices')} className="hover:text-amber-400 transition">
                Circulars & Notices
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('calendar')} className="hover:text-amber-400 transition font-bold text-amber-300">
                Academic Calendar 2026-27
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('app-download')} className="hover:text-amber-400 transition">
                Download Android App
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('gallery')} className="hover:text-amber-400 transition">
                Campus Photo Gallery
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('contact')} className="hover:text-amber-400 transition">
                Contact Administration
              </button>
            </li>
            <li>
              <button onClick={() => setActiveTab('admin')} className="text-amber-400 hover:text-amber-300 transition font-bold flex items-center gap-1">
                <span>Admin Login (WISDOM)</span>
              </button>
            </li>
          </ul>
        </div>

        {/* Contact Info */}
        <div className="space-y-2">
          <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-3">School Office</h4>
          <p className="text-slate-300">Admin: <span className="text-white font-bold">{SCHOOL_INFO.adminName}</span></p>
          <p className="text-slate-300">Essur - 603301, Tamil Nadu</p>
          <p className="text-amber-300 font-bold">Ph: {SCHOOL_INFO.phone}</p>
          <p className="text-slate-400 text-[11px]">{SCHOOL_INFO.email}</p>
        </div>
      </div>

      <div className="bg-slate-900 border-t border-slate-800 py-4 px-4 text-center text-[11px] text-slate-500">
        <p>© {new Date().getFullYear()} Wisdom Nursery and Primary School, Essur - 603301. All rights reserved.</p>
        <p className="mt-0.5 text-[10px] text-slate-600">
          Motto: "Learn Today, Lead Tomorrow." | Admin: R. Saravanan | UPI: {SCHOOL_INFO.upiId}
        </p>
      </div>
    </footer>
  );
};

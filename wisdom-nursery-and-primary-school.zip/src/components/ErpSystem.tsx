import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  GraduationCap,
  CreditCard,
  CalendarCheck,
  FileSpreadsheet,
  BookOpen,
  Clock,
  FileText,
  Award,
  Bus,
  Library,
  HeartPulse,
  FolderOpen,
  Send,
  Download,
  Building2,
  Globe,
  Moon,
  Sun,
  Search,
  Plus,
  CheckCircle2,
  XCircle,
  AlertCircle,
  QrCode,
  Printer,
  ShieldAlert,
  Sparkles,
  PhoneCall,
  UserPlus,
  FileCheck,
  FileBadge,
} from 'lucide-react';
import { StudentExcelImporter } from './StudentExcelImporter';
import {
  SCHOOL_INFO,
  TEACHERS_DATA,
  CLASSES_DATA,
  ATTENDANCE_DATA,
  TIMETABLE_DATA,
  LIBRARY_BOOKS_DATA,
  TRANSPORT_ROUTES_DATA,
  HEALTH_RECORDS_DATA,
  STUDENT_DOCUMENTS_DATA,
  SMS_NOTIFICATIONS_DATA,
  TAMIL_TRANSLATIONS,
} from '../data/schoolData';
import {
  UserRole,
  SchoolBranch,
  StudentProfile,
  Teacher,
  AttendanceRecord,
  TransferCertificate,
  LibraryBook,
  TransportRoute,
  HealthRecord,
  DocumentItem,
  SmsNotification,
} from '../types';

interface ErpSystemProps {
  darkMode?: boolean;
  setDarkMode?: (val: boolean) => void;
  lang?: 'en' | 'ta';
  setLang?: (val: 'en' | 'ta') => void;
}

export const ErpSystem: React.FC<ErpSystemProps> = ({
  darkMode = false,
  setDarkMode,
  lang = 'en',
  setLang,
}) => {
  // Global State for ERP
  const [currentRole, setCurrentRole] = useState<UserRole>('Super Admin');
  const [currentBranch, setCurrentBranch] = useState<SchoolBranch>('Essur Main Campus');
  const [activeModule, setActiveModule] = useState<
    | 'dashboard'
    | 'students'
    | 'teachers'
    | 'fees'
    | 'classes'
    | 'attendance'
    | 'exams'
    | 'timetable'
    | 'tc-certificates'
    | 'report-cards'
    | 'id-cards'
    | 'library'
    | 'transport'
    | 'health'
    | 'documents'
    | 'notifications'
  >('dashboard');

  // Interactive Local Datasets State
  const [studentsList, setStudentsList] = useState<StudentProfile[]>([
    {
      id: 'WNS-2026-01',
      name: 'R. Kavin',
      grade: 'Class 3',
      rollNo: '01',
      fatherName: 'R. Saravanan',
      motherName: 'S. Kavitha',
      classTeacher: 'Mrs. S. Lakshmi',
      attendancePercentage: 94,
      totalDays: 45,
      presentDays: 42,
      bloodGroup: 'O +ve',
      feeStatus: 'Paid',
      term1Marks: [
        { subject: 'Tamil', mark: 92, max: 100, grade: 'A1' },
        { subject: 'English', mark: 88, max: 100, grade: 'A2' },
        { subject: 'Mathematics', mark: 95, max: 100, grade: 'A1' },
        { subject: 'General Science', mark: 90, max: 100, grade: 'A1' },
        { subject: 'Social Studies', mark: 86, max: 100, grade: 'A2' },
        { subject: 'Computer Basics', mark: 98, max: 100, grade: 'A1' },
      ],
      homework: [
        { id: 'hw-1', subject: 'Tamil', title: 'Thirukkural memorization lines 1-5', dueDate: '2026-07-23', status: 'Submitted' },
        { id: 'hw-2', subject: 'Maths', title: 'Chapter 2 Multiplication sums 1 to 10', dueDate: '2026-07-24', status: 'Pending' },
      ],
      teacherNotes: 'Excellent performance in Mathematics. Polite and attentive in class.',
    },
    {
      id: 'WNS-2026-02',
      name: 'S. Anitha',
      grade: 'Class 3',
      rollNo: '02',
      fatherName: 'S. Sundaram',
      motherName: 'Deepa S.',
      classTeacher: 'Mrs. S. Lakshmi',
      attendancePercentage: 98,
      totalDays: 45,
      presentDays: 44,
      bloodGroup: 'B +ve',
      feeStatus: 'Paid',
      term1Marks: [
        { subject: 'Tamil', mark: 95, max: 100, grade: 'A1' },
        { subject: 'English', mark: 94, max: 100, grade: 'A1' },
        { subject: 'Mathematics', mark: 89, max: 100, grade: 'A2' },
        { subject: 'General Science', mark: 92, max: 100, grade: 'A1' },
        { subject: 'Social Studies', mark: 91, max: 100, grade: 'A1' },
        { subject: 'Computer Basics', mark: 96, max: 100, grade: 'A1' },
      ],
      homework: [],
      teacherNotes: 'Very neat handwriting. Active participation in drawing and story reading.',
    },
    {
      id: 'WNS-2026-03',
      name: 'M. Vignesh',
      grade: 'Class 3',
      rollNo: '03',
      fatherName: 'M. Murugan',
      motherName: 'V. Valli',
      classTeacher: 'Mrs. S. Lakshmi',
      attendancePercentage: 86,
      totalDays: 45,
      presentDays: 39,
      bloodGroup: 'A +ve',
      feeStatus: 'Pending ₹2,500',
      term1Marks: [
        { subject: 'Tamil', mark: 78, max: 100, grade: 'B1' },
        { subject: 'English', mark: 74, max: 100, grade: 'B2' },
        { subject: 'Mathematics', mark: 82, max: 100, grade: 'A2' },
        { subject: 'General Science', mark: 80, max: 100, grade: 'A2' },
        { subject: 'Social Studies', mark: 76, max: 100, grade: 'B1' },
        { subject: 'Computer Basics', mark: 88, max: 100, grade: 'A2' },
      ],
      homework: [],
      teacherNotes: 'Needs slight improvement in English vocabulary. Regular attendance recommended.',
    },
  ]);

  const [teachersList, setTeachersList] = useState<Teacher[]>(TEACHERS_DATA);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(ATTENDANCE_DATA);
  const [smsList, setSmsList] = useState<SmsNotification[]>(SMS_NOTIFICATIONS_DATA);

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedClassFilter, setSelectedClassFilter] = useState('All');

  // New Student Modal
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [showExcelImporter, setShowExcelImporter] = useState(false);
  const [newStudent, setNewStudent] = useState({
    name: '',
    grade: 'Class 1',
    fatherName: '',
    motherName: '',
    bloodGroup: 'O +ve',
    phone: '',
  });

  // TC Generator Modal
  const [selectedTcStudent, setSelectedTcStudent] = useState<StudentProfile | null>(null);
  const [tcData, setTcData] = useState<TransferCertificate | null>(null);

  // Selected Report Card Student
  const [selectedReportStudent, setSelectedReportStudent] = useState<StudentProfile | null>(null);

  // Translation helper
  const t = (key: string) => {
    if (lang === 'ta' && TAMIL_TRANSLATIONS[key]) {
      return TAMIL_TRANSLATIONS[key];
    }
    return key;
  };

  // Export Data to CSV
  const handleExportCSV = (type: 'students' | 'fees' | 'attendance') => {
    let headers = '';
    let rows: string[] = [];

    if (type === 'students') {
      headers = 'ID,Name,Grade,Father Name,Mother Name,Attendance %,Fee Status\n';
      rows = studentsList.map(
        (s) => `"${s.id}","${s.name}","${s.grade}","${s.fatherName}","${s.motherName}",${s.attendancePercentage}%,"${s.feeStatus}"`
      );
    } else if (type === 'attendance') {
      headers = 'ID,Student Name,Grade,Date,Status,Remarks\n';
      rows = attendanceRecords.map(
        (a) => `"${a.studentId}","${a.studentName}","${a.grade}","${a.date}","${a.status}","${a.remarks || ''}"`
      );
    }

    const csvContent = 'data:text/csv;charset=utf-8,' + headers + rows.join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Wisdom_School_${type}_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Handle Add Student
  const handleSaveStudent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudent.name) return;

    const newId = `WNS-2026-0${studentsList.length + 1}`;
    const created: StudentProfile = {
      id: newId,
      name: newStudent.name,
      grade: newStudent.grade,
      rollNo: `0${studentsList.length + 1}`,
      fatherName: newStudent.fatherName || 'Parent Name',
      motherName: newStudent.motherName || 'Mother Name',
      classTeacher: 'Mrs. S. Lakshmi',
      attendancePercentage: 100,
      totalDays: 1,
      presentDays: 1,
      bloodGroup: newStudent.bloodGroup,
      feeStatus: 'Pending ₹4,500',
      term1Marks: [
        { subject: 'Tamil', mark: 85, max: 100, grade: 'A2' },
        { subject: 'English', mark: 85, max: 100, grade: 'A2' },
        { subject: 'Mathematics', mark: 90, max: 100, grade: 'A1' },
      ],
      homework: [],
      teacherNotes: 'Newly enrolled student for Academic Session 2026-27.',
    };

    setStudentsList([...studentsList, created]);
    setShowAddStudentModal(false);
    setNewStudent({ name: '', grade: 'Class 1', fatherName: '', motherName: '', bloodGroup: 'O +ve', phone: '' });
  };

  // Generate TC
  const generateTC = (student: StudentProfile) => {
    const tcNo = `WNS/TC/2026/${Math.floor(1000 + Math.random() * 9000)}`;
    const tcObj: TransferCertificate = {
      tcNo,
      studentId: student.id,
      studentName: student.name,
      fatherName: student.fatherName,
      motherName: student.motherName,
      dob: '2018-06-15',
      gender: 'Male',
      gradeAdmitted: 'LKG',
      gradeLeaving: student.grade,
      dateOfLeaving: new Date().toISOString().slice(0, 10),
      reasonForLeaving: 'Parent Relocation / Standard Promotion',
      conduct: 'Excellent',
      promotedToNextClass: true,
      issueDate: new Date().toLocaleDateString('en-IN'),
      qrVerificationCode: `VERIFY-TC-${tcNo}`,
    };

    setTcData(tcObj);
    setSelectedTcStudent(student);
  };

  // Send WhatsApp alert simulation
  const sendWhatsAppNotification = (phone: string, name: string, message: string) => {
    const newSms: SmsNotification = {
      id: `SMS-${Date.now()}`,
      recipientPhone: phone,
      recipientName: name,
      message,
      sentAt: new Date().toLocaleTimeString('en-IN'),
      channel: 'WhatsApp',
      status: 'Delivered',
    };
    setSmsList([newSms, ...smsList]);
    alert(`WhatsApp Alert Triggered to ${name} (${phone}):\n"${message}"`);
  };

  // Toggle attendance state
  const toggleAttendance = (recordId: string, newStatus: AttendanceRecord['status']) => {
    setAttendanceRecords(
      attendanceRecords.map((rec) => {
        if (rec.id === recordId) {
          return { ...rec, status: newStatus };
        }
        return rec;
      })
    );
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>
      
      {/* ERP Top Header & Control Bar */}
      <div className="bg-gradient-to-r from-blue-950 via-indigo-950 to-slate-900 text-white p-4 sm:p-6 shadow-xl border-b border-blue-800">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Brand & Branch Selector */}
          <div className="flex items-center space-x-3 w-full md:w-auto">
            <img
              src={SCHOOL_INFO.logoUrl}
              alt={SCHOOL_INFO.name}
              referrerPolicy="no-referrer"
              className="w-12 h-12 rounded-full border-2 border-amber-400 bg-white p-0.5 object-contain shadow"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white uppercase">
                  WISDOM SCHOOL ERP SYSTEM
                </h1>
                <span className="bg-amber-400 text-blue-950 font-extrabold text-[10px] px-2 py-0.5 rounded-full uppercase">
                  2026 - 2027
                </span>
              </div>
              <p className="text-xs text-amber-300 font-bold">
                {t('motto')} • Essur 603301
              </p>
            </div>
          </div>

          {/* ERP Settings Bar: Roles, Branch, Language, Dark Mode */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end text-xs font-bold">
            {/* Multi-School Branch Selector */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-xl px-2.5 py-1 flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-amber-400" />
              <select
                value={currentBranch}
                onChange={(e) => setCurrentBranch(e.target.value as SchoolBranch)}
                className="bg-transparent text-white outline-none cursor-pointer font-bold text-xs"
              >
                <option value="Essur Main Campus" className="bg-slate-900 text-white">Essur Main Campus</option>
                <option value="Kanchipuram Primary Branch" className="bg-slate-900 text-white">Kanchipuram Branch</option>
                <option value="Chengalpattu Campus" className="bg-slate-900 text-white">Chengalpattu Branch</option>
              </select>
            </div>

            {/* Login Role Switcher */}
            <div className="bg-slate-800/80 border border-slate-700 rounded-xl px-2.5 py-1 flex items-center gap-1.5">
              <span className="text-[10px] text-amber-400 uppercase font-black">Role:</span>
              <select
                value={currentRole}
                onChange={(e) => setCurrentRole(e.target.value as UserRole)}
                className="bg-transparent text-white outline-none cursor-pointer font-bold text-xs"
              >
                <option value="Super Admin" className="bg-slate-900">Super Admin</option>
                <option value="Principal" className="bg-slate-900">Principal</option>
                <option value="Office Staff" className="bg-slate-900">Office Staff</option>
                <option value="Teacher" className="bg-slate-900">Teacher</option>
                <option value="Parent" className="bg-slate-900">Parent</option>
                <option value="Student" className="bg-slate-900">Student</option>
              </select>
            </div>

            {/* Language Switcher (EN / Tamil) */}
            <button
              onClick={() => setLang && setLang(lang === 'en' ? 'ta' : 'en')}
              className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-300 px-3 py-1.5 rounded-xl transition flex items-center gap-1"
              title="Switch Language"
            >
              <Globe className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'en' ? 'தமிழ்' : 'English'}</span>
            </button>

            {/* Dark Mode Toggle */}
            <button
              onClick={() => setDarkMode && setDarkMode(!darkMode)}
              className="bg-slate-800 hover:bg-slate-700 border border-slate-700 text-amber-300 p-1.5 rounded-xl transition"
              title="Toggle Dark/Light Mode"
            >
              {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-amber-400" />}
            </button>
          </div>
        </div>
      </div>

      {/* Main ERP Navigation Tabs Bar */}
      <div className={`border-b ${darkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-white'} shadow-sm overflow-x-auto`}>
        <div className="max-w-7xl mx-auto px-4 flex space-x-1 sm:space-x-2 py-2 text-xs font-extrabold whitespace-nowrap">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
            { id: 'students', label: 'Students', icon: Users },
            { id: 'teachers', label: 'Teachers', icon: GraduationCap },
            { id: 'fees', label: 'Fees Collection', icon: CreditCard },
            { id: 'classes', label: 'Classes & Sections', icon: BookOpen },
            { id: 'attendance', label: 'Daily Attendance', icon: CalendarCheck },
            { id: 'exams', label: 'Exams & Marks', icon: FileSpreadsheet },
            { id: 'timetable', label: 'Timetable', icon: Clock },
            { id: 'tc-certificates', label: 'TC & Certificates', icon: FileCheck },
            { id: 'report-cards', label: 'Report Cards', icon: FileBadge },
            { id: 'id-cards', label: '3D Smart ID Cards', icon: QrCode },
            { id: 'library', label: 'Library', icon: Library },
            { id: 'transport', label: 'Transport / Vans', icon: Bus },
            { id: 'health', label: 'Health Cards', icon: HeartPulse },
            { id: 'documents', label: 'Document Vault', icon: FolderOpen },
            { id: 'notifications', label: 'SMS & WhatsApp', icon: Send },
          ].map((tab) => {
            const IconComp = tab.icon;
            const isActive = activeModule === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveModule(tab.id as any)}
                className={`flex items-center space-x-1.5 px-3 py-2 rounded-xl transition ${
                  isActive
                    ? 'bg-blue-950 text-amber-400 shadow-md font-black'
                    : darkMode
                    ? 'text-slate-300 hover:bg-slate-800'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <IconComp className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* BODY CONTENT AREA */}
      <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
        
        {/* MODULE 1: DASHBOARD OVERVIEW */}
        {activeModule === 'dashboard' && (
          <div className="space-y-8 animate-fadeIn">
            {/* Role Header Banner */}
            <div className={`p-6 rounded-3xl border shadow-sm flex flex-col md:flex-row items-center justify-between gap-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-2xl bg-amber-400 text-blue-950 flex items-center justify-center font-black text-xl shadow">
                  {currentRole.charAt(0)}
                </div>
                <div>
                  <h2 className="text-xl font-extrabold text-blue-950 dark:text-amber-300">
                    Welcome, {currentRole}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Active Branch: <strong className="text-blue-900 dark:text-amber-400">{currentBranch}</strong> • Role-based view initialized
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => handleExportCSV('students')}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 shadow"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Backup Student CSV</span>
                </button>
              </div>
            </div>

            {/* Dashboard KPI Counters Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
              <div className={`p-4 rounded-2xl border shadow-sm space-y-1 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] uppercase font-black text-slate-400">Total Students</span>
                <div className="text-2xl font-black text-blue-950 dark:text-amber-400">217</div>
                <span className="text-[9px] text-emerald-600 font-bold">+14 New 2026 Admissions</span>
              </div>

              <div className={`p-4 rounded-2xl border shadow-sm space-y-1 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] uppercase font-black text-slate-400">Total Teachers</span>
                <div className="text-2xl font-black text-purple-900 dark:text-purple-300">18</div>
                <span className="text-[9px] text-purple-600 font-bold">100% Certified</span>
              </div>

              <div className={`p-4 rounded-2xl border shadow-sm space-y-1 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] uppercase font-black text-slate-400">Today Attendance</span>
                <div className="text-2xl font-black text-emerald-600">96.2%</div>
                <span className="text-[9px] text-slate-500 font-medium">208 / 217 Present</span>
              </div>

              <div className={`p-4 rounded-2xl border shadow-sm space-y-1 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] uppercase font-black text-slate-400">Term Fee Collected</span>
                <div className="text-2xl font-black text-blue-900 dark:text-blue-300">₹8,42,000</div>
                <span className="text-[9px] text-blue-600 font-bold">88.6% Target Achieved</span>
              </div>

              <div className={`p-4 rounded-2xl border shadow-sm space-y-1 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] uppercase font-black text-slate-400">Pending Dues</span>
                <div className="text-2xl font-black text-red-600">₹1,08,000</div>
                <span className="text-[9px] text-red-500 font-semibold">24 Parent Alerts Sent</span>
              </div>

              <div className={`p-4 rounded-2xl border shadow-sm space-y-1 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <span className="text-[10px] uppercase font-black text-slate-400">Upcoming Exam</span>
                <div className="text-lg font-extrabold text-amber-600">Unit Test I</div>
                <span className="text-[9px] text-slate-500 font-medium">Starts July 20, 2026</span>
              </div>
            </div>

            {/* Quick Overview Widgets */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Fee Collection Progress Widget */}
              <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <div className="flex justify-between items-center border-b pb-3 border-slate-100 dark:border-slate-800">
                  <h3 className="font-extrabold text-slate-800 dark:text-slate-100 text-sm">
                    Fee Collection Status (Term 1)
                  </h3>
                  <span className="text-xs font-bold text-emerald-600">₹8,42,000 Collected</span>
                </div>

                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                      <span>Primary Classes (Class 1 to 5)</span>
                      <span>92%</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3">
                      <div className="bg-emerald-500 h-3 rounded-full" style={{ width: '92%' }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-bold text-slate-600 dark:text-slate-300 mb-1">
                      <span>Kindergarten (Nursery, LKG, UKG)</span>
                      <span>82%</span>
                    </div>
                    <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3">
                      <div className="bg-amber-500 h-3 rounded-full" style={{ width: '82%' }}></div>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex justify-between items-center text-xs text-slate-500">
                  <span>Supported Gateways: UPI / GPay / PhonePe / Cash / Easebuzz</span>
                  <button onClick={() => setActiveModule('fees')} className="text-blue-900 dark:text-amber-400 font-bold hover:underline">
                    Manage Fees →
                  </button>
                </div>
              </div>

              {/* Attendance & Recent Activity */}
              <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <div className="flex justify-between items-center border-b pb-3 border-slate-100 dark:border-slate-800">
                  <h3 className="font-extrabold text-slate-800 dark:text-slate-100 text-sm">
                    Today Attendance Summary ({new Date().toLocaleDateString('en-IN')})
                  </h3>
                  <button onClick={() => setActiveModule('attendance')} className="text-xs font-bold text-blue-900 dark:text-amber-400 hover:underline">
                    Mark Register
                  </button>
                </div>

                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200">
                    <span className="text-[10px] font-bold text-emerald-800 dark:text-emerald-300 uppercase">Present</span>
                    <div className="text-xl font-black text-emerald-600">208</div>
                  </div>

                  <div className="p-3 bg-red-50 dark:bg-red-950/40 rounded-2xl border border-red-200">
                    <span className="text-[10px] font-bold text-red-800 dark:text-red-300 uppercase">Absent</span>
                    <div className="text-xl font-black text-red-600">6</div>
                  </div>

                  <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-2xl border border-amber-200">
                    <span className="text-[10px] font-bold text-amber-800 dark:text-amber-300 uppercase">Late Entry</span>
                    <div className="text-xl font-black text-amber-600">3</div>
                  </div>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed">
                  Automated SMS & WhatsApp absence alerts are triggered instantly when marked absent by class teachers.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* MODULE 2: STUDENT MANAGEMENT */}
        {activeModule === 'students' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                  Student Management Directory
                </h2>
                <p className="text-xs text-slate-500">
                  Total Enrolled: <strong>{studentsList.length} Students</strong> • Class & Roll Number Roster
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setShowExcelImporter(true)}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow transform active:scale-95"
                >
                  <FileSpreadsheet className="w-4 h-4 text-amber-300" />
                  <span>Import Excel (.xlsx)</span>
                </button>
                <button
                  onClick={() => setShowAddStudentModal(true)}
                  className="bg-blue-950 hover:bg-blue-900 text-white font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow"
                >
                  <UserPlus className="w-4 h-4 text-amber-400" />
                  <span>Add New Student</span>
                </button>
                <button
                  onClick={() => handleExportCSV('students')}
                  className="bg-slate-700 hover:bg-slate-600 text-white font-extrabold px-3.5 py-2.5 rounded-xl text-xs flex items-center gap-1.5 shadow"
                >
                  <Download className="w-4 h-4" />
                  <span>Export CSV</span>
                </button>
              </div>
            </div>

            {/* Filter & Search Bar */}
            <div className={`p-4 rounded-2xl border shadow-sm flex flex-col md:flex-row gap-3 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search student by name, ID, father name..."
                  className="w-full text-xs font-bold pl-10 pr-4 py-2 rounded-xl border border-slate-300 dark:border-slate-700 dark:bg-slate-800 outline-none"
                />
              </div>

              <select
                value={selectedClassFilter}
                onChange={(e) => setSelectedClassFilter(e.target.value)}
                className="text-xs font-bold px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 dark:bg-slate-800 outline-none"
              >
                <option value="All">All Classes</option>
                <option value="Class 3">Class 3</option>
                <option value="Class 2">Class 2</option>
                <option value="Class 1">Class 1</option>
                <option value="LKG">LKG</option>
              </select>
            </div>

            {/* Student Table */}
            <div className={`rounded-3xl border shadow-sm overflow-hidden ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className={`font-extrabold uppercase border-b ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-slate-100 border-slate-200 text-slate-700'}`}>
                    <tr>
                      <th className="p-4">Student ID</th>
                      <th className="p-4">Student Name</th>
                      <th className="p-4">Grade</th>
                      <th className="p-4">Parents</th>
                      <th className="p-4">Attendance</th>
                      <th className="p-4">Fee Status</th>
                      <th className="p-4 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    {studentsList.map((stu) => (
                      <tr key={stu.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition">
                        <td className="p-4 font-mono font-bold text-blue-900 dark:text-amber-400">{stu.id}</td>
                        <td className="p-4">
                          <span className="font-extrabold text-slate-900 dark:text-slate-100 block">{stu.name}</span>
                          <span className="text-[10px] text-slate-400">Roll: {stu.rollNo} • Blood: {stu.bloodGroup}</span>
                        </td>
                        <td className="p-4 font-bold">{stu.grade}</td>
                        <td className="p-4">
                          <span className="block font-bold">{stu.fatherName}</span>
                          <span className="text-[10px] text-slate-400">{stu.motherName}</span>
                        </td>
                        <td className="p-4">
                          <span className="font-bold text-emerald-600">{stu.attendancePercentage}%</span>
                          <span className="text-[10px] text-slate-400 block">({stu.presentDays}/{stu.totalDays} days)</span>
                        </td>
                        <td className="p-4">
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${stu.feeStatus === 'Paid' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'}`}>
                            {stu.feeStatus}
                          </span>
                        </td>
                        <td className="p-4 text-center space-x-1">
                          <button
                            onClick={() => generateTC(stu)}
                            className="px-2.5 py-1 bg-amber-400 hover:bg-amber-300 text-blue-950 rounded-lg text-[10px] font-black transition"
                          >
                            Generate TC
                          </button>
                          <button
                            onClick={() => {
                              setSelectedReportStudent(stu);
                              setActiveModule('report-cards');
                            }}
                            className="px-2.5 py-1 bg-blue-900 hover:bg-blue-800 text-white rounded-lg text-[10px] font-bold transition"
                          >
                            Report Card
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* MODULE 3: TEACHERS MANAGEMENT */}
        {activeModule === 'teachers' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                  Teaching Faculty Directory
                </h2>
                <p className="text-xs text-slate-500">
                  Qualified & Experienced Educators at Wisdom Nursery & Primary School
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {teachersList.map((tch) => (
                <div
                  key={tch.id}
                  className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 rounded-full bg-blue-950 text-amber-400 font-black text-lg flex items-center justify-center border border-amber-400 shrink-0">
                      {tch.name.charAt(4) || 'T'}
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">{tch.name}</h3>
                      <p className="text-xs text-blue-900 dark:text-amber-400 font-bold">{tch.qualification}</p>
                    </div>
                  </div>

                  <div className="space-y-1 text-xs text-slate-600 dark:text-slate-300 pt-2 border-t border-slate-100 dark:border-slate-800">
                    <p><strong>Subject:</strong> {tch.subject}</p>
                    <p><strong>Class Assignment:</strong> {tch.assignedClass}</p>
                    <p><strong>Phone:</strong> {tch.phone}</p>
                    <p><strong>Experience:</strong> Since {tch.joiningYear}</p>
                  </div>

                  <button
                    onClick={() => sendWhatsAppNotification(tch.phone, tch.name, 'Dear Teacher, Faculty meeting scheduled tomorrow at 03:45 PM in Staff Room.')}
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Staff WhatsApp Alert</span>
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODULE 4: FEES COLLECTION & PAYMENT GATEWAY */}
        {activeModule === 'fees' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                  Fees Collection & Online Gateway
                </h2>
                <p className="text-xs text-slate-500">
                  Easebuzz / Razorpay / UPI Google Pay Integration & Automated Digital Receipts
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* UPI & Easebuzz Simulator */}
              <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-amber-500" />
                  <span>Collect Term Fee (UPI / Easebuzz / Cash)</span>
                </h3>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">Select Student</label>
                    <select className="w-full border rounded-xl p-2.5 font-bold outline-none dark:bg-slate-800 dark:border-slate-700">
                      {studentsList.map((s) => (
                        <option key={s.id} value={s.id}>{s.name} ({s.id}) - {s.grade}</option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">Fee Term</label>
                      <select className="w-full border rounded-xl p-2.5 font-bold outline-none dark:bg-slate-800 dark:border-slate-700">
                        <option>Term 1 Tuition Fee</option>
                        <option>Term 2 Tuition Fee</option>
                        <option>Term 3 Tuition Fee</option>
                        <option>Annual Book & Uniform Fee</option>
                        <option>Van Transport Fee</option>
                      </select>
                    </div>

                    <div>
                      <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">Amount (₹)</label>
                      <input type="number" defaultValue={4500} className="w-full border rounded-xl p-2.5 font-bold outline-none dark:bg-slate-800 dark:border-slate-700" />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-600 dark:text-slate-400 mb-1">UPI Transaction Reference / UTR</label>
                    <input type="text" placeholder="12-digit UPI UTR e.g. 382910482910" className="w-full border rounded-xl p-2.5 font-mono font-bold outline-none dark:bg-slate-800 dark:border-slate-700" />
                  </div>

                  <button
                    onClick={() => alert('Fee Payment Recorded Successfully! Receipt generated and SMS alert sent to parent.')}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold rounded-xl text-xs transition shadow"
                  >
                    Confirm & Issue Digital Fee Receipt
                  </button>
                </div>
              </div>

              {/* Outstanding Fee Summary */}
              <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <h3 className="font-bold text-slate-800 dark:text-slate-100 text-base">
                  Pending Fee Alert Register
                </h3>

                <div className="space-y-3">
                  {studentsList
                    .filter((s) => s.feeStatus.includes('Pending'))
                    .map((stu) => (
                      <div key={stu.id} className="p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 rounded-2xl flex items-center justify-between">
                        <div>
                          <h4 className="font-bold text-red-950 dark:text-red-300 text-xs">{stu.name} ({stu.grade})</h4>
                          <p className="text-[10px] text-slate-500">Parent: {stu.fatherName}</p>
                          <span className="text-xs font-black text-red-600">{stu.feeStatus}</span>
                        </div>

                        <button
                          onClick={() => sendWhatsAppNotification('+919176593129', stu.fatherName, `Dear Parent of ${stu.name}, friendly reminder regarding pending Term fee ${stu.feeStatus}. Kindly pay via UPI rsaravanan102002-1@okhdfcbank.`)}
                          className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1"
                        >
                          <Send className="w-3 h-3" />
                          <span>WhatsApp Reminder</span>
                        </button>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MODULE 5: CLASSES & SECTIONS */}
        {activeModule === 'classes' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                Class & Section Roster
              </h2>
              <p className="text-xs text-slate-500">Pre-Nursery, LKG, UKG and Primary Grades 1 to 5</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {CLASSES_DATA.map((cls) => (
                <div key={cls.id} className={`p-5 rounded-3xl border shadow-sm space-y-2 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                  <div className="flex justify-between items-center">
                    <span className="font-black text-blue-950 dark:text-amber-400 text-base">{cls.className}</span>
                    <span className="bg-amber-400 text-blue-950 font-black text-[10px] px-2 py-0.5 rounded-full">Section {cls.section}</span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300">Class Teacher: <strong>{cls.classTeacher}</strong></p>
                  <div className="flex justify-between items-center pt-2 border-t border-slate-100 text-xs font-bold">
                    <span>Room: {cls.roomNo}</span>
                    <span className="text-emerald-600">{cls.totalStudents} Students</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODULE 6: DAILY ATTENDANCE REGISTER */}
        {activeModule === 'attendance' && (
          <div className="space-y-6 animate-fadeIn">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                  Daily Attendance Register
                </h2>
                <p className="text-xs text-slate-500">
                  Class 3 Section A • Date: <strong>{new Date().toLocaleDateString('en-IN')}</strong>
                </p>
              </div>

              <button
                onClick={() => handleExportCSV('attendance')}
                className="bg-emerald-600 text-white font-extrabold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Attendance Log</span>
              </button>
            </div>

            <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="space-y-3">
                {attendanceRecords.map((rec) => (
                  <div key={rec.id} className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 border border-slate-200 dark:border-slate-700">
                    <div>
                      <h4 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">{rec.studentName}</h4>
                      <p className="text-xs text-slate-500">ID: {rec.studentId} • {rec.grade}</p>
                      {rec.remarks && <p className="text-[10px] text-red-500 font-bold">Note: {rec.remarks}</p>}
                    </div>

                    <div className="flex items-center gap-2">
                      {(['Present', 'Absent', 'Late', 'Leave'] as const).map((st) => (
                        <button
                          key={st}
                          onClick={() => toggleAttendance(rec.id, st)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-black transition ${
                            rec.status === st
                              ? st === 'Present'
                                ? 'bg-emerald-600 text-white shadow'
                                : st === 'Absent'
                                ? 'bg-red-600 text-white shadow'
                                : 'bg-amber-500 text-white shadow'
                              : 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                          }`}
                        >
                          {st}
                        </button>
                      ))}

                      {rec.status === 'Absent' && (
                        <button
                          onClick={() => sendWhatsAppNotification('+919176593129', rec.studentName, `Dear Parent, ${rec.studentName} is marked ABSENT today (${rec.date}). Please inform school admin if sick leave.`)}
                          className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1"
                          title="Trigger Absence WhatsApp to Parent"
                        >
                          <Send className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* MODULE 7: EXAMS & MARKS */}
        {activeModule === 'exams' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                Examinations & Subject Marks Entry
              </h2>
              <p className="text-xs text-slate-500">Term 1 Assessment Marks & Automatic Grade Calculation</p>
            </div>

            <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className={`font-extrabold uppercase border-b ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-300' : 'bg-slate-100 border-slate-200 text-slate-700'}`}>
                    <tr>
                      <th className="p-3">Subject</th>
                      <th className="p-3">Max Marks</th>
                      <th className="p-3">Obtained Marks (R. Kavin)</th>
                      <th className="p-3">Grade</th>
                      <th className="p-3">Performance</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                    {studentsList[0].term1Marks.map((m, idx) => (
                      <tr key={idx}>
                        <td className="p-3 font-bold text-slate-900 dark:text-slate-100">{m.subject}</td>
                        <td className="p-3 font-mono">{m.max}</td>
                        <td className="p-3 font-bold text-blue-900 dark:text-amber-400 font-mono text-sm">{m.mark}</td>
                        <td className="p-3">
                          <span className="bg-amber-400 text-blue-950 font-black px-2 py-0.5 rounded text-[10px]">{m.grade}</span>
                        </td>
                        <td className="p-3 text-emerald-600 font-bold">{m.mark >= 90 ? 'Excellent' : 'Very Good'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* MODULE 8: TIMETABLE */}
        {activeModule === 'timetable' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                Weekly Class Timetable
              </h2>
              <p className="text-xs text-slate-500">Class 3 Section A Schedule (Period 1 to 7)</p>
            </div>

            <div className="space-y-6">
              {TIMETABLE_DATA.map((dayObj) => (
                <div key={dayObj.day} className={`p-6 rounded-3xl border shadow-sm space-y-3 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                  <h3 className="font-black text-lg text-blue-950 dark:text-amber-400">{dayObj.day}</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {dayObj.periods.map((p) => (
                      <div key={p.periodNo} className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-2xl border border-slate-200 dark:border-slate-700 space-y-1">
                        <div className="flex justify-between text-[10px] font-bold text-amber-600">
                          <span>Period {p.periodNo}</span>
                          <span>{p.time}</span>
                        </div>
                        <div className="font-extrabold text-slate-900 dark:text-slate-100 text-xs">{p.subject}</div>
                        <p className="text-[10px] text-slate-500">{p.teacherName} • {p.room}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODULE 9: TC & CERTIFICATES */}
        {activeModule === 'tc-certificates' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                Transfer Certificate (TC) & Conduct Generator
              </h2>
              <p className="text-xs text-slate-500">Official printable certificate generation with QR validation code</p>
            </div>

            {selectedTcStudent && tcData ? (
              <div className="bg-white text-slate-900 p-8 rounded-3xl border-2 border-amber-400 shadow-2xl space-y-6 max-w-2xl mx-auto font-serif">
                <div className="text-center space-y-1 border-b-2 border-slate-800 pb-4">
                  <img src={SCHOOL_INFO.logoUrl} alt={SCHOOL_INFO.name} className="w-16 h-16 mx-auto rounded-full border border-amber-400 p-0.5 object-contain" />
                  <h3 className="text-xl font-black text-blue-950 uppercase">WISDOM NURSERY AND PRIMARY SCHOOL</h3>
                  <p className="text-xs font-sans font-bold text-slate-600">ESSUR - 603301, TAMIL NADU, INDIA</p>
                  <span className="bg-amber-400 text-blue-950 px-3 py-1 font-sans font-black text-xs inline-block mt-2 rounded">
                    OFFICIAL TRANSFER CERTIFICATE
                  </span>
                </div>

                <div className="space-y-3 text-xs leading-relaxed font-sans">
                  <div className="flex justify-between"><span>TC Number: <strong>{tcData.tcNo}</strong></span> <span>Date: <strong>{tcData.issueDate}</strong></span></div>
                  <div className="flex justify-between"><span>Student Name: <strong>{tcData.studentName}</strong></span> <span>EMIS ID: <strong>{tcData.studentId}</strong></span></div>
                  <div className="flex justify-between"><span>Father / Guardian Name: <strong>{tcData.fatherName}</strong></span></div>
                  <div className="flex justify-between"><span>Class Last Studied: <strong>{tcData.gradeLeaving}</strong></span> <span>Conduct: <strong>{tcData.conduct}</strong></span></div>
                  <div className="flex justify-between"><span>Reason for Leaving: <strong>{tcData.reasonForLeaving}</strong></span></div>
                </div>

                <div className="pt-6 border-t flex justify-between items-end font-sans text-xs">
                  <div className="text-center space-y-1">
                    <QrCode className="w-12 h-12 mx-auto text-blue-950" />
                    <span className="text-[9px] text-slate-500 font-mono">Scan QR to Verify</span>
                  </div>

                  <div className="text-center font-bold">
                    <p className="mb-8">R. SARAVANAN</p>
                    <p className="border-t border-slate-800 pt-1 text-[10px]">CORRESPONDENT / PRINCIPAL</p>
                  </div>
                </div>

                <div className="flex gap-3 pt-4 font-sans">
                  <button onClick={() => window.print()} className="flex-1 py-2.5 bg-blue-950 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1">
                    <Printer className="w-4 h-4 text-amber-400" /> Print Official TC
                  </button>
                  <button onClick={() => setSelectedTcStudent(null)} className="py-2.5 px-4 bg-slate-200 text-slate-800 font-bold rounded-xl text-xs">
                    Back
                  </button>
                </div>
              </div>
            ) : (
              <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <p className="text-xs text-slate-500">Select any student from the Student Directory tab to issue a Transfer Certificate or Bonafide Certificate.</p>
                <button onClick={() => setActiveModule('students')} className="px-4 py-2 bg-blue-950 text-white font-bold rounded-xl text-xs">
                  Go to Student Directory
                </button>
              </div>
            )}
          </div>
        )}

        {/* MODULE 10: REPORT CARDS */}
        {activeModule === 'report-cards' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                Student Progress Report Cards
              </h2>
              <p className="text-xs text-slate-500">Term 1 Performance Statement & Grade Sheet</p>
            </div>

            {selectedReportStudent ? (
              <div className="bg-white text-slate-900 p-8 rounded-3xl border-2 border-blue-900 shadow-2xl space-y-6 max-w-2xl mx-auto">
                <div className="text-center border-b pb-4 space-y-1">
                  <img src={SCHOOL_INFO.logoUrl} alt={SCHOOL_INFO.name} className="w-16 h-16 mx-auto rounded-full border border-amber-400 p-0.5 object-contain" />
                  <h3 className="text-lg font-black text-blue-950 uppercase">WISDOM NURSERY AND PRIMARY SCHOOL</h3>
                  <p className="text-xs text-amber-600 font-bold">ESSUR - 603301 | ACADEMIC REPORT CARD 2026-2027</p>
                </div>

                <div className="grid grid-cols-2 gap-4 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  <div><strong>Student Name:</strong> {selectedReportStudent.name}</div>
                  <div><strong>Student ID:</strong> {selectedReportStudent.id}</div>
                  <div><strong>Grade / Class:</strong> {selectedReportStudent.grade}</div>
                  <div><strong>Roll No:</strong> {selectedReportStudent.rollNo}</div>
                </div>

                <table className="w-full text-left text-xs border border-slate-200">
                  <thead className="bg-blue-950 text-white uppercase font-bold">
                    <tr>
                      <th className="p-2 border">Subject</th>
                      <th className="p-2 border">Max</th>
                      <th className="p-2 border">Obtained</th>
                      <th className="p-2 border">Grade</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y font-medium">
                    {selectedReportStudent.term1Marks.map((m, i) => (
                      <tr key={i}>
                        <td className="p-2 border font-bold">{m.subject}</td>
                        <td className="p-2 border">{m.max}</td>
                        <td className="p-2 border font-bold text-blue-900">{m.mark}</td>
                        <td className="p-2 border font-bold text-amber-600">{m.grade}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs">
                  <strong>Teacher's Remark:</strong> "{selectedReportStudent.teacherNotes}"
                </div>

                <div className="flex gap-3">
                  <button onClick={() => window.print()} className="flex-1 py-2.5 bg-blue-950 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1">
                    <Printer className="w-4 h-4 text-amber-400" /> Print Progress Report
                  </button>
                  <button onClick={() => setSelectedReportStudent(null)} className="py-2.5 px-4 bg-slate-200 text-slate-800 font-bold rounded-xl text-xs">
                    Close
                  </button>
                </div>
              </div>
            ) : (
              <div className={`p-6 rounded-3xl border shadow-sm text-center space-y-3 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <p className="text-xs text-slate-500">Select any student from the Student Directory tab to view and print their official report card.</p>
                <button onClick={() => setActiveModule('students')} className="px-4 py-2 bg-blue-950 text-white font-bold rounded-xl text-xs">
                  Open Student List
                </button>
              </div>
            )}
          </div>
        )}

        {/* MODULE 11: 3D SMART ID CARDS */}
        {activeModule === 'id-cards' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                3D Smart Student ID Cards
              </h2>
              <p className="text-xs text-slate-500">Interactive Flippable Student ID Badge with QR Validation Code</p>
            </div>

            <div className="max-w-md mx-auto">
              <div className="bg-gradient-to-br from-blue-950 via-indigo-950 to-slate-900 rounded-3xl p-6 text-white shadow-2xl border-2 border-amber-400 space-y-4">
                <div className="flex items-center justify-between border-b border-amber-400/30 pb-3">
                  <div className="flex items-center space-x-2">
                    <img src={SCHOOL_INFO.logoUrl} alt={SCHOOL_INFO.name} className="w-8 h-8 rounded-full bg-white p-0.5 border border-amber-400" />
                    <div>
                      <h4 className="font-black text-xs text-amber-300">WISDOM SCHOOL ESSUR</h4>
                      <p className="text-[9px] text-slate-300">Nursery & Primary School • 603301</p>
                    </div>
                  </div>
                  <span className="bg-amber-400 text-blue-950 font-black text-[9px] px-2 py-0.5 rounded">STUDENT</span>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="w-20 h-20 rounded-2xl bg-white/10 border-2 border-amber-400 p-1 flex items-center justify-center shrink-0">
                    <Users className="w-10 h-10 text-amber-400" />
                  </div>
                  <div className="space-y-1 text-xs">
                    <h3 className="text-base font-extrabold text-amber-300">R. KAVIN</h3>
                    <p>ID: <span className="font-mono font-bold">WNS-2026-01</span></p>
                    <p>Grade: <span className="font-bold text-amber-400">Class 3</span></p>
                    <p>Emergency: <span className="font-bold">+91 9176593129</span></p>
                  </div>
                </div>

                <div className="pt-3 border-t border-amber-400/30 flex justify-between items-center text-[10px]">
                  <span>Motto: "LEARN TODAY, LEAD TOMORROW."</span>
                  <QrCode className="w-8 h-8 text-amber-400" />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* MODULE 12: LIBRARY MANAGEMENT */}
        {activeModule === 'library' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                School Library Catalog
              </h2>
              <p className="text-xs text-slate-500">Tamil Literature, Panchatantra Moral Tales & Science Reference Books</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {LIBRARY_BOOKS_DATA.map((bk) => (
                <div key={bk.id} className={`p-6 rounded-3xl border shadow-sm space-y-3 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                  <span className="bg-blue-100 text-blue-900 font-extrabold text-[10px] px-2.5 py-1 rounded-full uppercase border border-blue-200">
                    {bk.category}
                  </span>
                  <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm leading-snug">{bk.title}</h3>
                  <p className="text-xs text-slate-500">Author: <strong>{bk.author}</strong></p>
                  <div className="flex justify-between items-center pt-2 border-t text-xs font-bold">
                    <span>Rack: {bk.rackNo}</span>
                    <span className="text-emerald-600">{bk.availableCopies} / {bk.totalCopies} Available</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODULE 13: TRANSPORT & VAN ROUTES */}
        {activeModule === 'transport' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                School Transport & Van Management
              </h2>
              <p className="text-xs text-slate-500">Pickup Routes across Essur, Vedanthangal & Madurantakam highway</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {TRANSPORT_ROUTES_DATA.map((tr) => (
                <div key={tr.id} className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-2xl bg-amber-400 text-blue-950 flex items-center justify-center font-black">
                      <Bus className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">{tr.routeName}</h3>
                      <p className="text-xs text-blue-900 dark:text-amber-400 font-bold">{tr.vanNumber}</p>
                    </div>
                  </div>

                  <div className="space-y-1 text-xs text-slate-600 dark:text-slate-300">
                    <p><strong>Driver Name:</strong> {tr.driverName} ({tr.driverPhone})</p>
                    <p><strong>Pickup Points:</strong> {tr.pickupPoints.join(' → ')}</p>
                    <p><strong>Timings:</strong> {tr.timingMorning} | {tr.timingEvening}</p>
                    <p><strong>Monthly Transport Fee:</strong> ₹{tr.monthlyFee}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODULE 14: HEALTH RECORDS */}
        {activeModule === 'health' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                Student Health & Annual Growth Records
              </h2>
              <p className="text-xs text-slate-500">Blood group registry, height/weight annual tracking</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {HEALTH_RECORDS_DATA.map((hr) => (
                <div key={hr.studentId} className={`p-6 rounded-3xl border shadow-sm space-y-3 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                  <div className="flex justify-between items-center">
                    <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">{hr.studentName} ({hr.grade})</h3>
                    <span className="bg-red-100 text-red-800 font-black text-xs px-2.5 py-0.5 rounded-full">{hr.bloodGroup}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 dark:bg-slate-800 p-3 rounded-2xl">
                    <div>Height: <strong>{hr.heightCm} cm</strong></div>
                    <div>Weight: <strong>{hr.weightKg} kg</strong></div>
                    <div>Allergies: <strong>{hr.allergies}</strong></div>
                    <div>Last Checkup: <strong>{hr.lastCheckupDate}</strong></div>
                  </div>

                  <p className="text-xs text-slate-500">Doctor Note: "{hr.doctorRemarks}"</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* MODULE 15: DOCUMENT VAULT */}
        {activeModule === 'documents' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                Student Document Vault
              </h2>
              <p className="text-xs text-slate-500">Birth Certificate, Aadhaar Card & Marksheets repository</p>
            </div>

            <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="space-y-3">
                {STUDENT_DOCUMENTS_DATA.map((doc) => (
                  <div key={doc.id} className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl flex items-center justify-between border border-slate-200 dark:border-slate-700">
                    <div className="flex items-center space-x-3">
                      <FolderOpen className="w-8 h-8 text-amber-500" />
                      <div>
                        <h4 className="font-extrabold text-slate-900 dark:text-slate-100 text-xs">{doc.docType} ({doc.fileName})</h4>
                        <p className="text-[10px] text-slate-500">Uploaded for {doc.studentName} • Size: {doc.fileSize}</p>
                      </div>
                    </div>

                    <span className="bg-emerald-100 text-emerald-800 font-bold text-[10px] px-2.5 py-0.5 rounded-full uppercase">
                      {doc.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* MODULE 16: SMS & WHATSAPP BROADCAST LOG */}
        {activeModule === 'notifications' && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <h2 className="text-2xl font-black text-blue-950 dark:text-amber-300">
                SMS & WhatsApp Broadcast Log
              </h2>
              <p className="text-xs text-slate-500">Direct notifications log sent to parent mobile numbers</p>
            </div>

            <div className={`p-6 rounded-3xl border shadow-sm space-y-4 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="space-y-3">
                {smsList.map((sms) => (
                  <div key={sms.id} className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-2xl space-y-1 border border-slate-200 dark:border-slate-700">
                    <div className="flex justify-between items-center text-xs font-bold">
                      <span className="text-blue-900 dark:text-amber-400">{sms.recipientName} ({sms.recipientPhone})</span>
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2 py-0.5 rounded-full">{sms.channel} • {sms.status}</span>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300">"{sms.message}"</p>
                    <span className="text-[10px] text-slate-400 block">{sms.sentAt}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>

      {/* ADD STUDENT MODAL */}
      {showAddStudentModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white text-slate-900 rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex justify-between items-center border-b pb-3">
              <h3 className="font-extrabold text-base text-blue-950">Add New Student Registration</h3>
              <button onClick={() => setShowAddStudentModal(false)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>

            <form onSubmit={handleSaveStudent} className="space-y-3 text-xs">
              <div>
                <label className="block font-bold text-slate-600 mb-1">Student Full Name</label>
                <input
                  type="text"
                  required
                  value={newStudent.name}
                  onChange={(e) => setNewStudent({ ...newStudent, name: e.target.value })}
                  placeholder="e.g. K. Dhanush"
                  className="w-full border rounded-xl p-2.5 font-bold outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-600 mb-1">Grade / Class</label>
                  <select
                    value={newStudent.grade}
                    onChange={(e) => setNewStudent({ ...newStudent, grade: e.target.value })}
                    className="w-full border rounded-xl p-2.5 font-bold outline-none"
                  >
                    <option>Pre-Nursery</option>
                    <option>LKG</option>
                    <option>UKG</option>
                    <option>Class 1</option>
                    <option>Class 2</option>
                    <option>Class 3</option>
                    <option>Class 4</option>
                    <option>Class 5</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-600 mb-1">Blood Group</label>
                  <select
                    value={newStudent.bloodGroup}
                    onChange={(e) => setNewStudent({ ...newStudent, bloodGroup: e.target.value })}
                    className="w-full border rounded-xl p-2.5 font-bold outline-none"
                  >
                    <option>O +ve</option>
                    <option>A +ve</option>
                    <option>B +ve</option>
                    <option>AB +ve</option>
                    <option>O -ve</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">Father's Name</label>
                <input
                  type="text"
                  required
                  value={newStudent.fatherName}
                  onChange={(e) => setNewStudent({ ...newStudent, fatherName: e.target.value })}
                  placeholder="Father / Guardian Name"
                  className="w-full border rounded-xl p-2.5 font-bold outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-600 mb-1">Parent Mobile Number</label>
                <input
                  type="tel"
                  required
                  value={newStudent.phone}
                  onChange={(e) => setNewStudent({ ...newStudent, phone: e.target.value })}
                  placeholder="10-digit mobile number"
                  className="w-full border rounded-xl p-2.5 font-bold outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-blue-950 hover:bg-blue-900 text-white font-extrabold rounded-xl transition shadow mt-2"
              >
                Enroll Student Record
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Student Excel Importer Modal */}
      <StudentExcelImporter
        isOpen={showExcelImporter}
        onClose={() => setShowExcelImporter(false)}
        onImportSuccess={(importedRows) => {
          const newProfiles: StudentProfile[] = importedRows.map((r) => ({
            id: r.id || `WNS-2026-${Math.floor(Math.random() * 900 + 100)}`,
            name: r.name,
            grade: r.grade,
            rollNo: r.rollNo || '01',
            fatherName: r.fatherName || 'Parent',
            motherName: r.motherName || 'Parent',
            classTeacher: r.classTeacher || 'Mrs. S. Lakshmi',
            attendancePercentage: 95,
            feeStatus: r.feeStatus || 'Paid for Term 1',
            phone: r.phone,
            dob: r.dob,
          }));
          setStudentsList((prev) => [...newProfiles, ...prev]);
        }}
      />

    </div>
  );
};

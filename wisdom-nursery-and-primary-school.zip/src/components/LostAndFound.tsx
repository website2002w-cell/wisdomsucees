import React, { useState } from 'react';
import {
  Search,
  Plus,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Clock,
  MapPin,
  Tag,
  Camera,
  User,
  Phone,
  Filter,
  Check,
  X,
  Sparkles,
  Building2,
  ShieldCheck,
  PackageCheck,
  FileText,
} from 'lucide-react';
import { StudentProfile } from '../types';

interface LostAndFoundProps {
  student?: StudentProfile | null;
}

export interface LostItem {
  id: string;
  title: string;
  type: 'Lost' | 'Found';
  category: 'Water Bottle' | 'Uniform / Sweater' | 'ID Card / Badge' | 'School Bag & Books' | 'Eyeglasses / Watch' | 'Sports Gear' | 'Other';
  location: string;
  dateReported: string;
  description: string;
  photoUrl: string;
  status: 'Unclaimed' | 'Handed Over to Office' | 'Claimed & Returned';
  contactPerson: string;
  contactPhone: string;
  claimedBy?: string;
  claimedDate?: string;
}

export const LostAndFound: React.FC<LostAndFoundProps> = ({ student }) => {
  const [items, setItems] = useState<LostItem[]>([
    {
      id: 'lf-101',
      title: 'Milton Steel Thermos Water Bottle (Blue with Stickers)',
      type: 'Found',
      category: 'Water Bottle',
      location: 'Primary Playground Bench (Near Slide)',
      dateReported: '26 Jul 2026',
      description: 'Blue insulated water bottle with Spider-Man stickers and student initials "K.V." written at the bottom.',
      photoUrl: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=500&q=80',
      status: 'Handed Over to Office',
      contactPerson: 'Mrs. S. Parvathi (Ground Supervisor)',
      contactPhone: '+91 98402 11223',
    },
    {
      id: 'lf-102',
      title: 'Navy Blue School Cardigan Sweater (Size 26")',
      type: 'Found',
      category: 'Uniform / Sweater',
      location: 'Science Lab 2 (Physics Row 3)',
      dateReported: '25 Jul 2026',
      description: 'Wisdom crest embroidered cardigan left on bench during afternoon practical session.',
      photoUrl: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=500&q=80',
      status: 'Unclaimed',
      contactPerson: 'Lab Assistant Mr. R. Sundaram',
      contactPhone: '+91 94431 09812',
    },
    {
      id: 'lf-103',
      title: 'Wisdom Student Smart ID Card (Grade 3-A)',
      type: 'Found',
      category: 'ID Card / Badge',
      location: 'School Bus No. 2 (Seat Row 4)',
      dateReported: '27 Jul 2026',
      description: 'Green lanyard ID card belonging to S. Kavin Vijay.',
      photoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=500&q=80',
      status: 'Handed Over to Office',
      contactPerson: 'Van Driver Thiru. Murugan',
      contactPhone: '+91 98402 38192',
    },
    {
      id: 'lf-104',
      title: 'Black Frame Prescription Spectacles in Red Case',
      type: 'Lost',
      category: 'Eyeglasses / Watch',
      location: 'Library Reading Area / Auditorium',
      dateReported: '24 Jul 2026',
      description: 'Child-sized rectangular black spectacles in a hard red plastic case.',
      photoUrl: 'https://images.unsplash.com/photo-1591076482161-42ce6da69f67?auto=format&fit=crop&w=500&q=80',
      status: 'Unclaimed',
      contactPerson: 'Parent M. Vijayakumar',
      contactPhone: '+91 98402 38192',
    },
    {
      id: 'lf-105',
      title: 'Camlin Geometry Box & Camel Watercolor Set',
      type: 'Found',
      category: 'School Bag & Books',
      location: 'Art Room Table B',
      dateReported: '22 Jul 2026',
      description: 'Complete compass box with student name tag.',
      photoUrl: 'https://images.unsplash.com/photo-1588072432836-e10032774350?auto=format&fit=crop&w=500&q=80',
      status: 'Claimed & Returned',
      contactPerson: 'Art Teacher Mrs. Deepa',
      contactPhone: '+91 94421 00192',
      claimedBy: 'Master A. Rahul (Class 4-B)',
      claimedDate: '23 Jul 2026',
    },
  ]);

  // Filters & Search
  const [activeTab, setActiveTab] = useState<'All' | 'Found' | 'Lost' | 'Claimed'>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showReportModal, setShowReportModal] = useState(false);
  const [showClaimModal, setShowClaimModal] = useState<LostItem | null>(null);

  // New Item Form State
  const [formTitle, setFormTitle] = useState('');
  const [formType, setFormType] = useState<'Lost' | 'Found'>('Found');
  const [formCategory, setFormCategory] = useState<LostItem['category']>('Water Bottle');
  const [formLocation, setFormLocation] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formContactPerson, setFormContactPerson] = useState(student?.name || '');
  const [formContactPhone, setFormContactPhone] = useState(student?.parentPhone || '');
  const [formPhotoUrl, setFormPhotoUrl] = useState('https://images.unsplash.com/photo-1584438784894-089d6a62b8fa?auto=format&fit=crop&w=500&q=80');

  // Claim Form State
  const [claimantName, setClaimantName] = useState(student?.name || '');
  const [claimantClass, setClaimantClass] = useState(student?.grade || 'Class 3-A');
  const [claimantNotes, setClaimantNotes] = useState('');

  const categories = ['All', 'Water Bottle', 'Uniform / Sweater', 'ID Card / Badge', 'School Bag & Books', 'Eyeglasses / Watch', 'Sports Gear', 'Other'];

  // Handle Post New Item
  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle || !formLocation) return;

    const newItem: LostItem = {
      id: `lf-${Date.now()}`,
      title: formTitle,
      type: formType,
      category: formCategory,
      location: formLocation,
      dateReported: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
      description: formDescription,
      photoUrl: formPhotoUrl,
      status: formType === 'Found' ? 'Handed Over to Office' : 'Unclaimed',
      contactPerson: formContactPerson || 'School Admin Desk',
      contactPhone: formContactPhone || '+91 98402 38192',
    };

    setItems([newItem, ...items]);
    setShowReportModal(false);
    // Reset form
    setFormTitle('');
    setFormLocation('');
    setFormDescription('');
  };

  // Handle Mark as Claimed / Handed Over
  const handleConfirmClaim = (e: React.FormEvent) => {
    e.preventDefault();
    if (!showClaimModal) return;

    const updated = items.map((it) => {
      if (it.id === showClaimModal.id) {
        return {
          ...it,
          status: 'Claimed & Returned' as const,
          claimedBy: `${claimantName} (${claimantClass})`,
          claimedDate: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }),
        };
      }
      return it;
    });

    setItems(updated);
    setShowClaimModal(null);
  };

  const filteredItems = items.filter((item) => {
    const matchesTab =
      activeTab === 'All'
        ? true
        : activeTab === 'Found'
        ? item.type === 'Found' && item.status !== 'Claimed & Returned'
        : activeTab === 'Lost'
        ? item.type === 'Lost' && item.status !== 'Claimed & Returned'
        : item.status === 'Claimed & Returned';

    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch =
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesTab && matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
      {/* Top Banner Header */}
      <div className="bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl shrink-0">
              <PackageCheck className="w-6 h-6 text-amber-900" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-blue-950">
                  School Lost & Found Registry
                </h2>
                <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-300">
                  Campus Main Office Desk (Room 102)
                </span>
              </div>
              <p className="text-xs text-slate-500">
                Report lost items, view found articles picked up on campus, and record owner verification for retrieval.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowReportModal(true)}
            className="px-4 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black text-xs transition shadow flex items-center gap-2 self-start md:self-auto"
          >
            <Plus className="w-4 h-4 text-amber-400" />
            <span>Report Lost or Found Item</span>
          </button>
        </div>

        {/* Status Counter Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl text-amber-950">
            <span className="text-[10px] text-amber-800 font-bold uppercase block">Active Found Items</span>
            <span className="font-extrabold text-lg text-amber-900">
              {items.filter((i) => i.type === 'Found' && i.status !== 'Claimed & Returned').length}
            </span>
          </div>

          <div className="p-3.5 bg-blue-50 border border-blue-200 rounded-2xl text-blue-950">
            <span className="text-[10px] text-blue-800 font-bold uppercase block">Reported Lost Items</span>
            <span className="font-extrabold text-lg text-blue-900">
              {items.filter((i) => i.type === 'Lost' && i.status !== 'Claimed & Returned').length}
            </span>
          </div>

          <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950">
            <span className="text-[10px] text-emerald-800 font-bold uppercase block">Reunited with Owners</span>
            <span className="font-extrabold text-lg text-emerald-900">
              {items.filter((i) => i.status === 'Claimed & Returned').length}
            </span>
          </div>

          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-slate-800">
            <span className="text-[10px] text-slate-500 font-bold uppercase block">Central Office Locker</span>
            <span className="font-bold text-xs text-blue-950 block mt-1">Admin Room 102 Box</span>
          </div>
        </div>

        {/* Search & Tabs Controls */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 text-xs pt-2">
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by title, location (e.g. Science Lab, Bus 2)..."
              className="w-full pl-10 pr-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-blue-800"
            />
          </div>

          <div className="md:col-span-4 flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            {(['All', 'Found', 'Lost', 'Claimed'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-2 rounded-lg text-xs font-extrabold transition ${
                  activeTab === tab
                    ? 'bg-blue-950 text-amber-400 shadow-xs'
                    : 'text-slate-700 hover:text-slate-900'
                }`}
              >
                {tab === 'All' ? 'All Registry' : tab === 'Found' ? 'Found Articles' : tab === 'Lost' ? 'Lost Reports' : 'Returned'}
              </button>
            ))}
          </div>

          <div className="md:col-span-3">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full font-bold px-3 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-800"
            >
              {categories.map((c) => (
                <option key={c} value={c}>Category: {c}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* REGISTRY ITEMS GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => {
          const isReturned = item.status === 'Claimed & Returned';

          return (
            <div
              key={item.id}
              className={`bg-white border rounded-3xl overflow-hidden shadow-sm hover:shadow-md transition flex flex-col justify-between ${
                isReturned ? 'border-emerald-200 opacity-85' : 'border-slate-200'
              }`}
            >
              {/* Image & Type Badge Header */}
              <div className="relative h-48 bg-slate-900 overflow-hidden group">
                <img
                  src={item.photoUrl}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition duration-500 opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent"></div>

                <div className="absolute top-3 left-3 flex gap-1.5">
                  <span
                    className={`font-black text-[9px] px-2.5 py-1 rounded-full border shadow-xs ${
                      item.type === 'Found'
                        ? 'bg-amber-400 text-blue-950 border-amber-300'
                        : 'bg-blue-950 text-amber-300 border-blue-800'
                    }`}
                  >
                    {item.type.toUpperCase()} ARTICLE
                  </span>
                  <span className="bg-slate-900/80 text-slate-200 font-bold text-[9px] px-2 py-1 rounded-full border border-slate-700 backdrop-blur-xs">
                    {item.category}
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 text-white">
                  <span className="text-[9px] font-bold text-slate-300 block">
                    Reported on: {item.dateReported}
                  </span>
                  <h4 className="font-extrabold text-sm leading-snug line-clamp-1">
                    {item.title}
                  </h4>
                </div>
              </div>

              {/* Item Content Details */}
              <div className="p-5 space-y-4 flex-1 flex flex-col justify-between text-xs">
                <div className="space-y-2">
                  <p className="text-slate-600 line-clamp-2 leading-relaxed text-[11px]">
                    {item.description}
                  </p>

                  <div className="p-2.5 bg-slate-50 rounded-2xl border border-slate-200 text-[11px] space-y-1">
                    <p className="text-slate-700 font-medium flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-blue-900 shrink-0" />
                      <span>Found / Lost at: <strong>{item.location}</strong></span>
                    </p>
                    <p className="text-slate-500 font-medium flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>Contact Custodian: <strong>{item.contactPerson}</strong></span>
                    </p>
                  </div>
                </div>

                {/* Footer Action Bar */}
                <div className="space-y-3 pt-3 border-t border-slate-100">
                  {isReturned ? (
                    <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-[11px] text-emerald-900 font-bold flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Returned to Owner
                      </span>
                      <span className="text-[10px] text-emerald-700 font-medium">{item.claimedBy}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setShowClaimModal(item)}
                        className="flex-1 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-extrabold transition shadow text-xs flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4 text-amber-400" />
                        <span>Claim / Handed Over</span>
                      </button>

                      <a
                        href={`tel:${item.contactPhone.replace(/\s+/g, '')}`}
                        className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold transition shrink-0"
                        title={`Call ${item.contactPerson}`}
                      >
                        <Phone className="w-4 h-4 text-blue-900" />
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* REPORT NEW ITEM MODAL */}
      {showReportModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5 shadow-2xl relative border-2 border-amber-400 animate-scaleUp">
            <button
              onClick={() => setShowReportModal(false)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-amber-100 text-amber-900 rounded-2xl">
                <PackageCheck className="w-6 h-6 text-amber-900" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Report Lost or Found Article</h4>
                <p className="text-xs text-slate-500">Post details to wisdom school campus board</p>
              </div>
            </div>

            <form onSubmit={handleCreatePost} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Report Type *</label>
                  <select
                    value={formType}
                    onChange={(e: any) => setFormType(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                  >
                    <option value="Found">I Found something on campus</option>
                    <option value="Lost">I Lost an item</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Category *</label>
                  <select
                    value={formCategory}
                    onChange={(e: any) => setFormCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                  >
                    {categories.filter((c) => c !== 'All').map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Item Name & Identifying Marks *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="e.g. Red Milton Water Bottle with Marvel stickers"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Campus Location *</label>
                <input
                  type="text"
                  required
                  value={formLocation}
                  onChange={(e) => setFormLocation(e.target.value)}
                  placeholder="e.g. Primary Playground, Science Lab 2, Bus No. 3"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Detailed Description</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Mention color, size, brand, name tags written on item..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Contact Person / Custodian</label>
                  <input
                    type="text"
                    value={formContactPerson}
                    onChange={(e) => setFormContactPerson(e.target.value)}
                    placeholder="e.g. S. Kavin Vijay / Admin Office"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-bold text-slate-700 block">Contact Phone Number</label>
                  <input
                    type="tel"
                    value={formContactPhone}
                    onChange={(e) => setFormContactPhone(e.target.value)}
                    placeholder="e.g. +91 98402 38192"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                  />
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900">
                📌 Found physical articles should be handed over to <strong>Admin Office Room 102 (Mrs. S. Parvathi)</strong> for secure storage.
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-amber-400 font-black transition shadow flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 text-amber-400" />
                  <span>Publish to Registry</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MARK AS CLAIMED / VERIFY MODAL */}
      {showClaimModal && (
        <div className="fixed inset-0 bg-blue-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full space-y-5 shadow-2xl relative border-2 border-emerald-500 animate-scaleUp">
            <button
              onClick={() => setShowClaimModal(null)}
              className="absolute top-4 right-4 p-2 text-slate-400 hover:text-slate-800 rounded-full hover:bg-slate-100 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 border-b border-slate-100 pb-3">
              <div className="p-3 bg-emerald-100 text-emerald-800 rounded-2xl">
                <CheckCircle2 className="w-6 h-6 text-emerald-600" />
              </div>
              <div>
                <h4 className="font-extrabold text-base text-blue-950">Verify Handover / Retrieval</h4>
                <p className="text-xs text-slate-500">Record owner verification for registry logs</p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1">
              <h5 className="font-bold text-slate-900">{showClaimModal.title}</h5>
              <p className="text-slate-500 text-[11px]">Location: {showClaimModal.location}</p>
            </div>

            <form onSubmit={handleConfirmClaim} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Student / Owner Name *</label>
                <input
                  type="text"
                  required
                  value={claimantName}
                  onChange={(e) => setClaimantName(e.target.value)}
                  placeholder="e.g. S. Kavin Vijay"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Grade / Section *</label>
                <input
                  type="text"
                  required
                  value={claimantClass}
                  onChange={(e) => setClaimantClass(e.target.value)}
                  placeholder="e.g. Class 3-A"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="font-bold text-slate-700 block">Verification Note / Identity Proof</label>
                <input
                  type="text"
                  value={claimantNotes}
                  onChange={(e) => setClaimantNotes(e.target.value)}
                  placeholder="e.g. Verified by Class Teacher Mrs. Anitha / School ID presented"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-bold text-slate-900 focus:outline-none"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowClaimModal(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 text-slate-700 font-bold hover:bg-slate-200 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black transition shadow flex items-center gap-1.5"
                >
                  <Check className="w-4 h-4 text-white" />
                  <span>Confirm Handed Over</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

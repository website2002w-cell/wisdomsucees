export interface StudentMark {
  subject: string;
  mark: number;
  max: number;
  grade: string;
}

export interface HomeworkItem {
  id: string;
  subject: string;
  title: string;
  dueDate: string;
  status: 'Pending' | 'Submitted';
}

export interface StudentProfile {
  id: string;
  name: string;
  grade: string;
  rollNo: string;
  fatherName: string;
  motherName: string;
  classTeacher: string;
  attendancePercentage: number;
  totalDays: number;
  presentDays: number;
  bloodGroup: string;
  feeStatus: string;
  term1Marks: StudentMark[];
  homework: HomeworkItem[];
  teacherNotes: string;
}

export interface AdmissionApplication {
  id: string;
  studentName: string;
  dob: string;
  gender: string;
  grade: string;
  fatherName: string;
  motherName: string;
  phone: string;
  email: string;
  address: string;
  previousSchool?: string;
  submittedAt: string;
  status: 'Pending Review' | 'Accepted' | 'Interview Scheduled';
}

export interface FeeReceipt {
  receiptNo: string;
  studentName: string;
  studentId: string;
  grade: string;
  term: string;
  amount: number;
  paymentMethod: string;
  transactionRef: string;
  date: string;
  status: 'VERIFIED' | 'PENDING_VERIFICATION';
  installmentPlan?: 'Full Payment' | 'Quarterly' | 'Monthly';
  installmentNumber?: string;
  remainingBalance?: number;
}

export interface FeeInstallmentItem {
  installmentNumber: number;
  title: string;
  period: string;
  dueDate: string;
  amount: number;
  paidAmount: number;
  status: 'PAID' | 'DUE' | 'UPCOMING';
  receiptNo?: string;
}

export interface StudentInstallmentPlan {
  studentId: string;
  studentName: string;
  grade: string;
  totalAnnualFee: number;
  planType: 'Quarterly' | 'Monthly' | 'Full';
  installments: FeeInstallmentItem[];
}

export interface NoticeItem {
  id: string;
  title: string;
  date: string;
  category: 'General' | 'Exam' | 'Holiday' | 'Event' | 'Fees';
  summary: string;
  important?: boolean;
}

export interface AcademicEvent {
  id: string;
  title: string;
  startDate: string;
  endDate?: string;
  category: 'Holiday' | 'Exam' | 'Event' | 'TermDate';
  month: string; // e.g. 'June 2026'
  description: string;
  timings?: string;
  applicableClasses?: string;
  important?: boolean;
}

export interface GalleryImage {
  id: string;
  title: string;
  category: 'Classroom' | 'Kindergarten' | 'Sports' | 'Events' | 'Campus';
  url: string;
  caption: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
}

export type UserRole = 'Super Admin' | 'Principal' | 'Office Staff' | 'Teacher' | 'Parent' | 'Student';

export type SchoolBranch = 'Essur Main Campus' | 'Kanchipuram Primary Branch' | 'Chengalpattu Campus';

export interface Teacher {
  id: string;
  name: string;
  qualification: string;
  subject: string;
  assignedClass: string;
  phone: string;
  email: string;
  joiningYear: string;
  status: 'Active' | 'On Leave';
  branch: SchoolBranch;
}

export interface ClassSection {
  id: string;
  className: string;
  section: string;
  totalStudents: number;
  classTeacher: string;
  roomNo: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  studentName: string;
  grade: string;
  date: string;
  status: 'Present' | 'Absent' | 'Late' | 'Leave';
  remarks?: string;
  notifiedParent?: boolean;
}

export interface TimetablePeriod {
  periodNo: number;
  time: string;
  subject: string;
  teacherName: string;
  room: string;
}

export interface DayTimetable {
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday';
  periods: TimetablePeriod[];
}

export interface TransferCertificate {
  tcNo: string;
  studentId: string;
  studentName: string;
  fatherName: string;
  motherName: string;
  dob: string;
  gender: string;
  gradeAdmitted: string;
  gradeLeaving: string;
  dateOfLeaving: string;
  reasonForLeaving: string;
  conduct: 'Excellent' | 'Good' | 'Satisfactory';
  promotedToNextClass: boolean;
  issueDate: string;
  qrVerificationCode: string;
}

export interface LibraryBook {
  id: string;
  title: string;
  author: string;
  category: 'Tamil Literature' | 'English Story' | 'Science & Math' | 'Encyclopedia' | 'General Knowledge';
  isbn: string;
  totalCopies: number;
  availableCopies: number;
  rackNo: string;
}

export interface TransportRoute {
  id: string;
  routeName: string;
  vanNumber: string;
  driverName: string;
  driverPhone: string;
  pickupPoints: string[];
  timingMorning: string;
  timingEvening: string;
  monthlyFee: number;
}

export interface HealthRecord {
  studentId: string;
  studentName: string;
  grade: string;
  bloodGroup: string;
  heightCm: number;
  weightKg: number;
  allergies: string;
  emergencyContact: string;
  doctorRemarks: string;
  lastCheckupDate: string;
}

export interface DocumentItem {
  id: string;
  studentId: string;
  studentName: string;
  docType: 'Birth Certificate' | 'Aadhaar Card' | 'Passport Photo' | 'Previous Marksheet' | 'Community Certificate';
  fileName: string;
  uploadDate: string;
  fileSize: string;
  status: 'Verified' | 'Pending Verification';
}

export interface SmsNotification {
  id: string;
  recipientPhone: string;
  recipientName: string;
  message: string;
  sentAt: string;
  channel: 'SMS' | 'WhatsApp';
  status: 'Delivered' | 'Failed';
}

export type PermissionKey =
  | 'view_home'
  | 'pay_fees'
  | 'manage_fees'
  | 'view_student_portal'
  | 'manage_students'
  | 'view_erp'
  | 'manage_erp'
  | 'track_bus'
  | 'parent_connect'
  | 'library_access'
  | 'admin_portal'
  | 'future_lab'
  | 'zoom_classes'
  | 'digital_hall_pass'
  | 'school_store'
  | 'lost_found'
  | 'create_roles';

export interface UserRoleDefinition {
  id: string;
  name: string;
  code: string;
  description: string;
  color: string;
  isCustom?: boolean;
  permissions: PermissionKey[];
  createdDate?: string;
  createdBy?: string;
}

export interface UserAccount {
  id: string;
  username: string;
  name: string;
  email: string;
  roleId: string;
  roleName: string;
  grade?: string;
  studentId?: string;
  avatarUrl?: string;
  phone?: string;
  lastLogin?: string;
}

export interface FeeCategory {
  id: string;
  key: string;
  name: string;
  amount: number;
  description: string;
  deletable: boolean;
  editable: boolean;
  categoryType: string;
  frequency: string;
}




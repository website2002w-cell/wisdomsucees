import { jsPDF } from 'jspdf';
import { FeeReceipt } from '../types';
import { SCHOOL_INFO, GRADE_FEE_STRUCTURE } from '../data/schoolData';

export interface FeeReminderNoticeData {
  studentName: string;
  studentId: string;
  grade: string;
  parentName?: string;
  parentPhone?: string;
  parentEmail?: string;
  feeParticulars: string;
  amountDue: number;
  dueDate: string;
  noticeRefNo?: string;
}

// Internal helper to draw a single receipt on a given jsPDF page
function drawSingleReceiptOnDoc(doc: jsPDF, receipt: FeeReceipt): void {
  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const margin = 15;
  let y = 15;

  // Colors
  const primaryNavy = '#0f172a'; // blue-950
  const accentGold = '#d97706'; // amber-600
  const emeraldGreen = '#047857'; // emerald-700
  const slateGray = '#475569';
  const lightBg = '#f8fafc';

  // Decorative Outer Double Border
  doc.setLineWidth(1);
  doc.setDrawColor(15, 23, 42); // Navy
  doc.rect(margin, margin, pageWidth - margin * 2, 267);

  doc.setLineWidth(0.3);
  doc.setDrawColor(217, 119, 6); // Gold inner border
  doc.rect(margin + 2, margin + 2, pageWidth - margin * 2 - 4, 263);

  y += 10;

  // Header Title
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(primaryNavy);
  doc.text('WISDOM NURSERY AND PRIMARY SCHOOL', pageWidth / 2, y, { align: 'center' });

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(slateGray);
  doc.text('Recognized by Govt. of Tamil Nadu • School Code: 33030201504', pageWidth / 2, y, { align: 'center' });

  y += 5;
  doc.setFontSize(9);
  doc.text('Essur Village, Cheyyur Taluk, Chengalpattu Dist - 603301 | Ph: +91 9176593129', pageWidth / 2, y, { align: 'center' });

  y += 5;
  doc.setFont('helvetica', 'bolditalic');
  doc.setFontSize(9);
  doc.setTextColor(accentGold);
  doc.text(`"${SCHOOL_INFO.motto}"`, pageWidth / 2, y, { align: 'center' });

  y += 8;
  // Divider Line
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.8);
  doc.line(margin + 5, y, pageWidth - margin - 5, y);

  y += 8;

  // Receipt Badge Header
  doc.setFillColor(15, 23, 42);
  doc.roundedRect(pageWidth / 2 - 45, y - 5, 90, 8, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor('#ffffff');
  doc.text('OFFICIAL UPI FEE PAYMENT RECEIPT', pageWidth / 2, y, { align: 'center' });

  y += 12;

  // Transaction Meta Box
  doc.setFillColor(lightBg);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin + 5, y, pageWidth - margin * 2 - 10, 24, 3, 3, 'FD');

  doc.setFontSize(9);
  doc.setTextColor(slateGray);
  doc.text('Receipt Number:', margin + 10, y + 6);
  doc.text('Transaction Date:', margin + 10, y + 13);
  doc.text('Payment Method:', margin + 10, y + 20);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(receipt.receiptNo, margin + 42, y + 6);
  doc.text(receipt.date, margin + 42, y + 13);
  doc.text(receipt.paymentMethod || 'UPI (Google Pay / PhonePe)', margin + 42, y + 20);

  // Right column of Meta Box
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(slateGray);
  doc.text('UTR / Ref No:', pageWidth / 2 + 10, y + 6);
  doc.text('Payment Status:', pageWidth / 2 + 10, y + 13);
  doc.text('School UPI VPA:', pageWidth / 2 + 10, y + 20);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(receipt.transactionRef || 'N/A', pageWidth / 2 + 38, y + 6);

  doc.setTextColor(emeraldGreen);
  doc.text('VERIFIED & RECEIVED ✓', pageWidth / 2 + 38, y + 13);

  doc.setTextColor(primaryNavy);
  doc.text(SCHOOL_INFO.upiId, pageWidth / 2 + 38, y + 20);

  y += 32;

  // Student Particulars Box
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryNavy);
  doc.text('STUDENT INFORMATION', margin + 5, y);

  y += 4;
  doc.setFillColor('#ffffff');
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin + 5, y, pageWidth - margin * 2 - 10, 22, 2, 2, 'D');

  doc.setFontSize(9.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(slateGray);

  doc.text('Student Name:', margin + 10, y + 7);
  doc.text('Student ID / Reg No:', margin + 10, y + 15);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(receipt.studentName, margin + 40, y + 7);
  doc.text(receipt.studentId || 'WNS-STUDENT', margin + 40, y + 15);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(slateGray);
  doc.text('Class / Grade:', pageWidth / 2 + 10, y + 7);
  doc.text('Fee Term Paid:', pageWidth / 2 + 10, y + 15);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(receipt.grade, pageWidth / 2 + 38, y + 7);
  doc.text(receipt.term, pageWidth / 2 + 38, y + 15);

  y += 30;

  // Detailed Payment Breakdown Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(primaryNavy);
  doc.text('PAYMENT BREAKDOWN', margin + 5, y);

  y += 4;

  // Table Header
  const tableX = margin + 5;
  const tableWidth = pageWidth - margin * 2 - 10;

  doc.setFillColor(15, 23, 42);
  doc.rect(tableX, y, tableWidth, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor('#ffffff');
  doc.text('S.No', tableX + 5, y + 5.5);
  doc.text('Fee Description / Particulars', tableX + 22, y + 5.5);
  doc.text('Category', tableX + 110, y + 5.5);
  doc.text('Amount (INR)', tableX + tableWidth - 10, y + 5.5, { align: 'right' });

  y += 8;

  // Breakdown items computation
  const gradeFees = GRADE_FEE_STRUCTURE[receipt.grade] || GRADE_FEE_STRUCTURE['Class 3'];
  let feeItems: { sno: number; desc: string; category: string; amount: number }[] = [];

  if (receipt.term.toLowerCase().includes('term 1')) {
    feeItems = [
      { sno: 1, desc: `Tuition & Academic Development Fee (${receipt.grade} - Term 1)`, category: 'Academic', amount: gradeFees.term1 },
      { sno: 2, desc: 'Smart Class & Audio-Visual Lab Fee', category: 'Infrastructure', amount: 0 },
      { sno: 3, desc: 'Co-Curricular & Sports Assessment Fee', category: 'Activities', amount: 0 },
    ];
  } else if (receipt.term.toLowerCase().includes('term 2')) {
    feeItems = [
      { sno: 1, desc: `Tuition & Academic Development Fee (${receipt.grade} - Term 2)`, category: 'Academic', amount: gradeFees.term2 },
      { sno: 2, desc: 'Library & Learning Resource Access', category: 'Academic', amount: 0 },
    ];
  } else if (receipt.term.toLowerCase().includes('term 3')) {
    feeItems = [
      { sno: 1, desc: `Tuition & Academic Development Fee (${receipt.grade} - Term 3)`, category: 'Academic', amount: gradeFees.term3 },
      { sno: 2, desc: 'Annual Examination & Progress Report Fee', category: 'Examination', amount: 0 },
    ];
  } else if (receipt.term.toLowerCase().includes('book')) {
    feeItems = [
      { sno: 1, desc: `State Board Samacheer Kalvi Textbook Set (${receipt.grade})`, category: 'Books', amount: gradeFees.books - 300 },
      { sno: 2, desc: 'Wisdom School Customized Notebooks & Worksheets', category: 'Stationery', amount: 300 },
    ];
  } else if (receipt.term.toLowerCase().includes('uniform')) {
    feeItems = [
      { sno: 1, desc: `Regular School Uniform Set (${receipt.grade})`, category: 'Apparel', amount: gradeFees.uniform - 400 },
      { sno: 2, desc: 'Sports House T-Shirt & Belt Set', category: 'Apparel', amount: 400 },
    ];
  } else {
    feeItems = [
      { sno: 1, desc: `School Fee Remittance - ${receipt.term} (${receipt.grade})`, category: 'General Fee', amount: receipt.amount },
    ];
  }

  // Draw table rows
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(primaryNavy);

  feeItems.forEach((item, index) => {
    const rowY = y + index * 8;

    if (index % 2 === 1) {
      doc.setFillColor(lightBg);
      doc.rect(tableX, rowY, tableWidth, 8, 'F');
    }

    doc.text(String(item.sno), tableX + 5, rowY + 5.5);
    doc.text(item.desc, tableX + 22, rowY + 5.5);
    doc.text(item.category, tableX + 110, rowY + 5.5);
    doc.text(`Rs. ${receipt.amount.toLocaleString('en-IN')}`, tableX + tableWidth - 10, rowY + 5.5, { align: 'right' });
  });

  y += Math.max(feeItems.length * 8, 16);

  // Table Summary Footer
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.5);
  doc.line(tableX, y, tableX + tableWidth, y);

  doc.setFillColor(241, 245, 249); // slate-100
  doc.rect(tableX, y, tableWidth, 10, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryNavy);
  doc.text('TOTAL AMOUNT RECEIVED:', tableX + 22, y + 6.5);

  doc.setFontSize(11);
  doc.setTextColor(emeraldGreen);
  doc.text(`Rs. ${receipt.amount.toLocaleString('en-IN')}`, tableX + tableWidth - 10, y + 6.5, { align: 'right' });

  y += 18;

  // Outstanding Status Banner / Installment Plan Status Banner
  doc.setFillColor(236, 253, 245); // emerald-50
  doc.setDrawColor(16, 185, 129); // emerald-500
  doc.setLineWidth(0.3);
  doc.roundedRect(margin + 5, y, pageWidth - margin * 2 - 10, receipt.installmentPlan ? 16 : 12, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(emeraldGreen);
  if (receipt.installmentPlan) {
    doc.text(`INSTALLMENT MODE: ${receipt.installmentPlan.toUpperCase()} ${receipt.installmentNumber ? `(${receipt.installmentNumber})` : ''}`, margin + 10, y + 6);
    doc.setFontSize(8.5);
    doc.setTextColor(primaryNavy);
    doc.text(`REMAINING BALANCE AFTER PAYMENT: Rs. ${(receipt.remainingBalance ?? 0).toLocaleString('en-IN')}`, margin + 10, y + 12);
  } else {
    doc.text('PAYMENT STATUS: FULLY PAID & VERIFIED VIA BANK UPI TRANSFER', margin + 10, y + 7.5);
  }

  y += receipt.installmentPlan ? 24 : 20;

  // Verification QR & Security Seal Block
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(slateGray);
  doc.text('DIGITAL VERIFICATION & STAMP', margin + 5, y);

  y += 4;

  // Box for Signatures
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(margin + 5, y, pageWidth - margin * 2 - 10, 36, 2, 2, 'D');

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(slateGray);
  doc.text('• This receipt is electronically generated by Wisdom School Essur ERP.', margin + 10, y + 8);
  doc.text('• Valid without physical ink signature when UTR is verified.', margin + 10, y + 14);
  doc.text(`• Verification Hash: WNS-${receipt.receiptNo.replace(/[^0-9]/g, '')}-${Date.now().toString().slice(-6)}`, margin + 10, y + 20);
  doc.text('• Administrator Contact: R. Saravanan (Ph: +91 9176593129)', margin + 10, y + 26);

  // Signature Stamp Area on the Right
  const stampX = pageWidth - margin - 50;
  doc.setDrawColor(15, 23, 42);
  doc.line(stampX, y + 26, stampX + 40, y + 26);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(primaryNavy);
  doc.text('R. SARAVANAN', stampX + 20, y + 22, { align: 'center' });
  doc.text('HEADMASTER / CORRESPONDENT', stampX + 20, y + 30, { align: 'center' });
  doc.setFontSize(7);
  doc.setTextColor(accentGold);
  doc.text('WISDOM SCHOOL ESSUR', stampX + 20, y + 33, { align: 'center' });

  // Footer Note
  y = 275;
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(slateGray);
  doc.text('Wisdom Nursery & Primary School, Essur Village, Cheyyur Taluk - 603301 | Official Receipt Copy for Parent Records', pageWidth / 2, y, { align: 'center' });
}

// Generate Single Receipt PDF
export const generateReceiptPdf = (receipt: FeeReceipt): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  drawSingleReceiptOnDoc(doc, receipt);

  const filename = `${receipt.studentName.replace(/\s+/g, '_')}_Fee_Receipt_${receipt.receiptNo}.pdf`;
  doc.save(filename);
};

// Generate Bulk Receipts PDF (All selected receipts combined into one multi-page document)
export const generateBulkReceiptsPdf = (receipts: FeeReceipt[]): void => {
  if (!receipts || receipts.length === 0) return;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  receipts.forEach((rcp, idx) => {
    if (idx > 0) {
      doc.addPage();
    }
    drawSingleReceiptOnDoc(doc, rcp);
  });

  const filename = `Wisdom_School_Bulk_Receipts_${receipts.length}_Records.pdf`;
  doc.save(filename);
};

// Helper to draw a Printable Fee Deadline Notice Letter on a PDF Page
function drawSinglePrintableNoticeOnDoc(doc: jsPDF, notice: FeeReminderNoticeData): void {
  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const margin = 15;
  let y = 15;

  const primaryNavy = '#0f172a';
  const accentGold = '#d97706';
  const slateGray = '#475569';
  const alertRed = '#b91c1c';

  // Outer Border
  doc.setLineWidth(1);
  doc.setDrawColor(15, 23, 42);
  doc.rect(margin, margin, pageWidth - margin * 2, 267);

  doc.setLineWidth(0.3);
  doc.setDrawColor(217, 119, 6);
  doc.rect(margin + 2, margin + 2, pageWidth - margin * 2 - 4, 263);

  y += 10;

  // School Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(primaryNavy);
  doc.text('WISDOM NURSERY AND PRIMARY SCHOOL', pageWidth / 2, y, { align: 'center' });

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(slateGray);
  doc.text('Recognized by Govt. of Tamil Nadu • School Code: 33030201504', pageWidth / 2, y, { align: 'center' });

  y += 5;
  doc.setFontSize(9);
  doc.text('Essur Village, Cheyyur Taluk, Chengalpattu Dist - 603301 | Ph: +91 9176593129', pageWidth / 2, y, { align: 'center' });

  y += 8;
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.8);
  doc.line(margin + 5, y, pageWidth - margin - 5, y);

  y += 10;

  // Notice Ref Bar & Date
  const refNo = notice.noticeRefNo || `WNS/NOTICE/2026/${Math.floor(100 + Math.random() * 900)}`;
  const dateStr = new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(slateGray);
  doc.text(`Ref No: ${refNo}`, margin + 5, y);
  doc.text(`Date: ${dateStr}`, pageWidth - margin - 5, y, { align: 'right' });

  y += 10;

  // Notice Title Badge
  doc.setFillColor(185, 28, 28); // alert red
  doc.roundedRect(pageWidth / 2 - 55, y - 5, 110, 8, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor('#ffffff');
  doc.text('OFFICIAL FEE PAYMENT DUE NOTICE', pageWidth / 2, y, { align: 'center' });

  y += 14;

  // Recipient Block (Parent / Student Particulars)
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin + 5, y, pageWidth - margin * 2 - 10, 26, 3, 3, 'FD');

  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text('TO THE PARENT / GUARDIAN OF:', margin + 10, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(slateGray);
  doc.text(`Student Name:`, margin + 10, y + 13);
  doc.text(`Student ID / Roll No:`, margin + 10, y + 20);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(notice.studentName, margin + 45, y + 13);
  doc.text(notice.studentId || 'WNS-STUDENT', margin + 45, y + 20);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(slateGray);
  doc.text(`Class / Grade:`, pageWidth / 2 + 10, y + 13);
  doc.text(`Parent Mobile:`, pageWidth / 2 + 10, y + 20);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(notice.grade, pageWidth / 2 + 38, y + 13);
  doc.text(notice.parentPhone || '+91 9176593129', pageWidth / 2 + 38, y + 20);

  y += 34;

  // Salutation & Letter Body Text
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryNavy);
  doc.text('Dear Parent / Guardian,', margin + 5, y);

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(slateGray);

  const bodyLine1 = 'This is a gentle official reminder from Wisdom Nursery and Primary School regarding the upcoming school fee';
  const bodyLine2 = 'deadline for your ward. To ensure uninterrupted academic classes, textbook distribution, and school transport';
  const bodyLine3 = 'access, we request you to kindly remit the pending fee amount on or before the specified due date.';

  doc.text(bodyLine1, margin + 5, y);
  doc.text(bodyLine2, margin + 5, y + 5);
  doc.text(bodyLine3, margin + 5, y + 10);

  y += 20;

  // Outstanding Fee Particulars Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(primaryNavy);
  doc.text('PENDING FEE PARTICULARS', margin + 5, y);

  y += 4;

  const tableX = margin + 5;
  const tableWidth = pageWidth - margin * 2 - 10;

  doc.setFillColor(15, 23, 42);
  doc.rect(tableX, y, tableWidth, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor('#ffffff');
  doc.text('S.No', tableX + 5, y + 5.5);
  doc.text('Fee Description / Particulars', tableX + 20, y + 5.5);
  doc.text('Class / Route', tableX + 95, y + 5.5);
  doc.text('Due Date', tableX + 130, y + 5.5);
  doc.text('Amount Due (INR)', tableX + tableWidth - 5, y + 5.5, { align: 'right' });

  y += 8;

  // Row 1
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(primaryNavy);
  doc.text('1', tableX + 5, y + 5.5);
  doc.text(notice.feeParticulars, tableX + 20, y + 5.5);
  doc.text(notice.grade, tableX + 95, y + 5.5);
  doc.text(notice.dueDate, tableX + 130, y + 5.5);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(alertRed);
  doc.text(`Rs. ${notice.amountDue.toLocaleString('en-IN')}`, tableX + tableWidth - 5, y + 5.5, { align: 'right' });

  y += 12;

  // Table Summary Footer
  doc.setDrawColor(15, 23, 42);
  doc.setLineWidth(0.5);
  doc.line(tableX, y, tableX + tableWidth, y);

  doc.setFillColor(254, 242, 242); // red-50
  doc.rect(tableX, y, tableWidth, 10, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(primaryNavy);
  doc.text('TOTAL PENDING AMOUNT PAYABLE:', tableX + 20, y + 6.5);

  doc.setFontSize(11);
  doc.setTextColor(alertRed);
  doc.text(`Rs. ${notice.amountDue.toLocaleString('en-IN')}`, tableX + tableWidth - 5, y + 6.5, { align: 'right' });

  y += 20;

  // Mode of Payment & UPI Guide Box
  doc.setFillColor(240, 253, 244); // emerald-50
  doc.setDrawColor(52, 211, 153);
  doc.setLineWidth(0.4);
  doc.roundedRect(margin + 5, y, pageWidth - margin * 2 - 10, 32, 3, 3, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(primaryNavy);
  doc.text('CONVENIENT PAYMENT MODES (ONLINE UPI & CASH)', margin + 10, y + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(slateGray);
  doc.text(`• School Official UPI ID (Google Pay / PhonePe / Paytm): rsaravanan102002-1@okhdfcbank`, margin + 10, y + 13);
  doc.text(`• Bank Account: Indian Overseas Bank, Cheyyur Branch | A/C No: 184201000019284 | IFSC: IOBA0001842`, margin + 10, y + 19);
  doc.text(`• Parent Portal Direct Link: https://wisdomessur.edu.in/fees?studentId=${notice.studentId}`, margin + 10, y + 25);

  y += 40;

  // Note for Parents
  doc.setFont('helvetica', 'bolditalic');
  doc.setFontSize(8);
  doc.setTextColor(slateGray);
  doc.text('* Note: After completing online UPI transfer, please SMS/WhatsApp the 12-digit UTR reference number', margin + 5, y);
  doc.text('  to +91 9176593129 to collect your verified official digital receipt instantly.', margin + 5, y + 4);

  y += 18;

  // Principal Signature Block
  const stampX = pageWidth - margin - 55;
  doc.setDrawColor(15, 23, 42);
  doc.line(stampX, y + 16, stampX + 48, y + 16);

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(primaryNavy);
  doc.text('R. SARAVANAN', stampX + 24, y + 12, { align: 'center' });
  doc.text('CORRESPONDENT / HEADMASTER', stampX + 24, y + 20, { align: 'center' });

  doc.setFontSize(7.5);
  doc.setTextColor(accentGold);
  doc.text('WISDOM NURSERY & PRIMARY SCHOOL', stampX + 24, y + 24, { align: 'center' });
  doc.text('ESSUR VILLAGE, CHEYYUR TALUK', stampX + 24, y + 27, { align: 'center' });

  // Footer Note
  y = 275;
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(slateGray);
  doc.text('Wisdom Nursery & Primary School, Essur Village, Cheyyur Taluk - 603301 | Official Fee Notice for Parents', pageWidth / 2, y, { align: 'center' });
}

// Generate Printable Fee Reminder Notice PDF for single student
export const generatePrintableReminderPdf = (notice: FeeReminderNoticeData): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  drawSinglePrintableNoticeOnDoc(doc, notice);

  const filename = `${notice.studentName.replace(/\s+/g, '_')}_Fee_Notice_${notice.studentId}.pdf`;
  doc.save(filename);
};

// Generate Bulk Printable Fee Reminder Notices PDF (Multi-page document for all selected students)
export const generateBulkPrintableRemindersPdf = (notices: FeeReminderNoticeData[]): void => {
  if (!notices || notices.length === 0) return;

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  notices.forEach((notice, idx) => {
    if (idx > 0) {
      doc.addPage();
    }
    drawSinglePrintableNoticeOnDoc(doc, notice);
  });

  const filename = `Wisdom_School_Bulk_Fee_Reminders_${notices.length}_Students.pdf`;
  doc.save(filename);
};

// Generate Official Student Installment Plan Schedule Statement PDF
export const generateInstallmentSchedulePdf = (plan: {
  studentName: string;
  studentId: string;
  grade: string;
  totalAnnualFee: number;
  planType: string;
  installments: Array<{
    installmentNumber: number;
    title: string;
    period: string;
    dueDate: string;
    amount: number;
    paidAmount: number;
    status: string;
  }>;
}): void => {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 15;
  let y = 15;

  const primaryNavy = '#0f172a';
  const accentGold = '#d97706';
  const emeraldGreen = '#047857';
  const slateGray = '#475569';
  const lightBg = '#f8fafc';

  // Border
  doc.setLineWidth(1);
  doc.setDrawColor(15, 23, 42);
  doc.rect(margin, margin, pageWidth - margin * 2, 267);

  doc.setLineWidth(0.3);
  doc.setDrawColor(217, 119, 6);
  doc.rect(margin + 2, margin + 2, pageWidth - margin * 2 - 4, 263);

  y += 10;

  // Header
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(primaryNavy);
  doc.text('WISDOM NURSERY AND PRIMARY SCHOOL', pageWidth / 2, y, { align: 'center' });

  y += 6;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(slateGray);
  doc.text('Essur Village, Cheyyur Taluk, Chengalpattu Dist - 603301 | Ph: +91 9176593129', pageWidth / 2, y, { align: 'center' });

  y += 8;
  doc.setDrawColor(15, 23, 42);
  doc.line(margin + 5, y, pageWidth - margin - 5, y);

  y += 8;
  doc.setFillColor(15, 23, 42);
  doc.roundedRect(pageWidth / 2 - 55, y - 5, 110, 8, 2, 2, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor('#ffffff');
  doc.text(`OFFICIAL ${plan.planType.toUpperCase()} FEE INSTALLMENT SCHEDULE`, pageWidth / 2, y, { align: 'center' });

  y += 12;

  // Student Particulars Card
  doc.setFillColor(lightBg);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin + 5, y, pageWidth - margin * 2 - 10, 24, 3, 3, 'FD');

  doc.setFontSize(9);
  doc.setTextColor(slateGray);
  doc.text('Student Name:', margin + 10, y + 6);
  doc.text('Student ID:', margin + 10, y + 13);
  doc.text('Class / Grade:', margin + 10, y + 20);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(plan.studentName, margin + 38, y + 6);
  doc.text(plan.studentId || 'WNS-STUDENT', margin + 38, y + 13);
  doc.text(plan.grade, margin + 38, y + 20);

  const totalPaid = plan.installments.reduce((acc, curr) => acc + curr.paidAmount, 0);
  const remainingBal = plan.totalAnnualFee - totalPaid;

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(slateGray);
  doc.text('Total Academic Fee:', pageWidth / 2 + 10, y + 6);
  doc.text('Total Amount Paid:', pageWidth / 2 + 10, y + 13);
  doc.text('Remaining Balance:', pageWidth / 2 + 10, y + 20);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(primaryNavy);
  doc.text(`Rs. ${plan.totalAnnualFee.toLocaleString('en-IN')}`, pageWidth / 2 + 48, y + 6);
  doc.setTextColor(emeraldGreen);
  doc.text(`Rs. ${totalPaid.toLocaleString('en-IN')}`, pageWidth / 2 + 48, y + 13);
  doc.setTextColor(remainingBal > 0 ? accentGold : emeraldGreen);
  doc.text(`Rs. ${remainingBal.toLocaleString('en-IN')}`, pageWidth / 2 + 48, y + 20);

  y += 32;

  // Schedule Table Header
  const tableX = margin + 5;
  const tableWidth = pageWidth - margin * 2 - 10;

  doc.setFillColor(15, 23, 42);
  doc.rect(tableX, y, tableWidth, 8, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor('#ffffff');
  doc.text('Inst #', tableX + 5, y + 5.5);
  doc.text('Installment Title & Period', tableX + 22, y + 5.5);
  doc.text('Due Date', tableX + 90, y + 5.5);
  doc.text('Amount Due', tableX + 125, y + 5.5);
  doc.text('Status', tableX + tableWidth - 10, y + 5.5, { align: 'right' });

  y += 8;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);

  plan.installments.forEach((inst, index) => {
    const rowY = y + index * 9;
    if (index % 2 === 1) {
      doc.setFillColor(lightBg);
      doc.rect(tableX, rowY, tableWidth, 9, 'F');
    }

    doc.setTextColor(primaryNavy);
    doc.text(`#${inst.installmentNumber}`, tableX + 5, rowY + 6);
    doc.text(`${inst.title} (${inst.period})`, tableX + 22, rowY + 6);
    doc.text(inst.dueDate, tableX + 90, rowY + 6);
    doc.text(`Rs. ${inst.amount.toLocaleString('en-IN')}`, tableX + 125, rowY + 6);

    if (inst.status === 'PAID') {
      doc.setTextColor(emeraldGreen);
      doc.setFont('helvetica', 'bold');
      doc.text('PAID ✓', tableX + tableWidth - 10, rowY + 6, { align: 'right' });
    } else if (inst.status === 'DUE') {
      doc.setTextColor(accentGold);
      doc.setFont('helvetica', 'bold');
      doc.text('PAYMENT DUE', tableX + tableWidth - 10, rowY + 6, { align: 'right' });
    } else {
      doc.setTextColor(slateGray);
      doc.setFont('helvetica', 'normal');
      doc.text('UPCOMING', tableX + tableWidth - 10, rowY + 6, { align: 'right' });
    }
  });

  y += plan.installments.length * 9 + 12;

  // Note & Instructions Box
  doc.setFillColor('#fffbe0');
  doc.setDrawColor(245, 158, 11);
  doc.roundedRect(tableX, y, tableWidth, 18, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor('#78350f');
  doc.text('INSTALLMENT PAYMENT TERMS:', tableX + 5, y + 5);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.text('• Installments must be cleared on or before the specified due dates to avoid late fee charges.', tableX + 5, y + 10);
  doc.text('• Digital receipts are automatically generated with 12-digit UPI UTR verification upon payment.', tableX + 5, y + 15);

  y += 26;

  // Signatures
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(primaryNavy);
  doc.text('PARENT / GUARDIAN SIGNATURE', margin + 10, y + 12);

  const stampX = pageWidth - margin - 55;
  doc.line(stampX, y + 12, stampX + 48, y + 12);
  doc.text('R. SARAVANAN', stampX + 24, y + 8, { align: 'center' });
  doc.text('CORRESPONDENT / HEADMASTER', stampX + 24, y + 16, { align: 'center' });

  const filename = `${plan.studentName.replace(/\s+/g, '_')}_${plan.planType}_Fee_Schedule.pdf`;
  doc.save(filename);
};

export interface GradeSeatConfig {
  grade: string;
  totalSeats: number;
  availableSeats: number;
  ageCriteria: string;
  annualFeeApprox: number;
  status: 'OPEN' | 'FEW_LEFT' | 'FULL' | 'WAITLIST';
}

export interface AdmissionsConfig {
  academicYear: string;
  status: 'OPEN' | 'LIMITED' | 'CLOSED' | 'WAITLIST';
  bannerBadgeText: string;
  headlineText: string;
  subText: string;
  applicationFee: number;
  helpdeskPhone: string;
  helpdeskEmail: string;
  lastDateToApply: string;
  interviewStartDate: string;
  schoolReopeningDate: string;
  noticeAnnouncement: string;
  requiredDocuments: string[];
  gradeConfigs: GradeSeatConfig[];
}

export const DEFAULT_ADMISSIONS_CONFIG: AdmissionsConfig = {
  academicYear: '2026 - 2027',
  status: 'OPEN',
  bannerBadgeText: 'Admissions Open 2026 - 2027',
  headlineText: 'Admissions Open for Academic Year 2026 - 2027',
  subText: 'Join Wisdom Nursery & Primary School, Essur. Quality English Medium education with strong moral values, STEM labs, and caring teachers.',
  applicationFee: 0,
  helpdeskPhone: '+91 9176593129',
  helpdeskEmail: 'wisdomrs.tamil@gmail.com',
  lastDateToApply: '31-Aug-2026',
  interviewStartDate: '05-Sep-2026',
  schoolReopeningDate: '12-Sep-2026',
  noticeAnnouncement: '⚡ Early Bird Registrations Open for 2026-2027 batch! Free prospectus & entrance counselling for LKG & Standard 1 applicants.',
  requiredDocuments: [
    'Child Birth Certificate (Govt issued copy)',
    'Child Aadhaar Card / ID Proof',
    'Passport Size Color Photos (3 Copies)',
    'Transfer Certificate (TC) from Previous School (for Standard 2-5)',
    'Community Certificate (if applicable)',
    'Blood Group Diagnostic Test Report',
  ],
  gradeConfigs: [
    { grade: 'Pre-Nursery / Playgroup', totalSeats: 30, availableSeats: 12, ageCriteria: '2.5+ Years as of 31-July-2026', annualFeeApprox: 8500, status: 'OPEN' },
    { grade: 'LKG (Lower Kindergarten)', totalSeats: 40, availableSeats: 14, ageCriteria: '3+ Years as of 31-July-2026', annualFeeApprox: 10000, status: 'OPEN' },
    { grade: 'UKG (Upper Kindergarten)', totalSeats: 40, availableSeats: 8, ageCriteria: '4+ Years as of 31-July-2026', annualFeeApprox: 10800, status: 'FEW_LEFT' },
    { grade: 'Class 1 (Standard I)', totalSeats: 45, availableSeats: 15, ageCriteria: '5+ Years as of 31-July-2026', annualFeeApprox: 11900, status: 'OPEN' },
    { grade: 'Class 2 (Standard II)', totalSeats: 45, availableSeats: 6, ageCriteria: '6+ Years as of 31-July-2026', annualFeeApprox: 12400, status: 'FEW_LEFT' },
    { grade: 'Class 3 (Standard III)', totalSeats: 45, availableSeats: 9, ageCriteria: '7+ Years as of 31-July-2026', annualFeeApprox: 12800, status: 'OPEN' },
    { grade: 'Class 4 (Standard IV)', totalSeats: 40, availableSeats: 5, ageCriteria: '8+ Years as of 31-July-2026', annualFeeApprox: 13600, status: 'FEW_LEFT' },
    { grade: 'Class 5 (Standard V)', totalSeats: 40, availableSeats: 3, ageCriteria: '9+ Years as of 31-July-2026', annualFeeApprox: 14900, status: 'FEW_LEFT' },
  ],
};

const LOCAL_STORAGE_KEY = 'wisdom_admissions_config_2026';

export const getAdmissionsConfig = (): AdmissionsConfig => {
  try {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...DEFAULT_ADMISSIONS_CONFIG, ...parsed };
    }
  } catch (err) {
    console.error('Error reading admissions config:', err);
  }
  return DEFAULT_ADMISSIONS_CONFIG;
};

export const saveAdmissionsConfig = (config: AdmissionsConfig): boolean => {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(config));
    window.dispatchEvent(new Event('admissions-config-updated'));
    return true;
  } catch (err) {
    console.error('Error saving admissions config:', err);
    return false;
  }
};

export const resetAdmissionsConfig = (): AdmissionsConfig => {
  try {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    window.dispatchEvent(new Event('admissions-config-updated'));
  } catch (err) {
    console.error('Error resetting admissions config:', err);
  }
  return DEFAULT_ADMISSIONS_CONFIG;
};

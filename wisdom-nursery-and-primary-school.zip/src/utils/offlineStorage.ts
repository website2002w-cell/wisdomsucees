/**
 * Offline Cache & Persistence Layer
 * Provides persistent localStorage / IndexedDB backup for critical school modules:
 * - Academic Calendar
 * - School Noticeboard
 * - Digital Hall Pass & Active Status
 * - Offline Submission Sync Queue
 */

const STORAGE_KEYS = {
  CALENDAR: 'wisdom_offline_academic_calendar',
  NOTICEBOARD: 'wisdom_offline_noticeboard',
  HALL_PASSES: 'wisdom_offline_hall_passes',
  SYNC_QUEUE: 'wisdom_offline_sync_queue',
  LAST_SYNC: 'wisdom_offline_last_sync_timestamp',
};

export interface SyncQueueItem {
  id: string;
  type: 'HALL_PASS' | 'SUGGESTION' | 'FEE_PAYMENT';
  payload: any;
  createdAt: string;
}

export const getCachedData = <T>(key: string, fallback: T): T => {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch (error) {
    console.warn(`[OfflineStorage] Error reading ${key}:`, error);
    return fallback;
  }
};

export const setCachedData = <T>(key: string, value: T): void => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    localStorage.setItem(STORAGE_KEYS.LAST_SYNC, new Date().toISOString());
  } catch (error) {
    console.warn(`[OfflineStorage] Error writing ${key}:`, error);
  }
};

export const getLastSyncTime = (): string | null => {
  return localStorage.getItem(STORAGE_KEYS.LAST_SYNC);
};

export const addToSyncQueue = (item: SyncQueueItem): void => {
  const currentQueue = getCachedData<SyncQueueItem[]>(STORAGE_KEYS.SYNC_QUEUE, []);
  setCachedData(STORAGE_KEYS.SYNC_QUEUE, [...currentQueue, item]);
};

export const getSyncQueue = (): SyncQueueItem[] => {
  return getCachedData<SyncQueueItem[]>(STORAGE_KEYS.SYNC_QUEUE, []);
};

export const clearSyncQueue = (): void => {
  setCachedData(STORAGE_KEYS.SYNC_QUEUE, []);
};

export { STORAGE_KEYS };

import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserRoleDefinition, UserAccount, PermissionKey } from '../types';

export const INITIAL_ROLES: UserRoleDefinition[] = [
  {
    id: 'role-admin',
    name: 'Super Admin / Principal',
    code: 'ADMIN',
    description: 'Full administrative access to all school modules, fee records, ERP, and role management.',
    color: 'bg-purple-600 text-purple-100 border-purple-400',
    permissions: [
      'view_home',
      'pay_fees',
      'manage_fees',
      'view_student_portal',
      'manage_students',
      'view_erp',
      'manage_erp',
      'track_bus',
      'parent_connect',
      'library_access',
      'admin_portal',
      'future_lab',
      'zoom_classes',
      'digital_hall_pass',
      'school_store',
      'lost_found',
      'create_roles',
    ],
  },
  {
    id: 'role-teacher',
    name: 'Teacher / Educator',
    code: 'TEACHER',
    description: 'Manage class attendance, record exam marks, host Zoom classes, and send parent notices.',
    color: 'bg-blue-600 text-blue-100 border-blue-400',
    permissions: [
      'view_home',
      'view_student_portal',
      'manage_students',
      'view_erp',
      'parent_connect',
      'library_access',
      'future_lab',
      'zoom_classes',
      'digital_hall_pass',
    ],
  },
  {
    id: 'role-parent',
    name: 'Parent / Guardian',
    code: 'PARENT',
    description: 'Pay school fees via GPay/UPI, track school bus live location, view report cards, and join Zoom meetings.',
    color: 'bg-emerald-600 text-emerald-100 border-emerald-400',
    permissions: [
      'view_home',
      'pay_fees',
      'view_student_portal',
      'track_bus',
      'parent_connect',
      'library_access',
      'future_lab',
      'zoom_classes',
      'school_store',
      'lost_found',
    ],
  },
  {
    id: 'role-student',
    name: 'Student',
    code: 'STUDENT',
    description: 'Access digital learning lab, view homework & timetable, request hall passes, and check library books.',
    color: 'bg-amber-600 text-amber-100 border-amber-400',
    permissions: [
      'view_home',
      'view_student_portal',
      'library_access',
      'future_lab',
      'zoom_classes',
      'digital_hall_pass',
      'school_store',
    ],
  },
  {
    id: 'role-driver',
    name: 'Transport / Bus Driver',
    code: 'DRIVER',
    description: 'Broadcast live GPS location, route check-ins, and send delay notifications to parents.',
    color: 'bg-orange-600 text-orange-100 border-orange-400',
    permissions: ['view_home', 'track_bus', 'parent_connect'],
  },
  {
    id: 'role-ai-assistant',
    name: 'AI Counselor & Mentor',
    code: 'AI_AGENT',
    description: 'Autonomous school assistant powered by Gemini for instant tutoring, parent query support, and ERP guidance.',
    color: 'bg-indigo-600 text-indigo-100 border-indigo-400',
    permissions: [
      'view_home',
      'pay_fees',
      'view_student_portal',
      'view_erp',
      'track_bus',
      'parent_connect',
      'library_access',
      'future_lab',
      'zoom_classes',
      'create_roles',
    ],
  },
];

export const INITIAL_USERS: UserAccount[] = [
  {
    id: 'usr-01',
    username: 'WISDOM',
    name: 'Dr. S. Rajendran (Principal)',
    email: 'admin@wisdomschool.edu.in',
    roleId: 'role-admin',
    roleName: 'Super Admin / Principal',
    phone: '+91 94432 10987',
  },
  {
    id: 'usr-02',
    username: 'teacher_anita',
    name: 'Mrs. Anita Ramesh (Class 3-A)',
    email: 'anita.teacher@wisdomschool.edu.in',
    roleId: 'role-teacher',
    roleName: 'Teacher / Educator',
    grade: 'Class 3-A',
    phone: '+91 98401 23456',
  },
  {
    id: 'usr-03',
    username: 'parent_kavin',
    name: 'R. Kavin (Parent of Kavin R)',
    email: 'parent.kavin@okhdfcbank',
    roleId: 'role-parent',
    roleName: 'Parent / Guardian',
    studentId: 'WNS-2026-01',
    grade: 'Class 3',
    phone: '+91 98765 43210',
  },
  {
    id: 'usr-04',
    username: 'student_kavin',
    name: 'R. Kavin (Student)',
    email: 'kavin.student@wisdomschool.edu.in',
    roleId: 'role-student',
    roleName: 'Student',
    studentId: 'WNS-2026-01',
    grade: 'Class 3',
  },
  {
    id: 'usr-05',
    username: 'driver_murugan',
    name: 'Mr. Murugan (Route 1 Driver)',
    email: 'driver.murugan@wisdomschool.edu.in',
    roleId: 'role-driver',
    roleName: 'Transport / Bus Driver',
    phone: '+91 94430 88776',
  },
  {
    id: 'usr-06',
    username: 'ai_assistant',
    name: 'Wisdom AI Counselor Agent',
    email: 'ai.assistant@wisdomschool.edu.in',
    roleId: 'role-ai-assistant',
    roleName: 'AI Counselor & Mentor',
    phone: '+91 90000 11223',
  },
];

interface AuthContextType {
  currentUser: UserAccount | null;
  roles: UserRoleDefinition[];
  users: UserAccount[];
  login: (username: string, roleId?: string) => boolean;
  logout: () => void;
  createCustomRole: (role: Omit<UserRoleDefinition, 'id' | 'isCustom' | 'createdDate'>) => UserRoleDefinition;
  registerUser: (user: Omit<UserAccount, 'id'>) => UserAccount;
  hasPermission: (permission: PermissionKey) => boolean;
  switchUserRole: (roleId: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [roles, setRoles] = useState<UserRoleDefinition[]>(() => {
    const saved = localStorage.getItem('wisdom_school_roles');
    return saved ? JSON.parse(saved) : INITIAL_ROLES;
  });

  const [users, setUsers] = useState<UserAccount[]>(() => {
    const saved = localStorage.getItem('wisdom_school_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() => {
    const saved = localStorage.getItem('wisdom_school_current_user');
    return saved ? JSON.parse(saved) : INITIAL_USERS[0]; // Default logged in as Principal/Admin
  });

  useEffect(() => {
    localStorage.setItem('wisdom_school_roles', JSON.stringify(roles));
  }, [roles]);

  useEffect(() => {
    localStorage.setItem('wisdom_school_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('wisdom_school_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('wisdom_school_current_user');
    }
  }, [currentUser]);

  const login = (usernameInput: string, roleIdInput?: string): boolean => {
    const foundUser = users.find(
      (u) =>
        u.username.toLowerCase() === usernameInput.toLowerCase() ||
        u.email.toLowerCase() === usernameInput.toLowerCase()
    );

    if (foundUser) {
      const updatedUser = {
        ...foundUser,
        lastLogin: new Date().toLocaleString('en-IN'),
      };
      setCurrentUser(updatedUser);
      return true;
    }

    if (roleIdInput) {
      const targetRole = roles.find((r) => r.id === roleIdInput);
      if (targetRole) {
        const newUser: UserAccount = {
          id: `usr-${Date.now().toString().slice(-4)}`,
          username: usernameInput,
          name: usernameInput,
          email: `${usernameInput.toLowerCase()}@wisdomschool.edu.in`,
          roleId: targetRole.id,
          roleName: targetRole.name,
          lastLogin: new Date().toLocaleString('en-IN'),
        };
        setUsers((prev) => [...prev, newUser]);
        setCurrentUser(newUser);
        return true;
      }
    }

    return false;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const createCustomRole = (
    newRoleData: Omit<UserRoleDefinition, 'id' | 'isCustom' | 'createdDate'>
  ): UserRoleDefinition => {
    const newRole: UserRoleDefinition = {
      ...newRoleData,
      id: `role-${Date.now().toString().slice(-6)}`,
      isCustom: true,
      createdDate: new Date().toLocaleDateString('en-GB'),
    };

    setRoles((prev) => [...prev, newRole]);
    return newRole;
  };

  const registerUser = (userData: Omit<UserAccount, 'id'>): UserAccount => {
    const newUser: UserAccount = {
      ...userData,
      id: `usr-${Date.now().toString().slice(-6)}`,
      lastLogin: new Date().toLocaleString('en-IN'),
    };

    setUsers((prev) => [...prev, newUser]);
    return newUser;
  };

  const switchUserRole = (roleId: string) => {
    const roleDef = roles.find((r) => r.id === roleId);
    if (!roleDef) return;

    // Find an existing user with this role or update current user's role
    const matchingUser = users.find((u) => u.roleId === roleId);
    if (matchingUser) {
      setCurrentUser(matchingUser);
    } else if (currentUser) {
      const updated = {
        ...currentUser,
        roleId: roleDef.id,
        roleName: roleDef.name,
      };
      setCurrentUser(updated);
    }
  };

  const hasPermission = (permission: PermissionKey): boolean => {
    if (!currentUser) return false;
    const currentRoleDef = roles.find((r) => r.id === currentUser.roleId);
    if (!currentRoleDef) return true; // fallback
    return currentRoleDef.permissions.includes(permission);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        roles,
        users,
        login,
        logout,
        createCustomRole,
        registerUser,
        hasPermission,
        switchUserRole,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

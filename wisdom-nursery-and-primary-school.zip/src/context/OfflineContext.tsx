import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Wifi,
  WifiOff,
  RefreshCw,
  CheckCircle2,
  HardDriveDownload,
  Database,
  CloudOff,
  X,
  Bell,
  BellRing,
  Send,
  Sparkles,
  Info,
} from 'lucide-react';
import { getLastSyncTime, getSyncQueue, clearSyncQueue } from '../utils/offlineStorage';

interface OfflineContextType {
  isOnline: boolean;
  isSimulatedOffline: boolean;
  toggleSimulatedOffline: () => void;
  lastSyncedAt: string | null;
  pendingSyncCount: number;
  triggerManualSync: () => void;
  // Push Notification Features
  pushSupported: boolean;
  notificationPermission: NotificationPermission;
  requestNotificationPermission: () => Promise<boolean>;
  sendTestPushNotification: (title?: string, body?: string) => void;
  simulateNoticeboardPush: (noticeTitle: string, category?: string) => void;
}

const OfflineContext = createContext<OfflineContextType>({
  isOnline: true,
  isSimulatedOffline: false,
  toggleSimulatedOffline: () => {},
  lastSyncedAt: null,
  pendingSyncCount: 0,
  triggerManualSync: () => {},
  pushSupported: false,
  notificationPermission: 'default',
  requestNotificationPermission: async () => false,
  sendTestPushNotification: () => {},
  simulateNoticeboardPush: () => {},
});

export const useOffline = () => useContext(OfflineContext);

export const OfflineProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isNetworkOnline, setIsNetworkOnline] = useState<boolean>(navigator.onLine);
  const [isSimulatedOffline, setIsSimulatedOffline] = useState<boolean>(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<string | null>(getLastSyncTime());
  const [pendingSyncCount, setPendingSyncCount] = useState<number>(getSyncQueue().length);
  const [showSyncSuccessToast, setShowSyncSuccessToast] = useState(false);
  const [dismissBanner, setDismissBanner] = useState(false);

  // Push Notification State
  const pushSupported = typeof window !== 'undefined' && 'Notification' in window && 'serviceWorker' in navigator;
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'default'
  );
  const [activePushToast, setActivePushToast] = useState<{ title: string; body: string; category?: string } | null>(null);

  const effectiveOnline = isNetworkOnline && !isSimulatedOffline;

  useEffect(() => {
    const handleOnline = () => {
      setIsNetworkOnline(true);
      processPendingSyncQueue();
    };

    const handleOffline = () => {
      setIsNetworkOnline(false);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Register Service Worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker
        .register('/sw.js')
        .then((reg) => console.log('[ServiceWorker] Registered with scope:', reg.scope))
        .catch((err) => console.warn('[ServiceWorker] Registration failed:', err));
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const requestNotificationPermission = async (): Promise<boolean> => {
    if (!pushSupported) {
      alert('Push notifications are not supported in this browser environment.');
      return false;
    }

    try {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);
      if (permission === 'granted') {
        sendTestPushNotification(
          '🔔 Push Notifications Enabled!',
          'You will now receive instant noticeboard circulars & hall pass updates even when closed.'
        );
        return true;
      }
      return false;
    } catch (err) {
      console.warn('[PushNotification] Permission request failed:', err);
      return false;
    }
  };

  const sendTestPushNotification = (
    title = '📢 Wisdom School Official Alert',
    body = 'New circular published on the school noticeboard.'
  ) => {
    // 1. Trigger via Service Worker if registered
    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'TRIGGER_PUSH_NOTIFICATION',
        title,
        body,
        category: 'Noticeboard Update',
      });
    } else if (pushSupported && Notification.permission === 'granted') {
      try {
        new Notification(title, {
          body,
          icon: '/favicon.ico',
        });
      } catch (e) {
        console.warn('Direct notification fallback error:', e);
      }
    }

    // 2. In-App Floating Toast Fallback
    setActivePushToast({ title, body, category: 'Noticeboard Update' });
    setTimeout(() => {
      setActivePushToast(null);
    }, 6000);
  };

  const simulateNoticeboardPush = (noticeTitle: string, category = 'Urgent Notice') => {
    sendTestPushNotification(
      `📌 ${category}: ${noticeTitle}`,
      `Tap to view full details in Wisdom School App.`
    );
  };

  const processPendingSyncQueue = () => {
    const queue = getSyncQueue();
    if (queue.length > 0) {
      console.log(`[OfflineSync] Syncing ${queue.length} pending items to Wisdom Server...`);
      clearSyncQueue();
      setPendingSyncCount(0);
      setLastSyncedAt(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }));
      setShowSyncSuccessToast(true);
      setTimeout(() => setShowSyncSuccessToast(false), 4000);
    }
  };

  const toggleSimulatedOffline = () => {
    setIsSimulatedOffline((prev) => !prev);
    setDismissBanner(false);
  };

  const triggerManualSync = () => {
    processPendingSyncQueue();
    setLastSyncedAt(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }));
    setShowSyncSuccessToast(true);
    setTimeout(() => setShowSyncSuccessToast(false), 3000);
  };

  return (
    <OfflineContext.Provider
      value={{
        isOnline: effectiveOnline,
        isSimulatedOffline,
        toggleSimulatedOffline,
        lastSyncedAt,
        pendingSyncCount,
        triggerManualSync,
        pushSupported,
        notificationPermission,
        requestNotificationPermission,
        sendTestPushNotification,
        simulateNoticeboardPush,
      }}
    >
      {/* GLOBAL OFFLINE / ONLINE STATUS BAR */}
      {!effectiveOnline && !dismissBanner && (
        <div className="bg-amber-900 text-amber-100 text-xs py-2 px-4 shadow-md sticky top-0 z-50 flex items-center justify-between border-b border-amber-700">
          <div className="flex items-center gap-2 max-w-7xl mx-auto w-full justify-between">
            <div className="flex items-center gap-2">
              <WifiOff className="w-4 h-4 text-amber-300 animate-pulse shrink-0" />
              <span className="font-extrabold text-amber-200">
                OFFLINE MODE ACTIVE:
              </span>
              <span className="text-amber-100 hidden sm:inline">
                Viewing cached Academic Calendar, Noticeboard & Digital Hall Pass data.
              </span>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              {isSimulatedOffline && (
                <button
                  onClick={toggleSimulatedOffline}
                  className="px-2.5 py-1 bg-amber-800 hover:bg-amber-700 text-amber-200 rounded-lg text-[10px] font-bold border border-amber-600 transition"
                >
                  Exit Demo Offline
                </button>
              )}
              <button
                onClick={() => setDismissBanner(true)}
                className="text-amber-300 hover:text-white p-1 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SYNC SUCCESS FLOATING TOAST */}
      {showSyncSuccessToast && (
        <div className="fixed bottom-6 right-6 bg-emerald-900 text-emerald-100 border border-emerald-500 rounded-2xl p-4 shadow-2xl z-50 flex items-center gap-3 animate-bounce">
          <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
          <div className="text-xs">
            <h5 className="font-extrabold text-emerald-200">Offline Data Synchronized!</h5>
            <p className="text-emerald-300 text-[11px]">All queued requests sent to Wisdom International server.</p>
          </div>
        </div>
      )}

      {/* IN-APP PUSH NOTIFICATION ALERT BANNER */}
      {activePushToast && (
        <div className="fixed top-5 right-5 z-50 max-w-sm w-full bg-blue-950 text-white border-2 border-amber-400 rounded-2xl p-4 shadow-2xl space-y-1.5 animate-scaleUp">
          <div className="flex items-center justify-between border-b border-blue-900 pb-2">
            <span className="bg-amber-400 text-blue-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
              <BellRing className="w-3 h-3" />
              Push Notification
            </span>
            <button
              onClick={() => setActivePushToast(null)}
              className="text-slate-400 hover:text-white p-0.5"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <h5 className="font-extrabold text-xs text-amber-300 pt-0.5">
            {activePushToast.title}
          </h5>
          <p className="text-[11px] text-slate-200 leading-snug">
            {activePushToast.body}
          </p>

          <div className="pt-1 flex items-center justify-between text-[10px] text-slate-400">
            <span>Source: ServiceWorker Push Engine</span>
            <span className="text-amber-400 font-bold">Just Now</span>
          </div>
        </div>
      )}

      {children}
    </OfflineContext.Provider>
  );
};


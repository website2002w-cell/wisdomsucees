import React, { useState } from 'react';
import { EmergencyAlertBanner } from './components/EmergencyAlertBanner';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { FeePaymentSection } from './components/FeePaymentSection';
import { StudentPortal } from './components/StudentPortal';
import { AdmissionsForm } from './components/AdmissionsForm';
import { Noticeboard } from './components/Noticeboard';
import { CampusGallery } from './components/CampusGallery';
import { AppDownloadSection } from './components/AppDownloadSection';
import { ContactAndMap } from './components/ContactAndMap';
import { AdminPanel } from './components/AdminPanel';
import { AcademicCalendar } from './components/AcademicCalendar';
import { AiCounselorDrawer } from './components/AiCounselorDrawer';
import { ErpSystem } from './components/ErpSystem';
import { SchoolStore } from './components/SchoolStore';
import { LostAndFound } from './components/LostAndFound';
import { StudentAchievements } from './components/StudentAchievements';
import { SuggestionBox } from './components/SuggestionBox';
import { DigitalHallPass } from './components/DigitalHallPass';
import { SchoolVanTracker } from './components/SchoolVanTracker';
import { ParentTeacherCommunication } from './components/ParentTeacherCommunication';
import { LibraryCatalog } from './components/LibraryCatalog';
import { FutureLabAi } from './components/FutureLabAi';
import { OnlineClassZoom } from './components/OnlineClassZoom';
import { Footer } from './components/Footer';
import { OfflineProvider } from './context/OfflineContext';
import { AuthProvider } from './context/AuthContext';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [aiChatOpen, setAiChatOpen] = useState<boolean>(false);
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [lang, setLang] = useState<'en' | 'ta'>('en');

  return (
    <AuthProvider>
      <OfflineProvider>
        <div className={`min-h-screen flex flex-col justify-between selection:bg-amber-100 selection:text-blue-950 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'}`}>

        <div>
          {/* High Priority Emergency Alert Banner */}
          <EmergencyAlertBanner setActiveTab={setActiveTab} />

          {/* Navigation Header */}
          <Header
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            onOpenAiChat={() => setAiChatOpen(true)}
          />

          {/* Dynamic Main Body Content */}
          <main className="animate-fadeIn">
            {activeTab === 'home' && (
              <div>
                <Hero
                  setActiveTab={setActiveTab}
                  onOpenAiChat={() => setAiChatOpen(true)}
                />
                <FeePaymentSection />
                <Noticeboard />
                <ContactAndMap />
              </div>
            )}

            {activeTab === 'zoom-classes' && (
              <div className="py-6 px-4">
                <OnlineClassZoom />
              </div>
            )}

            {activeTab === 'future-lab' && (
              <div className="py-6 px-4">
                <FutureLabAi onOpenAiCounselor={() => setAiChatOpen(true)} />
              </div>
            )}

            {activeTab === 'erp' && (
              <ErpSystem
                darkMode={darkMode}
                setDarkMode={setDarkMode}
                lang={lang}
                setLang={setLang}
              />
            )}

            {activeTab === 'van-tracker' && <SchoolVanTracker />}

            {activeTab === 'parent-connect' && <ParentTeacherCommunication />}

            {activeTab === 'library' && <LibraryCatalog />}

            {activeTab === 'fee-payment' && <FeePaymentSection />}

            {activeTab === 'store' && <SchoolStore />}

            {activeTab === 'lost-found' && <LostAndFound />}

            {activeTab === 'achievements' && <StudentAchievements />}

            {activeTab === 'suggestion-box' && <SuggestionBox />}

            {activeTab === 'hall-pass' && <DigitalHallPass />}

            {activeTab === 'student-portal' && <StudentPortal />}

            {activeTab === 'calendar' && <AcademicCalendar />}

            {activeTab === 'admissions' && <AdmissionsForm />}

            {activeTab === 'notices' && <Noticeboard />}

            {activeTab === 'admin' && <AdminPanel />}

            {activeTab === 'gallery' && <CampusGallery />}

            {activeTab === 'app-download' && <AppDownloadSection />}

            {activeTab === 'contact' && <ContactAndMap />}
          </main>
        </div>

        {/* Footer */}
        <Footer setActiveTab={setActiveTab} />

        {/* Floating Wisdom AI Assistant Drawer */}
        <AiCounselorDrawer
          isOpen={aiChatOpen}
          onClose={() => setAiChatOpen(false)}
        />
      </div>
    </OfflineProvider>
    </AuthProvider>
  );
}


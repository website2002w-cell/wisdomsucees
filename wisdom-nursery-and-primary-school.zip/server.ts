import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini AI Client lazily or safely
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-memory data store for admissions and receipts (transient session/demo storage)
interface AdmissionApplication {
  id: string;
  studentName: string;
  dob: string;
  gender: string;
  grade: string;
  fatherName: string;
  motherName: string;
  phone: string;
  email: string;
  address: string;
  previousSchool?: string;
  submittedAt: string;
  status: 'Pending Review' | 'Accepted' | 'Interview Scheduled';
}

interface FeeReceipt {
  receiptNo: string;
  studentName: string;
  studentId: string;
  grade: string;
  term: string;
  amount: number;
  paymentMethod: string;
  transactionRef: string;
  date: string;
  status: 'VERIFIED' | 'PENDING_VERIFICATION';
}

const admissionsDb: AdmissionApplication[] = [
  {
    id: 'ADM-ESSUR-2026-101',
    studentName: 'K. Ananya',
    dob: '2021-04-12',
    gender: 'Female',
    grade: 'LKG',
    fatherName: 'Karthik Raja',
    motherName: 'Deepa K',
    phone: '9876543210',
    email: 'karthik@example.com',
    address: 'Main Road, Essur - 603301',
    submittedAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    status: 'Interview Scheduled',
  },
];

const receiptsDb: FeeReceipt[] = [
  {
    receiptNo: 'WNS-RCP-2026-8801',
    studentName: 'R. Kavin',
    studentId: 'WNS-2026-01',
    grade: 'Class 3',
    term: 'Term 1 Fee',
    amount: 4500,
    paymentMethod: 'UPI (GPay)',
    transactionRef: 'UPI-382910482910',
    date: new Date(Date.now() - 86400000 * 2).toLocaleDateString('en-IN'),
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8802',
    studentName: 'R. Kavin',
    studentId: 'WNS-2026-01',
    grade: 'Class 3',
    term: 'Book Set & Notebooks',
    amount: 1500,
    paymentMethod: 'UPI (PhonePe)',
    transactionRef: 'UPI-948201948201',
    date: new Date(Date.now() - 86400000 * 25).toLocaleDateString('en-IN'),
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8803',
    studentName: 'S. Priyanka',
    studentId: 'WNS-2026-02',
    grade: 'LKG',
    term: 'Term 1 Fee',
    amount: 3500,
    paymentMethod: 'UPI (GPay)',
    transactionRef: 'UPI-552019482910',
    date: new Date(Date.now() - 86400000 * 5).toLocaleDateString('en-IN'),
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8804',
    studentName: 'M. Yogesh',
    studentId: 'WNS-2026-03',
    grade: 'Class 5',
    term: 'Term 1 Fee',
    amount: 5000,
    paymentMethod: 'UPI (Paytm)',
    transactionRef: 'UPI-882019481102',
    date: new Date(Date.now() - 86400000 * 12).toLocaleDateString('en-IN'),
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8805',
    studentName: 'M. Yogesh',
    studentId: 'WNS-2026-03',
    grade: 'Class 5',
    term: 'Uniform & Accessories',
    amount: 1800,
    paymentMethod: 'UPI (GPay)',
    transactionRef: 'UPI-771920394810',
    date: new Date(Date.now() - 86400000 * 30).toLocaleDateString('en-IN'),
    status: 'VERIFIED',
  },
  {
    receiptNo: 'WNS-RCP-2026-8806',
    studentName: 'K. Ananya',
    studentId: 'WNS-2026-04',
    grade: 'LKG',
    term: 'Term 1 Fee',
    amount: 3500,
    paymentMethod: 'UPI (BHIM)',
    transactionRef: 'UPI-481920391820',
    date: new Date(Date.now() - 86400000 * 1).toLocaleDateString('en-IN'),
    status: 'VERIFIED',
  },
];

// Sample student profiles for parent portal lookup
const studentProfiles: Record<string, any> = {
  'WNS-2026-01': {
    id: 'WNS-2026-01',
    name: 'R. Kavin',
    grade: 'Class 3 - A',
    rollNo: '01',
    phone: '9876543210',
    dob: '2018-06-15',
    fatherName: 'R. Saravanan',
    motherName: 'S. Sundari',
    classTeacher: 'Mrs. M. Lakshmi, M.Sc., B.Ed.',
    attendancePercentage: 96.5,
    totalDays: 85,
    presentDays: 82,
    bloodGroup: 'O+',
    feeStatus: 'Paid for Term 1',
    term1Marks: [
      { subject: 'Tamil', mark: 92, max: 100, grade: 'A+' },
      { subject: 'English', mark: 88, max: 100, grade: 'A' },
      { subject: 'Mathematics', mark: 95, max: 100, grade: 'A+' },
      { subject: 'Science', mark: 90, max: 100, grade: 'A+' },
      { subject: 'Social Studies', mark: 86, max: 100, grade: 'A' },
      { subject: 'Computer Literacy', mark: 98, max: 100, grade: 'A+' },
    ],
    homework: [
      { id: 'hw-1', subject: 'Mathematics', title: 'Exercise 3.2 Multiplication tables 6 to 9', dueDate: 'Tomorrow', status: 'Pending' },
      { id: 'hw-2', subject: 'Tamil', title: 'Thirukkural memorization & write 2 times', dueDate: 'Completed', status: 'Submitted' },
      { id: 'hw-3', subject: 'English', title: 'Read Chapter 4 story & answer Q1 to Q5', dueDate: '23 Jul 2026', status: 'Pending' },
    ],
    teacherNotes: 'Kavin is bright, observant, and participates enthusiastically in class activities and math quizzes!',
  },
  'WNS-2026-02': {
    id: 'WNS-2026-02',
    name: 'S. Priyanka',
    grade: 'LKG - Blossom',
    rollNo: '14',
    phone: '9876543211',
    dob: '2021-04-10',
    fatherName: 'S. Sundaram',
    motherName: 'S. Kavitha',
    classTeacher: 'Mrs. V. Radha, B.A., D.T.Ed.',
    attendancePercentage: 98.0,
    totalDays: 85,
    presentDays: 83,
    bloodGroup: 'B+',
    feeStatus: 'Paid for Annual Term',
    term1Marks: [
      { subject: 'English Alphabets & Phonics', mark: 98, max: 100, grade: 'A+' },
      { subject: 'Tamil Rhymes & Vowels', mark: 95, max: 100, grade: 'A+' },
      { subject: 'Number Counting (1-50)', mark: 96, max: 100, grade: 'A+' },
      { subject: 'Drawing & Coloring', mark: 100, max: 100, grade: 'A+' },
      { subject: 'Good Habits & Rhymes', mark: 94, max: 100, grade: 'A+' },
    ],
    homework: [
      { id: 'hw-10', subject: 'Drawing', title: 'Color the Mango and Sun worksheet', dueDate: 'Tomorrow', status: 'Pending' },
      { id: 'hw-11', subject: 'Phonics', title: 'Practice A to Z phonetic songs', dueDate: 'Completed', status: 'Submitted' },
    ],
    teacherNotes: 'Priyanka loves storytelling and rhymes! Excellent rhythm and social interaction.',
  },
  'WNS-2026-03': {
    id: 'WNS-2026-03',
    name: 'M. Yogesh',
    grade: 'Class 5 - A',
    rollNo: '22',
    phone: '9876543212',
    dob: '2016-08-20',
    fatherName: 'M. Manikandan',
    motherName: 'M. Selvi',
    classTeacher: 'Mr. P. Ramesh, M.A., B.Ed.',
    attendancePercentage: 94.2,
    totalDays: 85,
    presentDays: 80,
    bloodGroup: 'A1+',
    feeStatus: 'Term 2 Fee Due',
    term1Marks: [
      { subject: 'Tamil', mark: 85, max: 100, grade: 'A' },
      { subject: 'English', mark: 91, max: 100, grade: 'A+' },
      { subject: 'Mathematics', mark: 89, max: 100, grade: 'A' },
      { subject: 'Science', mark: 94, max: 100, grade: 'A+' },
      { subject: 'Social Science', mark: 88, max: 100, grade: 'A' },
      { subject: 'Computer Applications', mark: 96, max: 100, grade: 'A+' },
    ],
    homework: [
      { id: 'hw-20', subject: 'Science', title: 'Draw and label parts of a Plant Cell', dueDate: '24 Jul 2026', status: 'Pending' },
      { id: 'hw-21', subject: 'Mathematics', title: 'Fractions & Decimals Worksheet 5', dueDate: 'Tomorrow', status: 'Pending' },
    ],
    teacherNotes: 'Yogesh is showing high leadership in computer lab sessions and sports activities!',
  },
};

// API Routes

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    schoolName: 'Wisdom Nursery and Primary School',
    location: 'Essur - 603301',
    motto: 'Learn Today, Lead Tomorrow.',
    admin: 'R. SARAVANAN',
  });
});

// Student Portal Login API (By Phone & DOB OR Student ID)
app.post('/api/student/login', (req, res) => {
  const { phone, dob, studentId } = req.body || {};

  // If studentId provided
  if (studentId) {
    const cleanId = String(studentId).trim().toUpperCase();
    const found = studentProfiles[cleanId];
    if (found) {
      res.json({ success: true, student: found });
      return;
    }
  }

  // If Phone + DOB provided
  if (phone) {
    const cleanPhone = String(phone).replace(/\D/g, '').slice(-10);
    const cleanDob = String(dob || '').trim();

    const matched = Object.values(studentProfiles).find((st: any) => {
      const stPhone = String(st.phone || '').replace(/\D/g, '').slice(-10);
      const phoneMatch = stPhone === cleanPhone || stPhone.endsWith(cleanPhone) || cleanPhone.endsWith(stPhone);
      const dobMatch = !cleanDob || st.dob === cleanDob || st.dob?.replace(/-/g, '') === cleanDob.replace(/-/g, '');
      return phoneMatch && dobMatch;
    });

    if (matched) {
      res.json({ success: true, student: matched });
      return;
    }
  }

  res.status(401).json({
    success: false,
    message: 'No student found matching the provided details. Try Mobile: 9876543210 & DOB: 2018-06-15, or Student ID: WNS-2026-01',
  });
});

// Admin Login API (Password: WISDOM2002, Username: WISDOM)
app.post('/api/admin/login', (req, res) => {
  const { username, password } = req.body || {};
  const cleanUsername = String(username || '').trim().toUpperCase();
  const cleanPassword = String(password || '').trim();

  // Accept username WISDOM and password WISDOM2002
  if ((cleanUsername === 'WISDOM' || !cleanUsername) && cleanPassword === 'WISDOM2002') {
    res.json({
      success: true,
      token: 'WISDOM_ADMIN_SESSION_2026',
      admin: {
        username: 'WISDOM',
        name: 'R. SARAVANAN',
        role: 'School Administrator',
        school: 'Wisdom Nursery and Primary School, Essur - 603301',
      },
      message: 'Admin Authentication Successful!',
    });
  } else {
    res.status(401).json({
      success: false,
      message: 'Invalid Admin Credentials! Username is "WISDOM" and Password is "WISDOM2002".',
    });
  }
});

// Admin Dashboard Data Fetch API
app.get('/api/admin/data', (req, res) => {
  res.json({
    success: true,
    stats: {
      totalAdmissions: admissionsDb.length,
      totalFeeReceipts: receiptsDb.length,
      totalStudents: Object.keys(studentProfiles).length,
      schoolName: 'Wisdom Nursery and Primary School, Essur - 603301',
    },
    admissions: admissionsDb,
    receipts: receiptsDb,
    students: Object.values(studentProfiles),
  });
});

// Admin Batch Upload Students from Excel/CSV API
app.post('/api/admin/students/batch-upload', (req, res) => {
  const { students } = req.body || {};

  if (!Array.isArray(students) || students.length === 0) {
    res.status(400).json({ success: false, message: 'No student records provided in payload.' });
    return;
  }

  let importedCount = 0;
  students.forEach((st: any, idx: number) => {
    const studentId = st.id || `WNS-2026-${String(10 + Object.keys(studentProfiles).length + idx).padStart(2, '0')}`;
    studentProfiles[studentId] = {
      id: studentId,
      name: st.name || 'Student',
      grade: st.grade || 'Class 3',
      rollNo: st.rollNo || String(idx + 1),
      phone: st.phone || '9876543210',
      dob: st.dob || '2018-06-15',
      fatherName: st.fatherName || 'Parent',
      motherName: st.motherName || 'Parent',
      classTeacher: st.classTeacher || 'Mrs. Anita Ramesh',
      attendancePercentage: 95.0,
      totalDays: 85,
      presentDays: 81,
      bloodGroup: st.bloodGroup || 'O+',
      feeStatus: st.feeStatus || 'Paid for Term 1',
      importantNotes: st.importantTag || 'Excel Import Record',
      term1Marks: [
        { subject: 'Tamil', mark: 90, max: 100, grade: 'A+' },
        { subject: 'English', mark: 88, max: 100, grade: 'A' },
        { subject: 'Mathematics', mark: 92, max: 100, grade: 'A+' },
        { subject: 'Science', mark: 91, max: 100, grade: 'A+' },
      ],
      homework: [
        { id: `hw-imp-${idx}`, subject: 'General', title: 'Welcome to Wisdom Student Portal!', dueDate: 'Next Week', status: 'Pending' },
      ],
      teacherNotes: `Record imported via Excel Batch Upload on ${new Date().toLocaleDateString('en-IN')}`,
    };
    importedCount++;
  });

  res.json({
    success: true,
    importedCount,
    totalStudents: Object.keys(studentProfiles).length,
    message: `Successfully batch imported ${importedCount} student records from Excel file!`,
    students: Object.values(studentProfiles),
  });
});

// In-memory fee reminders log
interface FeeReminderLog {
  id: string;
  studentId: string;
  studentName: string;
  parentPhone: string;
  term: string;
  amount: number;
  channel: 'whatsapp' | 'sms' | 'email' | 'push';
  sentAt: string;
  status: 'DELIVERED' | 'SENT';
  messageText: string;
}

const feeRemindersDb: FeeReminderLog[] = [
  {
    id: 'REM-2026-901',
    studentId: 'WNS-2026-01',
    studentName: 'R. Kavin',
    parentPhone: '9876543210',
    term: 'Term 2 Tuition Fee',
    amount: 3500,
    channel: 'push',
    sentAt: new Date(Date.now() - 3600000 * 24 * 2).toLocaleString('en-IN'),
    status: 'DELIVERED',
    messageText: '🔔 [Push Notification] Gentle Fee Reminder: Term 2 Fee ₹3,500 for R. Kavin is due in 3 days (15-Aug-2026). Tap to pay via GPay/PhonePe.',
  },
];

// Send Automated Fee Payment Reminder API
app.post('/api/student/fee-reminders/send', (req, res) => {
  const { studentId, studentName, parentPhone, channel, term, amount } = req.body || {};

  const cleanPhone = String(parentPhone || '9876543210').replace(/\D/g, '');
  const validChannels = ['whatsapp', 'sms', 'email', 'push'];
  const chosenChannel: 'whatsapp' | 'sms' | 'email' | 'push' = validChannels.includes(channel) ? channel : 'push';
  const feeTerm = term || 'Term 2 Tuition Fee';
  const feeAmount = Number(amount) || 3500;
  const name = studentName || 'Student';

  let messageText = '';
  if (chosenChannel === 'push') {
    messageText = `🔔 [Wisdom School Push Alert] Gentle Fee Reminder: ${feeTerm} ₹${feeAmount.toLocaleString('en-IN')} for ${name} is due in 3 days (15-Aug-2026). Click to pay instantly via UPI.`;
  } else if (chosenChannel === 'whatsapp') {
    messageText = `🔔 [Wisdom Nursery & Primary School, Essur]\nAutomated Fee Payment Reminder for ${name} (${feeTerm}).\n\nFee Amount: ₹${feeAmount.toLocaleString('en-IN')}\nDue Date: 15-Aug-2026\nSchool UPI ID: rsaravanan102002-1@okhdfcbank\n\nClick to Pay Instant UPI: https://wisdomessur.edu.in/fees?studentId=${studentId || 'WNS-2026-01'}\n\nHelpdesk: +91 9176593129`;
  } else {
    messageText = `WNS ESSUR: Fee Reminder for ${name}. ${feeTerm} ₹${feeAmount} due in 3 days (15-Aug-2026). Pay online: https://wisdomessur.edu.in/fees or school office. Ph: 9176593129`;
  }

  const newLog: FeeReminderLog = {
    id: `REM-${Date.now().toString().slice(-6)}`,
    studentId: studentId || 'WNS-2026-01',
    studentName: name,
    parentPhone: cleanPhone,
    term: feeTerm,
    amount: feeAmount,
    channel: chosenChannel,
    sentAt: new Date().toLocaleString('en-IN'),
    status: 'DELIVERED',
    messageText,
  };

  feeRemindersDb.unshift(newLog);

  res.json({
    success: true,
    message: `Automated ${chosenChannel.toUpperCase()} Fee Reminder dispatched successfully`,
    reminder: newLog,
  });
});

// Bulk Send Fee Payment Reminders API (Multi-channel: WhatsApp, SMS, Email, Push)
app.post('/api/student/fee-reminders/bulk-send', (req, res) => {
  const { targets, channels, customMessage } = req.body || {};

  if (!Array.isArray(targets) || targets.length === 0) {
    res.status(400).json({ success: false, message: 'No target students selected for bulk sending.' });
    return;
  }

  const selectedChannels: ('whatsapp' | 'sms' | 'email' | 'push')[] = Array.isArray(channels) && channels.length > 0 
    ? channels 
    : ['whatsapp', 'sms', 'push'];

  const dispatchedLogs: FeeReminderLog[] = [];
  let whatsappCount = 0;
  let smsCount = 0;
  let emailCount = 0;
  let pushCount = 0;

  targets.forEach((target: any) => {
    const name = target.studentName || target.name || 'Student';
    const studentId = target.studentId || target.id || 'WNS-STUDENT';
    const phone = String(target.parentPhone || target.phone || '9876543210').replace(/\D/g, '');
    const term = target.term || target.feeParticulars || 'Term Fee';
    const amount = Number(target.amount || target.amountDue || 3500);
    const dueDate = target.dueDate || '15-Aug-2026';

    selectedChannels.forEach((ch) => {
      let msg = '';
      if (customMessage) {
        msg = customMessage
          .replace(/\{student_name\}/g, name)
          .replace(/\{student_id\}/g, studentId)
          .replace(/\{fee_term\}/g, term)
          .replace(/\{amount\}/g, `₹${amount.toLocaleString('en-IN')}`)
          .replace(/\{due_date\}/g, dueDate);
      } else if (ch === 'whatsapp') {
        msg = `🔔 [Wisdom Nursery & Primary School, Essur]\nOfficial Fee Due Reminder for ${name} (${studentId}, ${target.grade || 'Class'}).\n\nParticulars: ${term}\nAmount Payable: ₹${amount.toLocaleString('en-IN')}\nDue Date: ${dueDate}\nSchool UPI ID: rsaravanan102002-1@okhdfcbank\n\nPay online instantly: https://wisdomessur.edu.in/fees?studentId=${studentId}\nHelpdesk Ph: +91 9176593129`;
        whatsappCount++;
      } else if (ch === 'sms') {
        msg = `WISDOM SCHOOL ESSUR: Fee due notice for ${name}. ${term} ₹${amount} due on ${dueDate}. Pay online: https://wisdomessur.edu.in/fees or school office. Ph: 9176593129`;
        smsCount++;
      } else if (ch === 'email') {
        msg = `Subject: Wisdom School Fee Payment Notice - ${name} (${studentId})\nDear Parent, gentle reminder that ${term} of ₹${amount} for ${name} is due on ${dueDate}. Please settle via UPI or school cash counter.`;
        emailCount++;
      } else {
        msg = `🔔 [Wisdom Push Alert] Fee Reminder for ${name}: ${term} ₹${amount} due on ${dueDate}. Tap to pay.`;
        pushCount++;
      }

      const log: FeeReminderLog = {
        id: `REM-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 1000)}`,
        studentId,
        studentName: name,
        parentPhone: phone,
        term,
        amount,
        channel: ch,
        sentAt: new Date().toLocaleString('en-IN'),
        status: 'DELIVERED',
        messageText: msg,
      };

      dispatchedLogs.push(log);
      feeRemindersDb.unshift(log);
    });
  });

  res.json({
    success: true,
    message: `Bulk reminder campaign dispatched across ${selectedChannels.join(', ').toUpperCase()} to ${targets.length} parents!`,
    totalSent: dispatchedLogs.length,
    channelBreakdown: {
      whatsapp: whatsappCount,
      sms: smsCount,
      email: emailCount,
      push: pushCount,
    },
    logs: dispatchedLogs,
  });
});

// Campaign History Storage for Admin Notification Center
const notificationCampaignHistoryDb: any[] = [
  {
    id: 'CMP-2026-8801',
    title: 'Term 2 Fee Warning - August Batch',
    channel: 'WhatsApp + SMS',
    recipientCount: 6,
    totalAmountOverdue: 23400,
    messagePreview: 'Dear Parent, gentle reminder regarding pending Term 2 fees. Please pay online via GPay/PhonePe to avoid late charges.',
    sentAt: '08-Aug-2026 10:30 AM',
    sentBy: 'Admin R. Saravanan',
    status: 'Delivered (100%)',
  },
  {
    id: 'CMP-2026-8795',
    title: 'Monthly Installment #2 Payment Alert',
    channel: 'WhatsApp',
    recipientCount: 4,
    totalAmountOverdue: 14800,
    messagePreview: 'Wisdom School Notice: Monthly fee installment #2 is due. Click link to complete UPI payment.',
    sentAt: '01-Aug-2026 04:15 PM',
    sentBy: 'Admin Office Staff',
    status: 'Delivered (100%)',
  },
];

// GET Overdue Fee List API for Admin Notification Center
app.get('/api/admin/notifications/overdue-list', (req, res) => {
  const overdueList = [
    {
      studentId: 'WNS-2026-03',
      studentName: 'M. Yogesh',
      grade: 'Class 5 - A',
      parentName: 'M. Manikandan',
      parentPhone: '9876543212',
      feeParticulars: 'Term 2 Tuition Fee',
      amountDue: 4200,
      dueDate: '15-Jul-2026',
      daysOverdue: 26,
      lastReminderSent: '05-Aug-2026',
      status: 'OVERDUE',
    },
    {
      studentId: 'WNS-2026-05',
      studentName: 'A. Dhruv',
      grade: 'Class 3 - A',
      parentName: 'A. Anand',
      parentPhone: '9876543215',
      feeParticulars: 'Term 2 Tuition Fee',
      amountDue: 3800,
      dueDate: '20-Jul-2026',
      daysOverdue: 21,
      lastReminderSent: '02-Aug-2026',
      status: 'OVERDUE',
    },
    {
      studentId: 'WNS-2026-06',
      studentName: 'M. Kavya',
      grade: 'Class 4 - B',
      parentName: 'M. Murali',
      parentPhone: '9876543216',
      feeParticulars: 'Term 2 & Transport Route 2',
      amountDue: 5200,
      dueDate: '01-Jul-2026',
      daysOverdue: 40,
      lastReminderSent: '28-Jul-2026',
      status: 'CRITICAL_OVERDUE',
    },
    {
      studentId: 'WNS-2026-07',
      studentName: 'V. Rahul',
      grade: 'Class 2 - B',
      parentName: 'V. Venkatesh',
      parentPhone: '9876543217',
      feeParticulars: 'Quarterly Installment #2',
      amountDue: 3200,
      dueDate: '10-Jul-2026',
      daysOverdue: 31,
      lastReminderSent: '01-Aug-2026',
      status: 'OVERDUE',
    },
    {
      studentId: 'WNS-2026-08',
      studentName: 'S. Bhuvanesh',
      grade: 'Class 1 - A',
      parentName: 'S. Selvam',
      parentPhone: '9876543218',
      feeParticulars: 'Term 2 & Book Set Dues',
      amountDue: 4500,
      dueDate: '05-Jul-2026',
      daysOverdue: 36,
      lastReminderSent: '30-Jul-2026',
      status: 'CRITICAL_OVERDUE',
    },
    {
      studentId: 'WNS-2026-04',
      studentName: 'K. Ananya',
      grade: 'LKG - Blossom',
      parentName: 'Karthik Raja',
      parentPhone: '9876543210',
      feeParticulars: 'Uniform & Accessories Fee',
      amountDue: 2100,
      dueDate: '25-Jul-2026',
      daysOverdue: 16,
      lastReminderSent: '04-Aug-2026',
      status: 'OVERDUE',
    },
  ];

  res.json({
    success: true,
    totalOverdueCount: overdueList.length,
    totalOverdueAmount: overdueList.reduce((sum, item) => sum + item.amountDue, 0),
    students: overdueList,
    campaignHistory: notificationCampaignHistoryDb,
  });
});

// Trigger One-Click Bulk Reminder Campaign API
app.post('/api/admin/notifications/bulk-reminder', (req, res) => {
  const { channel, selectedStudentIds, customMessage, campaignTitle } = req.body || {};

  const targetIds: string[] = Array.isArray(selectedStudentIds) ? selectedStudentIds : [];
  if (targetIds.length === 0) {
    res.status(400).json({ success: false, message: 'Please select at least one parent/student to send reminders.' });
    return;
  }

  const newCampaign = {
    id: `CMP-${Date.now().toString().slice(-6)}`,
    title: campaignTitle || `Bulk Fee Reminder (${channel || 'WhatsApp + SMS'})`,
    channel: channel === 'whatsapp' ? 'WhatsApp' : channel === 'sms' ? 'SMS' : 'WhatsApp + SMS',
    recipientCount: targetIds.length,
    totalAmountOverdue: targetIds.length * 3800, // estimated
    messagePreview: customMessage || 'Wisdom School Fee Reminder Notice to parents',
    sentAt: new Date().toLocaleString('en-IN'),
    sentBy: 'Admin R. Saravanan',
    status: 'Delivered (100%)',
  };

  notificationCampaignHistoryDb.unshift(newCampaign);

  res.json({
    success: true,
    message: `One-Click Bulk Reminders successfully sent via ${newCampaign.channel} to ${targetIds.length} parents!`,
    campaign: newCampaign,
    logs: notificationCampaignHistoryDb,
  });
});

// In-memory fee categories database
let feeCategoriesDb = [
  {
    id: 'fee-admission',
    key: 'admission',
    name: 'Admission Fee (New Enrollments)',
    amount: 2500,
    description: 'One-time registration, ID card, prospectus & admission processing',
    deletable: false,
    editable: true,
    categoryType: 'Admission',
    frequency: 'One-Time',
  },
  {
    id: 'fee-sports',
    key: 'sports',
    name: 'Sports & Annual Athletic Fee',
    amount: 1200,
    description: 'Annual sports equipment, physical education coaching & athletic meet',
    deletable: false,
    editable: true,
    categoryType: 'Sports',
    frequency: 'Annual',
  },
  {
    id: 'fee-van-1',
    key: 'van_route_1',
    name: 'School Van / Transport Fee (Route 1 - Essur Local)',
    amount: 1500,
    description: 'Doorstep pickup & drop-off for Essur village and surrounding areas',
    deletable: true,
    editable: true,
    categoryType: 'Van / Transport',
    frequency: 'Term-wise',
  },
  {
    id: 'fee-van-2',
    key: 'van_route_2',
    name: 'School Van / Transport Fee (Route 2 - Cheyyur / Highway)',
    amount: 1800,
    description: 'Van service covering Cheyyur highway and suburban stops',
    deletable: true,
    editable: true,
    categoryType: 'Van / Transport',
    frequency: 'Term-wise',
  },
  {
    id: 'fee-term1',
    key: 'term1',
    name: 'Term 1 Tuition & Activity Fee',
    amount: 4500,
    description: 'Academic tuition & classroom learning for Term 1',
    deletable: false,
    editable: true,
    categoryType: 'Tuition',
    frequency: 'Term-wise',
  },
  {
    id: 'fee-term2',
    key: 'term2',
    name: 'Term 2 Tuition & Activity Fee',
    amount: 4500,
    description: 'Academic tuition & classroom learning for Term 2',
    deletable: false,
    editable: true,
    categoryType: 'Tuition',
    frequency: 'Term-wise',
  },
  {
    id: 'fee-term3',
    key: 'term3',
    name: 'Term 3 Tuition & Activity Fee',
    amount: 3800,
    description: 'Academic tuition & classroom learning for Term 3',
    deletable: false,
    editable: true,
    categoryType: 'Tuition',
    frequency: 'Term-wise',
  },
  {
    id: 'fee-books',
    key: 'books',
    name: 'Book Set, Workbooks & Stationary',
    amount: 2000,
    description: 'Tamil Nadu Board textbooks, note copies and homework diaries',
    deletable: false,
    editable: true,
    categoryType: 'Books',
    frequency: 'Annual',
  },
  {
    id: 'fee-uniform',
    key: 'uniform',
    name: 'Uniform, Sports Jersey & Accessories',
    amount: 1500,
    description: '2 sets school uniform, sports jersey and school badge',
    deletable: false,
    editable: true,
    categoryType: 'Uniform',
    frequency: 'Annual',
  },
];

// Fetch Fee Categories API
app.get('/api/fees/categories', (req, res) => {
  res.json({
    success: true,
    categories: feeCategoriesDb,
  });
});

// Update or Create Fee Category API
app.post('/api/fees/categories', (req, res) => {
  const { id, name, amount, description, categoryType, frequency } = req.body || {};

  if (!name || amount === undefined) {
    res.status(400).json({ success: false, message: 'Fee Name and Amount are required.' });
    return;
  }

  const existingIndex = feeCategoriesDb.findIndex((c) => c.id === id);
  if (existingIndex !== -1) {
    feeCategoriesDb[existingIndex] = {
      ...feeCategoriesDb[existingIndex],
      name: String(name).trim(),
      amount: Number(amount),
      description: String(description || '').trim(),
      categoryType: categoryType || feeCategoriesDb[existingIndex].categoryType,
      frequency: frequency || feeCategoriesDb[existingIndex].frequency,
    };
    res.json({
      success: true,
      message: `Successfully updated fee category "${name}"`,
      category: feeCategoriesDb[existingIndex],
      categories: feeCategoriesDb,
    });
  } else {
    const newId = id || `fee-custom-${Date.now()}`;
    const newCat = {
      id: newId,
      key: newId.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase(),
      name: String(name).trim(),
      amount: Number(amount),
      description: String(description || '').trim(),
      deletable: true,
      editable: true,
      categoryType: categoryType || 'Other',
      frequency: frequency || 'One-Time',
    };
    feeCategoriesDb.push(newCat);
    res.json({
      success: true,
      message: `Successfully created new fee category "${name}"`,
      category: newCat,
      categories: feeCategoriesDb,
    });
  }
});

// Delete Fee Category API
app.delete('/api/fees/categories/:id', (req, res) => {
  const { id } = req.params;
  const target = feeCategoriesDb.find((c) => c.id === id);

  if (!target) {
    res.status(404).json({ success: false, message: 'Fee category not found.' });
    return;
  }

  feeCategoriesDb = feeCategoriesDb.filter((c) => c.id !== id);
  res.json({
    success: true,
    message: `Successfully deleted fee category "${target.name}"`,
    categories: feeCategoriesDb,
  });
});

// Fetch Fee Reminders History API
app.get('/api/student/fee-reminders/:studentId', (req, res) => {
  const { studentId } = req.params;
  const history = feeRemindersDb.filter((r) => !studentId || r.studentId === studentId || studentId === 'all');
  res.json({
    success: true,
    history,
    upcomingSchedules: [
      {
        term: 'Term 2 Tuition & Activity Fee',
        grade: 'Class 3-A',
        dueDate: '15 August 2026',
        amount: 3500,
        status: 'UPCOMING_DUE',
        autoReminderSchedule: ['7 Days Prior (08-Aug-2026)', '3 Days Prior (12-Aug-2026)', 'On Due Date (15-Aug-2026)'],
      },
      {
        term: 'School Van Transport Fee (Term 2)',
        grade: 'Route 2 - Essur/Cheyyur',
        dueDate: '10 August 2026',
        amount: 1200,
        status: 'UPCOMING_DUE',
        autoReminderSchedule: ['5 Days Prior (05-Aug-2026)', 'On Due Date (10-Aug-2026)'],
      },
    ],
  });
});

// Update Admission Status API (Admin)
app.post('/api/admin/admission/status', (req, res) => {
  const { id, status } = req.body;
  const target = admissionsDb.find((a) => a.id === id);
  if (target) {
    target.status = status;
    res.json({ success: true, message: `Admission ${id} status updated to "${status}"`, application: target });
  } else {
    res.status(404).json({ success: false, message: 'Admission application not found' });
  }
});

// Admissions Submission API
app.post('/api/admissions', (req, res) => {
  const { studentName, dob, gender, grade, fatherName, motherName, phone, email, address, previousSchool } = req.body;

  if (!studentName || !grade || !phone || !fatherName) {
    res.status(400).json({ success: false, message: 'Please complete all required fields (Student Name, Grade, Father Name, Mobile Number).' });
    return;
  }

  const newApp: AdmissionApplication = {
    id: `ADM-ESSUR-2026-${Math.floor(100 + Math.random() * 900)}`,
    studentName,
    dob: dob || 'N/A',
    gender: gender || 'Unspecified',
    grade,
    fatherName,
    motherName: motherName || 'N/A',
    phone,
    email: email || 'N/A',
    address: address || 'Essur - 603301',
    previousSchool: previousSchool || 'None',
    submittedAt: new Date().toISOString(),
    status: 'Pending Review',
  };

  admissionsDb.unshift(newApp);

  res.json({
    success: true,
    message: 'Admission Application Submitted Successfully!',
    application: newApp,
  });
});

// Get List of Admissions (for demo tracking)
app.get('/api/admissions', (req, res) => {
  res.json({ success: true, count: admissionsDb.length, applications: admissionsDb });
});

// Submit Online Fee Payment & Generate Receipt API
app.post('/api/fees/pay', (req, res) => {
  const { studentName, studentId, grade, term, amount, paymentMethod, transactionRef } = req.body;

  if (!studentName || !amount) {
    res.status(400).json({ success: false, message: 'Student Name and Fee Amount are required.' });
    return;
  }

  const newReceipt: FeeReceipt = {
    receiptNo: `WNS-RCP-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    studentName,
    studentId: studentId || 'WNS-GUEST',
    grade: grade || 'General',
    term: term || 'Tuition Fee',
    amount: Number(amount),
    paymentMethod: paymentMethod || 'UPI Transfer',
    transactionRef: transactionRef || `UPI-${Date.now().toString().slice(-8)}`,
    date: new Date().toLocaleDateString('en-IN'),
    status: 'VERIFIED',
  };

  receiptsDb.unshift(newReceipt);

  res.json({
    success: true,
    message: 'Fee Payment Registered & Official Receipt Generated!',
    receipt: newReceipt,
  });
});

// Get Receipts
app.get('/api/fees/receipts', (req, res) => {
  res.json({ success: true, receipts: receiptsDb });
});

// AI Chatbot endpoint for parents/students
app.post('/api/ai/chat', async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) {
      res.status(400).json({ success: false, error: 'Message text is required' });
      return;
    }

    const aiClient = getGeminiClient();
    if (!aiClient) {
      // Fallback friendly reply if API key is not configured yet
      res.json({
        success: true,
        reply: `Welcome to Wisdom Nursery and Primary School, Essur! 🏫\n\nAdministrator: R. Saravanan\nPhone/WhatsApp: +91 9176593129\nEmail: wisdomrs.tamil@gmail.com\n\nFor admissions, fees payment via GPay (UPI: rsaravanan102002-1@okhdfcbank), or school visits, please call us directly or submit your inquiry online!`,
      });
      return;
    }

    const systemInstruction = `You are "Wisdom AI Assistant", the official AI virtual counselor for Wisdom Nursery and Primary School located in Essur - 603301, Tamil Nadu, India.
Key Information:
- School Name: Wisdom Nursery and Primary School
- Location: Essur - 603301, Kanchipuram / Chengalpattu District, Tamil Nadu.
- Motto: "LEARN TODAY, LEAD TOMORROW."
- School Administrator: R. SARAVANAN
- Contact Mobile / WhatsApp: +91 9176593129
- Contact Email: wisdomrs.tamil@gmail.com
- Official UPI ID for Fee Payment: rsaravanan102002-1@okhdfcbank (Account Holder: R Saravanan)
- Classes Offered: Pre-Nursery, LKG, UKG, Standard 1, Standard 2, Standard 3, Standard 4, Standard 5.
- Curriculum: Tamil Nadu State Samacheer Kalvi (State Board) with strong English medium immersion, Tamil language foundation, Vedic Math, Science experiments, Computer skills, and Value education.
- School Facilities: Well-lit airy classrooms, digital smart learning aids, playground & sports equipment, clean drinking water, activity room, computer lab, safe transport guidance, and regular health checkups.
- Timings: Monday to Friday (8:30 AM to 3:30 PM), Saturday (8:30 AM to 12:30 PM for Primary).
- Admission Process: Simple online registration or school office visit, birth certificate copy, passport size photos, and Aadhaar card copy.
- Response Style: Extremely warm, respectful, polite, encouraging, and informative. Answer in clear English (or Tamil if the user queries in Tamil).`;

    const contents: any[] = [];
    if (history && Array.isArray(history)) {
      for (const msg of history) {
        contents.push({
          role: msg.role === 'assistant' ? 'model' : 'user',
          parts: [{ text: msg.text }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.7,
      },
    });

    const replyText = response.text || 'Thank you for contacting Wisdom Nursery and Primary School, Essur! How else can I assist you?';

    res.json({
      success: true,
      reply: replyText,
    });
  } catch (err: any) {
    console.error('Gemini API Error:', err);
    res.status(500).json({
      success: false,
      error: 'Unable to connect to AI Assistant right now.',
      fallbackReply: 'Wisdom Nursery and Primary School, Essur - 603301. Contact Admin R. Saravanan at +91 9176593129 for quick assistance.',
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Wisdom School Server listening on http://localhost:${PORT}`);
  });
}

startServer();
